import type { WebSocket } from 'ws';
import { FLOWS, STYLES } from '../src/data/styles.ts';
import {
  applySimPlayerInput,
  buildSimActors,
  buildSimWorldSnapshot,
  createSimRoom,
  handleSimDiscreteAction,
  serializeSimLobby,
  type SimBroadcastSink,
  type SimRoomState,
  startSimMatch,
  stepSimRoom,
} from '../src/network/roomSimulation.ts';
import type { FlowId, GkDifficulty, MatchMode, StyleId } from '../src/types/game.ts';

interface WsRoom extends SimRoomState {
  sockets: Map<string, WebSocket>;
}

const rooms = new Map<string, WsRoom>();
const clientToRoom = new Map<string, string>();

function genRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? genRoomCode() : code;
}

function sendJson(ws: WebSocket | undefined, type: string, payload: unknown) {
  if (!ws || ws.readyState !== 1) return;
  ws.send(JSON.stringify({ type, payload }));
}

function broadcastRoom(room: WsRoom, type: string, payload: unknown) {
  const msg = JSON.stringify({ type, payload });
  for (const ws of room.sockets.values()) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

function makeSink(room: WsRoom): SimBroadcastSink {
  return {
    broadcastLobby: (lobby) => broadcastRoom(room, 'room:state', lobby),
    broadcastCutscene: (evt) => broadcastRoom(room, 'match:cutscene', evt),
    broadcastSound: (sound, power, pitch) =>
      broadcastRoom(room, 'match:sound', { sound, power, pitch }),
  };
}

export function listPublicRooms() {
  const list: Array<{ roomCode: string; playerCount: number; gkDifficulty: GkDifficulty; matchMode: MatchMode; status: string }> = [];
  for (const room of rooms.values()) {
    list.push({
      roomCode: room.roomCode,
      playerCount: room.players.size,
      gkDifficulty: room.gkDifficulty,
      matchMode: room.matchMode,
      status: room.status,
    });
  }
  return list;
}

let loopStarted = false;
function ensureSimulationLoop() {
  if (loopStarted) return;
  loopStarted = true;
  let lastTime = Date.now();
  setInterval(() => {
    const now = Date.now();
    const dt = Math.min(0.05, (now - lastTime) / 1000);
    lastTime = now;

    for (const room of rooms.values()) {
      if (room.status === 'PLAYING') {
        stepSimRoom(room, dt, makeSink(room));
        room.tickAccum += dt;
        if (room.tickAccum >= 0.04) {
          room.tickAccum = 0;
          for (const [cid, ws] of room.sockets.entries()) {
            sendJson(ws, 'world:state', buildSimWorldSnapshot(room, cid));
          }
        }
      }
    }
  }, 33);
}

export function handleWsConnection(ws: WebSocket) {
  ensureSimulationLoop();
  const clientId = Math.random().toString(36).slice(2, 10);
  sendJson(ws, 'ws:welcome', { clientId });

  const leaveCurrentRoom = () => {
    const oldCode = clientToRoom.get(clientId);
    if (!oldCode) return;
    clientToRoom.delete(clientId);
    const room = rooms.get(oldCode);
    if (!room) return;
    room.players.delete(clientId);
    room.sockets.delete(clientId);
    if (room.players.size === 0) {
      rooms.delete(oldCode);
      return;
    }
    if (room.hostId === clientId) {
      const nextHost = room.players.values().next().value;
      if (nextHost) {
        room.hostId = nextHost.clientId;
        nextHost.isHost = true;
      }
    }
    broadcastRoom(room, 'room:state', serializeSimLobby(room));
  };

  ws.on('message', (raw) => {
    let msg: { type?: string; payload?: Record<string, unknown> };
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    const type = msg.type;
    const p = msg.payload ?? {};

    if (type === 'ws:ping') {
      return;
    }

    if (type === 'room:create') {
      leaveCurrentRoom();
      const code = genRoomCode();
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Egoist';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'musab') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const gkDifficulty = (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'HARD' ? p.gkDifficulty : 'MEDIUM') as GkDifficulty;
      const matchMode: MatchMode = p.matchMode === '1V1' ? '1V1' : '3V3';

      const base = createSimRoom(code, clientId, gkDifficulty, matchMode);
      const room: WsRoom = {
        ...base,
        sockets: new Map(),
      };
      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: 'BLUE',
        styleId,
        flowId,
        isHost: true,
        ready: true,
      });
      room.sockets.set(clientId, ws);
      rooms.set(code, room);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
    } else if (type === 'room:join') {
      const code = typeof p.roomCode === 'string' ? p.roomCode.trim().toUpperCase() : '';
      const room = rooms.get(code);
      if (!room) {
        sendJson(ws, 'room:error', { message: `"${code}" kodlu sunucu odası bulunamadı. Share linkindeyseniz P2P modunu deneyin!` });
        return;
      }
      if (room.players.size >= 6) {
        sendJson(ws, 'room:error', { message: 'Oda dolu (Maksimum 6 oyuncu).' });
        return;
      }
      leaveCurrentRoom();
      const blueCount = Array.from(room.players.values()).filter((pl) => pl.team === 'BLUE').length;
      const redCount = Array.from(room.players.values()).filter((pl) => pl.team === 'RED').length;
      const autoTeam: 'BLUE' | 'RED' = redCount < blueCount ? 'RED' : 'BLUE';
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Oyuncu';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'iskender') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;

      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: autoTeam,
        styleId,
        flowId,
        isHost: false,
        ready: true,
      });
      room.sockets.set(clientId, ws);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
      if (room.status === 'PLAYING') {
        room.actors = buildSimActors(room);
        sendJson(ws, 'world:state', buildSimWorldSnapshot(room, clientId));
      }
    } else if (type === 'room:leave') {
      leaveCurrentRoom();
    } else if (type === 'room:update_player') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const info = room?.players.get(clientId);
      if (!room || !info) return;
      if (typeof p.styleId === 'string' && p.styleId in STYLES) info.styleId = p.styleId as StyleId;
      if (typeof p.flowId === 'string' && p.flowId in FLOWS) info.flowId = p.flowId as FlowId;
      if (p.team === 'BLUE' || p.team === 'RED') info.team = p.team;
      if (typeof p.name === 'string' && p.name.trim()) info.name = p.name.trim().slice(0, 14);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
    } else if (type === 'room:set_gk') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'MEDIUM' || p.gkDifficulty === 'HARD') {
        room.gkDifficulty = p.gkDifficulty;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:set_mode') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.matchMode === '1V1' || p.matchMode === '3V3') {
        room.matchMode = p.matchMode;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:start') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      startSimMatch(room, makeSink(room));
    } else if (type === 'player:input') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room) return;
      applySimPlayerInput(
        room,
        clientId,
        Number(p.moveX),
        Number(p.moveZ),
        Boolean(p.sprint),
        Boolean(p.chargingShot),
        typeof p.aimYaw === 'number' ? p.aimYaw : undefined,
        Boolean(p.lockYaw)
      );
    } else if (type === 'player:action') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || typeof p.action !== 'string') return;
      handleSimDiscreteAction(room, clientId, p.action, makeSink(room));
    }
  });

  ws.on('close', () => {
    leaveCurrentRoom();
  });
}
