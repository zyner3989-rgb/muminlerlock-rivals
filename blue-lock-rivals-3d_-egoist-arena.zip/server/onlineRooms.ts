import type { WebSocket } from 'ws';
import { FLOWS, STYLES } from '../src/data/styles.ts';
import {
  applySimPlayerInput,
  buildSimActors,
  buildSimWorldSnapshot,
  createSimRoom,
  handleSimDiscreteAction,
  serializeSimLobby,
  type SimBroadcastSink,
  type SimRoomState,
  startSimMatch,
  stepSimRoom,
} from '../src/network/roomSimulation.ts';
import { ROLES } from '../src/data/roles.ts';
import type { FlowId, GkDifficulty, MatchMode, PlayerRole, QueueType, StyleId } from '../src/types/game.ts';

function parseRole(raw: unknown): PlayerRole {
  return typeof raw === 'string' && raw in ROLES ? (raw as PlayerRole) : 'CF';
}

interface WsRoom extends SimRoomState {
  sockets: Map<string, WebSocket>;
}

interface QueueEntry {
  clientId: string;
  ws: WebSocket;
  name: string;
  styleId: StyleId;
  flowId: FlowId;
  role: PlayerRole;
  matchMode: MatchMode;
  queueType: QueueType;
  rp: number;
  joinedAt: number;
}

const rooms = new Map<string, WsRoom>();
const clientToRoom = new Map<string, string>();
const matchmakingQueue = new Map<string, QueueEntry>();

function genRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? genRoomCode() : code;
}

function sendJson(ws: WebSocket | undefined, type: string, payload: unknown) {
  if (!ws || ws.readyState !== 1) return;
  ws.send(JSON.stringify({ type, payload }));
}

function broadcastRoom(room: WsRoom, type: string, payload: unknown) {
  const msg = JSON.stringify({ type, payload });
  for (const ws of room.sockets.values()) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

function makeSink(room: WsRoom): SimBroadcastSink {
  return {
    broadcastLobby: (lobby) => broadcastRoom(room, 'room:state', lobby),
    broadcastCutscene: (evt) => broadcastRoom(room, 'match:cutscene', evt),
    broadcastSound: (sound, power, pitch) =>
      broadcastRoom(room, 'match:sound', { sound, power, pitch }),
  };
}

export function listPublicRooms() {
  const list: Array<{
    roomCode: string;
    playerCount: number;
    gkDifficulty: GkDifficulty;
    matchMode: MatchMode;
    queueType: QueueType;
    status: string;
  }> = [];
  for (const room of rooms.values()) {
    list.push({
      roomCode: room.roomCode,
      playerCount: room.players.size,
      gkDifficulty: room.gkDifficulty,
      matchMode: room.matchMode,
      queueType: room.queueType,
      status: room.status,
    });
  }
  return list;
}

function launchMatchedRoom(entries: QueueEntry[], matchMode: MatchMode, queueType: QueueType) {
  if (entries.length === 0) return;
  const code = genRoomCode();
  const host = entries[0];
  const gkDifficulty: GkDifficulty = queueType === 'RANKED' ? 'HARD' : 'MEDIUM';
  const base = createSimRoom(code, host.clientId, gkDifficulty, matchMode, queueType);
  const room: WsRoom = {
    ...base,
    sockets: new Map(),
  };

  const maxPerTeam = matchMode === '1V1' ? 1 : 3;
  let blueCount = 0;
  let redCount = 0;

  entries.forEach((entry, idx) => {
    matchmakingQueue.delete(entry.clientId);
    const oldCode = clientToRoom.get(entry.clientId);
    if (oldCode && oldCode !== code) {
      const oldRoom = rooms.get(oldCode);
      if (oldRoom) {
        oldRoom.players.delete(entry.clientId);
        oldRoom.sockets.delete(entry.clientId);
      }
    }

    let team: 'BLUE' | 'RED' = idx % 2 === 0 ? 'BLUE' : 'RED';
    if (team === 'BLUE' && blueCount >= maxPerTeam) team = 'RED';
    if (team === 'RED' && redCount >= maxPerTeam) team = 'BLUE';
    if (team === 'BLUE') blueCount++;
    else redCount++;

    room.players.set(entry.clientId, {
      clientId: entry.clientId,
      name: entry.name,
      team,
      styleId: entry.styleId,
      flowId: entry.flowId,
      role: entry.role,
      isHost: entry.clientId === host.clientId,
      ready: true,
      rp: entry.rp,
    });
    room.sockets.set(entry.clientId, entry.ws);
    clientToRoom.set(entry.clientId, code);
  });

  rooms.set(code, room);
  const lobby = serializeSimLobby(room);
  for (const entry of entries) {
    sendJson(entry.ws, 'matchmaking:matched', lobby);
  }
  startSimMatch(room, makeSink(room));
  for (const [cid, ws] of room.sockets.entries()) {
    sendJson(ws, 'world:state', buildSimWorldSnapshot(room, cid));
  }
}

function processMatchmaking(nowMs: number) {
  if (matchmakingQueue.size === 0) return;

  // Group queued players by queueType + matchMode
  const buckets = new Map<string, QueueEntry[]>();
  for (const [cid, entry] of matchmakingQueue.entries()) {
    if (entry.ws.readyState !== 1) {
      matchmakingQueue.delete(cid);
      continue;
    }
    const key = `${entry.queueType}:${entry.matchMode}`;
    const list = buckets.get(key) ?? [];
    list.push(entry);
    buckets.set(key, list);
  }

  for (const list of buckets.values()) {
    list.sort((a, b) => a.joinedAt - b.joinedAt);
    const maxHumans = list[0].matchMode === '1V1' ? 2 : 6;

    // Pair human players immediately if >= 2 waiting
    while (list.length >= 2) {
      const batch = list.splice(0, Math.min(maxHumans, list.length));
      launchMatchedRoom(batch, batch[0].matchMode, batch[0].queueType);
    }

    // Single remaining player: notify queue status; auto-backfill with AI after 6.5s wait
    for (const solo of list) {
      const elapsedSec = Math.floor((nowMs - solo.joinedAt) / 1000);
      if (nowMs - solo.joinedAt >= 6500) {
        launchMatchedRoom([solo], solo.matchMode, solo.queueType);
      } else {
        sendJson(solo.ws, 'matchmaking:status', {
          searching: true,
          queueType: solo.queueType,
          matchMode: solo.matchMode,
          elapsedSec,
          playersInQueue: matchmakingQueue.size,
        });
      }
    }
  }
}

let loopStarted = false;
function ensureSimulationLoop() {
  if (loopStarted) return;
  loopStarted = true;
  let lastTime = Date.now();
  let queueAccum = 0;

  setInterval(() => {
    const now = Date.now();
    const dt = Math.min(0.05, Math.max(0.004, (now - lastTime) / 1000));
    lastTime = now;

    queueAccum += dt;
    if (queueAccum >= 0.75) {
      queueAccum = 0;
      processMatchmaking(now);
    }

    for (const room of rooms.values()) {
      if (room.status === 'PLAYING') {
        stepSimRoom(room, dt, makeSink(room));
        room.tickAccum += dt;
        if (room.tickAccum >= 0.024) {
          room.tickAccum = 0;
          room.worldSeq++;
          for (const [cid, ws] of room.sockets.entries()) {
            sendJson(ws, 'world:state', buildSimWorldSnapshot(room, cid));
          }
        }
      }
    }
  }, 16);
}

export function handleWsConnection(ws: WebSocket) {
  ensureSimulationLoop();
  // Disable Nagle algorithm for ultra-low input latency
  const rawSocket = (ws as unknown as { _socket?: { setNoDelay?: (b: boolean) => void } })._socket;
  rawSocket?.setNoDelay?.(true);

  const clientId = Math.random().toString(36).slice(2, 10);
  sendJson(ws, 'ws:welcome', { clientId });

  const leaveCurrentRoom = () => {
    matchmakingQueue.delete(clientId);
    const oldCode = clientToRoom.get(clientId);
    if (!oldCode) return;
    clientToRoom.delete(clientId);
    const room = rooms.get(oldCode);
    if (!room) return;
    room.players.delete(clientId);
    room.sockets.delete(clientId);
    if (room.players.size === 0) {
      rooms.delete(oldCode);
      return;
    }
    if (room.hostId === clientId) {
      const nextHost = room.players.values().next().value;
      if (nextHost) {
        room.hostId = nextHost.clientId;
        nextHost.isHost = true;
      }
    }
    broadcastRoom(room, 'room:state', serializeSimLobby(room));
  };

  ws.on('message', (raw) => {
    let msg: { type?: string; payload?: Record<string, unknown> };
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    const type = msg.type;
    const p = msg.payload ?? {};

    if (type === 'ws:ping') {
      sendJson(ws, 'ws:pong', { ts: typeof p.ts === 'number' ? p.ts : Date.now() });
      return;
    }

    if (type === 'matchmaking:join') {
      leaveCurrentRoom();
      const playerName =
        typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Egoist';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'musab') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const matchMode: MatchMode = p.matchMode === '1V1' ? '1V1' : '3V3';
      const queueType: QueueType = p.queueType === 'RANKED' ? 'RANKED' : 'CASUAL';
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : 1000;

      const entry: QueueEntry = {
        clientId,
        ws,
        name: playerName,
        styleId,
        flowId,
        role: parseRole(p.role),
        matchMode,
        queueType,
        rp,
        joinedAt: Date.now(),
      };
      matchmakingQueue.set(clientId, entry);
      sendJson(ws, 'matchmaking:status', {
        searching: true,
        queueType,
        matchMode,
        elapsedSec: 0,
        playersInQueue: matchmakingQueue.size,
      });
      processMatchmaking(Date.now());
      return;
    }

    if (type === 'matchmaking:cancel') {
      const removed = matchmakingQueue.delete(clientId);
      if (removed) {
        sendJson(ws, 'matchmaking:status', {
          searching: false,
          queueType: 'CASUAL',
          matchMode: '3V3',
          elapsedSec: 0,
          playersInQueue: matchmakingQueue.size,
        });
      }
      return;
    }

    if (type === 'matchmaking:force_start') {
      const entry = matchmakingQueue.get(clientId);
      if (entry) {
        launchMatchedRoom([entry], entry.matchMode, entry.queueType);
      }
      return;
    }

    if (type === 'room:create') {
      leaveCurrentRoom();
      const code = genRoomCode();
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Egoist';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'musab') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const gkDifficulty = (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'HARD' ? p.gkDifficulty : 'MEDIUM') as GkDifficulty;
      const matchMode: MatchMode = p.matchMode === '1V1' ? '1V1' : '3V3';
      const queueType: QueueType = p.queueType === 'RANKED' ? 'RANKED' : 'CASUAL';
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : undefined;

      const base = createSimRoom(code, clientId, gkDifficulty, matchMode, queueType);
      const room: WsRoom = {
        ...base,
        sockets: new Map(),
      };
      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: 'BLUE',
        styleId,
        flowId,
        role: parseRole(p.role),
        isHost: true,
        ready: true,
        rp,
      });
      room.sockets.set(clientId, ws);
      rooms.set(code, room);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
    } else if (type === 'room:join') {
      const code = typeof p.roomCode === 'string' ? p.roomCode.trim().toUpperCase() : '';
      const room = rooms.get(code);
      if (!room) {
        sendJson(ws, 'room:error', {
          message: `"${code}" kodlu sunucu odası bulunamadı. Share linkinden bağlanıyorsan P2P (Share Uyumlu) modunu seç!`,
        });
        return;
      }
      if (room.players.size >= 6) {
        sendJson(ws, 'room:error', { message: 'Oda dolu (Maksimum 6 oyuncu).' });
        return;
      }
      leaveCurrentRoom();
      const blueCount = Array.from(room.players.values()).filter((pl) => pl.team === 'BLUE').length;
      const redCount = Array.from(room.players.values()).filter((pl) => pl.team === 'RED').length;
      const autoTeam: 'BLUE' | 'RED' = redCount < blueCount ? 'RED' : 'BLUE';
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Oyuncu';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'iskender') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : undefined;

      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: autoTeam,
        styleId,
        flowId,
        role: parseRole(p.role),
        isHost: false,
        ready: true,
        rp,
      });
      room.sockets.set(clientId, ws);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
      if (room.status === 'PLAYING') {
        room.actors = buildSimActors(room);
        sendJson(ws, 'world:state', buildSimWorldSnapshot(room, clientId));
      }
    } else if (type === 'room:leave') {
      leaveCurrentRoom();
    } else if (type === 'room:update_player') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const info = room?.players.get(clientId);
      if (!room || !info) return;
      if (typeof p.styleId === 'string' && p.styleId in STYLES) info.styleId = p.styleId as StyleId;
      if (typeof p.flowId === 'string' && p.flowId in FLOWS) info.flowId = p.flowId as FlowId;
      if (p.team === 'BLUE' || p.team === 'RED') info.team = p.team;
      if (typeof p.role === 'string' && p.role in ROLES) info.role = p.role as PlayerRole;
      if (typeof p.name === 'string' && p.name.trim()) info.name = p.name.trim().slice(0, 14);
      if (typeof p.rp === 'number' && Number.isFinite(p.rp)) info.rp = Math.max(0, Math.round(p.rp));
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
    } else if (type === 'room:set_gk') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'MEDIUM' || p.gkDifficulty === 'HARD') {
        room.gkDifficulty = p.gkDifficulty;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:set_mode') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.matchMode === '1V1' || p.matchMode === '3V3') {
        room.matchMode = p.matchMode;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:start') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      startSimMatch(room, makeSink(room));
    } else if (type === 'player:input') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room) return;
      applySimPlayerInput(
        room,
        clientId,
        Number(p.moveX),
        Number(p.moveZ),
        Boolean(p.sprint),
        Boolean(p.chargingShot),
        typeof p.aimYaw === 'number' ? p.aimYaw : undefined,
        Boolean(p.lockYaw)
      );
    } else if (type === 'player:action') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || typeof p.action !== 'string') return;
      handleSimDiscreteAction(room, clientId, p.action, makeSink(room));
    }
  });

  ws.on('close', () => {
    leaveCurrentRoom();
  });
}
