import 'dotenv/config';
import fs from 'fs';
import http from 'http';
import path from 'path';
import express from 'express';
import { WebSocketServer } from 'ws';
import { handleWsConnection, listPublicRooms } from './server/onlineRooms.ts';

const PORT = Number(process.env.PORT) || 3000;

const app = express();
app.use(express.json({ limit: '1mb' }));

app.get('/api/rooms', (_req, res) => {
  res.json({ rooms: listPublicRooms() });
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

async function startServer() {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });
  wss.on('connection', (ws) => {
    handleWsConnection(ws);
  });

  // Keep WebSocket connections alive behind free-tier reverse proxies (Render, Cloudflare, etc.)
  const heartbeat = setInterval(() => {
    for (const client of wss.clients) {
      if (client.readyState === 1) {
        client.ping();
      }
    }
  }, 20000);
  wss.on('close', () => clearInterval(heartbeat));

  const distPath = path.resolve(process.cwd(), 'dist');
  const distIndex = path.join(distPath, 'index.html');
  const useStaticDist =
    fs.existsSync(distIndex) &&
    (process.env.NODE_ENV === 'production' || process.env.npm_lifecycle_event === 'start');

  if (useStaticDist) {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(distIndex);
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Blue Lock Rivals 3D (HTTP + WebSocket) running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
