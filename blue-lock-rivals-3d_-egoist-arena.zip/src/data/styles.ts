import type { FlowDefinition, FlowId, Rarity, StyleDefinition, StyleId } from '../types/game';

export const RARITY_ORDER: Record<Rarity, number> = {
  MASTER: 4,
  'WORLD CLASS': 3,
  MYTHIC: 2,
  RARE: 1,
};

export const RARITY_COLORS: Record<
  Rarity,
  { badgeBg: string; border: string; text: string; glow: string; labelTr: string }
> = {
  MASTER: {
    badgeBg: 'linear-gradient(135deg, #f59e0b 0%, #a855f7 50%, #ec4899 100%)',
    border: '#fbbf24',
    text: '#fde68a',
    glow: 'rgba(251, 191, 36, 0.45)',
    labelTr: 'MASTER (EN NADİR)',
  },
  'WORLD CLASS': {
    badgeBg: 'linear-gradient(135deg, #ef4444 0%, #f97316 100%)',
    border: '#fb7185',
    text: '#fecdd3',
    glow: 'rgba(239, 68, 68, 0.4)',
    labelTr: 'WORLD CLASS',
  },
  MYTHIC: {
    badgeBg: 'linear-gradient(135deg, #06b6d4 0%, #8b5cf6 100%)',
    border: '#38bdf8',
    text: '#bae6fd',
    glow: 'rgba(56, 189, 248, 0.35)',
    labelTr: 'MİTİK',
  },
  RARE: {
    badgeBg: 'linear-gradient(135deg, #2563eb 0%, #475569 100%)',
    border: '#60a5fa',
    text: '#bfdbfe',
    glow: 'rgba(96, 165, 250, 0.3)',
    labelTr: 'RARE (BAŞLANGIÇ)',
  },
};

export const STYLES: Record<StyleId, StyleDefinition> = {
  musab: {
    id: 'musab',
    name: 'MUSAB',
    jerseyNumber: 10,
    rarity: 'MASTER',
    title: 'Kulaklıklı Oyun Canavarı',
    primaryColor: '#1d4ed8', // Mavi-Sarı Forma
    secondaryColor: '#facc15',
    auraColor: '#facc15',
    hairColor: '#1f2937',
    skinColor: '#f3cfb6',
    accessory: 'headset',
    stats: { speed: 97, shotPower: 99, dribble: 96, steal: 91 },
    skill1: {
      key: '1',
      name: 'Gökkuşağı Makara',
      description: 'Topu havalandırıp rakibin üstünden aşırır ve sarı-mavi şimşek hızıyla geçer.',
      cooldown: 6,
    },
    skill2: {
      key: '2',
      name: 'Sarı-Mavi Yıldırım',
      description: 'Kaleye veya kanada yüksek falsolu yıldırım şutu / ara pası gönderir.',
      cooldown: 7,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Kulaklık Bass Şoku',
      description: 'Özel Yetenek: Kulaklıktan bas dalgası yayıp etrafındaki rakipleri savurur ve hız kazanır.',
      cooldown: 10,
    },
    awakeningName: 'Uyanıp Makarayız!',
    awakeningSummary: 'Musab uyanıp "Makarayız!" der, telefonla Musa\'yı arayıp "Ses gel!" diye bağırır.',
    awakeningQuote: 'Uyanıp makarayız! Alo Musa, SES GEL!',
    ultiName: 'Monitörden Çıkan Kâbus Vole',
    ultiSummary:
      'Monitörde Blue Lock oynarken top korku filmindeki canavar gibi ekrandan sahaya fırlar! Musab kulaklığını masaya bırakıp zıplayarak kaleden kaleye vole çakar.',
    ultiRange: 'FULL_PITCH',
    ultiRangeLabel: 'Kaleden Kaleye',
  },
  musa: {
    id: 'musa',
    name: 'MUSA',
    jerseyNumber: 11,
    rarity: 'MASTER',
    title: 'Öfkeli As Egoist',
    primaryColor: '#0f172a',
    secondaryColor: '#38bdf8',
    auraColor: '#38bdf8',
    hairColor: '#0f172a',
    skinColor: '#f2ccb0',
    accessory: 'spiky',
    stats: { speed: 98, shotPower: 98, dribble: 95, steal: 92 },
    skill1: {
      key: '1',
      name: 'Buzul Çalım',
      description: 'Aniden hızlanıp rakibin markajını buz gibi kırar.',
      cooldown: 6,
    },
    skill2: {
      key: '2',
      name: 'Ters Köşe Füze',
      description: 'Kalecinin uzanamayacağı köşeye sert şut çıkarır.',
      cooldown: 8,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Öfke Presi',
      description: 'Özel Yetenek: Top rakipteyken üstüne atılıp topu söker ve anında sprint patlatır.',
      cooldown: 10,
    },
    awakeningName: 'Musab Aramasına Sövüş',
    awakeningSummary: 'Maçın ortasında Musab arar; Musa telefonu açıp öfkeyle söver ve egoist aurasını patlatır!',
    awakeningQuote: 'ALO MUSAB MAÇIN ORTASINDA NE ARIYON LAN #@$%!!',
    ultiName: 'Yastıktan Füzeye Dönüşüm',
    ultiSummary:
      'Musa yerdeki yastığa tüm gücüyle vurur; yastık anında alevli futbol topuna dönüşüp kaleden kaleye sonik hızda fırlar!',
    ultiRange: 'FULL_PITCH',
    ultiRangeLabel: 'Kaleden Kaleye',
  },
  iskender: {
    id: 'iskender',
    name: 'İSKENDER',
    jerseyNumber: 7,
    rarity: 'MASTER',
    title: 'Çoraplı Boyut Bükücü',
    primaryColor: '#eab308', // Sarı Forma
    secondaryColor: '#0f172a',
    auraColor: '#fde047',
    hairColor: '#292524',
    skinColor: '#eec6a8',
    accessory: 'shades',
    stats: { speed: 95, shotPower: 96, dribble: 99, steal: 91 },
    skill1: {
      key: '1',
      name: 'Çorap Şoku',
      description: 'Yakındaki rakipleri şaşkına çevirip yavaşlatır ve topu korur.',
      cooldown: 7,
    },
    skill2: {
      key: '2',
      name: 'Gökkuşağı Sıçrayış',
      description: 'Topu havalandırıp rakibin üzerinden akrobatik şekilde aşırır.',
      cooldown: 7,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Sarı Flaş Çorap',
      description: 'Özel Yetenek: Kısa süreli boyut kırılmasıyla ileri sıçrayıp markajı sıfırlar.',
      cooldown: 9,
    },
    awakeningName: 'Görüntülü Çorap Şovu',
    awakeningSummary:
      'Musa ile görüntülü konuşurken telefonu bir anda yere koyup kameraya parlayan çorabını gösterir!',
    awakeningQuote: 'Musa iyi izle, ÇORABIMA BAK LAN!',
    ultiName: 'Boyut Yaran Işınlanma Rovaşata',
    ultiSummary:
      'Musa ile görüntülü konuşurken boşluğa rovaşata atar; tam kalktığı anda sahaya ışınlanır ve ayağında beliren topu kaleden kaleye gömer!',
    ultiRange: 'FULL_PITCH',
    ultiRangeLabel: 'Kaleden Kaleye',
  },
  aras: {
    id: 'aras',
    name: 'ARAS',
    jerseyNumber: 9,
    rarity: 'WORLD CLASS',
    title: 'Hamburgerle Uyanan Yıkıcı',
    primaryColor: '#7f1d1d',
    secondaryColor: '#f97316',
    auraColor: '#ef4444',
    hairColor: '#1c1917',
    skinColor: '#f1c7aa',
    accessory: 'headband',
    stats: { speed: 92, shotPower: 96, dribble: 89, steal: 88 },
    skill1: {
      key: '1',
      name: 'Yenilgi Öfkesi',
      description: 'Öfkeyle patlayıp yakındaki rakipleri iter ve hız kazanır.',
      cooldown: 7,
    },
    skill2: {
      key: '2',
      name: 'Alev Şutu',
      description: 'Yere paralel yüksek hızlı ateşli şut gönderir.',
      cooldown: 8,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Hamburger Enerjisi',
      description: 'Özel Yetenek: Dayanıklılığı anında +50 yeniler ve kısa süreli süper hız açar.',
      cooldown: 11,
    },
    awakeningName: 'İskender\'e Yenilip Çıldırış',
    awakeningSummary: 'İskender\'le Blue Lock oynarken 5-0 yenilip sinirden köpürür!',
    awakeningQuote: 'İSKENDER KESİN HİLE YAPIYO! YETER LAN!',
    ultiName: 'Hamburger Işınlanma Füzesi',
    ultiSummary:
      'Antrenmanda otururken antrenör yere dev bir hamburger atar; Aras topun ve hamburgerin yanına ışınlanıp kaleden kaleye sert vuruş çakar!',
    ultiRange: 'FULL_PITCH',
    ultiRangeLabel: 'Kaleden Kaleye',
  },
  ebulfez: {
    id: 'ebulfez',
    name: 'EBULFEZ',
    jerseyNumber: 99,
    rarity: 'WORLD CLASS',
    title: 'Sonsuzluk Eldivenli Hayalet',
    primaryColor: '#4c1d95',
    secondaryColor: '#facc15',
    auraColor: '#e879f9',
    hairColor: '#171717',
    skinColor: '#ecc3a5',
    accessory: 'gauntlet',
    stats: { speed: 93, shotPower: 93, dribble: 91, steal: 97 },
    skill1: {
      key: '1',
      name: 'Kozmik Adım',
      description: 'Kısa mesafede ışınlanıp rakibin savunmasını deler.',
      cooldown: 7,
    },
    skill2: {
      key: '2',
      name: 'Eldiven Çekişi',
      description: 'Topu rakipten manyetik güçle çeker alır.',
      cooldown: 8,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Taşların Çekimi',
      description: 'Özel Yetenek: Geniş alandaki serbest veya rakipteki topu eldivenle ayağına çeker.',
      cooldown: 11,
    },
    awakeningName: 'Thanos Şıklatması',
    awakeningSummary:
      '"Bir daha görüşmemek dileğiyle..." diyerek parmak şıklatır ve toz olup ortadan kaybolur!',
    awakeningQuote: 'Bir daha görüşmemek dileğiyle... *ŞIK!*',
    ultiName: 'Geri Geldim! Sıçrayan Çalma Vuruşu',
    ultiSummary:
      'Yeniden parmak şıklatıp "Geri geldim!" diyerek belirir, rakibin topunu çalıp üstünden zıplayarak sert vuruş yapar!',
    ultiRange: 'FULL_PITCH',
    ultiRangeLabel: 'Uzun Menzil',
  },
  zero: {
    id: 'zero',
    name: 'ZERO',
    jerseyNumber: 0,
    rarity: 'MYTHIC',
    title: 'Yapay Zeka Hile Mühendisi',
    primaryColor: '#164e63',
    secondaryColor: '#22d3ee',
    auraColor: '#06b6d4',
    hairColor: '#0f172a',
    skinColor: '#f3d1b8',
    accessory: 'visor',
    stats: { speed: 88, shotPower: 86, dribble: 92, steal: 85 },
    skill1: {
      key: '1',
      name: 'Glitch Çalım',
      description: 'Hologram izi bırakarak hızlı yön değiştirir.',
      cooldown: 6,
    },
    skill2: {
      key: '2',
      name: 'Oto-Falso',
      description: 'Topa dijital kavis vererek orta mesafeden şut çeker.',
      cooldown: 8,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Algoritma Taraması',
      description: 'Özel Yetenek: Topu ayağına sabitler, rakipleri 1 sn yavaşlatır ve pas/şut açısı açar.',
      cooldown: 10,
    },
    awakeningName: 'Yapay Zeka Hile Kodlama',
    awakeningSummary: 'Bilgisayarda Yapay Zekaya hile kodlatıp sevinçten havaya uçar!',
    awakeningQuote: 'YAPAY ZEKA HİLEYİ KODLADI! GG EASY!',
    ultiName: 'AI Hileli Falsolu Vuruş',
    ultiSummary:
      'Yapay Zekanın yazdığı hileyle topu havada otomatik kontrol ettirip orta sahadan abartılı falsolu bir vuruş atar!',
    ultiRange: 'MIDFIELD',
    ultiRangeLabel: 'Orta Saha',
  },
  berk: {
    id: 'berk',
    name: 'BERK',
    jerseyNumber: 42,
    rarity: 'RARE',
    title: 'Yatak Krallığının Savunmacısı',
    primaryColor: '#1e3a8a',
    secondaryColor: '#93c5fd',
    auraColor: '#60a5fa',
    hairColor: '#3f3f46',
    skinColor: '#f5d0b5',
    accessory: 'relaxed',
    stats: { speed: 78, shotPower: 82, dribble: 76, steal: 86 },
    skill1: {
      key: '1',
      name: 'Ağır Gövde Bloku',
      description: 'Geniş omuz darbesiyle rakibi sarsıp topu keser.',
      cooldown: 6,
    },
    skill2: {
      key: '2',
      name: 'Uyku Sersemi Şut',
      description: 'Orta mesafeden tok ve ağır bir şut vurur.',
      cooldown: 8,
    },
    personalSkill: {
      key: 'E / 3',
      name: 'Yastık Duvarı',
      description: 'Özel Yetenek: 3 saniye boyunca rakiplerin çarptığı yerde sendelediği kaya savunması açar.',
      cooldown: 10,
    },
    awakeningName: 'Obez Yatak Keyfi',
    awakeningSummary: 'Sahanın ortasında yatak açıp cipsle birlikte rahatça uzanır!',
    awakeningQuote: 'Of ya... Bi 5 dakika daha yatayım...',
    ultiName: 'Orta Saha Kapma Şutu',
    ultiSummary:
      'Orta sahadan karşısındakinden gövde gücüyle topu çalıp kaleye doğru sert bir şut çıkarır!',
    ultiRange: 'MIDFIELD',
    ultiRangeLabel: 'Orta Saha',
  },
};

export const STYLE_LIST: StyleDefinition[] = [
  STYLES.musab,
  STYLES.musa,
  STYLES.iskender,
  STYLES.aras,
  STYLES.ebulfez,
  STYLES.zero,
  STYLES.berk,
];

export const FLOWS: Record<FlowId, FlowDefinition> = {
  egoist: {
    id: 'egoist',
    name: 'Egoist Aura',
    rarity: 'MASTER',
    color: '#38bdf8',
    bonusText: '+%18 Şut Gücü · +%12 Hız',
    speedMult: 1.12,
    shotMult: 1.18,
    staminaRegenMult: 1.25,
  },
  godspeed: {
    id: 'godspeed',
    name: 'Tanrı Hızı',
    rarity: 'WORLD CLASS',
    color: '#fbbf24',
    bonusText: '+%20 Hız · +%35 Dayanıklılık Yenileme',
    speedMult: 1.2,
    shotMult: 1.08,
    staminaRegenMult: 1.35,
  },
  prodigy: {
    id: 'prodigy',
    name: 'Dahi Görüşü',
    rarity: 'MYTHIC',
    color: '#a855f7',
    bonusText: '+%15 Şut · +%15 Hız',
    speedMult: 1.15,
    shotMult: 1.15,
    staminaRegenMult: 1.2,
  },
  wildcard: {
    id: 'wildcard',
    name: 'Joker',
    rarity: 'WORLD CLASS',
    color: '#ef4444',
    bonusText: '+%22 Şut Gücü · +%10 Hız',
    speedMult: 1.1,
    shotMult: 1.22,
    staminaRegenMult: 1.15,
  },
  dribbler: {
    id: 'dribbler',
    name: 'Canavar Dripling',
    rarity: 'RARE',
    color: '#34d399',
    bonusText: '+%14 Hız · +%25 Dayanıklılık Yenileme',
    speedMult: 1.14,
    shotMult: 1.05,
    staminaRegenMult: 1.25,
  },
};

export function rollStyleGacha(lucky: boolean): StyleDefinition {
  const r = Math.random() * 100;
  const masterCut = lucky ? 16 : 4;
  const wcCut = lucky ? 46 : 15;
  const mythicCut = lucky ? 80 : 40;

  let targetRarity: Rarity = 'RARE';
  if (r < masterCut) targetRarity = 'MASTER';
  else if (r < wcCut) targetRarity = 'WORLD CLASS';
  else if (r < mythicCut) targetRarity = 'MYTHIC';

  const pool = STYLE_LIST.filter((s) => s.rarity === targetRarity);
  return pool[Math.floor(Math.random() * pool.length)];
}

export function rollFlowGacha(): FlowDefinition {
  const list = Object.values(FLOWS);
  return list[Math.floor(Math.random() * list.length)];
}
