import type { EmoteId, StyleId } from '../types/game';

export interface VoiceClipSpec {
  key: string;
  text: string;
  voiceName: 'Puck' | 'Charon' | 'Fenrir';
  stylePrompt: string;
  pitchFallback: number;
  rateFallback: number;
}

export const TURKISH_VOICE_SCRIPTS: Record<string, VoiceClipSpec> = {
  musab_awakening: {
    key: 'musab_awakening',
    text: 'Uyanıp makarayız! Alo Musa, ses gel! Şimdi sahayı yakma vakti!',
    voiceName: 'Puck',
    stylePrompt:
      'Enerjik, kendinden emin ve coşkulu genç Türk anime erkek futbolcu (shonen egoist striker), yüksek motivasyonlu ve karizmatik ton.',
    pitchFallback: 1.05,
    rateFallback: 1.12,
  },
  musab_ulti: {
    key: 'musab_ulti',
    text: 'Kulaklığı masaya bırakıyorum... Monitörden çıkan kâbus vole! Kaleden kaleye!',
    voiceName: 'Puck',
    stylePrompt:
      'Dramatik ve patlayıcı Türk anime erkek ana karakteri, önce gergin fısıltı ardından tüm gücüyle şonen ulti haykırışı.',
    pitchFallback: 1.02,
    rateFallback: 1.1,
  },
  musa_awakening: {
    key: 'musa_awakening',
    text: 'Alo Musab! Maçın ortasında ne arıyorsun lan! Egoist alevimi uyandırdın, şimdi bittiniz!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Öfkeli, hırslı, derin ve gür sesli Türk anime erkek forvet, agresif shonen rakip tonlaması.',
    pitchFallback: 0.92,
    rateFallback: 1.16,
  },
  musa_ulti: {
    key: 'musa_ulti',
    text: 'Yastık füzeye dönüşüyor! Sonik hızla kaleden kaleye ateşle!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Çok güçlü, tutkulu ve sert Türk anime erkek savaşçı/futbolcu haykırışı, aksiyon sahnesi enerjisi.',
    pitchFallback: 0.9,
    rateFallback: 1.14,
  },
  iskender_awakening: {
    key: 'iskender_awakening',
    text: 'Musa iyi izle... Parlayan çorabıma bak! Boyut bükme zamanı!',
    voiceName: 'Puck',
    stylePrompt:
      'Kibirli, özgüveni tavan, alaycı ama çok havalı genç Türk anime erkek dahi futbolcu.',
    pitchFallback: 1.1,
    rateFallback: 1.08,
  },
  iskender_ulti: {
    key: 'iskender_ulti',
    text: 'Boşluğa rovaşata... Sahaya ışınlandım! Boyut yaran vuruş!',
    voiceName: 'Puck',
    stylePrompt:
      'Keskin, şovmen ve heyecan verici Türk anime erkek futbolcu, ani ışınlanma sonrası patlayıcı bitirici bağırış.',
    pitchFallback: 1.08,
    rateFallback: 1.12,
  },
  aras_awakening: {
    key: 'aras_awakening',
    text: 'İskender kesin hile yapıyor! Yeter artık, bütün gücümle sahayı yıkacağım!',
    voiceName: 'Charon',
    stylePrompt:
      'Sinirli, patlamaya hazır ve gür sesli Türk anime erkek striker, yüksek öfke ve kararlılık.',
    pitchFallback: 0.88,
    rateFallback: 1.14,
  },
  aras_ulti: {
    key: 'aras_ulti',
    text: 'Hamburger enerjisi doldu! Yanına ışınlandım, kaleden kaleye alev füzesi!',
    voiceName: 'Charon',
    stylePrompt:
      'Çılgın, tutkulu ve güçlü Türk anime erkek karakter, şut vururken doruğa çıkan enerji.',
    pitchFallback: 0.92,
    rateFallback: 1.12,
  },
  ebulfez_awakening: {
    key: 'ebulfez_awakening',
    text: 'Bir daha görüşmemek dileğiyle... Sonsuzluk eldiveni, şık!',
    voiceName: 'Charon',
    stylePrompt:
      'Soğukkanlı, gizemli ve derin sesli Türk anime erkek kötü adam/anti-kahraman karizması.',
    pitchFallback: 0.84,
    rateFallback: 1.0,
  },
  ebulfez_ulti: {
    key: 'ebulfez_ulti',
    text: 'Geri geldim! Üstünden zıplayıp topu çalıyorum, kozmik vuruş!',
    voiceName: 'Charon',
    stylePrompt:
      'Karizmatik, etkileyici ve keskin Türk anime erkek sesi, zafer vurgulu bitiş.',
    pitchFallback: 0.86,
    rateFallback: 1.1,
  },
  zero_awakening: {
    key: 'zero_awakening',
    text: 'Yapay zeka hileyi kodladı! Bütün açılar hesaplandı, gg easy!',
    voiceName: 'Puck',
    stylePrompt:
      'Zeki, hızlı konuşan ve dijital deha havasında genç Türk anime erkek oyuncu, kendinden emin gülümseme tonu.',
    pitchFallback: 1.12,
    rateFallback: 1.16,
  },
  zero_ulti: {
    key: 'zero_ulti',
    text: 'Algoritma kilidi aktif! Orta sahadan imkansız falso vuruşu!',
    voiceName: 'Puck',
    stylePrompt:
      'Cool, keskin ve yüksek tempolu Türk anime erkek dahi tonu, net telaffuz.',
    pitchFallback: 1.1,
    rateFallback: 1.14,
  },
  berk_awakening: {
    key: 'berk_awakening',
    text: 'Of ya... Bir beş dakika daha yatayım... Tamam kalktım, topu verin!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Başta uykulu ve rahat, ikinci cümlede aniden ciddileşip gürleyen kalın sesli Türk anime erkek savunmacı.',
    pitchFallback: 0.82,
    rateFallback: 0.98,
  },
  berk_ulti: {
    key: 'berk_ulti',
    text: 'Gövde gücüyle topu kaptım! Orta sahadan ağır top füzesi geliyor!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Ağırbaşlı, güçlü ve sarsıcı kalın erkek Türk anime karakter sesi.',
    pitchFallback: 0.8,
    rateFallback: 1.05,
  },
};

export function getVoiceClipKey(styleId: StyleId, kind: 'AWAKENING' | 'ULTI'): string {
  return `${styleId}_${kind === 'AWAKENING' ? 'awakening' : 'ulti'}`;
}

export const EMOTE_LIST: Array<{ id: EmoteId; label: string; shout: string }> = [
  { id: 'SIUUU', label: 'SİUUU SIÇRAYIŞI', shout: 'SİUUU!!' },
  { id: 'EGOIST_POSE', label: 'EGOİST ZİRVE POZU', shout: 'BEN EGOİSTİM!' },
  { id: 'KNEE_SLIDE', label: 'DİZ KAYMA KUTLAMASI', shout: 'İŞTE BU!' },
  { id: 'ARMS_CROSSED', label: 'SOĞUK KRAL POZU', shout: 'ÇOK KOLAY.' },
  { id: 'FLEX_ROAR', label: 'ÇİFT KOL KÜKREME', shout: 'DURDURULAMAZ!' },
];
