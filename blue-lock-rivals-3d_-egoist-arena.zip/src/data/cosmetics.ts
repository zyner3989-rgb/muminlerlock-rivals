import type {
  BackAccessoryId,
  CleatId,
  GameSettings,
  HairStyleId,
  OutfitId,
  StyleId,
  WardrobeConfig,
} from '../types/game';

export interface OutfitOption {
  id: OutfitId;
  name: string;
  subtitle: string;
  previewPrimary: string;
  previewSecondary: string;
}

export const OUTFIT_OPTIONS: OutfitOption[] = [
  {
    id: 'signature',
    name: 'Karakter İmzası',
    subtitle: 'Orijinal Blue Lock forması',
    previewPrimary: '#1d4ed8',
    previewSecondary: '#fbbf24',
  },
  {
    id: 'neoblack',
    name: 'Neo Siyah-Altın',
    subtitle: 'Mat siyah elit deplasman kiti',
    previewPrimary: '#0f172a',
    previewSecondary: '#facc15',
  },
  {
    id: 'royalwhite',
    name: 'Kraliyet Beyazı',
    subtitle: 'Gümüş-buz şampiyon forması',
    previewPrimary: '#f1f5f9',
    previewSecondary: '#0284c7',
  },
  {
    id: 'cyberjacket',
    name: 'Tekno Ceket',
    subtitle: 'Açık yaka spor ceket & tişört',
    previewPrimary: '#111827',
    previewSecondary: '#22d3ee',
  },
  {
    id: 'hoodie',
    name: 'Sokak Kapüşonlu',
    subtitle: '3D kapüşon & kanguru cep stili',
    previewPrimary: '#312e81',
    previewSecondary: '#a855f7',
  },
  {
    id: 'crimson',
    name: 'Kızıl İmparator',
    subtitle: 'Koyu bordo & altın şeritli kit',
    previewPrimary: '#7f1d1d',
    previewSecondary: '#fbbf24',
  },
];

export interface HairOption {
  id: HairStyleId;
  name: string;
  subtitle: string;
}

export const HAIR_STYLE_OPTIONS: HairOption[] = [
  { id: 'character', name: 'Karakter Saçı', subtitle: 'Her karakterin kendi Robux saçı' },
  { id: 'wolfcut', name: 'Egoist Wolfcut', subtitle: 'Katmanlı Robux UGC uzun kesim' },
  { id: 'spiky', name: 'Süper Spike', subtitle: 'Geriye taralı keskin anime tutamları' },
  { id: 'curtain', name: 'Orta Ayrım', subtitle: 'Akıcı iki yana ayrılmış perçemler' },
  { id: 'curly', name: 'Fluffy Kıvırcık', subtitle: 'Hacimli Roblox UGC kıvırcık kesim' },
  { id: 'windswept', name: 'Fırtına Yele', subtitle: 'Asimetrik tek göz kapatan şık stil' },
  { id: 'ponytail', name: 'Samuray Topuzu', subtitle: 'Yüksek at kuyruğu & şakak tutamı' },
  { id: 'frostcrown', name: 'Buz Tacı', subtitle: 'Çift renk uçlu hacimli UGC taç' },
];

export interface HairColorOption {
  value: string;
  label: string;
  swatch: string;
}

export const HAIR_COLOR_OPTIONS: HairColorOption[] = [
  { value: 'character', label: 'Doğal', swatch: 'linear-gradient(135deg,#38bdf8,#fbbf24)' },
  { value: '#0f172a', label: 'Gece Siyahı', swatch: '#0f172a' },
  { value: '#f8fafc', label: 'Platin Beyaz', swatch: '#f8fafc' },
  { value: '#facc15', label: 'Altın Sarı', swatch: '#facc15' },
  { value: '#dc2626', label: 'Kızıl Alev', swatch: '#dc2626' },
  { value: '#0284c7', label: 'Buz Mavisi', swatch: '#0284c7' },
  { value: '#7c3aed', label: 'Mor Aura', swatch: '#7c3aed' },
  { value: '#78350f', label: 'Kestane', swatch: '#78350f' },
  { value: '#db2777', label: 'Neon Pembe', swatch: '#db2777' },
];

export interface CleatOption {
  id: CleatId;
  name: string;
  cleatHex: string;
  sockHex: string;
}

export const CLEAT_OPTIONS: CleatOption[] = [
  { id: 'character', name: 'Karakter Uyumu', cleatHex: '#38bdf8', sockHex: '#f8fafc' },
  { id: 'gold_pro', name: 'Altın Elit', cleatHex: '#fbbf24', sockHex: '#0f172a' },
  { id: 'cyber_cyan', name: 'Buz Siber', cleatHex: '#22d3ee', sockHex: '#082f49' },
  { id: 'crimson_speed', name: 'Kızıl Fırtına', cleatHex: '#ef4444', sockHex: '#18181b' },
  { id: 'phantom_black', name: 'Karbon Hayalet', cleatHex: '#334155', sockHex: '#090d16' },
];

export interface BackAccessoryOption {
  id: BackAccessoryId;
  name: string;
  subtitle: string;
}

export const BACK_ACCESSORY_OPTIONS: BackAccessoryOption[] = [
  { id: 'none', name: 'Yok', subtitle: 'Sade forma arkası' },
  { id: 'scarf', name: 'Egoist Atkı', subtitle: 'Dalgalanan neon boyun atkısı' },
  { id: 'cape', name: 'Kraliyet Pelerini', subtitle: 'Omuzdan sarkan kısa pelerin' },
  { id: 'katana', name: 'Siber Katana', subtitle: 'Sırtında çapraz kın & kabza' },
  { id: 'wings', name: 'Hologram Kanat', subtitle: 'Parlayan enerji kanatları' },
];

export const DEFAULT_WARDROBE: WardrobeConfig = {
  outfitId: 'signature',
  hairStyleId: 'character',
  hairColor: 'character',
  cleatId: 'character',
  backAccessoryId: 'none',
};

export const DEFAULT_SETTINGS: GameSettings = {
  quality: 'HIGH',
  fpsMode: 'UNLIMITED',
  bloom: true,
  shadows: true,
  particles: true,
  weather: 'NIGHT',
  fov: 56,
  cameraDistance: 11.5,
  mouseSensitivity: 1.0,
  masterVolume: 90,
  showFps: true,
};

/**
 * Each character has a signature Roblox Robux UGC hair default when hairStyleId === 'character'
 */
export function resolveDefaultHairForStyle(styleId: StyleId): Exclude<HairStyleId, 'character'> {
  switch (styleId) {
    case 'musab':
      return 'wolfcut';
    case 'musa':
      return 'spiky';
    case 'iskender':
      return 'curtain';
    case 'aras':
      return 'ponytail';
    case 'ebulfez':
      return 'frostcrown';
    case 'zero':
      return 'windswept';
    case 'berk':
    default:
      return 'curly';
  }
}
