import * as THREE from 'three';
import { soundEngine } from '../audio/soundEngine';
import { STYLES } from '../data/styles';
import type { StyleId } from '../types/game';
import type { CutscenePropPack, PlayerRig } from './models';
import { PITCH_HALF_LENGTH } from './models';

export type CutsceneKind = 'AWAKENING' | 'ULTI';

export interface ActiveCutscene {
  styleId: StyleId;
  kind: CutsceneKind;
  elapsed: number;
  duration: number;
  anchorPos: THREE.Vector3;
  opponentPos: THREE.Vector3;
  triggeredEvents: Set<string>;
}

export interface CutsceneFrameResult {
  finished: boolean;
  cameraPos: THREE.Vector3;
  cameraLook: THREE.Vector3;
  banner: {
    active: boolean;
    speaker: string;
    subtitle: string;
    badge: string;
    accentColor: string;
  };
  spawnBurst?: { pos: THREE.Vector3; color: string; count: number };
  launchShot?: {
    from: THREE.Vector3;
    range: 'FULL_PITCH' | 'MIDFIELD';
    curve: number;
    speed: number;
    loft: number;
    stealAndTeleportPos?: THREE.Vector3;
  };
}

const _camPos = new THREE.Vector3();
const _camLook = new THREE.Vector3();

export function startCutsceneState(
  styleId: StyleId,
  kind: CutsceneKind,
  playerPos: THREE.Vector3,
  nearestOpponentPos: THREE.Vector3,
  props: CutscenePropPack
): ActiveCutscene {
  // Reset all props before starting
  props.root.visible = true;
  props.root.position.set(playerPos.x, 0, playerPos.z);
  props.root.rotation.y = 0;
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  props.deskHeadset.visible = false;

  // Fire synchronous anime tension riser + deep anime male voice cry immediately inside user gesture!
  soundEngine.playAnimeAwakeningIntro(styleId, kind);

  const durationMap: Record<CutsceneKind, Record<StyleId, number>> = {
    AWAKENING: {
      musab: 2.9,
      musa: 2.8,
      iskender: 2.8,
      aras: 2.8,
      ebulfez: 2.9,
      zero: 2.7,
      berk: 2.8,
    },
    ULTI: {
      musab: 3.3,
      musa: 2.5,
      iskender: 2.8,
      aras: 2.6,
      ebulfez: 2.5,
      zero: 2.4,
      berk: 2.3,
    },
  };

  return {
    styleId,
    kind,
    elapsed: 0,
    duration: durationMap[kind][styleId],
    anchorPos: playerPos.clone(),
    opponentPos: nearestOpponentPos.clone(),
    triggeredEvents: new Set(),
  };
}

export function resetAfterCutscene(rig: PlayerRig, props: CutscenePropPack, stopAudio = false) {
  if (stopAudio) {
    soundEngine.stopSpeech();
  }
  props.root.visible = false;
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  props.deskHeadset.visible = false;

  rig.bodyPivot.visible = true;
  rig.bodyPivot.position.set(0, 0, 0);
  rig.bodyPivot.rotation.set(0, 0, 0);
  rig.leftArmPivot.rotation.set(0, 0, 0);
  rig.rightArmPivot.rotation.set(0, 0, 0);
  rig.leftLegPivot.rotation.set(0, 0, 0);
  rig.rightLegPivot.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);
  if (rig.headsetProp) rig.headsetProp.visible = true;
}

export function stepCutscene(
  cs: ActiveCutscene,
  dt: number,
  rig: PlayerRig,
  ballGroup: THREE.Group,
  props: CutscenePropPack
): CutsceneFrameResult {
  cs.elapsed += dt;
  const t = cs.elapsed;
  const style = STYLES[cs.styleId];
  const ax = cs.anchorPos.x;
  const az = cs.anchorPos.z;

  // Face toward +X (opponent goal) by default during cutscenes
  rig.root.position.set(ax, 0, az);
  rig.root.rotation.y = 0;

  let subtitle = style.awakeningQuote;
  let badge = cs.kind === 'AWAKENING' ? `UYANIŞ · ${style.rarity}` : `ULTİ · ${style.ultiRangeLabel.toUpperCase()}`;
  let spawnBurst: CutsceneFrameResult['spawnBurst'];
  let launchShot: CutsceneFrameResult['launchShot'];

  const fireOnce = (key: string, fn: () => void) => {
    if (!cs.triggeredEvents.has(key)) {
      cs.triggeredEvents.add(key);
      fn();
    }
  };

  if (cs.kind === 'AWAKENING') {
    switch (cs.styleId) {
      case 'musab': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);
        if (t < 0.85) {
          fireOnce('musab_sleep', () => soundEngine.playSnore());
          // Lying on bed then waking up
          const wake = Math.min(1, t / 0.7);
          rig.bodyPivot.position.set(0, 0.72, 0);
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(Math.PI / 2.2, 0, wake);
          subtitle = 'Zzz... *Gözlerini açar*';
          _camPos.set(ax + 4.2, 2.6, az + 3.2);
          _camLook.set(ax, 1.3, az);
        } else {
          fireOnce('jump_boom', () => {
            soundEngine.playPhoneRing();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: style.auraColor, count: 24 };
          });
          rig.bodyPivot.rotation.z = 0;
          rig.bodyPivot.position.set(0, Math.abs(Math.sin((t - 0.85) * 6)) * 0.45, 0);
          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(0.42, 2.15, 0.35);
          props.phone.rotation.set(0, -0.4, 0);
          rig.rightArmPivot.rotation.set(0, 0, 2.1);
          subtitle = 'Uyanıp makarayız! Alo Musa, SES GEL!';
          if (t > 1.9) {
            fireOnce('boom', () => soundEngine.playAwakeningBoom());
          }
          const orbit = (t - 0.85) * 1.4;
          _camPos.set(ax + Math.cos(orbit) * 4.5, 2.2, az + Math.sin(orbit) * 4.5);
          _camLook.set(ax, 1.6, az);
        }
        break;
      }

      case 'musa': {
        fireOnce('ring', () => soundEngine.playPhoneRing());
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 0.9) {
          props.phone.position.set(0.55, 1.5 + Math.sin(t * 28) * 0.08, 0.3);
          rig.rightArmPivot.rotation.z = 1.1;
          subtitle = '*Telefon çalar: MUSAB ARIYOR...*';
          _camPos.set(ax + 3.8, 2.0, az + 2.8);
          _camLook.set(ax, 1.5, az);
        } else {
          fireOnce('rage', () => {
            soundEngine.playPhonePickup();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.5, az), color: style.auraColor, count: 28 };
          });
          if (t > 2.05) {
            fireOnce('censor', () => soundEngine.playCensorBeep());
          }
          props.phone.position.set(0.36, 2.2, 0.36);
          rig.rightArmPivot.rotation.z = 2.25;
          rig.leftArmPivot.rotation.z = Math.sin(t * 24) * 0.6 + 1.4;
          rig.bodyPivot.position.y = Math.abs(Math.sin(t * 14)) * 0.18;
          subtitle = 'ALO MUSAB MAÇIN ORTASINDA NE ARIYON LAN #@$%!!';
          _camPos.set(ax + 3.4 + Math.sin(t * 45) * 0.08, 2.1, az - 2.6);
          _camLook.set(ax, 1.7, az);
        }
        break;
      }

      case 'iskender': {
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.05) {
          fireOnce('isk_call', () => {
            soundEngine.playPhonePickup();
          });
          props.phone.position.set(0.85, 1.75, 0);
          rig.rightArmPivot.rotation.z = 1.25;
          subtitle = 'Musa görüntülüdeyiz, bekle bi saniye...';
          _camPos.set(ax + 3.6, 2.1, az + 2.5);
          _camLook.set(ax, 1.6, az);
        } else {
          fireOnce('sock_boom', () => {
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.2, az), color: style.auraColor, count: 24 };
          });
          // Put phone on floor & lift leg showing glowing sock right at camera!
          props.phone.position.set(1.25, 0.25, 0.4);
          props.phone.rotation.set(0, 0, -0.7);
          props.sock.visible = true;
          props.sock.position.set(1.05, 1.35, 0);
          props.sock.rotation.set(0, 0, -Math.PI / 2.2);
          props.sock.scale.setScalar(1.45);
          rig.rightLegPivot.rotation.z = 1.4;
          rig.bodyPivot.rotation.z = -0.25;
          subtitle = 'Musa iyi izle, ÇORABIMA BAK LAN!';
          _camPos.set(ax + 3.2, 1.5, az + 0.6);
          _camLook.set(ax + 0.8, 1.35, az);
        }
        break;
      }

      case 'aras': {
        props.desk.visible = true;
        props.desk.position.set(1.6, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.aras_lose;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.1) {
          fireOnce('aras_lose_sfx', () => soundEngine.playGlitchBeep());
          rig.bodyPivot.position.y = -0.15;
          rig.leftArmPivot.rotation.z = 1.0;
          rig.rightArmPivot.rotation.z = 1.0;
          subtitle = 'Ekranda: YENİLDİN 0-5 (İSKENDER KAZANDI)';
          _camPos.set(ax - 2.6, 2.5, az + 3.4);
          _camLook.set(ax + 1.2, 1.6, az);
        } else {
          fireOnce('aras_rage', () => {
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#ef4444', count: 30 };
          });
          rig.bodyPivot.position.y = Math.abs(Math.sin(t * 16)) * 0.28;
          rig.leftArmPivot.rotation.z = 2.6;
          rig.rightArmPivot.rotation.z = 2.6;
          subtitle = 'İSKENDER KESİN HİLE YAPIYO! YETER LAN!';
          _camPos.set(ax + 3.8 + Math.sin(t * 50) * 0.1, 2.0, az + 2.4);
          _camLook.set(ax, 1.6, az);
        }
        break;
      }

      case 'ebulfez': {
        if (t < 1.15) {
          rig.rightArmPivot.rotation.z = 1.9;
          subtitle = 'Bir daha görüşmemek dileğiyle...';
          _camPos.set(ax + 3.0, 2.0, az + 2.0);
          _camLook.set(ax, 1.7, az);
        } else if (t < 2.05) {
          fireOnce('snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 36 };
          });
          // Disappear completely!
          rig.bodyPivot.visible = false;
          props.snapRing.visible = true;
          const p = (t - 1.15) / 0.9;
          props.snapRing.position.set(0, 1.4, 0);
          props.snapRing.scale.setScalar(1 + p * 6.5);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - p);
          subtitle = '*PARMAK ŞIKLATIR — ORTADAN KAYBOLUR!*';
          _camPos.set(ax + 4.4, 2.5, az + 3.2);
          _camLook.set(ax, 1.4, az);
        } else {
          fireOnce('return_boom', () => {
            soundEngine.playAwakeningBoom();
          });
          rig.bodyPivot.visible = true;
          props.snapRing.visible = false;
          subtitle = 'Ebulfez Uyanışı Aktif!';
          _camPos.set(ax + 3.8, 2.1, az - 2.4);
          _camLook.set(ax, 1.5, az);
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(1.6, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('glitch', () => soundEngine.playAiHackComplete());
          rig.leftArmPivot.rotation.z = 1.1 + Math.sin(t * 28) * 0.35;
          rig.rightArmPivot.rotation.z = 1.1 - Math.sin(t * 28) * 0.35;
          subtitle = 'Yapay Zeka hile kodunu yazıyor...';
          _camPos.set(ax - 2.4, 2.5, az + 3.4);
          _camLook.set(ax + 1.2, 1.7, az);
        } else {
          fireOnce('zero_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.5, az), color: '#22d3ee', count: 28 };
          });
          rig.bodyPivot.position.y = Math.abs(Math.sin((t - 1.15) * 9)) * 0.85;
          rig.leftArmPivot.rotation.z = 2.8;
          rig.rightArmPivot.rotation.z = 2.8;
          subtitle = 'YAPAY ZEKA HİLEYİ KODLADI! GG EASY!';
          _camPos.set(ax + 4.2, 2.2, az + 2.8);
          _camLook.set(ax, 1.8, az);
        }
        break;
      }

      case 'berk': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);
        if (t < 1.75) {
          fireOnce('berk_snore', () => {
            soundEngine.playSnore();
          });
          rig.bodyPivot.position.set(0, 0.85, 0);
          rig.bodyPivot.rotation.z = Math.PI / 2;
          rig.leftArmPivot.rotation.z = 0.5;
          rig.rightArmPivot.rotation.z = 0.5;
          subtitle = 'Of ya... Bi 5 dakika daha yatayım... *Horlar*';
          _camPos.set(ax + 3.8, 2.8, az + 3.2);
          _camLook.set(ax, 1.0, az);
        } else {
          fireOnce('berk_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.2, az), color: '#60a5fa', count: 20 };
          });
          const p = Math.min(1, (t - 1.75) / 0.65);
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(Math.PI / 2, 0, p);
          rig.bodyPivot.position.y = THREE.MathUtils.lerp(0.85, 0, p);
          subtitle = 'Tamam kalktım, topu verin!';
          _camPos.set(ax + 4.0, 2.2, az + 2.8);
          _camLook.set(ax, 1.4, az);
        }
        break;
      }
    }
  } else {
    // ================= ULTI / AWAKENING SHOTS =================
    switch (cs.styleId) {
      case 'musab': {
        props.desk.visible = true;
        props.desk.position.set(2.2, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.bluelock_game;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.05) {
          fireOnce('musab_bounce', () => soundEngine.playKick(0.35));
          if (t > 0.45) fireOnce('musab_bounce2', () => soundEngine.playKick(0.35));
          // Bouncing ball on head while playing Blue Lock on monitor
          const bounce = Math.abs(Math.sin(t * 11)) * 0.7;
          ballGroup.position.set(ax, 2.85 + bounce, az);
          rig.headGroup.rotation.z = Math.sin(t * 11) * 0.15;
          subtitle = 'Monitörde Blue Lock oynarken topu kafasında sektiriyor...';
          _camPos.set(ax - 2.8, 2.8, az + 3.8);
          _camLook.set(ax + 1.5, 2.0, az);
        } else if (t < 2.15) {
          // Ball bursts OUT of the monitor screen like a horror movie monster and flies skyward!
          fireOnce('monster', () => {
            soundEngine.playHorrorMonitorBurst();
            spawnBurst = { pos: new THREE.Vector3(ax + 2.1, 2.0, az), color: '#a855f7', count: 32 };
          });
          const p = (t - 1.05) / 1.1;
          props.monsterBall.visible = true;
          props.monsterBall.position.set(
            THREE.MathUtils.lerp(2.0, 0.2, p),
            THREE.MathUtils.lerp(2.05, 5.2, p),
            0
          );
          props.monsterBall.scale.setScalar(0.8 + p * 0.9);
          props.monsterBall.rotation.y += dt * 10;
          ballGroup.position.set(ax + props.monsterBall.position.x, props.monsterBall.position.y, az);
          subtitle = 'MONİTÖRDEN KÂBUS GİBİ SAHAYA ÇIKTI!!';
          _camPos.set(ax + 4.8, 2.4, az + 4.0);
          _camLook.set(ax + 0.5, 2.8, az);
        } else {
          // Musab puts headset on desk, leaps skyward and smashes full-pitch volley!
          fireOnce('headset_off', () => {
            if (rig.headsetProp) rig.headsetProp.visible = false;
            props.deskHeadset.visible = true;
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
          });
          props.monsterBall.visible = false;
          const p = Math.min(1, (t - 2.15) / 1.05);
          rig.bodyPivot.position.y = Math.sin(p * Math.PI) * 4.4;
          rig.bodyPivot.rotation.z = -p * Math.PI * 1.3;
          rig.rightLegPivot.rotation.z = 1.5;
          ballGroup.position.set(ax + 0.4, 4.7 - Math.abs(p - 0.5) * 1.2, az);
          subtitle = 'KULAKLIĞI MASAYA KOYDU — KALEDEN KALEYE VOLE!!';
          _camPos.set(ax - 3.5, 3.8, az + 5.0);
          _camLook.set(ax + 0.5, 3.6, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 0.8, 3.5, az),
              range: 'FULL_PITCH',
              curve: 0.15,
              speed: 58,
              loft: 6.5,
            };
          }
        }
        break;
      }

      case 'musa': {
        if (t < 1.15) {
          props.pillow.visible = true;
          props.pillow.position.set(1.2, 0.2, 0);
          rig.bodyPivot.position.x = THREE.MathUtils.lerp(-0.8, 0.3, t / 1.15);
          rig.rightLegPivot.rotation.z = Math.sin((t / 1.15) * Math.PI) * -1.1;
          ballGroup.position.set(ax + 1.2, -5, az); // hide normal ball until transformation
          subtitle = 'Musa yerdeki yastığa doğru koşuyor...';
          _camPos.set(ax + 3.8, 1.8, az + 3.4);
          _camLook.set(ax + 0.8, 0.9, az);
        } else {
          fireOnce('pillow_transform', () => {
            soundEngine.playPillowTransform();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(1.0);
            spawnBurst = { pos: new THREE.Vector3(ax + 1.2, 0.6, az), color: '#38bdf8', count: 34 };
          });
          props.pillow.visible = false;
          rig.rightLegPivot.rotation.z = 1.65;
          rig.bodyPivot.rotation.z = -0.35;
          ballGroup.position.set(ax + 1.4, 0.65, az);
          subtitle = 'YASTIK TOPA DÖNÜŞTÜ — KALEDEN KALEYE SONİK ŞUT!!';
          _camPos.set(ax - 2.8, 1.9, az + 3.6);
          _camLook.set(ax + 5.0, 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 1.4, 0.65, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 62,
              loft: 4.5,
            };
          }
        }
        break;
      }

      case 'iskender': {
        if (t < 1.15) {
          fireOnce('isk_ulti_say', () => {
            soundEngine.playPhonePickup();
          });
          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(1.6, 1.4, 0.6);

          const p = t / 1.15;
          rig.bodyPivot.position.y = p * 2.4;
          rig.bodyPivot.rotation.z = p * Math.PI * 0.85;
          ballGroup.position.set(ax, -5, az); // No ball yet — kicking thin air!
          subtitle = 'Görüntülü konuşmada boşluğa rovaşataya kalkıyor...';
          _camPos.set(ax + 3.6, 2.2, az + 3.6);
          _camLook.set(ax, 1.8, az);
        } else {
          fireOnce('isk_tp', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: new THREE.Vector3(ax, 2.2, az), color: '#2dd4bf', count: 34 };
          });
          props.phone.visible = false;
          const p = Math.min(1, (t - 1.15) / 1.5);
          rig.bodyPivot.position.y = 2.4 - p * 1.4;
          rig.bodyPivot.rotation.z = Math.PI * 0.85 + p * 0.85;
          rig.rightLegPivot.rotation.z = 1.6;
          ballGroup.position.set(ax + 0.9, 2.2 - p * 0.8, az);
          subtitle = 'SAHAYA IŞINLANDI — AYAĞINDA TOP BELİRDİ!!';
          _camPos.set(ax - 3.2, 2.8, az + 4.4);
          _camLook.set(ax + 2.0, 1.8, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 0.9, 1.6, az),
              range: 'FULL_PITCH',
              curve: -0.1,
              speed: 56,
              loft: 6.0,
            };
          }
        }
        break;
      }

      case 'aras': {
        props.coach.visible = true;
        props.coach.position.set(-2.2, 0, -1.8);
        props.coach.rotation.y = -0.4;
        props.hamburger.visible = true;

        if (t < 1.15) {
          fireOnce('aras_coach', () => {
            soundEngine.playWhistle();
          });
          if (t > 0.75) {
            fireOnce('burger_land', () => soundEngine.playBurgerSplat());
          }
          // Aras sitting on grass while coach throws hamburger!
          const p = t / 1.15;
          rig.bodyPivot.position.y = -0.45;
          rig.bodyPivot.rotation.z = 0.35;
          props.hamburger.position.set(
            THREE.MathUtils.lerp(-1.8, 2.4, p),
            Math.sin(p * Math.PI) * 2.8 + 0.1,
            THREE.MathUtils.lerp(-1.4, 0, p)
          );
          ballGroup.position.set(ax + 2.8, 0.36, az);
          subtitle = 'Antrenör Aras kalksın diye yere HAMBURGER attı!';
          _camPos.set(ax + 4.5, 2.2, az + 4.2);
          _camLook.set(ax + 0.5, 1.1, az);
        } else {
          fireOnce('burger_tp', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(1.0);
            spawnBurst = { pos: new THREE.Vector3(ax + 2.4, 0.8, az), color: '#ef4444', count: 34 };
          });
          props.hamburger.position.set(2.4, 0.05, 0);
          rig.bodyPivot.position.set(2.1, Math.sin(((t - 1.15) / 1.45) * Math.PI) * 0.6, 0);
          rig.bodyPivot.rotation.z = -0.3;
          rig.rightLegPivot.rotation.z = 1.55;
          ballGroup.position.set(ax + 2.8, 0.6, az);
          subtitle = 'ARAS HAMBURGERİN YANINA IŞINLANDI — KALEDEN KALEYE!!';
          _camPos.set(ax - 1.5, 2.2, az + 4.2);
          _camLook.set(ax + 3.5, 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 2.8, 0.6, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 58,
              loft: 4.8,
            };
          }
        }
        break;
      }

      case 'ebulfez': {
        // Snap & teleport beside opponent, steal ball, jump over opponent, shoot!
        const targetPos = cs.opponentPos.clone();
        if (t < 0.85) {
          fireOnce('ebu_snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 28 };
          });
          props.snapRing.visible = true;
          props.snapRing.position.set(0, 1.3, 0);
          props.snapRing.scale.setScalar(1 + (t / 0.85) * 4);
          subtitle = '*ŞIK!* Geri geldim!';
          _camPos.set(ax + 3.5, 2.2, az + 3.2);
          _camLook.set(ax, 1.4, az);
        } else {
          fireOnce('ebu_leap', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: targetPos.clone().setY(1.2), color: '#e879f9', count: 26 };
          });
          props.snapRing.visible = false;
          rig.root.position.set(targetPos.x, 0, targetPos.z);
          props.root.position.set(targetPos.x, 0, targetPos.z);
          const p = (t - 0.85) / 1.65;
          rig.bodyPivot.position.set(p * 1.8 - 0.8, Math.sin(p * Math.PI) * 3.1, 0);
          rig.bodyPivot.rotation.z = -p * Math.PI * 2;
          ballGroup.position.set(targetPos.x + p * 1.8 - 0.3, Math.sin(p * Math.PI) * 2.6 + 0.4, targetPos.z);
          subtitle = 'GERİ GELDİM! RAKİBİN ÜSTÜNDEN ZIPLAYIP ÇALDI!!';
          _camPos.set(targetPos.x - 3.6, 3.0, targetPos.z + 4.4);
          _camLook.set(targetPos.x + 1.0, 1.8, targetPos.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(targetPos.x + 1.2, 1.1, targetPos.z),
              range: 'FULL_PITCH',
              curve: 0.25,
              speed: 52,
              loft: 5.2,
              stealAndTeleportPos: new THREE.Vector3(targetPos.x + 1.0, 0, targetPos.z),
            };
          }
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(-1.6, 0, -1.4);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('zero_ai', () => {
            soundEngine.playAiHackComplete();
          });
          const p = t / 1.15;
          ballGroup.position.set(ax + 1.1, 1.2 + Math.sin(p * 14) * 0.25, az);
          rig.rightArmPivot.rotation.z = 1.7;
          subtitle = 'AI HİLE AKTİF: Top havada otomatik kontrol ediliyor...';
          _camPos.set(ax + 3.6, 2.2, az + 3.4);
          _camLook.set(ax + 0.8, 1.4, az);
        } else {
          fireOnce('zero_kick', () => {
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: new THREE.Vector3(ax + 1.1, 1.2, az), color: '#22d3ee', count: 28 };
          });
          rig.rightLegPivot.rotation.z = 1.6;
          rig.bodyPivot.rotation.y = 0.5;
          ballGroup.position.set(ax + 1.3, 1.1, az);
          subtitle = 'ORTA SAHA HİLELİ FALSOLU VURUŞ!!';
          _camPos.set(ax - 3.2, 2.4, az + 3.8);
          _camLook.set(ax + 4.0, 1.2, az);

          if (t >= cs.duration - 0.05) {
            const clampedX = Math.max(-2, ax); // Midfield reach
            launchShot = {
              from: new THREE.Vector3(ax + 1.2, 1.0, az),
              range: 'MIDFIELD',
              curve: az >= 0 ? -1.4 : 1.4, // Huge banana curve toward center goal!
              speed: clampedX >= -4 ? 46 : 36,
              loft: 5.5,
            };
          }
        }
        break;
      }

      case 'berk': {
        // Steal from midfield opponent and fire midfield cannon!
        const stealOrigin = new THREE.Vector3(
          Math.max(-4, Math.min(PITCH_HALF_LENGTH - 12, cs.opponentPos.x)),
          0,
          cs.opponentPos.z
        );
        if (t < 0.95) {
          fireOnce('berk_steal', () => {
            soundEngine.playKick(0.7);
            spawnBurst = { pos: stealOrigin.clone().setY(1.0), color: '#60a5fa', count: 22 };
          });
          rig.root.position.copy(stealOrigin);
          rig.bodyPivot.rotation.z = -0.22;
          ballGroup.position.set(stealOrigin.x + 1.0, 0.36, stealOrigin.z);
          subtitle = 'Berk orta sahadan gövde gücüyle topu kaptı!';
          _camPos.set(stealOrigin.x - 3.4, 2.3, stealOrigin.z + 3.6);
          _camLook.set(stealOrigin.x + 0.8, 1.2, stealOrigin.z);
        } else {
          fireOnce('berk_shoot', () => {
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
          });
          rig.root.position.copy(stealOrigin);
          rig.rightLegPivot.rotation.z = 1.5;
          ballGroup.position.set(stealOrigin.x + 1.2, 0.55, stealOrigin.z);
          subtitle = 'ORTA SAHADAN AĞIR TOP FÜZESİ!!';
          _camPos.set(stealOrigin.x - 3.0, 2.1, stealOrigin.z + 3.4);
          _camLook.set(stealOrigin.x + 4.0, 1.2, stealOrigin.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(stealOrigin.x + 1.2, 0.55, stealOrigin.z),
              range: 'MIDFIELD',
              curve: 0,
              speed: 42,
              loft: 4.2,
              stealAndTeleportPos: stealOrigin.clone(),
            };
          }
        }
        break;
      }
    }
  }

  return {
    finished: t >= cs.duration,
    cameraPos: _camPos.clone(),
    cameraLook: _camLook.clone(),
    banner: {
      active: true,
      speaker: style.name,
      subtitle,
      badge,
      accentColor: style.auraColor,
    },
    spawnBurst,
    launchShot,
  };
}
