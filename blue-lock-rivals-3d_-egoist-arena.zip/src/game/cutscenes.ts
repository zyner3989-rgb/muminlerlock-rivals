import * as THREE from 'three';
import { soundEngine } from '../audio/soundEngine';
import { STYLES } from '../data/styles';
import type { StyleId } from '../types/game';
import type { CutscenePropPack, PlayerRig } from './models';
import { PITCH_HALF_LENGTH } from './models';

export type CutsceneKind = 'AWAKENING' | 'ULTI' | 'COMBO';

export interface ActiveCutscene {
  styleId: StyleId;
  kind: CutsceneKind;
  elapsed: number;
  duration: number;
  anchorPos: THREE.Vector3;
  opponentPos: THREE.Vector3;
  triggeredEvents: Set<string>;
}

export interface CutsceneFrameResult {
  finished: boolean;
  cameraPos: THREE.Vector3;
  cameraLook: THREE.Vector3;
  banner: {
    active: boolean;
    speaker: string;
    subtitle: string;
    badge: string;
    accentColor: string;
  };
  spawnBurst?: { pos: THREE.Vector3; color: string; count: number };
  launchShot?: {
    from: THREE.Vector3;
    range: 'FULL_PITCH' | 'MIDFIELD';
    curve: number;
    speed: number;
    loft: number;
    stealAndTeleportPos?: THREE.Vector3;
  };
}

const _camPos = new THREE.Vector3();
const _camLook = new THREE.Vector3();

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function easeOutCubic(t: number): number {
  const x = clamp01(t);
  return 1 - Math.pow(1 - x, 3);
}

function easeInOutCubic(t: number): number {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
}

function easeOutBack(t: number): number {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

export function startCutsceneState(
  styleId: StyleId,
  kind: CutsceneKind,
  playerPos: THREE.Vector3,
  nearestOpponentPos: THREE.Vector3,
  props: CutscenePropPack
): ActiveCutscene {
  props.root.visible = true;
  props.root.position.set(playerPos.x, 0, playerPos.z);
  props.root.rotation.set(0, 0, 0);
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  props.deskHeadset.visible = false;

  if (kind === 'COMBO') {
    soundEngine.playAnimeAwakeningIntro('musab', 'ULTI');
  } else {
    soundEngine.playAnimeAwakeningIntro(styleId, kind);
  }

  const durationMap: Record<CutsceneKind, Record<StyleId, number>> = {
    AWAKENING: {
      musab: 2.9,
      musa: 2.8,
      iskender: 2.8,
      aras: 2.8,
      ebulfez: 2.9,
      zero: 2.7,
      berk: 2.8,
    },
    ULTI: {
      musab: 3.3,
      musa: 2.5,
      iskender: 2.8,
      aras: 2.6,
      ebulfez: 2.5,
      zero: 2.4,
      berk: 2.3,
    },
    COMBO: {
      musab: 3.4,
      musa: 3.4,
      iskender: 3.4,
      aras: 3.4,
      ebulfez: 3.4,
      zero: 3.4,
      berk: 3.4,
    },
  };

  return {
    styleId,
    kind,
    elapsed: 0,
    duration: durationMap[kind][styleId],
    anchorPos: playerPos.clone(),
    opponentPos: nearestOpponentPos.clone(),
    triggeredEvents: new Set(),
  };
}

function resetSingleRig(rig: PlayerRig) {
  rig.bodyPivot.visible = true;
  rig.bodyPivot.scale.set(1, 1, 1);
  rig.bodyPivot.position.set(0, 0, 0);
  rig.bodyPivot.rotation.set(0, 0, 0);
  rig.upperTorsoPivot.rotation.set(0, 0, 0);
  rig.leftArmPivot.rotation.set(0, 0, 0);
  rig.leftElbowPivot.rotation.set(0, 0, 0);
  rig.rightArmPivot.rotation.set(0, 0, 0);
  rig.rightElbowPivot.rotation.set(0, 0, 0);
  rig.leftLegPivot.rotation.set(0, 0, 0);
  rig.leftKneePivot.rotation.set(0, 0, 0);
  rig.rightLegPivot.rotation.set(0, 0, 0);
  rig.rightKneePivot.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.auraPillars.visible = false;
  rig.auraPillars.position.set(0, 0, 0);
  rig.auraPillars.scale.set(1, 1, 1);
  rig.auraRing.position.set(0, 0.04, 0);
  (rig.auraRing.material as THREE.MeshBasicMaterial).opacity = 0;
  if (rig.headsetProp) rig.headsetProp.visible = true;
}

export function resetAfterCutscene(
  rig: PlayerRig,
  props: CutscenePropPack,
  stopAudio = false,
  partnerRig?: PlayerRig | null
) {
  if (stopAudio) {
    soundEngine.stopSpeech();
  }
  props.root.visible = false;
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  props.deskHeadset.visible = false;

  resetSingleRig(rig);
  if (partnerRig && partnerRig !== rig) {
    resetSingleRig(partnerRig);
  }
}

function normalizeRigForFrame(rig: PlayerRig) {
  rig.bodyPivot.visible = true;
  rig.bodyPivot.scale.set(1, 1, 1);
  rig.bodyPivot.position.set(0, 0, 0);
  rig.bodyPivot.rotation.set(0, 0, 0);
  rig.upperTorsoPivot.rotation.set(0, 0, 0);
  rig.leftArmPivot.rotation.set(0, 0, 0);
  rig.leftElbowPivot.rotation.set(0, 0, 0.18);
  rig.rightArmPivot.rotation.set(0, 0, 0);
  rig.rightElbowPivot.rotation.set(0, 0, 0.18);
  rig.leftLegPivot.rotation.set(0, 0, 0);
  rig.leftKneePivot.rotation.set(0, 0, -0.05);
  rig.rightLegPivot.rotation.set(0, 0, 0);
  rig.rightKneePivot.rotation.set(0, 0, -0.05);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.auraPillars.visible = false;
  rig.auraPillars.position.set(0, 0, 0);
  rig.auraPillars.scale.set(1, 1, 1);
  rig.auraRing.position.set(0, 0.04, 0);
  (rig.auraRing.material as THREE.MeshBasicMaterial).opacity = 0;
}

export function stepCutscene(
  cs: ActiveCutscene,
  dt: number,
  rig: PlayerRig,
  ballGroup: THREE.Group,
  props: CutscenePropPack,
  partnerRig?: PlayerRig | null
): CutsceneFrameResult {
  cs.elapsed += dt;
  const t = cs.elapsed;
  const style = STYLES[cs.styleId];
  const ax = cs.anchorPos.x;
  const az = cs.anchorPos.z;

  normalizeRigForFrame(rig);
  rig.root.position.set(ax, 0, az);
  rig.root.rotation.set(0, 0, 0);
  if (partnerRig && partnerRig !== rig) {
    normalizeRigForFrame(partnerRig);
  }

  let subtitle = style.awakeningQuote;
  const badge =
    cs.kind === 'COMBO'
      ? 'KİMYASAL TEPKİME · MUSAB × MUSA'
      : cs.kind === 'AWAKENING'
        ? `UYANIŞ · ${style.rarity}`
        : `ULTİ · ${style.ultiRangeLabel.toUpperCase()}`;
  let spawnBurst: CutsceneFrameResult['spawnBurst'];
  let launchShot: CutsceneFrameResult['launchShot'];

  const fireOnce = (key: string, fn: () => void) => {
    if (!cs.triggeredEvents.has(key)) {
      cs.triggeredEvents.add(key);
      fn();
    }
  };

  const showAuraOn = (targetRig: PlayerRig, intensity: number) => {
    const inverted = Math.abs(targetRig.bodyPivot.rotation.z) > 0.75;
    targetRig.auraPillars.visible = intensity > 0.05 && !inverted;
    targetRig.auraPillars.position.set(
      targetRig.bodyPivot.position.x,
      Math.max(0, targetRig.bodyPivot.position.y * 0.25),
      targetRig.bodyPivot.position.z
    );
    targetRig.auraPillars.rotation.y += dt * 2.8;
    targetRig.auraPillars.scale.set(1, 0.75 + intensity * 0.45, 1);
    targetRig.auraRing.position.set(targetRig.bodyPivot.position.x, 0.04, targetRig.bodyPivot.position.z);
    targetRig.auraRing.rotation.z -= dt * 3.2;
    (targetRig.auraRing.material as THREE.MeshBasicMaterial).opacity = Math.min(0.75, intensity * 0.7);
  };

  const showAura = (intensity: number) => {
    showAuraOn(rig, intensity);
  };

  if (cs.kind === 'AWAKENING') {
    switch (cs.styleId) {
      case 'musab': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);

        if (t < 0.9) {
          fireOnce('musab_sleep', () => soundEngine.playSnore());
          // Lying properly with head ON the pillow (+X = +1.05) and gentle breathing chest
          const sitUp = t > 0.62 ? easeInOutCubic((t - 0.62) / 0.28) : 0;
          const breathe = Math.sin(t * 5.2) * 0.03;
          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(-1.12, -0.1, sitUp),
            0.92 + breathe * (1 - sitUp),
            0
          );
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-Math.PI / 2, -0.15, sitUp);
          rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(0.08, -0.24, sitUp);
          rig.leftLegPivot.rotation.z = THREE.MathUtils.lerp(0.28, 0.95, sitUp);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(0.2, 0.85, sitUp);
          rig.leftKneePivot.rotation.z = THREE.MathUtils.lerp(-0.45, -1.05, sitUp);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.32, -0.95, sitUp);
          rig.leftArmPivot.rotation.set(0.3, 0, THREE.MathUtils.lerp(0.2, 0.9, sitUp));
          rig.rightArmPivot.rotation.set(-0.3, 0, THREE.MathUtils.lerp(0.35, 1.0, sitUp));
          rig.leftElbowPivot.rotation.z = 1.1;
          rig.rightElbowPivot.rotation.z = 1.25;
          rig.headGroup.rotation.z = sitUp * 0.22;

          subtitle = t > 0.62 ? '*Gözlerini fal taşı gibi açar!*' : 'Zzz... *Derin uyku*';
          _camPos.set(ax + 3.2, 2.55, az + 3.1);
          _camLook.set(ax + 0.35, 1.15, az);
        } else if (t < 1.38) {
          // Explosive leap off the bed onto the pitch at x = +2.05!
          fireOnce('jump_boom', () => {
            soundEngine.playPhoneRing();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax + 1.8, 1.2, az), color: style.auraColor, count: 28 };
          });
          const p = (t - 0.9) / 0.48;
          const easeP = easeOutCubic(p);
          const jumpY = Math.sin(p * Math.PI) * 1.35 + (1 - easeP) * 0.85;
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(-0.1, 2.05, easeP), jumpY, 0);
          rig.bodyPivot.rotation.y = easeP * 0.25;
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.leftLegPivot.rotation.set(0.14, 0, 0.55 * Math.sin(p * Math.PI));
          rig.rightLegPivot.rotation.set(-0.14, 0, -0.35 * Math.sin(p * Math.PI));
          rig.leftKneePivot.rotation.z = -0.95 * Math.sin(p * Math.PI) - 0.35;
          rig.rightKneePivot.rotation.z = -0.75 * Math.sin(p * Math.PI) - 0.25;
          rig.rightArmPivot.rotation.set(0.18, 0, 1.05);
          rig.rightElbowPivot.rotation.z = 1.32;
          rig.leftArmPivot.rotation.set(0.42, 0, 0.75);
          rig.leftElbowPivot.rotation.z = 0.85;

          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(rig.bodyPivot.position.x + 0.28, rig.bodyPivot.position.y + 2.02, 0.36);
          props.phone.rotation.set(0, -Math.PI / 2 + 0.25, -0.15);

          showAura(p);
          subtitle = 'Uyanıp makarayız! Alo Musa, SES GEL!';
          _camPos.set(ax + 4.8, 2.45, az + 3.0);
          _camLook.set(ax + 1.5, 1.6, az);
        } else {
          // Grounded energetic anime call stance beside bed with glowing aura
          const p = (t - 1.38) / (cs.duration - 1.38);
          const settle = easeOutCubic(Math.min(1, p * 3));
          const hypeBob = Math.abs(Math.sin((t - 1.38) * 10)) * 0.08;
          rig.bodyPivot.position.set(2.05, hypeBob, 0);
          rig.bodyPivot.rotation.y = 0.25 - Math.sin(p * Math.PI) * 0.15;
          rig.upperTorsoPivot.rotation.set(0, Math.sin(t * 8) * 0.14, -0.18 + Math.sin(t * 10) * 0.06);
          rig.headGroup.rotation.z = 0.14;

          // Athletic wide stance with natural knee flex
          rig.leftLegPivot.rotation.set(0.16, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.16, 0, 0.28);
          rig.leftKneePivot.rotation.z = -0.38 - settle * 0.05;
          rig.rightKneePivot.rotation.z = -0.32 - settle * 0.05;

          // Right hand holds phone tightly to right ear; left fist pumps enthusiastically
          rig.rightArmPivot.rotation.set(0.22, 0, 1.05);
          rig.rightElbowPivot.rotation.z = 1.35;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.65 + Math.sin(t * 14) * 0.45);
          rig.leftElbowPivot.rotation.z = 1.15;

          props.phone.visible = true;
          props.phone.position.set(2.05 + 0.26, 2.02 + hypeBob, 0.36);
          props.phone.rotation.set(0, -Math.PI / 2 + 0.25, -0.15);

          if (t > 2.0) {
            fireOnce('boom', () => soundEngine.playAwakeningBoom());
          }
          showAura(1.0);
          rig.auraPillars.position.x = 2.05;
          rig.auraRing.position.x = 2.05;
          subtitle = 'Uyanıp makarayız! Alo Musa, SES GEL!';
          const orbit = p * 1.15;
          _camPos.set(ax + 2.05 + Math.cos(orbit) * 3.8, 2.05, az + Math.sin(orbit) * 3.6);
          _camLook.set(ax + 2.05, 1.55, az);
        }
        break;
      }

      case 'musa': {
        fireOnce('ring', () => soundEngine.playPhoneRing());
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 0.92) {
          // Looking down at vibrating phone held naturally in right hand
          const vib = Math.sin(t * 36) * 0.025;
          rig.upperTorsoPivot.rotation.z = -0.14;
          rig.headGroup.rotation.z = -0.34;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.12);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.16);
          rig.leftKneePivot.rotation.z = -0.22;
          rig.rightKneePivot.rotation.z = -0.18;

          rig.rightArmPivot.rotation.set(0.28, 0, 0.78);
          rig.rightElbowPivot.rotation.z = 1.12;
          rig.leftArmPivot.rotation.set(0.12, 0, -0.12);
          rig.leftElbowPivot.rotation.z = 0.55;

          props.phone.position.set(0.56 + vib, 1.48, 0.28 + vib);
          props.phone.rotation.set(0, 0.35, -0.45);
          subtitle = '*Telefon çalar: MUSAB ARIYOR...*';
          _camPos.set(ax + 3.4, 2.0, az + 2.5);
          _camLook.set(ax + 0.2, 1.45, az);
        } else {
          fireOnce('rage', () => {
            soundEngine.playPhonePickup();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: style.auraColor, count: 32 };
          });
          if (t > 2.05) {
            fireOnce('censor', () => soundEngine.playCensorBeep());
          }
          const snapP = easeOutCubic(Math.min(1, (t - 0.92) / 0.25));
          const rageWave = Math.sin((t - 0.92) * 16);

          // Grounded enraged power stance (deep knee flex, torso leaning into roar)
          rig.bodyPivot.position.y = -0.08 + Math.abs(rageWave) * 0.04;
          rig.upperTorsoPivot.rotation.set(0, rageWave * 0.16, THREE.MathUtils.lerp(-0.14, 0.16, snapP) + rageWave * 0.08);
          rig.headGroup.rotation.set(rageWave * 0.12, 0, 0.2);

          rig.leftLegPivot.rotation.set(0.2, 0, -0.26);
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.3);
          rig.leftKneePivot.rotation.z = -0.44;
          rig.rightKneePivot.rotation.z = -0.38;

          // Right hand slams phone to ear; left arm shakes fist violently
          rig.rightArmPivot.rotation.set(0.22, 0, THREE.MathUtils.lerp(0.78, 1.08, snapP));
          rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(1.12, 1.38, snapP);
          rig.leftArmPivot.rotation.set(0.35, 0, 0.75 + rageWave * 0.55);
          rig.leftElbowPivot.rotation.z = 1.25 + rageWave * 0.25;

          props.phone.position.set(
            THREE.MathUtils.lerp(0.56, 0.27, snapP),
            THREE.MathUtils.lerp(1.48, 2.02, snapP),
            THREE.MathUtils.lerp(0.28, 0.36, snapP)
          );
          props.phone.rotation.set(0, -Math.PI / 2 + 0.22, -0.12);

          showAura(snapP);
          subtitle = 'ALO MUSAB MAÇIN ORTASINDA NE ARIYON LAN #@$%!!';
          const shake = Math.sin(t * 48) * 0.06;
          _camPos.set(ax + 3.3 + shake, 1.95 + shake * 0.5, az - 2.35);
          _camLook.set(ax, 1.55, az);
        }
        break;
      }

      case 'iskender': {
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.0) {
          fireOnce('isk_call', () => soundEngine.playPhonePickup());
          const nod = Math.sin(t * 8) * 0.08;
          rig.leftLegPivot.rotation.set(0.1, 0, -0.1);
          rig.rightLegPivot.rotation.set(-0.1, 0, 0.14);
          rig.leftKneePivot.rotation.z = -0.18;
          rig.rightKneePivot.rotation.z = -0.15;
          rig.upperTorsoPivot.rotation.z = -0.08;
          rig.headGroup.rotation.z = nod;
          rig.rightArmPivot.rotation.set(0.24, 0, 0.88);
          rig.rightElbowPivot.rotation.z = 1.08;
          rig.leftArmPivot.rotation.set(0.18, 0, 0.25);
          rig.leftElbowPivot.rotation.z = 0.8;

          props.phone.position.set(0.62, 1.62, 0.22);
          props.phone.rotation.set(0, 0.2, -0.25);
          subtitle = 'Musa görüntülüdeyiz, bekle bi saniye...';
          _camPos.set(ax + 3.4, 2.0, az + 2.3);
          _camLook.set(ax + 0.2, 1.55, az);
        } else {
          fireOnce('sock_boom', () => {
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax + 0.7, 1.0, az), color: style.auraColor, count: 28 };
          });
          const kickP = easeOutBack(Math.min(1, (t - 1.0) / 0.42));
          // Smoothly place phone on turf facing up at him
          const dropP = easeOutCubic(Math.min(1, (t - 1.0) / 0.28));
          props.phone.position.set(
            THREE.MathUtils.lerp(0.62, 1.15, dropP),
            THREE.MathUtils.lerp(1.62, 0.12, dropP),
            THREE.MathUtils.lerp(0.22, 0.48, dropP)
          );
          props.phone.rotation.set(0, -0.2, THREE.MathUtils.lerp(-0.25, -1.25, dropP));

          // Grounded left leg supports weight while torso leans back and right leg kicks high!
          rig.bodyPivot.position.y = -0.08 * kickP;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.2 * kickP);
          rig.leftKneePivot.rotation.z = -0.26 * kickP;
          rig.upperTorsoPivot.rotation.set(0, -0.18 * kickP, 0.34 * kickP);
          rig.headGroup.rotation.z = -0.24 * kickP;

          // Arms out wide for martial-arts balance
          rig.leftArmPivot.rotation.set(0.65 * kickP, 0, -0.25);
          rig.leftElbowPivot.rotation.z = 0.55;
          rig.rightArmPivot.rotation.set(-0.65 * kickP, 0, 0.35);
          rig.rightElbowPivot.rotation.z = 0.55;

          const legAng = THREE.MathUtils.lerp(0.14, 1.48, kickP);
          rig.rightLegPivot.rotation.set(0, 0, legAng);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.35, -0.08, kickP);

          // Glowing sock hugs the lifted right shin/foot cleanly
          props.sock.visible = kickP > 0.35;
          const sockDist = 0.72;
          props.sock.position.set(
            Math.sin(legAng) * sockDist,
            0.92 - 0.08 * kickP - Math.cos(legAng) * sockDist,
            0.18
          );
          props.sock.rotation.set(0, 0, legAng - Math.PI);
          props.sock.scale.setScalar(1.22);

          showAura(kickP);
          subtitle = 'Musa iyi izle, ÇORABIMA BAK LAN!';
          _camPos.set(ax + 2.9, 1.45, az + 1.55);
          _camLook.set(ax + 0.6, 1.15, az + 0.1);
        }
        break;
      }

      case 'aras': {
        props.desk.visible = true;
        props.desk.position.set(1.45, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.aras_lose;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.05) {
          fireOnce('aras_lose_sfx', () => soundEngine.playGlitchBeep());
          // Hunched seated/crouched posture at desk staring at 0-5 defeat screen
          const shake = Math.sin(t * 6) * 0.04;
          rig.bodyPivot.position.set(0.12, -0.22, 0);
          rig.upperTorsoPivot.rotation.z = -0.32;
          rig.headGroup.rotation.set(0, shake, -0.18);
          rig.leftLegPivot.rotation.set(0.15, 0, 1.15);
          rig.rightLegPivot.rotation.set(-0.15, 0, 1.15);
          rig.leftKneePivot.rotation.z = -1.28;
          rig.rightKneePivot.rotation.z = -1.28;
          rig.leftArmPivot.rotation.set(0.22, 0, 0.85);
          rig.rightArmPivot.rotation.set(-0.22, 0, 0.85);
          rig.leftElbowPivot.rotation.z = 0.72;
          rig.rightElbowPivot.rotation.z = 0.72;

          subtitle = 'Ekranda: YENİLDİN 0-5 (İSKENDER KAZANDI)';
          _camPos.set(ax - 2.3, 2.45, az + 3.1);
          _camLook.set(ax + 1.1, 1.55, az);
        } else if (t < 1.42) {
          // Explosive double-fist desk slam!
          fireOnce('aras_slam', () => soundEngine.playDeskThud());
          const p = easeOutCubic((t - 1.05) / 0.37);
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(0.12, 0.25, p), THREE.MathUtils.lerp(-0.22, -0.12, p), 0);
          rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(-0.32, -0.52, p);
          rig.leftLegPivot.rotation.set(0.15, 0, 0.9);
          rig.rightLegPivot.rotation.set(-0.15, 0, 0.9);
          rig.leftKneePivot.rotation.z = -1.05;
          rig.rightKneePivot.rotation.z = -1.05;
          rig.leftArmPivot.rotation.set(0.22, 0, 1.15);
          rig.rightArmPivot.rotation.set(-0.22, 0, 1.15);
          rig.leftElbowPivot.rotation.z = 0.42;
          rig.rightElbowPivot.rotation.z = 0.42;

          subtitle = 'İSKENDER KESİN HİLE YAPIYO!!';
          _camPos.set(ax - 2.0, 2.35, az + 3.0);
          _camLook.set(ax + 1.0, 1.5, az);
        } else {
          // Explosive push-back into crimson rage power-up roar!
          fireOnce('aras_rage', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax - 0.15, 1.4, az), color: '#ef4444', count: 36 };
          });
          const p = easeOutCubic(Math.min(1, (t - 1.42) / 0.35));
          const roarVib = Math.sin(t * 28) * 0.04;
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(0.25, -0.22, p), -0.1, 0);
          rig.upperTorsoPivot.rotation.set(0, roarVib, THREE.MathUtils.lerp(-0.3, 0.28, p));
          rig.headGroup.rotation.set(roarVib * 1.5, 0, 0.32 * p);

          // Wide braced athletic stance
          rig.leftLegPivot.rotation.set(0.24, 0, -0.28);
          rig.rightLegPivot.rotation.set(-0.24, 0, 0.32);
          rig.leftKneePivot.rotation.z = -0.46;
          rig.rightKneePivot.rotation.z = -0.4;

          // Fists clenched tight at waist/chest roaring
          rig.leftArmPivot.rotation.set(0.55, 0, -0.45 + roarVib);
          rig.rightArmPivot.rotation.set(-0.55, 0, -0.45 - roarVib);
          rig.leftElbowPivot.rotation.z = 1.65;
          rig.rightElbowPivot.rotation.z = 1.65;

          showAura(p);
          rig.auraPillars.position.x = -0.22;
          rig.auraRing.position.x = -0.22;
          subtitle = 'İSKENDER KESİN HİLE YAPIYO! YETER LAN!';
          const camShake = Math.sin(t * 50) * 0.08;
          _camPos.set(ax + 2.8 + camShake, 1.95 + camShake * 0.4, az + 2.6);
          _camLook.set(ax - 0.15, 1.55, az);
        }
        break;
      }

      case 'ebulfez': {
        if (t < 1.1) {
          // Turn heroically & raise Infinity Gauntlet arm in front of face
          const raiseP = easeInOutCubic(t / 0.85);
          rig.bodyPivot.rotation.y = -0.32 * raiseP;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.14);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.14);
          rig.leftKneePivot.rotation.z = -0.2;
          rig.rightKneePivot.rotation.z = -0.2;
          rig.upperTorsoPivot.rotation.set(0, 0.22 * raiseP, 0.08 * raiseP);

          rig.rightArmPivot.rotation.set(0.28 * raiseP, 0, 1.25 * raiseP);
          rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(0.25, 1.05, raiseP);
          rig.leftArmPivot.rotation.set(0.12, 0, -0.18);
          rig.leftElbowPivot.rotation.z = 0.45;

          subtitle = 'Bir daha görüşmemek dileğiyle...';
          _camPos.set(ax + 3.1, 1.9, az + 1.8);
          _camLook.set(ax, 1.65, az);
        } else if (t < 2.0) {
          fireOnce('snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 40 };
          });
          const p = (t - 1.1) / 0.9;
          const fade = Math.max(0, 1 - p * 3.2);
          if (fade > 0.04) {
            rig.bodyPivot.visible = true;
            rig.bodyPivot.scale.setScalar(fade);
            rig.bodyPivot.rotation.y = -0.32 + p * 2.4;
            rig.rightArmPivot.rotation.set(0.25, 0, 1.8);
            rig.rightElbowPivot.rotation.z = 0.45;
          } else {
            rig.bodyPivot.visible = false;
          }

          props.snapRing.visible = true;
          props.snapRing.position.set(0, 1.4, 0);
          props.snapRing.scale.setScalar(1 + easeOutCubic(p) * 7.0);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - p);

          subtitle = '*ŞIK!* Geri döndürülemez tozlaşma...';
          _camPos.set(ax + 4.3, 2.35, az + 2.9);
          _camLook.set(ax, 1.45, az);
        } else {
          fireOnce('return_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 0.8, az), color: style.auraColor, count: 34 };
          });
          props.snapRing.visible = false;
          const landP = easeOutCubic(Math.min(1, (t - 2.0) / 0.4));
          rig.bodyPivot.visible = true;
          rig.bodyPivot.scale.setScalar(THREE.MathUtils.lerp(0.25, 1, landP));
          // Dynamic low superhero landing crouch!
          rig.bodyPivot.position.y = (1 - landP) * 0.95 - landP * 0.24;
          rig.bodyPivot.rotation.y = -0.25;
          rig.upperTorsoPivot.rotation.set(0, 0.35, -0.36 * landP);
          rig.headGroup.rotation.z = 0.28 * landP;

          rig.leftLegPivot.rotation.set(0.24, 0, -0.45 * landP);
          rig.leftKneePivot.rotation.z = -0.95 * landP;
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.78 * landP);
          rig.rightKneePivot.rotation.z = -1.25 * landP;

          rig.leftArmPivot.rotation.set(0.28, 0, 1.05 * landP);
          rig.leftElbowPivot.rotation.z = 0.18;
          rig.rightArmPivot.rotation.set(-0.45, 0, -0.65 * landP);
          rig.rightElbowPivot.rotation.z = 0.9;

          showAura(landP);
          subtitle = 'Ebulfez Uyanışı Aktif!';
          _camPos.set(ax + 3.4, 1.85, az - 2.3);
          _camLook.set(ax, 1.15, az);
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(1.45, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('glitch', () => soundEngine.playAiHackComplete());
          // Leaning over desk with bent elbows rapidly typing code
          rig.bodyPivot.position.set(0.2, -0.05, 0);
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.headGroup.rotation.set(0, Math.sin(t * 7) * 0.08, -0.12);
          rig.leftLegPivot.rotation.set(0.12, 0, -0.1);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.12);
          rig.leftKneePivot.rotation.z = -0.24;
          rig.rightKneePivot.rotation.z = -0.24;

          const typeWave = Math.sin(t * 28);
          rig.leftArmPivot.rotation.set(0.18, 0, 0.8 + typeWave * 0.14);
          rig.rightArmPivot.rotation.set(-0.18, 0, 0.8 - typeWave * 0.14);
          rig.leftElbowPivot.rotation.z = 1.15 + typeWave * 0.25;
          rig.rightElbowPivot.rotation.z = 1.15 - typeWave * 0.25;

          subtitle = 'Yapay Zeka hile kodunu yazıyor...';
          _camPos.set(ax - 2.2, 2.35, az + 3.0);
          _camLook.set(ax + 1.0, 1.6, az);
        } else {
          fireOnce('zero_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax - 0.3, 1.4, az), color: '#22d3ee', count: 32 };
          });
          // Backflip/spin leap away from desk and land in cool pointing cyber stance
          const p = (t - 1.15) / (cs.duration - 1.15);
          const airP = clamp01(p / 0.52);
          const airArc = p < 0.52 ? Math.sin(airP * Math.PI) : 0;

          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(0.2, -0.45, easeOutCubic(Math.min(1, p * 2.2))),
            airArc * 1.1,
            0
          );
          rig.bodyPivot.rotation.y = airP * Math.PI * 2;
          rig.upperTorsoPivot.rotation.set(0, -0.22, p < 0.52 ? -0.18 : 0.1);

          if (p < 0.52) {
            rig.leftKneePivot.rotation.z = -1.05 * airArc;
            rig.rightKneePivot.rotation.z = -0.95 * airArc;
            rig.leftArmPivot.rotation.set(0.45, 0, 0.8);
            rig.rightArmPivot.rotation.set(-0.45, 0, 0.8);
          } else {
            // Crisp pointing pose
            rig.leftLegPivot.rotation.set(0.18, 0, -0.2);
            rig.rightLegPivot.rotation.set(-0.18, 0, 0.25);
            rig.leftKneePivot.rotation.z = -0.35;
            rig.rightKneePivot.rotation.z = -0.3;
            rig.rightArmPivot.rotation.set(-0.15, 0, 2.28);
            rig.rightElbowPivot.rotation.z = 0.2;
            rig.leftArmPivot.rotation.set(0.32, 0, -0.38);
            rig.leftElbowPivot.rotation.z = 1.45;
          }

          showAura(Math.min(1, p * 2.5));
          rig.auraPillars.position.x = rig.bodyPivot.position.x;
          rig.auraRing.position.x = rig.bodyPivot.position.x;
          subtitle = 'YAPAY ZEKA HİLEYİ KODLADI! GG EASY!';
          _camPos.set(ax + 3.4, 2.05, az + 2.75);
          _camLook.set(ax - 0.35, 1.55, az);
        }
        break;
      }

      case 'berk': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);
        if (t < 1.55) {
          fireOnce('berk_snore', () => soundEngine.playSnore());
          // Sleeping comfortably with head right ON the pillow (+X = +1.05) and relaxed bent knees
          const snore = Math.sin(t * 4.2) * 0.035;
          rig.bodyPivot.position.set(-1.12, 0.92 + snore, 0);
          rig.bodyPivot.rotation.z = -Math.PI / 2;
          rig.leftLegPivot.rotation.z = 0.26;
          rig.rightLegPivot.rotation.z = 0.42;
          rig.leftKneePivot.rotation.z = -0.45;
          rig.rightKneePivot.rotation.z = -0.68;
          rig.leftArmPivot.rotation.set(0.28, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.4;
          rig.rightArmPivot.rotation.set(-0.2, 0, 0.18);
          rig.rightElbowPivot.rotation.z = 0.85;

          subtitle = 'Of ya... Bi 5 dakika daha yatayım... *Horlar*';
          _camPos.set(ax + 3.4, 2.6, az + 3.0);
          _camLook.set(ax + 0.15, 1.0, az);
        } else if (t < 2.2) {
          // Roll upright and hop off the bed onto the turf
          const p = (t - 1.55) / 0.65;
          const e = easeInOutCubic(p);
          const hop = p > 0.35 ? Math.sin(((p - 0.35) / 0.65) * Math.PI) * 0.65 : 0;
          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(-1.12, 2.0, e),
            THREE.MathUtils.lerp(0.92, 0, e) + hop,
            0
          );
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-Math.PI / 2, 0, Math.min(1, e * 1.4));
          rig.upperTorsoPivot.rotation.z = 0.14;
          rig.leftKneePivot.rotation.z = -0.55;
          rig.rightKneePivot.rotation.z = -0.45;
          // Big overhead yawn stretch!
          rig.leftArmPivot.rotation.set(0.32, 0, 2.45 * e);
          rig.rightArmPivot.rotation.set(-0.32, 0, 2.45 * e);
          rig.leftElbowPivot.rotation.z = 0.55;
          rig.rightElbowPivot.rotation.z = 0.55;

          subtitle = '*Esner* Tamam kalktım...';
          _camPos.set(ax + 4.3, 2.25, az + 2.8);
          _camLook.set(ax + 1.2, 1.4, az);
        } else {
          fireOnce('berk_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax + 2.0, 1.2, az), color: '#60a5fa', count: 26 };
          });
          // Slam into immovable heavyweight tank stance
          const settle = easeOutCubic((t - 2.2) / 0.45);
          rig.bodyPivot.position.set(2.0, -0.06 * settle, 0);
          rig.upperTorsoPivot.rotation.z = -0.18 * settle;
          rig.leftLegPivot.rotation.set(0.24, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.24, 0, 0.24);
          rig.leftKneePivot.rotation.z = -0.42;
          rig.rightKneePivot.rotation.z = -0.42;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.55);
          rig.rightArmPivot.rotation.set(-0.45, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.45;
          rig.rightElbowPivot.rotation.z = 1.45;

          showAura(settle);
          rig.auraPillars.position.x = 2.0;
          rig.auraRing.position.x = 2.0;
          subtitle = 'Tamam kalktım, topu verin!';
          _camPos.set(ax + 4.8, 2.05, az + 2.75);
          _camLook.set(ax + 2.0, 1.35, az);
        }
        break;
      }
    }
  } else if (cs.kind === 'COMBO') {
    // ================= MUSAB x MUSA UZAK MESAFE KOMBİNE PAS & GÖKYÜZÜ ROVEŞATA =================
    const musabRig = rig;
    const musaRig = partnerRig ?? rig;
    // Far-apart long-distance pitch coordinates (~22m cross-field pass!)
    const centerX = THREE.MathUtils.clamp(ax, -PITCH_HALF_LENGTH + 18, PITCH_HALF_LENGTH - 18);
    const centerZ = THREE.MathUtils.clamp(az, -18, 18);
    const musabStartX = centerX - 11.5;
    const musabStartZ = centerZ - 4.4;
    const musaX = centerX + 9.5;
    const musaZ = centerZ + 3.2;

    musabRig.root.position.set(musabStartX, 0, musabStartZ);
    musabRig.root.rotation.set(0, -0.34, 0);
    if (musaRig !== musabRig) {
      musaRig.root.position.set(musaX, 0, musaZ);
      musaRig.root.rotation.set(0, 0.14, 0);
    }

    if (t < 1.35) {
      // Phase 1: Musab fires a sweeping 22m long aerial pass across the pitch while Musa sprints & leaps!
      fireOnce('combo_launch', () => {
        soundEngine.playAwakeningBoom();
        spawnBurst = { pos: new THREE.Vector3(musabStartX + 0.8, 1.0, musabStartZ), color: '#facc15', count: 32 };
      });
      if (t > 0.35) {
        fireOnce('combo_pass_kick', () => soundEngine.playKick(0.82));
      }
      const p = easeOutCubic(t / 1.35);
      const kickP = easeOutCubic(clamp01((t - 0.15) / 0.5));
      const runMusa = clamp01(t / 1.0);
      const leapMusa = easeOutCubic(clamp01((t - 0.78) / 0.57));

      // Musab plant & long lofted pass follow-through (stays nicely framed on ground/slight hop)
      musabRig.bodyPivot.position.set(p * 1.4, Math.sin(kickP * Math.PI) * 0.45, 0);
      musabRig.bodyPivot.rotation.set(0, -0.25 * kickP, -0.18 * kickP);
      musabRig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.3, -0.45, kickP), -0.16);
      musabRig.leftKneePivot.rotation.z = -0.38;
      musabRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.75, 1.52, kickP);
      musabRig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.1, -0.12, kickP);
      musabRig.leftArmPivot.rotation.set(0.45, 0, 1.05);
      musabRig.rightArmPivot.rotation.set(-0.45, 0, -0.55);

      // Musa sprints forward across distance then leaps high into the air!
      if (musaRig !== musabRig) {
        const stride = Math.sin(t * 14);
        musaRig.bodyPivot.position.set(THREE.MathUtils.lerp(-4.5, 0, runMusa), leapMusa * 3.45, 0);
        musaRig.bodyPivot.rotation.z = leapMusa * 0.65;
        musaRig.upperTorsoPivot.rotation.z = -0.22;
        musaRig.leftLegPivot.rotation.z = (1 - leapMusa) * stride * 0.72;
        musaRig.rightLegPivot.rotation.z = (1 - leapMusa) * -stride * 0.72;
        musaRig.leftKneePivot.rotation.z = -0.55 - leapMusa * 0.55;
        musaRig.rightKneePivot.rotation.z = -0.55 - leapMusa * 0.45;
        musaRig.leftArmPivot.rotation.set(0.4, 0, 0.85);
        musaRig.rightArmPivot.rotation.set(-0.4, 0, 0.85);
      }

      // Long 22m high aerial arc from Musab to Musa's sky point (NEVER drops below peak!)
      const passArc = easeInOutCubic(clamp01((t - 0.25) / 1.1));
      const bx = THREE.MathUtils.lerp(musabStartX + 1.0, musaX + 0.55, passArc);
      const bz = THREE.MathUtils.lerp(musabStartZ + 0.3, musaZ, passArc);
      const by = THREE.MathUtils.lerp(0.65, 4.15, passArc) + Math.sin(passArc * Math.PI) * 1.45;
      ballGroup.position.set(bx, by, bz);
      ballGroup.rotation.y += dt * 18;

      showAuraOn(musabRig, 0.9);
      if (musaRig !== musabRig) showAuraOn(musaRig, 0.95);

      subtitle = 'MUSAB UZAKTAN HAVADAN ADRESE TESLİM ATTI — MUSA GÖKYÜZÜNE UÇTU!!';
      // Dynamic tracking camera follows the long aerial ball across the pitch!
      _camPos.set(bx - 4.8, Math.max(2.6, by + 0.6), bz + 7.2);
      _camLook.set(bx + 1.4, Math.max(1.8, by * 0.82), bz);
    } else if (t < 2.4) {
      // Phase 2: Musa coils upside-down HIGH above turf (head stays at y ≈ 1.7m, zero ground clipping!)
      fireOnce('combo_sync', () => {
        soundEngine.playAwakenedImpact();
        spawnBurst = { pos: new THREE.Vector3(musaX + 0.55, 4.15, musaZ), color: '#38bdf8', count: 36 };
      });
      const p = easeInOutCubic((t - 1.35) / 1.05);

      // Musab runs forward cheering in background
      musabRig.bodyPivot.position.set(1.4 + p * 2.2, Math.abs(Math.sin(t * 10)) * 0.14, 0);
      musabRig.leftKneePivot.rotation.z = -0.32;
      musabRig.rightKneePivot.rotation.z = -0.32;
      musabRig.leftArmPivot.rotation.set(0.35, 0, 2.35);
      musabRig.rightArmPivot.rotation.set(-0.35, 0, 2.35);

      if (musaRig !== musabRig) {
        // Suspended cleanly at y = 3.55m so inverted head is at ~1.7m above grass!
        musaRig.bodyPivot.position.set(0, 3.55, 0);
        musaRig.bodyPivot.rotation.z = THREE.MathUtils.lerp(0.65, Math.PI * 0.82, p);
        musaRig.upperTorsoPivot.rotation.set(0, -0.22 * p, 0.22);
        musaRig.leftLegPivot.rotation.z = THREE.MathUtils.lerp(0.2, 0.48, p);
        musaRig.leftKneePivot.rotation.z = -1.1;
        musaRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(0.1, -0.68, p);
        musaRig.rightKneePivot.rotation.z = -1.2;
        musaRig.leftArmPivot.rotation.set(0.6, 0, 0.55);
        musaRig.rightArmPivot.rotation.set(-0.6, 0, 0.55);
      }

      // Ball stays LOCKED STEADY at high apex (y = 4.15m) right above Musa's boot!
      ballGroup.position.set(musaX + 0.65, 4.15, musaZ);
      ballGroup.rotation.y += dt * 24;
      props.snapRing.visible = true;
      props.snapRing.position.set(musaX - ax + 0.65, 4.15, musaZ - az);
      props.snapRing.rotation.set(0, 0, t * 4);
      props.snapRing.scale.setScalar(1.05 + Math.sin(t * 14) * 0.14);

      showAuraOn(musabRig, 1.0);
      if (musaRig !== musabRig) showAuraOn(musaRig, 1.0);
      subtitle = 'UZAK MESAFE ÇİFT EGOİST SENKRONU — ROVEŞATA HAZIRLIĞI!!';
      // Wide unobstructed stadium framing showing full upside-down body + ball + Musab in distance!
      _camPos.set(musaX - 1.4, 3.25, musaZ + 7.4);
      _camLook.set(musaX + 0.1, 2.75, musaZ);
    } else {
      fireOnce('combo_rovesata_boom', () => {
        soundEngine.playAwakeningBoom();
        soundEngine.playKick(1.0);
        spawnBurst = { pos: new THREE.Vector3(musaX + 0.75, 4.15, musaZ), color: '#facc15', count: 44 };
      });
      props.snapRing.visible = false;
      const p = clamp01((t - 2.4) / 0.95);
      const whip = easeOutCubic(Math.min(1, p * 2.1));

      musabRig.bodyPivot.position.set(3.6, Math.abs(Math.sin(t * 10)) * 0.1, 0);
      musabRig.leftArmPivot.rotation.set(0.35, 0, 2.5);
      musabRig.rightArmPivot.rotation.set(-0.35, 0, 2.5);

      if (musaRig !== musabRig) {
        musaRig.bodyPivot.position.set(0, 3.55 - p * 0.25, 0);
        musaRig.bodyPivot.rotation.z = Math.PI * 0.82 + whip * 0.2;
        musaRig.upperTorsoPivot.rotation.set(0, -0.35, 0.2);
        musaRig.leftLegPivot.rotation.z = 0.28;
        musaRig.leftKneePivot.rotation.z = -1.2;
        musaRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.68, 1.78, whip);
        musaRig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.2, -0.08, whip);
        musaRig.leftArmPivot.rotation.set(0.75, 0, -0.35);
        musaRig.rightArmPivot.rotation.set(-0.75, 0, -0.35);
      }

      // Ball stays cleanly at y = 4.15m on contact!
      ballGroup.position.set(musaX + 0.75 + whip * 0.45, 4.15, musaZ);
      ballGroup.rotation.y += dt * 34;

      showAuraOn(musabRig, 1.0);
      if (musaRig !== musabRig) showAuraOn(musaRig, 1.0);
      subtitle = 'MUSAB × MUSA: GÖKYÜZÜ İKİZ ROVEŞATA FÜZESİ!!';
      _camPos.set(musaX - 4.8, 3.6, musaZ + 6.8);
      _camLook.set(musaX + 1.2, 3.1, musaZ);

      if (t >= cs.duration - 0.05) {
        launchShot = {
          from: new THREE.Vector3(musaX + 1.0, 4.0, musaZ),
          range: 'FULL_PITCH',
          curve: 0.22,
          speed: 66,
          loft: 5.2,
          stealAndTeleportPos: new THREE.Vector3(musaX, 0, musaZ),
        };
      }
    }
  } else {
    // ================= ULTI / AWAKENING SHOTS =================
    switch (cs.styleId) {
      case 'musab': {
        props.desk.visible = true;
        props.desk.position.set(2.2, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.bluelock_game;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.05) {
          fireOnce('musab_bounce', () => soundEngine.playKick(0.35));
          if (t > 0.45) fireOnce('musab_bounce2', () => soundEngine.playKick(0.35));
          const bounce = Math.abs(Math.sin(t * 11)) * 0.7;
          ballGroup.position.set(ax, 2.85 + bounce, az);
          rig.headGroup.rotation.z = Math.sin(t * 11) * 0.16;
          rig.leftKneePivot.rotation.z = -0.18;
          rig.rightKneePivot.rotation.z = -0.18;
          rig.leftArmPivot.rotation.set(0.32, 0, 0.35);
          rig.rightArmPivot.rotation.set(-0.32, 0, 0.35);
          rig.leftElbowPivot.rotation.z = 1.1;
          rig.rightElbowPivot.rotation.z = 1.1;
          subtitle = 'Monitörde Blue Lock oynarken topu kafasında sektiriyor...';
          _camPos.set(ax - 2.8, 2.8, az + 3.8);
          _camLook.set(ax + 1.5, 2.0, az);
        } else if (t < 2.15) {
          fireOnce('monster', () => {
            soundEngine.playHorrorMonitorBurst();
            spawnBurst = { pos: new THREE.Vector3(ax + 2.1, 2.0, az), color: '#a855f7', count: 32 };
          });
          const p = easeOutCubic((t - 1.05) / 1.1);
          props.monsterBall.visible = true;
          props.monsterBall.position.set(
            THREE.MathUtils.lerp(2.0, 0.45, p),
            THREE.MathUtils.lerp(2.05, 3.85, p),
            0
          );
          props.monsterBall.scale.setScalar(0.8 + p * 0.75);
          props.monsterBall.rotation.y += dt * 10;
          ballGroup.position.set(ax + props.monsterBall.position.x, props.monsterBall.position.y, az);
          rig.upperTorsoPivot.rotation.z = 0.18 * p;
          rig.headGroup.rotation.z = 0.42 * p;
          rig.leftKneePivot.rotation.z = -0.35 * p;
          rig.rightKneePivot.rotation.z = -0.35 * p;
          showAura(p);
          subtitle = 'MONİTÖRDEN KÂBUS GİBİ SAHAYA ÇIKTI!!';
          _camPos.set(ax + 4.8, 2.4, az + 4.0);
          _camLook.set(ax + 0.5, 2.8, az);
        } else {
          fireOnce('headset_off', () => {
            if (rig.headsetProp) rig.headsetProp.visible = false;
            props.deskHeadset.visible = true;
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
          });
          props.monsterBall.visible = false;
          const p = clamp01((t - 2.15) / 1.15);
          const leap = easeOutCubic(Math.min(1, p * 1.7));
          const strike = easeOutCubic(clamp01((p - 0.35) / 0.45));
          // Player leaps up to meet the suspended ball at y = 4.25m (no ground clip!)
          rig.bodyPivot.position.y = leap * 3.65;
          rig.bodyPivot.rotation.z = -leap * Math.PI * 0.65;
          rig.upperTorsoPivot.rotation.set(0, -0.42 * strike, -0.24);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.55, 1.52, strike);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.15, -0.1, strike);
          rig.leftLegPivot.rotation.z = -0.35;
          rig.leftKneePivot.rotation.z = -0.95;
          rig.leftArmPivot.rotation.set(0.45, 0, 1.05);
          rig.rightArmPivot.rotation.set(-0.35, 0, -0.55);
          rig.leftElbowPivot.rotation.z = 0.75;
          rig.rightElbowPivot.rotation.z = 0.75;
          showAura(1.0);
          // Ball hovers steady at 4.25m in mid-air while Musab strikes it!
          ballGroup.position.set(ax + 0.65, 4.25, az);
          ballGroup.rotation.y += dt * 20;
          subtitle = 'KULAKLIĞI MASAYA KOYDU — KALEDEN KALEYE VOLE!!';
          _camPos.set(ax - 4.2, 3.6, az + 6.4);
          _camLook.set(ax + 0.5, 3.1, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 0.8, 3.85, az),
              range: 'FULL_PITCH',
              curve: 0.15,
              speed: 58,
              loft: 6.5,
            };
          }
        }
        break;
      }

      case 'musa': {
        if (t < 1.15) {
          props.pillow.visible = true;
          props.pillow.position.set(1.2, 0.2, 0);
          const runP = t / 1.15;
          rig.bodyPivot.position.x = THREE.MathUtils.lerp(-0.9, 0.35, easeInOutCubic(runP));
          const stride = Math.sin(runP * Math.PI * 3.5);
          rig.leftLegPivot.rotation.z = stride * 0.75;
          rig.rightLegPivot.rotation.z = -stride * 0.75;
          rig.leftKneePivot.rotation.z = -0.65;
          rig.rightKneePivot.rotation.z = -0.85;
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.leftArmPivot.rotation.set(0.15, 0, -stride * 0.65);
          rig.rightArmPivot.rotation.set(-0.15, 0, stride * 0.65);
          rig.leftElbowPivot.rotation.z = 1.05;
          rig.rightElbowPivot.rotation.z = 1.05;
          ballGroup.position.set(ax + 1.2, -5, az);
          subtitle = 'Musa yerdeki yastığa doğru koşuyor...';
          _camPos.set(ax + 3.8, 1.8, az + 3.4);
          _camLook.set(ax + 0.8, 0.9, az);
        } else {
          const kP = clamp01((t - 1.15) / 1.35);
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.38));
          if (kP > 0.26) {
            fireOnce('pillow_transform', () => {
              soundEngine.playPillowTransform();
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(ax + 1.25, 0.7, az), color: '#38bdf8', count: 36 };
            });
          }
          props.pillow.visible = kP < 0.28;
          props.pillow.position.set(1.2, 0.2, 0);

          // Dynamic windup -> explosive whip kick!
          rig.bodyPivot.position.x = 0.35 + kickP * 0.25;
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(0.08, -0.28, kickP);
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.28, -0.45, kickP), -0.18);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.92, windP) : THREE.MathUtils.lerp(-0.92, 1.48, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.2, -1.2, windP) : THREE.MathUtils.lerp(-1.2, -0.12, kickP);
          rig.leftLegPivot.rotation.z = -0.28;
          rig.leftKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.35, 0, THREE.MathUtils.lerp(-0.4, 0.95, kickP));
          rig.leftElbowPivot.rotation.z = 0.9;
          rig.rightArmPivot.rotation.set(-0.25, 0, -0.55);
          showAura(Math.max(0.4, kickP));
          ballGroup.position.set(ax + 1.35, kP < 0.28 ? -5 : 0.68, az);
          subtitle = 'YASTIK TOPA DÖNÜŞTÜ — KALEDEN KALEYE SONİK ŞUT!!';
          _camPos.set(ax - 2.8, 1.9, az + 3.6);
          _camLook.set(ax + 5.0, 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 1.4, 0.68, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 62,
              loft: 4.5,
            };
          }
        }
        break;
      }

      case 'iskender': {
        if (t < 1.05) {
          fireOnce('isk_ulti_say', () => soundEngine.playPhonePickup());
          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(1.6, 0.2, 0.72);
          props.phone.rotation.set(0, -0.25, -1.2);

          // Explosive launch upward into upside-down bicycle-kick arch high above grass!
          const p = easeOutCubic(t / 1.05);
          rig.bodyPivot.position.y = p * 3.45;
          rig.bodyPivot.rotation.z = p * Math.PI * 0.82;
          rig.upperTorsoPivot.rotation.z = 0.22 * p;
          rig.leftKneePivot.rotation.z = -1.05 * p;
          rig.rightLegPivot.rotation.z = -0.45 * p;
          rig.rightKneePivot.rotation.z = -1.1 * p;
          rig.leftArmPivot.rotation.set(0.55, 0, 0.75);
          rig.rightArmPivot.rotation.set(-0.55, 0, 0.75);
          ballGroup.position.set(ax, -5, az);
          subtitle = 'Görüntülü konuşmada boşluğa rovaşataya kalkıyor...';
          _camPos.set(ax + 4.4, 2.8, az + 5.6);
          _camLook.set(ax, 2.3, az);
        } else {
          fireOnce('isk_tp', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: new THREE.Vector3(ax + 0.75, 4.05, az), color: '#2dd4bf', count: 36 };
          });
          props.phone.visible = false;
          const p = clamp01((t - 1.05) / 1.75);
          const whip = easeOutCubic(clamp01(p / 0.55));
          // İskender stays suspended cleanly at y = 3.45m; head stays well above grass & ball hovers at y = 4.05m!
          rig.bodyPivot.position.y = 3.45;
          rig.bodyPivot.rotation.z = Math.PI * 0.82 + whip * 0.16;
          rig.upperTorsoPivot.rotation.set(0, -0.28 * whip, 0.22);
          rig.leftLegPivot.rotation.z = 0.22;
          rig.leftKneePivot.rotation.z = -1.18;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.45, 1.72, whip);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.1, -0.08, whip);
          rig.leftArmPivot.rotation.set(0.65, 0, 0.2);
          rig.rightArmPivot.rotation.set(-0.65, 0, 0.2);
          showAura(1.0);
          ballGroup.position.set(ax + 0.75, 4.05, az);
          ballGroup.rotation.y += dt * 26;
          subtitle = 'SAHAYA IŞINLANDI — HAVADA DURAN TOPA ROVEŞATA!!';
          _camPos.set(ax - 4.2, 3.4, az + 6.4);
          _camLook.set(ax + 1.0, 2.85, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 0.9, 4.0, az),
              range: 'FULL_PITCH',
              curve: -0.1,
              speed: 56,
              loft: 6.0,
            };
          }
        }
        break;
      }

      case 'aras': {
        props.coach.visible = true;
        props.coach.position.set(-2.2, 0, -1.8);
        props.coach.rotation.y = -0.4;
        props.hamburger.visible = true;

        if (t < 1.15) {
          fireOnce('aras_coach', () => soundEngine.playWhistle());
          if (t > 0.75) {
            fireOnce('burger_land', () => soundEngine.playBurgerSplat());
          }
          const p = t / 1.15;
          rig.bodyPivot.position.y = -0.38;
          rig.upperTorsoPivot.rotation.z = 0.25;
          rig.leftLegPivot.rotation.set(0.16, 0, 1.15);
          rig.rightLegPivot.rotation.set(-0.16, 0, 1.15);
          rig.leftKneePivot.rotation.z = -0.85;
          rig.rightKneePivot.rotation.z = -0.85;
          rig.leftArmPivot.rotation.set(0.25, 0, -0.45);
          rig.rightArmPivot.rotation.set(-0.25, 0, -0.45);

          props.hamburger.position.set(
            THREE.MathUtils.lerp(-1.8, 2.4, p),
            Math.sin(p * Math.PI) * 2.8 + 0.1,
            THREE.MathUtils.lerp(-1.4, 0, p)
          );
          ballGroup.position.set(ax + 2.8, 0.36, az);
          subtitle = 'Antrenör Aras kalksın diye yere HAMBURGER attı!';
          _camPos.set(ax + 4.5, 2.2, az + 4.2);
          _camLook.set(ax + 0.5, 1.1, az);
        } else {
          const kP = clamp01((t - 1.15) / 1.45);
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.42));
          if (kP > 0.24) {
            fireOnce('burger_tp', () => {
              soundEngine.playTeleportWhoosh();
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(ax + 2.4, 0.8, az), color: '#ef4444', count: 34 };
            });
          }
          props.hamburger.position.set(2.4, 0.05, 0);
          rig.bodyPivot.position.set(1.9 + kickP * 0.22, Math.sin(kP * Math.PI) * 0.3, 0);
          rig.bodyPivot.rotation.z = -0.25 * kickP;
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.25, -0.45, kickP), -0.2);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.85, windP) : THREE.MathUtils.lerp(-0.85, 1.5, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.25, -1.15, windP) : THREE.MathUtils.lerp(-1.15, -0.1, kickP);
          rig.leftKneePivot.rotation.z = -0.38;
          rig.leftArmPivot.rotation.set(0.4, 0, 0.9);
          rig.rightArmPivot.rotation.set(-0.2, 0, -0.6);
          showAura(1.0);
          rig.auraPillars.position.x = rig.bodyPivot.position.x;
          rig.auraRing.position.x = rig.bodyPivot.position.x;
          ballGroup.position.set(ax + 2.8, 0.58, az);
          subtitle = 'ARAS HAMBURGERİN YANINA IŞINLANDI — KALEDEN KALEYE!!';
          _camPos.set(ax - 1.5, 2.2, az + 4.2);
          _camLook.set(ax + 3.5, 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(ax + 2.8, 0.6, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 58,
              loft: 4.8,
            };
          }
        }
        break;
      }

      case 'ebulfez': {
        const targetPos = cs.opponentPos.clone();
        if (t < 0.85) {
          fireOnce('ebu_snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 28 };
          });
          const p = easeOutCubic(t / 0.85);
          rig.rightArmPivot.rotation.set(0.25, 0, 1.5 * p);
          rig.rightElbowPivot.rotation.z = 0.85;
          props.snapRing.visible = true;
          props.snapRing.position.set(0, 1.3, 0);
          props.snapRing.scale.setScalar(1 + p * 4.5);
          subtitle = '*ŞIK!* Geri geldim!';
          _camPos.set(ax + 3.5, 2.2, az + 3.2);
          _camLook.set(ax, 1.4, az);
        } else {
          fireOnce('ebu_leap', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: targetPos.clone().setY(1.8), color: '#e879f9', count: 32 };
          });
          props.snapRing.visible = false;
          rig.root.position.set(targetPos.x, 0, targetPos.z);
          props.root.position.set(targetPos.x, 0, targetPos.z);
          const p = clamp01((t - 0.85) / 1.65);
          const flipP = easeInOutCubic(Math.min(1, p * 1.15));
          const strikeP = easeOutCubic(clamp01((p - 0.45) / 0.4));
          // Ebulfez flips over opponent and strikes ball hovering cleanly at y = 2.45m (no sudden drop!)
          rig.bodyPivot.position.set(flipP * 1.6 - 0.65, Math.sin(flipP * Math.PI * 0.85) * 2.55, 0);
          rig.bodyPivot.rotation.z = -flipP * Math.PI * 1.35;
          rig.leftKneePivot.rotation.z = -1.0;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.4, 1.45, strikeP);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.9, -0.15, strikeP);
          rig.leftArmPivot.rotation.set(0.35, 0, 1.1);
          rig.rightArmPivot.rotation.set(-0.35, 0, 1.1);
          showAura(1.0);
          const liftP = easeOutCubic(Math.min(1, p * 2.4));
          ballGroup.position.set(targetPos.x + 1.15, THREE.MathUtils.lerp(1.2, 2.45, liftP), targetPos.z);
          subtitle = 'GERİ GELDİM! RAKİBİN ÜSTÜNDEN ZIPLAYIP ÇALDI!!';
          _camPos.set(targetPos.x - 3.6, 3.0, targetPos.z + 4.4);
          _camLook.set(targetPos.x + 1.0, 2.1, targetPos.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(targetPos.x + 1.2, 2.45, targetPos.z),
              range: 'FULL_PITCH',
              curve: 0.25,
              speed: 52,
              loft: 5.2,
              stealAndTeleportPos: new THREE.Vector3(targetPos.x + 1.0, 0, targetPos.z),
            };
          }
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(-1.6, 0, -1.4);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('zero_ai', () => soundEngine.playAiHackComplete());
          const p = t / 1.15;
          ballGroup.position.set(ax + 1.1, 1.3 + Math.sin(p * 12) * 0.14, az);
          rig.upperTorsoPivot.rotation.z = 0.08;
          rig.rightArmPivot.rotation.set(0.2, 0, 1.55);
          rig.rightElbowPivot.rotation.z = 0.45;
          rig.leftKneePivot.rotation.z = -0.25;
          rig.rightKneePivot.rotation.z = -0.25;
          subtitle = 'AI HİLE AKTİF: Top havada otomatik kontrol ediliyor...';
          _camPos.set(ax + 3.6, 2.2, az + 3.4);
          _camLook.set(ax + 0.8, 1.4, az);
        } else {
          const kP = clamp01((t - 1.15) / 1.25);
          const windP = clamp01(kP / 0.25);
          const kickP = easeOutCubic(clamp01((kP - 0.22) / 0.42));
          if (kP > 0.24) {
            fireOnce('zero_kick', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(0.95);
              spawnBurst = { pos: new THREE.Vector3(ax + 1.15, 1.3, az), color: '#22d3ee', count: 28 };
            });
          }
          rig.rightLegPivot.rotation.z =
            kP < 0.22 ? THREE.MathUtils.lerp(0, -0.82, windP) : THREE.MathUtils.lerp(-0.82, 1.58, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.22 ? THREE.MathUtils.lerp(-0.2, -1.05, windP) : THREE.MathUtils.lerp(-1.05, -0.1, kickP);
          rig.leftKneePivot.rotation.z = -0.32;
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.2, -0.45, kickP), -0.22);
          rig.leftArmPivot.rotation.set(0.45, 0, 0.9);
          showAura(1.0);
          ballGroup.position.set(ax + 1.25, 1.3, az);
          subtitle = 'ORTA SAHA HİLELİ FALSOLU VURUŞ!!';
          _camPos.set(ax - 3.2, 2.4, az + 3.8);
          _camLook.set(ax + 4.0, 1.2, az);

          if (t >= cs.duration - 0.05) {
            const clampedX = Math.max(-2, ax);
            launchShot = {
              from: new THREE.Vector3(ax + 1.2, 1.3, az),
              range: 'MIDFIELD',
              curve: az >= 0 ? -1.4 : 1.4,
              speed: clampedX >= -4 ? 46 : 36,
              loft: 5.5,
            };
          }
        }
        break;
      }

      case 'berk': {
        const stealOrigin = new THREE.Vector3(
          Math.max(-4, Math.min(PITCH_HALF_LENGTH - 12, cs.opponentPos.x)),
          0,
          cs.opponentPos.z
        );
        if (t < 0.95) {
          fireOnce('berk_steal', () => {
            soundEngine.playKick(0.7);
            spawnBurst = { pos: stealOrigin.clone().setY(1.0), color: '#60a5fa', count: 22 };
          });
          const p = easeOutCubic(t / 0.95);
          rig.root.position.copy(stealOrigin);
          rig.bodyPivot.rotation.z = -0.2 * p;
          rig.upperTorsoPivot.rotation.z = -0.22 * p;
          rig.leftKneePivot.rotation.z = -0.42;
          rig.rightKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.4, 0, 0.55);
          rig.rightArmPivot.rotation.set(-0.4, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.25;
          rig.rightElbowPivot.rotation.z = 1.25;
          ballGroup.position.set(stealOrigin.x + 1.0, 0.36, stealOrigin.z);
          subtitle = 'Berk orta sahadan gövde gücüyle topu kaptı!';
          _camPos.set(stealOrigin.x - 3.4, 2.3, stealOrigin.z + 3.6);
          _camLook.set(stealOrigin.x + 0.8, 1.2, stealOrigin.z);
        } else {
          const kP = clamp01((t - 0.95) / 1.35);
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.42));
          if (kP > 0.24) {
            fireOnce('berk_shoot', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(0.95);
            });
          }
          rig.root.position.copy(stealOrigin);
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.22, -0.42, kickP), -0.24);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.88, windP) : THREE.MathUtils.lerp(-0.88, 1.48, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.2, -1.12, windP) : THREE.MathUtils.lerp(-1.12, -0.12, kickP);
          rig.leftKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.95);
          showAura(1.0);
          ballGroup.position.set(stealOrigin.x + 1.2, 0.55, stealOrigin.z);
          subtitle = 'ORTA SAHADAN AĞIR TOP FÜZESİ!!';
          _camPos.set(stealOrigin.x - 3.0, 2.1, stealOrigin.z + 3.4);
          _camLook.set(stealOrigin.x + 4.0, 1.2, stealOrigin.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(stealOrigin.x + 1.2, 0.55, stealOrigin.z),
              range: 'MIDFIELD',
              curve: 0,
              speed: 42,
              loft: 4.2,
              stealAndTeleportPos: stealOrigin.clone(),
            };
          }
        }
        break;
      }
    }
  }

  return {
    finished: t >= cs.duration,
    cameraPos: _camPos.clone(),
    cameraLook: _camLook.clone(),
    banner: {
      active: true,
      speaker: cs.kind === 'COMBO' ? 'MUSAB × MUSA' : style.name,
      subtitle,
      badge,
      accentColor: cs.kind === 'COMBO' ? '#facc15' : style.auraColor,
    },
    spawnBurst,
    launchShot,
  };
}
