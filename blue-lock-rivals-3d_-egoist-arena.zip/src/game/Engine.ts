import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { soundEngine } from '../audio/soundEngine';
import { DEFAULT_SETTINGS, DEFAULT_WARDROBE } from '../data/cosmetics';
import { getRoleSpawnOffset, ROLES } from '../data/roles';
import { FLOWS, STYLE_LIST, STYLES } from '../data/styles';
import { EMOTE_LIST } from '../data/voiceScripts';
import type { MultiplayerClient } from '../network/onlineClient';
import type {
  ActionAnimId,
  EmoteId,
  FlowId,
  GameSettings,
  GkDifficulty,
  HudSnapshot,
  MatchMode,
  MatchPhase,
  MatchStats,
  NetCutsceneEvent,
  NetWorldSnapshot,
  PlayerRole,
  QueueType,
  RadarEntity,
  StyleDefinition,
  StyleId,
  WardrobeConfig,
} from '../types/game';
import {
  ActiveCutscene,
  type CutsceneFrameResult,
  resetAfterCutscene,
  startCutsceneState,
  stepCutscene,
} from './cutscenes';
import {
  buildCutsceneProps,
  buildRobloxPlayer,
  buildSoccerBall,
  buildStadium,
  CutscenePropPack,
  GOAL_DEPTH,
  GOAL_HALF_WIDTH,
  GOAL_HEIGHT,
  PITCH_HALF_LENGTH,
  PITCH_HALF_WIDTH,
  PlayerRig,
  StadiumRefs,
} from './models';

interface Actor {
  id: string;
  isUser: boolean;
  isGoalkeeper: boolean;
  role: PlayerRole;
  gkBallInHands: boolean;
  gkHoldTimer: number;
  gkDiveTimer: number;
  gkDiveCd: number;
  team: 'BLUE' | 'RED';
  style: StyleDefinition;
  rig: PlayerRig;
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  targetYaw: number;
  homePos: THREE.Vector3;
  stunTimer: number;
  dribbleIFrame: number;
  tackleTimer: number;
  stealCooldown: number;
  wallShieldTimer: number;
  awakened: boolean;
  animPhase: number;
  emote: EmoteId | null;
  emoteTimer: number;
  actionAnim: ActionAnimId;
  actionTimer: number;
  actionDuration: number;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
}

const _vecA = new THREE.Vector3();
const _vecB = new THREE.Vector3();
const _vecC = new THREE.Vector3();
const _camTargetPos = new THREE.Vector3();
const _camTargetLook = new THREE.Vector3();
const _camCurrLook = new THREE.Vector3(0, 1, 0);

const MATCH_DURATION_SEC = 180;
const AWAKENING_DURATION_SEC = 18;

export class BlueLockEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private isSoftwareGl: boolean;
  private frameId = 0;
  private disposed = false;

  private stadium!: StadiumRefs;
  private cutsceneProps!: CutscenePropPack;
  private ball!: ReturnType<typeof buildSoccerBall>;
  private actors: Actor[] = [];
  private userActor!: Actor;
  private particles: Particle[] = [];

  // Lighting & Post-processing refs
  private hemiLight!: THREE.HemisphereLight;
  private keyLight!: THREE.DirectionalLight;
  private rimLight!: THREE.DirectionalLight;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;

  // Wardrobe & Live Settings
  private wardrobe: WardrobeConfig = { ...DEFAULT_WARDROBE };
  private settings: GameSettings = { ...DEFAULT_SETTINGS };

  // Ball physics state
  private ballPos = new THREE.Vector3(0, 0.36, 0);
  private ballTargetPos = new THREE.Vector3(0, 0.36, 0);
  private ballVel = new THREE.Vector3(0, 0, 0);
  private ballCurve = 0;
  private ballTopspin = 0;
  private ballOwner: Actor | null = null;
  private lastTouchActorId: string | null = 'user';
  private lastTouchTeam: 'BLUE' | 'RED' = 'BLUE';
  private lastTouchName = 'MUSAB';
  private emoteCursor = 0;
  private isUltiBallActive = false;
  private netRippleTimer = 0;
  private netRippleSide: 'BLUE' | 'RED' = 'RED';

  // Match & Gameplay state
  private phase: MatchPhase = 'IDLE';
  private activeStyleId: StyleId = 'musab';
  private activeFlowId: FlowId = 'egoist';
  private gkDifficulty: GkDifficulty = 'MEDIUM';
  private matchMode: MatchMode = '3V3';
  private selectedRole: PlayerRole = 'CF';
  private isTraining = false;
  private blueScore = 0;
  private redScore = 0;
  private timeRemaining = MATCH_DURATION_SEC;
  private stamina = 100;
  private awakening = 40;
  private isAwakened = false;
  private awakeningTimeLeft = 0;
  private ultiUsedInAwakening = false;
  private matchStats: MatchStats = { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 };

  // Cooldowns & combat feel
  private skill1Cd = 0;
  private skill2Cd = 0;
  private personalCd = 0;
  private dribbleCd = 0;
  private slideCd = 0;
  private speedBoostTimer = 0;
  private shotCharging = false;
  private shotCharge = 0;
  private hitstopTimer = 0;
  private slowMoTimer = 0;
  private cameraShake = 0;
  private goalCelebrationTimer = 0;
  private goalBanner: HudSnapshot['goalBanner'] = null;
  private toastText: string | null = null;
  private toastTimer = 0;

  private activeCutscene: ActiveCutscene | null = null;
  private cutsceneActorRig: PlayerRig | null = null;
  private cutscenePartnerRig: PlayerRig | null = null;
  private cutsceneBanner: HudSnapshot['cutsceneBanner'] = null;
  private isPreviewCutscene = false;

  // Musab <-> Musa aerial combo pass state
  private duoPass: {
    active: boolean;
    passerId: string;
    receiverId: string;
    timer: number;
    autoTriggerTimer: number;
  } | null = null;
  private duoComboCd = 0;
  private aiDuoCooldown = 5.5;
  private netDuoPrompt: HudSnapshot['duoComboPrompt'] = null;

  // Camera orbit & Roblox ShiftLock state
  private camYaw = 0;
  private camPitch = 0.42;
  private camDist = 11.5;
  private shiftLock = false;
  private isRightDragging = false;
  private hasLastMouse = false;
  private lastMouseX = 0;
  private lastMouseY = 0;
  private cameraInitializedForOnline = false;

  // Online mode
  private onlineMode = false;
  private onlineClient: MultiplayerClient | null = null;
  private onlineRoomCode: string | null = null;
  private onlinePingMs: number | null = null;
  private onlineQueueType: QueueType = 'CASUAL';
  private netInputAccum = 0;
  private netHasBall = false;
  private netGkBallInHands = false;
  private netGkHoldLeft = 0;
  private netGkDiveCd = 0;

  // High-FPS loop & measurement
  private fpsFrames = 0;
  private fpsAccum = 0;
  private currentFps = 60;
  private msgChannel: MessageChannel | null = null;
  private lastFramePerfMs = performance.now();
  private highFpsYieldCounter = 0;

  // Input state
  private heldKeys = new Set<string>();
  private onHudUpdate: (snap: HudSnapshot) => void;
  private onMatchEnd: (blue: number, red: number, stats: MatchStats) => void;
  private hudEmitAccum = 0;

  constructor(
    container: HTMLElement,
    initialStyle: StyleId,
    initialFlow: FlowId,
    initialGk: GkDifficulty,
    initialMatchMode: MatchMode,
    initialWardrobe: WardrobeConfig,
    initialSettings: GameSettings,
    onHudUpdate: (snap: HudSnapshot) => void,
    onMatchEnd: (blue: number, red: number, stats: MatchStats) => void,
    initialRole: PlayerRole = 'CF'
  ) {
    this.container = container;
    this.activeStyleId = initialStyle;
    this.activeFlowId = initialFlow;
    this.gkDifficulty = initialGk;
    this.matchMode = initialMatchMode;
    this.selectedRole = initialRole;
    this.wardrobe = { ...initialWardrobe };
    this.settings = { ...initialSettings };
    this.camDist = this.settings.cameraDistance;
    this.onHudUpdate = onHudUpdate;
    this.onMatchEnd = onMatchEnd;

    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.88;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#071226');
    this.scene.fog = new THREE.FogExp2('#071226', 0.0046);

    const aspect = (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(56, aspect, 0.1, 360);
    this.camera.position.set(-12, 8, 14);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight('#bae6fd', '#14532d', 0.52);
    this.hemiLight = hemi;
    this.scene.add(hemi);

    const keyLight = new THREE.DirectionalLight('#fff7ed', 1.22);
    keyLight.position.set(34, 56, 32);
    keyLight.castShadow = !this.isSoftwareGl && this.settings.shadows;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.left = -72;
    keyLight.shadow.camera.right = 72;
    keyLight.shadow.camera.top = 46;
    keyLight.shadow.camera.bottom = -46;
    keyLight.shadow.camera.near = 4;
    keyLight.shadow.camera.far = 160;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    this.keyLight = keyLight;
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight('#38bdf8', 0.42);
    rimLight.position.set(-40, 28, -32);
    this.rimLight = rimLight;
    this.scene.add(rimLight);

    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.stadium = buildStadium(maxAniso);
    this.scene.add(this.stadium.root);

    this.ball = buildSoccerBall(maxAniso);
    this.scene.add(this.ball.group, this.ball.shadow);

    this.cutsceneProps = buildCutsceneProps(maxAniso);
    this.scene.add(this.cutsceneProps.root);

    this.initPostProcessing(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight
    );
    this.applySettings(this.settings);

    this.initParticlePool();
    this.rebuildSoloTeams();
    this.resetKickoffPositions();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    if (typeof MessageChannel !== 'undefined') {
      this.msgChannel = new MessageChannel();
      this.msgChannel.port1.onmessage = () => this.tick();
    }

    this.bindEvents();
    this.clock.start();
    this.lastFramePerfMs = performance.now();
    this.tick();
  }

  private initPostProcessing(w: number, h: number) {
    if (this.isSoftwareGl) return;
    const composer = new EffectComposer(this.renderer);
    composer.setSize(w, h);
    composer.addPass(new RenderPass(this.scene, this.camera));

    const bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.16, 0.42, 0.92);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());

    this.composer = composer;
    this.bloomPass = bloom;
  }

  public setWardrobe(wardrobe: WardrobeConfig) {
    this.wardrobe = { ...wardrobe };
    if (!this.onlineMode && (this.phase === 'IDLE' || this.phase === 'PAUSED') && !this.isPreviewCutscene) {
      if (this.phase === 'IDLE') {
        this.rebuildSoloTeams();
        this.resetKickoffPositions();
      }
    }
  }

  public applySettings(next: GameSettings) {
    this.settings = { ...next };

    // Audio
    soundEngine.setMasterVolume(next.masterVolume);

    // Camera FOV & Distance
    if (Math.abs(this.camera.fov - next.fov) > 0.1) {
      this.camera.fov = next.fov;
      this.camera.updateProjectionMatrix();
    }
    if (this.phase === 'IDLE') {
      this.camDist = next.cameraDistance;
    }

    // Quality Preset -> PixelRatio & Shadow Map Resolution
    const targetDpr =
      this.isSoftwareGl || next.quality === 'LOW'
        ? 1
        : next.quality === 'MEDIUM'
          ? Math.min(window.devicePixelRatio, 1.25)
          : next.quality === 'HIGH'
            ? Math.min(window.devicePixelRatio, 1.75)
            : Math.min(window.devicePixelRatio, 2);

    this.renderer.setPixelRatio(targetDpr);
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setPixelRatio(targetDpr);
      this.composer.setSize(w, h);
    }

    // Shadows
    const shadowsActive = !this.isSoftwareGl && next.shadows && next.quality !== 'LOW';
    this.renderer.shadowMap.enabled = shadowsActive;
    if (this.keyLight) {
      this.keyLight.castShadow = shadowsActive;
      const smSize = next.quality === 'ULTRA' ? 2048 : next.quality === 'HIGH' ? 1536 : 1024;
      if (this.keyLight.shadow.mapSize.width !== smSize) {
        this.keyLight.shadow.mapSize.set(smSize, smSize);
        this.keyLight.shadow.map?.dispose();
        this.keyLight.shadow.map = null;
      }
    }

    // Bloom strength (restrained to avoid washout)
    if (this.bloomPass) {
      this.bloomPass.strength = next.quality === 'ULTRA' ? 0.2 : 0.14;
    }

    // Weather / Stadium Atmosphere
    this.applyWeather(next.weather);
  }

  private applyWeather(weather: GameSettings['weather']) {
    if (!this.stadium) return;
    const uniforms = this.stadium.skyMat.uniforms;
    const isRain = weather === 'RAIN';
    const isSunset = weather === 'SUNSET';

    if (isSunset) {
      uniforms.uTopColor.value.set('#1e1b4b');
      uniforms.uHorizonColor.value.set('#c2410c');
      uniforms.uSunColor.value.set('#fbbf24');
      uniforms.uSunDir.value.set(-0.6, 0.16, -0.75).normalize();
      uniforms.uStarIntensity.value = 0.12;
      (this.scene.fog as THREE.FogExp2).color.set('#2c130e');
      (this.scene.fog as THREE.FogExp2).density = 0.0038;
      this.hemiLight.color.set('#fed7aa');
      this.hemiLight.groundColor.set('#14532d');
      this.hemiLight.intensity = 0.6;
      this.keyLight.color.set('#fdba74');
      this.keyLight.intensity = 1.35;
      this.rimLight.color.set('#f472b6');
      this.stadium.pitchMat.clearcoat = 0.04;
      this.stadium.pitchMat.roughness = 0.82;
      this.stadium.floodBeams.forEach((b) => {
        b.visible = true;
        (b.material as THREE.MeshBasicMaterial).opacity = 0.012;
        (b.material as THREE.MeshBasicMaterial).color.set('#fde68a');
      });
    } else if (isRain) {
      uniforms.uTopColor.value.set('#090d16');
      uniforms.uHorizonColor.value.set('#1e293b');
      uniforms.uSunColor.value.set('#64748b');
      uniforms.uStarIntensity.value = 0.0;
      (this.scene.fog as THREE.FogExp2).color.set('#0f172a');
      (this.scene.fog as THREE.FogExp2).density = 0.0068;
      this.hemiLight.color.set('#94a3b8');
      this.hemiLight.groundColor.set('#0f3f22');
      this.hemiLight.intensity = 0.48;
      this.keyLight.color.set('#e2e8f0');
      this.keyLight.intensity = 1.05;
      this.rimLight.color.set('#38bdf8');
      this.stadium.pitchMat.clearcoat = 0.55;
      this.stadium.pitchMat.roughness = 0.52;
      this.stadium.floodBeams.forEach((b) => {
        b.visible = !this.isSoftwareGl;
        (b.material as THREE.MeshBasicMaterial).opacity = 0.026;
        (b.material as THREE.MeshBasicMaterial).color.set('#bae6fd');
      });
    } else {
      // NIGHT
      uniforms.uTopColor.value.set('#020617');
      uniforms.uHorizonColor.value.set('#0c2448');
      uniforms.uSunColor.value.set('#38bdf8');
      uniforms.uSunDir.value.set(0.45, 0.35, -0.6).normalize();
      uniforms.uStarIntensity.value = 0.9;
      (this.scene.fog as THREE.FogExp2).color.set('#071226');
      (this.scene.fog as THREE.FogExp2).density = 0.0044;
      this.hemiLight.color.set('#bae6fd');
      this.hemiLight.groundColor.set('#14532d');
      this.hemiLight.intensity = 0.52;
      this.keyLight.color.set('#fff7ed');
      this.keyLight.intensity = 1.22;
      this.rimLight.color.set('#38bdf8');
      this.stadium.pitchMat.clearcoat = 0.0;
      this.stadium.pitchMat.roughness = 0.84;
      this.stadium.floodBeams.forEach((b) => {
        b.visible = !this.isSoftwareGl;
        (b.material as THREE.MeshBasicMaterial).opacity = 0.018;
        (b.material as THREE.MeshBasicMaterial).color.set('#bae6fd');
      });
    }

    this.stadium.rainPoints.visible = isRain && this.settings.particles;
    soundEngine.setRainAmbiance(isRain && this.phase === 'LIVE');
  }

  private initParticlePool() {
    const geo = new THREE.BoxGeometry(0.24, 0.24, 0.24);
    for (let i = 0; i < 64; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: '#38bdf8', transparent: true, opacity: 0.9 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.5,
      });
    }
  }

  private spawnParticles(pos: THREE.Vector3, colorHex: string, count = 16, speed = 7) {
    if (!this.settings.particles) return;
    let spawned = 0;
    for (const p of this.particles) {
      if (p.life <= 0) {
        p.mesh.visible = true;
        p.mesh.position.copy(pos);
        (p.mesh.material as THREE.MeshBasicMaterial).color.set(colorHex);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = 0.95;
        p.mesh.scale.setScalar(0.8 + Math.random() * 0.9);
        p.vel.set(
          (Math.random() - 0.5) * speed * 2,
          Math.random() * speed * 1.4 + 1.5,
          (Math.random() - 0.5) * speed * 2
        );
        p.maxLife = 0.45 + Math.random() * 0.45;
        p.life = p.maxLife;
        spawned++;
        if (spawned >= count) break;
      }
    }
  }

  private clearActors() {
    for (const actor of this.actors) {
      this.scene.remove(actor.rig.root);
    }
    this.actors = [];
  }

  private rebuildSoloTeams() {
    this.clearActors();
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();

    const userStyle = STYLES[this.activeStyleId];
    const otherStyles = STYLE_LIST.filter((s) => s.id !== this.activeStyleId);

    const addActor = (
      id: string,
      isUser: boolean,
      isGoalkeeper: boolean,
      role: PlayerRole,
      team: 'BLUE' | 'RED',
      style: StyleDefinition,
      homeX: number,
      homeZ: number
    ) => {
      const rig = buildRobloxPlayer(
        style,
        team,
        maxAniso,
        isGoalkeeper,
        isUser ? this.wardrobe : undefined
      );
      this.scene.add(rig.root);
      const actor: Actor = {
        id,
        isUser,
        isGoalkeeper,
        role,
        gkBallInHands: false,
        gkHoldTimer: 0,
        gkDiveTimer: 0,
        gkDiveCd: 0,
        team,
        style,
        rig,
        pos: new THREE.Vector3(homeX, 0, homeZ),
        targetPos: new THREE.Vector3(homeX, 0, homeZ),
        vel: new THREE.Vector3(),
        yaw: team === 'BLUE' ? 0 : Math.PI,
        targetYaw: team === 'BLUE' ? 0 : Math.PI,
        homePos: new THREE.Vector3(homeX, 0, homeZ),
        stunTimer: 0,
        dribbleIFrame: 0,
        tackleTimer: 0,
        stealCooldown: 0,
        wallShieldTimer: 0,
        awakened: false,
        animPhase: Math.random() * Math.PI * 2,
        emote: null,
        emoteTimer: 0,
        actionAnim: 'NONE',
        actionTimer: 0,
        actionDuration: 0.4,
      };
      this.actors.push(actor);
      if (isUser) this.userActor = actor;
    };

    const userIsGk = this.selectedRole === 'GK';
    const userSpawn = getRoleSpawnOffset(this.selectedRole, 'BLUE');
    addActor('user', true, userIsGk, this.selectedRole, 'BLUE', userStyle, userSpawn.x, userSpawn.z);

    if (this.isTraining && (userStyle.id === 'musab' || userStyle.id === 'musa')) {
      // Antrenmanda Musab <-> Musa paslaşma ve ikiz roveşata kombosu çalışılabilsin
      const duoPartner = userStyle.id === 'musab' ? STYLES.musa : STYLES.musab;
      addActor('blue_duo_partner', false, false, 'CF', 'BLUE', duoPartner, -4, -10);
    } else if (!this.isTraining && userIsGk) {
      // Kaleci seçen oyuncunun topu pas atabileceği saha içi takım arkadaşları olsun
      addActor('blue_cf', false, false, 'CF', 'BLUE', otherStyles[0], -10, 0);
      if (this.matchMode === '3V3') {
        addActor('blue_wing_top', false, false, 'LW', 'BLUE', otherStyles[1], -22, -13);
        addActor('blue_wing_bot', false, false, 'RW', 'BLUE', otherStyles[2], -22, 13);
      }
    } else if (!this.isTraining && this.matchMode === '3V3') {
      // Takımda Musab varsa partneri Musa, Musa varsa partneri Musab her zaman olsun
      const preferred0 =
        userStyle.id === 'musab'
          ? STYLES.musa
          : userStyle.id === 'musa'
            ? STYLES.musab
            : otherStyles[0];
      const remaining = otherStyles.filter((st) => st.id !== preferred0.id);
      addActor('blue_wing_top', false, false, 'LW', 'BLUE', preferred0, -22, -13);
      addActor('blue_wing_bot', false, false, 'RW', 'BLUE', remaining[0], -22, 13);
    }

    if (!userIsGk) {
      addActor('blue_gk', false, true, 'GK', 'BLUE', STYLES.berk, -PITCH_HALF_LENGTH + 1.8, 0);
    }

    if (!this.isTraining) {
      addActor('red_st', false, false, 'CF', 'RED', otherStyles[2], 10, 0);
      if (this.matchMode === '3V3') {
        addActor('red_mid_top', false, false, 'LW', 'RED', otherStyles[3], 22, -13);
        addActor('red_mid_bot', false, false, 'RW', 'RED', otherStyles[4], 22, 13);
      }
    }
    addActor('red_gk', false, true, 'GK', 'RED', STYLES.aras, PITCH_HALF_LENGTH - 1.8, 0);
  }

  private setActorAction(actor: Actor, anim: ActionAnimId, duration: number) {
    actor.actionAnim = anim;
    actor.actionTimer = duration;
    actor.actionDuration = Math.max(0.12, duration);
  }

  public setLoadout(
    styleId: StyleId,
    flowId: FlowId,
    gkDifficulty: GkDifficulty,
    matchMode: MatchMode = this.matchMode,
    role: PlayerRole = this.selectedRole
  ) {
    this.activeStyleId = styleId;
    this.activeFlowId = flowId;
    this.gkDifficulty = gkDifficulty;
    this.matchMode = matchMode;
    this.selectedRole = role;
    if (!this.onlineMode && this.phase === 'IDLE' && !this.isPreviewCutscene) {
      this.rebuildSoloTeams();
      this.resetKickoffPositions();
    }
    this.emitHud();
  }

  public previewCutscene(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO') {
    if (this.onlineMode) return;
    this.activeStyleId = kind === 'COMBO' ? 'musab' : styleId;
    this.isPreviewCutscene = true;
    this.rebuildSoloTeams();
    this.resetKickoffPositions();
    const opp = this.actors.find((a) => a.team === 'RED' && !a.isGoalkeeper) ?? this.userActor;
    this.cutsceneActorRig = this.userActor.rig;

    if (kind === 'COMBO') {
      let musaActor = this.actors.find((a) => a.team === 'BLUE' && !a.isGoalkeeper && a.style.id === 'musa');
      if (!musaActor) {
        const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
        const rig = buildRobloxPlayer(STYLES.musa, 'BLUE', maxAniso, false);
        this.scene.add(rig.root);
        musaActor = {
          id: 'preview_musa',
          isUser: false,
          isGoalkeeper: false,
          role: 'CF',
          gkBallInHands: false,
          gkHoldTimer: 0,
          gkDiveTimer: 0,
          gkDiveCd: 0,
          team: 'BLUE',
          style: STYLES.musa,
          rig,
          pos: new THREE.Vector3(2, 0, 1),
          targetPos: new THREE.Vector3(2, 0, 1),
          vel: new THREE.Vector3(),
          yaw: 0,
          targetYaw: 0,
          homePos: new THREE.Vector3(2, 0, 1),
          stunTimer: 0,
          dribbleIFrame: 0,
          tackleTimer: 0,
          stealCooldown: 0,
          wallShieldTimer: 0,
          awakened: false,
          animPhase: 0,
          emote: null,
          emoteTimer: 0,
          actionAnim: 'NONE',
          actionTimer: 0,
          actionDuration: 0.4,
        };
        this.actors.push(musaActor);
      }
      this.cutscenePartnerRig = musaActor.rig;
    } else {
      this.cutscenePartnerRig = null;
    }

    this.activeCutscene = startCutsceneState(
      kind === 'COMBO' ? 'musab' : styleId,
      kind,
      this.userActor.pos,
      opp.pos,
      this.cutsceneProps
    );
    this.phase = 'CUTSCENE';
    this.emitHud();
  }

  public stopPreviewCutscene() {
    if (!this.isPreviewCutscene) return;
    if (this.cutsceneActorRig) {
      resetAfterCutscene(this.cutsceneActorRig, this.cutsceneProps, true, this.cutscenePartnerRig);
    }
    this.isPreviewCutscene = false;
    this.activeCutscene = null;
    this.cutsceneActorRig = null;
    this.cutscenePartnerRig = null;
    this.cutsceneBanner = null;
    this.phase = 'IDLE';
    this.rebuildSoloTeams();
    this.resetKickoffPositions();
    this.emitHud();
  }

  public startNewMatch(gkDifficulty?: GkDifficulty, matchMode?: MatchMode, trainingMode = false) {
    if (gkDifficulty) this.gkDifficulty = gkDifficulty;
    if (matchMode) this.matchMode = matchMode;
    this.isTraining = trainingMode;
    this.onlineMode = false;
    this.onlineClient = null;
    this.onlineRoomCode = null;
    this.isPreviewCutscene = false;
    this.cameraInitializedForOnline = false;
    this.camYaw = 0;
    this.camPitch = 0.42;
    this.camDist = this.settings.cameraDistance;
    this.setShiftLock(false, true);
    this.isRightDragging = false;
    this.rebuildSoloTeams();
    this.blueScore = 0;
    this.redScore = 0;
    this.timeRemaining = trainingMode ? 999 : MATCH_DURATION_SEC;
    this.stamina = 100;
    this.awakening = trainingMode ? 100 : 40;
    this.isAwakened = false;
    this.awakeningTimeLeft = 0;
    this.ultiUsedInAwakening = false;
    this.matchStats = { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 };
    this.skill1Cd = 0;
    this.skill2Cd = 0;
    this.personalCd = 0;
    this.dribbleCd = 0;
    this.slideCd = 0;
    this.slowMoTimer = 0;
    this.goalBanner = null;
    this.cutsceneBanner = null;
    this.activeCutscene = null;
    this.cutsceneActorRig = null;
    this.cutscenePartnerRig = null;
    this.duoPass = null;
    this.duoComboCd = 0;
    this.aiDuoCooldown = 5.5;
    this.netDuoPrompt = null;
    resetAfterCutscene(this.userActor.rig, this.cutsceneProps);
    this.resetKickoffPositions();
    this.phase = 'LIVE';
    soundEngine.setRainAmbiance(this.settings.weather === 'RAIN');
    soundEngine.playWhistle();
    this.showToast(
      trainingMode
        ? 'SERBEST ANTRENMAN! [G] Uyanış Hazır · Dilediğin Gibi Şut & Skill Dene!'
        : `MAÇ BAŞLADI! (${this.matchMode === '1V1' ? '1v1' : '3v3'} · Kaleci: ${this.gkLabel()})`
    );
    this.emitHud();
  }

  public startOnlineSession(client: MultiplayerClient, roomCode: string, queueType: QueueType = 'CASUAL') {
    this.isTraining = false;
    this.onlineMode = true;
    this.onlineClient = client;
    this.onlineRoomCode = roomCode;
    this.onlineQueueType = queueType;
    this.onlinePingMs = client.pingMs ?? null;
    this.isPreviewCutscene = false;
    this.cameraInitializedForOnline = false;
    this.camPitch = 0.42;
    this.camDist = this.settings.cameraDistance;
    this.matchStats = { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 };
    this.setShiftLock(false, true);
    this.isRightDragging = false;
    this.clearActors();
    this.phase = 'LIVE';
    this.activeCutscene = null;
    this.cutsceneActorRig = null;
    this.cutscenePartnerRig = null;
    this.duoPass = null;
    this.duoComboCd = 0;
    this.netDuoPrompt = null;
    this.netGkBallInHands = false;
    this.netGkHoldLeft = 0;
    this.netGkDiveCd = 0;
    this.cutsceneBanner = null;
    this.goalBanner = null;
    soundEngine.setRainAmbiance(this.settings.weather === 'RAIN');
    this.emitHud();
  }

  public setOnlineMeta(pingMs: number | null, queueType?: QueueType) {
    this.onlinePingMs = pingMs;
    if (queueType) this.onlineQueueType = queueType;
  }

  public applyNetworkWorld(snap: NetWorldSnapshot, selfClientId: string | null) {
    if (!this.onlineMode) return;
    const prevPhase = this.phase;
    // Preserve local active cutscene playback until it naturally completes (unless match ended)
    if (!this.activeCutscene || snap.phase === 'ENDED') {
      this.phase = snap.phase;
    }
    this.blueScore = snap.blueScore;
    this.redScore = snap.redScore;
    this.timeRemaining = snap.timeRemaining;
    this.gkDifficulty = snap.gkDifficulty;
    this.matchMode = snap.matchMode ?? '3V3';
    this.goalBanner = snap.goalBanner;
    if (snap.toast) this.toastText = snap.toast;

    // Sync actors roster idempotently
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    const incomingIds = new Set(snap.actors.map((a) => a.id));
    for (let i = this.actors.length - 1; i >= 0; i--) {
      if (!incomingIds.has(this.actors[i].id)) {
        this.scene.remove(this.actors[i].rig.root);
        this.actors.splice(i, 1);
      }
    }

    for (const netA of snap.actors) {
      let existing = this.actors.find((a) => a.id === netA.id);
      const isUser = Boolean(selfClientId && netA.clientId === selfClientId);
      const styleDef = STYLES[netA.styleId] ?? STYLES.musab;

      if (!existing || existing.style.id !== netA.styleId || existing.team !== netA.team || existing.isGoalkeeper !== netA.isGoalkeeper) {
        if (existing) {
          this.scene.remove(existing.rig.root);
          this.actors = this.actors.filter((a) => a.id !== netA.id);
        }
        const rig = buildRobloxPlayer(
          styleDef,
          netA.team,
          maxAniso,
          netA.isGoalkeeper,
          isUser ? this.wardrobe : undefined
        );
        this.scene.add(rig.root);
        existing = {
          id: netA.id,
          isUser,
          isGoalkeeper: netA.isGoalkeeper,
          role: netA.role ?? (netA.isGoalkeeper ? 'GK' : 'CF'),
          gkBallInHands: Boolean(netA.gkBallInHands),
          gkHoldTimer: 0,
          gkDiveTimer: 0,
          gkDiveCd: 0,
          team: netA.team,
          style: styleDef,
          rig,
          pos: new THREE.Vector3(netA.x, 0, netA.z),
          targetPos: new THREE.Vector3(netA.x, 0, netA.z),
          vel: new THREE.Vector3(netA.vx, 0, netA.vz),
          yaw: netA.yaw,
          targetYaw: netA.yaw,
          homePos: new THREE.Vector3(netA.x, 0, netA.z),
          stunTimer: netA.stun,
          dribbleIFrame: netA.dribble,
          tackleTimer: netA.slide,
          stealCooldown: 0,
          wallShieldTimer: netA.wallShield ?? 0,
          awakened: netA.awakened,
          animPhase: 0,
          emote: netA.emote ?? null,
          emoteTimer: netA.emoteTimer ?? 0,
          actionAnim: netA.actionAnim ?? 'NONE',
          actionTimer: netA.actionTimer ?? 0,
          actionDuration: Math.max(0.4, netA.actionTimer ?? 0.4),
        };
        this.actors.push(existing);
      }

      existing.isUser = isUser;
      existing.isGoalkeeper = netA.isGoalkeeper;
      existing.role = netA.role ?? existing.role;
      existing.gkBallInHands = Boolean(netA.gkBallInHands);
      existing.targetPos.set(netA.x, 0, netA.z);
      existing.vel.set(netA.vx, 0, netA.vz);
      existing.targetYaw = netA.yaw;
      existing.stunTimer = netA.stun;
      existing.dribbleIFrame = netA.dribble;
      existing.tackleTimer = netA.slide;
      existing.wallShieldTimer = netA.wallShield ?? 0;
      existing.awakened = netA.awakened;
      existing.emote = netA.emote ?? null;
      existing.emoteTimer = netA.emoteTimer ?? 0;
      const incomingAnim = netA.actionAnim ?? 'NONE';
      const incomingTimer = netA.actionTimer ?? 0;
      if (incomingAnim !== existing.actionAnim && incomingTimer > 0) {
        existing.actionDuration = Math.max(0.25, incomingTimer);
      }
      existing.actionAnim = incomingAnim;
      existing.actionTimer = incomingTimer;
      if (isUser) {
        this.userActor = existing;
        this.activeStyleId = existing.style.id;
        this.selectedRole = existing.role;
        if (!this.cameraInitializedForOnline) {
          this.cameraInitializedForOnline = true;
          this.camYaw = existing.team === 'RED' ? Math.PI : 0;
        }
      }
    }

    if (prevPhase !== 'GOAL_CELEBRATION' && snap.phase === 'GOAL_CELEBRATION') {
      this.goalCelebrationTimer = 2.6;
    }

    this.ballTargetPos.set(snap.ball.x, snap.ball.y, snap.ball.z);
    this.ballVel.set(snap.ball.vx, snap.ball.vy, snap.ball.vz);
    this.isUltiBallActive = snap.ball.isUlti;
    this.netHasBall = Boolean(this.userActor && snap.ball.ownerId === this.userActor.id);
    this.netDuoPrompt = snap.duoComboPrompt ?? null;

    if (snap.selfHud) {
      this.stamina = snap.selfHud.stamina;
      this.awakening = snap.selfHud.awakening;
      this.isAwakened = snap.selfHud.isAwakened;
      this.awakeningTimeLeft = snap.selfHud.awakeningTimeLeft;
      this.ultiUsedInAwakening = snap.selfHud.ultiUsedInAwakening;
      this.shotCharge = snap.selfHud.shotCharge;
      this.skill1Cd = snap.selfHud.skill1Cd;
      this.skill2Cd = snap.selfHud.skill2Cd;
      this.personalCd = snap.selfHud.personalCd;
      this.dribbleCd = snap.selfHud.dribbleCd;
      this.slideCd = snap.selfHud.slideCd;
      this.netGkBallInHands = Boolean(snap.selfHud.gkBallInHands);
      this.netGkHoldLeft = snap.selfHud.gkHoldLeft ?? 0;
      this.netGkDiveCd = snap.selfHud.gkDiveCd ?? 0;
    }

    if (prevPhase !== 'ENDED' && snap.phase === 'ENDED') {
      soundEngine.setRainAmbiance(false);
      this.onMatchEnd(this.blueScore, this.redScore, { ...this.matchStats });
    }
    this.emitHud();
  }

  public triggerNetworkCutscene(evt: NetCutsceneEvent) {
    const actor = this.actors.find((a) => a.id === evt.actorId) ?? this.userActor;
    if (!actor) return;
    const partner = evt.partnerId ? this.actors.find((a) => a.id === evt.partnerId) : null;
    this.cutsceneActorRig = actor.rig;
    this.cutscenePartnerRig = partner ? partner.rig : null;
    this.activeCutscene = startCutsceneState(
      evt.styleId,
      evt.kind,
      new THREE.Vector3(evt.anchorX, 0, evt.anchorZ),
      new THREE.Vector3(evt.oppX, 0, evt.oppZ),
      this.cutsceneProps
    );
    this.phase = 'CUTSCENE';
    this.emitHud();
  }

  private gkLabel(): string {
    return this.gkDifficulty === 'EASY' ? 'Kolay' : this.gkDifficulty === 'HARD' ? 'Zor' : 'Orta';
  }

  public returnToTitle() {
    this.isTraining = false;
    this.onlineMode = false;
    this.onlineClient = null;
    this.onlineRoomCode = null;
    this.isPreviewCutscene = false;
    this.cameraInitializedForOnline = false;
    this.setShiftLock(false, true);
    this.isRightDragging = false;
    this.phase = 'IDLE';
    this.shotCharging = false;
    this.shotCharge = 0;
    this.slowMoTimer = 0;
    this.activeCutscene = null;
    this.cutsceneActorRig = null;
    this.cutscenePartnerRig = null;
    this.duoPass = null;
    this.netDuoPrompt = null;
    this.cutsceneBanner = null;
    this.goalBanner = null;
    soundEngine.setRainAmbiance(false);
    this.rebuildSoloTeams();
    resetAfterCutscene(this.userActor.rig, this.cutsceneProps, true);
    this.resetKickoffPositions();
    this.emitHud();
  }

  public togglePause() {
    if (this.onlineMode) return; // Online matches stay live
    if (this.phase === 'LIVE') {
      this.phase = 'PAUSED';
      this.heldKeys.clear();
      this.shotCharging = false;
      this.isRightDragging = false;
      this.setShiftLock(false, true);
      this.emitHud();
    } else if (this.phase === 'PAUSED') {
      this.phase = 'LIVE';
      this.emitHud();
    }
  }

  public triggerActionFromHud(
    action:
      | 'SKILL1'
      | 'SKILL2'
      | 'PERSONAL'
      | 'DRIBBLE'
      | 'SLIDE'
      | 'PASS'
      | 'EMOTE'
      | 'AWAKENING'
      | 'ULTI'
      | 'GK_DIVE_LEFT'
      | 'GK_DIVE_RIGHT'
  ) {
    if (this.phase !== 'LIVE') return;
    if (this.onlineMode && this.onlineClient) {
      this.onlineClient.sendAction(action);
      return;
    }
    if (action === 'GK_DIVE_LEFT') this.triggerGkDive('LEFT');
    else if (action === 'GK_DIVE_RIGHT') this.triggerGkDive('RIGHT');
    else if (action === 'SKILL1') this.useSkill1();
    else if (action === 'SKILL2') this.useSkill2();
    else if (action === 'PERSONAL') this.usePersonalSkill(true);
    else if (action === 'DRIBBLE') this.useDribble();
    else if (action === 'SLIDE') this.useSlideTackle();
    else if (action === 'PASS') this.usePass();
    else if (action === 'EMOTE') this.triggerEmote();
    else if (action === 'AWAKENING') this.tryActivateAwakening();
    else if (action === 'ULTI') this.tryActivateUlti();
  }

  private showToast(msg: string) {
    this.toastText = msg;
    this.toastTimer = 2.4;
  }

  private resetKickoffPositions() {
    this.ballOwner = null;
    this.duoPass = null;
    this.ballPos.set(0, 0.36, 0);
    this.ballTargetPos.copy(this.ballPos);
    this.ballVel.set(0, 0, 0);
    this.ballCurve = 0;
    this.ballTopspin = 0;
    this.isUltiBallActive = false;

    for (const actor of this.actors) {
      actor.pos.copy(actor.homePos);
      actor.targetPos.copy(actor.homePos);
      actor.vel.set(0, 0, 0);
      actor.stunTimer = 0;
      actor.dribbleIFrame = 0;
      actor.tackleTimer = 0;
      actor.stealCooldown = 0;
      actor.wallShieldTimer = 0;
      actor.gkBallInHands = false;
      actor.gkHoldTimer = 0;
      actor.gkDiveTimer = 0;
      actor.gkDiveCd = 0;
      actor.emote = null;
      actor.emoteTimer = 0;
      actor.actionAnim = 'NONE';
      actor.actionTimer = 0;
      actor.actionDuration = 0.4;
      actor.yaw = actor.team === 'BLUE' ? 0 : Math.PI;
      actor.targetYaw = actor.yaw;
      actor.rig.root.position.copy(actor.pos);
      actor.rig.root.rotation.y = actor.yaw;
    }
  }

  // ==================== SOLO USER ABILITIES & EMOTES ====================

  private triggerEmote() {
    if (!this.userActor || this.userActor.stunTimer > 0) return;
    const spec = EMOTE_LIST[this.emoteCursor % EMOTE_LIST.length];
    this.emoteCursor++;
    this.userActor.emote = spec.id;
    this.userActor.emoteTimer = 2.2;
    soundEngine.playEmoteChime();
    this.spawnParticles(this.userActor.pos.clone().setY(1.3), this.userActor.style.auraColor, 18, 6);
    this.showToast(`[X] ${spec.label}: "${spec.shout}"`);
  }

  private useDribble() {
    // [Q] Çalım (Uyanışta çok daha güçlü şok dalgalı süper çalım!)
    if (this.dribbleCd > 0 || this.stamina < 12) return;
    const awake = this.isAwakened;
    this.dribbleCd = awake ? 1.35 : 2.0;
    this.stamina = Math.max(0, this.stamina - (awake ? 8 : 12));
    this.userActor.dribbleIFrame = awake ? 1.15 : 0.65;
    this.speedBoostTimer = Math.max(this.speedBoostTimer, awake ? 1.15 : 0.55);
    this.setActorAction(this.userActor, awake ? 'AWAKENED_DRIBBLE' : 'DRIBBLE_SPIN', awake ? 0.78 : 0.55);
    this.awakening = Math.min(100, this.awakening + 6);
    this.matchStats.dribbles++;

    const fwdX = Math.cos(this.userActor.yaw);
    const fwdZ = -Math.sin(this.userActor.yaw);
    if (awake) {
      this.userActor.vel.set(fwdX * 26, 0, fwdZ * 26);
      for (const opp of this.actors) {
        if (opp.team !== this.userActor.team && !opp.isGoalkeeper && opp.pos.distanceTo(this.userActor.pos) < 5.2) {
          opp.stunTimer = 0.95;
          opp.vel.set((opp.pos.x - this.userActor.pos.x) * 3.5, 0, (opp.pos.z - this.userActor.pos.z) * 3.5);
        }
      }
      soundEngine.playAwakenedImpact();
      this.spawnParticles(this.userActor.pos.clone().setY(1.0), this.userActor.style.auraColor, 26, 9);
      this.showToast('[Q] UYANIK EGOİST ÇALIM ŞOKU!!');
    } else {
      soundEngine.playSkill(540);
      this.spawnParticles(this.userActor.pos.clone().setY(0.8), this.userActor.style.auraColor, 14, 5);
      this.showToast('[Q] ÇALIM!');
    }
  }

  private triggerGkDive(dir: 'LEFT' | 'RIGHT' | 'JUMP') {
    const u = this.userActor;
    if (!u || !u.isGoalkeeper || u.stunTimer > 0) return;
    if (u.gkBallInHands) {
      this.showToast('Top elindeyken atlayamazsın — [R]/[Tık] Degaj veya [C] Pas!');
      return;
    }
    if (u.gkDiveCd > 0) return;

    if (dir === 'JUMP') {
      u.gkDiveTimer = 0.36;
      u.gkDiveCd = 0.9;
      this.setActorAction(u, 'GK_DIVE', 0.42);
      soundEngine.playSkill(520);
      this.showToast('[Space] KALECİ ZIPLAYIŞI!');
      return;
    }

    const rightX = Math.sin(this.camYaw);
    const rightZ = Math.cos(this.camYaw);
    const sign = dir === 'RIGHT' ? 1 : -1;
    u.gkDiveTimer = 0.48;
    u.gkDiveCd = 1.05;
    u.vel.set(rightX * sign * 21, 0, rightZ * sign * 21);
    this.setActorAction(u, 'GK_DIVE', 0.55);
    soundEngine.playSlide();
    this.spawnParticles(u.pos.clone().setY(0.6), '#10b981', 16, 6);
    this.showToast(dir === 'LEFT' ? '[Q] SOLA KALECİ ATLAYIŞI!' : '[E] SAĞA KALECİ ATLAYIŞI!');

    if (!this.ballOwner && u.pos.distanceTo(this.ballPos) < 2.8 && this.ballPos.y < 3.4) {
      this.catchBallAsGk(u);
    }
  }

  private catchBallAsGk(gk: Actor) {
    this.ballOwner = gk;
    this.isUltiBallActive = false;
    this.duoPass = null;
    this.lastTouchActorId = gk.id;
    this.lastTouchTeam = gk.team;
    this.lastTouchName = gk.style.name;
    const inBox =
      gk.team === 'BLUE'
        ? gk.pos.x <= -38 && Math.abs(gk.pos.z) <= 18
        : gk.pos.x >= 38 && Math.abs(gk.pos.z) <= 18;
    if (inBox) {
      gk.gkBallInHands = true;
      gk.gkHoldTimer = 6.0;
      this.showToast('HARİKA KURTARIŞ! TOP ELİNDE (DOKUNULMAZ)');
    } else {
      this.showToast('KALECİ TOPU ALDI!');
    }
    soundEngine.playKick(0.65);
    this.spawnParticles(this.ballPos, '#10b981', 22, 8);
  }

  private useSlideTackle() {
    // [F] Kayma / Top Çalma (Uyanışta şok dalgalı yıldırımlı top çalma!)
    if (this.slideCd > 0 || this.stamina < 14) return;
    const awake = this.isAwakened;
    this.slideCd = awake ? 1.45 : 2.2;
    this.stamina = Math.max(0, this.stamina - (awake ? 10 : 14));
    this.userActor.tackleTimer = awake ? 0.56 : 0.42;
    this.setActorAction(this.userActor, awake ? 'AWAKENED_STEAL' : 'SLIDE', awake ? 0.58 : 0.44);
    if (awake) {
      soundEngine.playAwakenedImpact();
      this.spawnParticles(this.userActor.pos.clone().setY(0.5), this.userActor.style.auraColor, 26, 9);
    } else {
      soundEngine.playSlide();
      this.spawnParticles(this.userActor.pos.clone().setY(0.2), '#4ade80', 14, 5);
    }

    const fwdX = Math.cos(this.userActor.yaw);
    const fwdZ = -Math.sin(this.userActor.yaw);
    this.userActor.vel.set(fwdX * (awake ? 31 : 23), 0, fwdZ * (awake ? 31 : 23));

    const stealRadius = awake ? 5.2 : 3.4;
    if (
      this.ballOwner &&
      this.ballOwner.team !== 'BLUE' &&
      !this.ballOwner.gkBallInHands &&
      this.userActor.pos.distanceTo(this.ballOwner.pos) < stealRadius
    ) {
      if (awake || this.ballOwner.dribbleIFrame <= 0) {
        this.stealBall(this.userActor, this.ballOwner, awake);
      }
    }
  }

  private stealBall(thief: Actor, victim: Actor, forceAwakened = false) {
    if (victim.gkBallInHands) return;
    if (!forceAwakened && (victim.dribbleIFrame > 0 || victim.wallShieldTimer > 0)) return;
    victim.stunTimer = forceAwakened ? 1.25 : 0.75;
    victim.stealCooldown = forceAwakened ? 1.2 : 0.9;
    this.ballOwner = thief;
    this.duoPass = null;
    this.lastTouchActorId = thief.id;
    this.lastTouchTeam = thief.team;
    this.lastTouchName = thief.style.name;
    if (thief.isUser) {
      this.matchStats.steals++;
      this.awakening = Math.min(100, this.awakening + 10);
      this.showToast(forceAwakened ? 'UYANIK TOP KAPMA ŞOKU!!' : 'KAYARAK TOP KAPILDI!');
    }
    soundEngine.playKick(forceAwakened ? 0.95 : 0.75);
    this.spawnParticles(this.ballPos, thief.style.auraColor, forceAwakened ? 24 : 16, forceAwakened ? 9 : 6);
  }

  private usePass() {
    // [C] Pas
    if (this.ballOwner !== this.userActor) return;
    let bestMate: Actor | null = null;
    let bestScore = -Infinity;
    for (const a of this.actors) {
      if (a.team === 'BLUE' && !a.isUser && !a.isGoalkeeper) {
        const dist = a.pos.distanceTo(this.userActor.pos);
        const score = a.pos.x * 0.6 - dist * 0.45;
        if (score > bestScore) {
          bestScore = score;
          bestMate = a;
        }
      }
    }
    if (!bestMate) return;
    _vecA.subVectors(bestMate.pos, this.ballPos);
    const dist = _vecA.length();
    _vecA.y = 0;
    _vecA.normalize();

    this.ballOwner = null;
    this.userActor.gkBallInHands = false;
    this.userActor.gkHoldTimer = 0;
    this.userActor.stealCooldown = 0.45;
    this.setActorAction(this.userActor, 'KICK', 0.36);
    const passSpeed = THREE.MathUtils.clamp(dist * 1.45, 16, 34);
    this.ballVel.set(_vecA.x * passSpeed, 2.3, _vecA.z * passSpeed);
    this.ballCurve = 0;
    this.ballTopspin = 0.1;
    this.matchStats.passes++;
    this.awakening = Math.min(100, this.awakening + 6);
    soundEngine.playKick(0.55);
    this.showToast(`[C] PAS -> ${bestMate.style.name}`);
  }

  private releaseShot() {
    if (!this.shotCharging) return;
    const charge = Math.max(0.28, this.shotCharge);
    this.shotCharging = false;
    this.shotCharge = 0;

    if (this.ballOwner !== this.userActor) return;
    const flow = FLOWS[this.activeFlowId];
    const roleDef = ROLES[this.userActor.role];
    const powerStat = this.userActor.style.stats.shotPower / 100;
    const awakeMult = this.isAwakened ? 1.28 : 1.0;

    const goalTargetX = PITCH_HALF_LENGTH;
    const aimZ = THREE.MathUtils.clamp(
      this.userActor.pos.z * 0.32 + (Math.random() - 0.5) * 2.2,
      -GOAL_HALF_WIDTH + 0.5,
      GOAL_HALF_WIDTH - 0.5
    );
    _vecA.set(goalTargetX - this.ballPos.x, 0, aimZ - this.ballPos.z).normalize();
    const fwdX = Math.cos(this.userActor.yaw);
    const fwdZ = -Math.sin(this.userActor.yaw);
    const facingForward = fwdX > -0.2;
    const assist = this.shiftLock ? 0.25 : 0.72;
    const dirX = facingForward ? THREE.MathUtils.lerp(fwdX, _vecA.x, assist) : fwdX;
    const dirZ = facingForward ? THREE.MathUtils.lerp(fwdZ, _vecA.z, assist) : fwdZ;
    _vecB.set(dirX, 0, dirZ).normalize();

    const wasGkHold = this.userActor.isGoalkeeper && this.userActor.gkBallInHands;
    const baseSpeed = (26 + charge * 25) * (0.85 + powerStat * 0.35) * flow.shotMult * roleDef.shotMult * awakeMult;
    const speed = wasGkHold ? Math.max(baseSpeed, 34) : baseSpeed;
    this.ballOwner = null;
    this.userActor.gkBallInHands = false;
    this.userActor.gkHoldTimer = 0;
    this.duoPass = null;
    this.lastTouchActorId = this.userActor.id;
    this.userActor.stealCooldown = 0.55;
    this.setActorAction(this.userActor, 'KICK', 0.46);
    this.ballVel.set(_vecB.x * speed, wasGkHold ? 5.2 + charge * 3.4 : 2.5 + charge * 5.2, _vecB.z * speed);
    this.ballCurve = (this.userActor.pos.z > 0 ? -0.42 : 0.42) * charge;
    this.ballTopspin = 0.38 * charge;
    this.matchStats.shots++;
    this.awakening = Math.min(100, this.awakening + 10);

    if (charge > 0.75) {
      this.hitstopTimer = 0.045;
      this.cameraShake = 0.35;
    }
    soundEngine.playKick(charge);
    this.spawnParticles(this.ballPos, this.userActor.style.auraColor, 18, 8);
  }

  private useSkill1() {
    const s = this.userActor.style;
    if (this.skill1Cd > 0) return;
    const awake = this.isAwakened;
    this.skill1Cd = awake ? Math.max(2.5, s.skill1.cooldown * 0.65) : s.skill1.cooldown;
    this.awakening = Math.min(100, this.awakening + 12);
    if (awake) soundEngine.playAwakenedImpact();
    else soundEngine.playSkill(580);
    this.spawnParticles(this.userActor.pos.clone().setY(1.0), s.auraColor, awake ? 32 : 20, awake ? 12 : 8);

    const fwdX = Math.cos(this.userActor.yaw);
    const fwdZ = -Math.sin(this.userActor.yaw);

    if (s.id === 'musab') {
      this.userActor.dribbleIFrame = awake ? 1.65 : 1.1;
      this.speedBoostTimer = awake ? 2.4 : 1.7;
      this.userActor.vel.set(fwdX * (awake ? 34 : 27), 0, fwdZ * (awake ? 34 : 27));
      this.setActorAction(this.userActor, awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST', 0.72);
      if (awake) {
        for (const a of this.actors) {
          if (a.team === 'RED' && !a.isGoalkeeper && a.pos.distanceTo(this.userActor.pos) < 5.5) a.stunTimer = 1.0;
        }
      }
    } else if (s.id === 'musa' || s.id === 'zero') {
      this.userActor.dribbleIFrame = awake ? 1.55 : 1.0;
      this.speedBoostTimer = awake ? 2.3 : 1.6;
      this.userActor.vel.set(fwdX * (awake ? 33 : 26), 0, fwdZ * (awake ? 33 : 26));
      this.setActorAction(this.userActor, awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST', 0.68);
      if (awake) {
        for (const a of this.actors) {
          if (a.team === 'RED' && !a.isGoalkeeper && a.pos.distanceTo(this.userActor.pos) < 5.0) a.stunTimer = 0.9;
        }
      }
    } else if (s.id === 'iskender' || s.id === 'aras') {
      const range = awake ? 11.5 : 7.5;
      for (const a of this.actors) {
        if (a.team === 'RED' && a.pos.distanceTo(this.userActor.pos) < range) {
          a.stunTimer = awake ? 2.2 : 1.6;
          if (this.ballOwner === a) this.stealBall(this.userActor, a, awake);
        }
      }
      this.speedBoostTimer = awake ? 2.0 : 1.3;
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.62);
    } else if (s.id === 'ebulfez') {
      const dist = awake ? 12.5 : 7.0;
      this.userActor.pos.x = THREE.MathUtils.clamp(this.userActor.pos.x + fwdX * dist, -PITCH_HALF_LENGTH + 2, PITCH_HALF_LENGTH - 2);
      this.userActor.pos.z = THREE.MathUtils.clamp(this.userActor.pos.z + fwdZ * dist, -PITCH_HALF_WIDTH + 2, PITCH_HALF_WIDTH - 2);
      this.userActor.dribbleIFrame = awake ? 1.45 : 0.9;
      this.setActorAction(this.userActor, 'SKILL_LEAP', 0.62);
      if (awake) {
        for (const a of this.actors) {
          if (a.team === 'RED' && !a.isGoalkeeper && a.pos.distanceTo(this.userActor.pos) < 5.5) {
            a.stunTimer = 1.1;
            if (this.ballOwner === a) this.stealBall(this.userActor, a, true);
          }
        }
      }
    } else if (s.id === 'berk') {
      this.userActor.vel.set(fwdX * (awake ? 28 : 20), 0, fwdZ * (awake ? 28 : 20));
      this.setActorAction(this.userActor, awake ? 'AWAKENED_STEAL' : 'SKILL_BURST', 0.65);
      const stealRange = awake ? 8.5 : 5.5;
      if (this.ballOwner && this.ballOwner.team === 'RED' && this.ballOwner.pos.distanceTo(this.userActor.pos) < stealRange) {
        this.stealBall(this.userActor, this.ballOwner, awake);
      }
    }
    this.showToast(awake ? `UYANIK ${s.skill1.name.toUpperCase()}!!` : `${s.skill1.name}!`);
  }

  private useSkill2() {
    const s = this.userActor.style;
    if (this.skill2Cd > 0) return;
    const awake = this.isAwakened;

    // Ebulfez top çekme: kendi sahipsiz/yakın topu veya rakip topunu mıknatısla çekebilir (kalecinin elindeyken çekemez)
    if (s.id === 'ebulfez' && this.ballOwner !== this.userActor) {
      if (this.ballOwner?.gkBallInHands) {
        this.showToast('Kaleci topu elinde tutuyor — dokunulmaz!');
        return;
      }
      if (this.ballPos.distanceTo(this.userActor.pos) < (awake ? 20 : 12)) {
        this.skill2Cd = awake ? Math.max(3.0, s.skill2.cooldown * 0.65) : s.skill2.cooldown;
        this.awakening = Math.min(100, this.awakening + 12);
        if (awake) soundEngine.playAwakenedImpact();
        else soundEngine.playSkill(740);
        this.ballOwner = this.userActor;
        this.duoPass = null;
        this.lastTouchActorId = this.userActor.id;
        this.lastTouchTeam = 'BLUE';
        this.lastTouchName = s.name;
        this.setActorAction(this.userActor, 'SKILL_BURST', 0.55);
        this.spawnParticles(this.ballPos, s.auraColor, awake ? 32 : 20, 9);
        this.showToast(awake ? `UYANIK ${s.skill2.name} — Süper Top Çekme!!` : `${s.skill2.name} — Top Çekildi!`);
        return;
      }
    }

    // Vuruş SADECE oyuncu topa sahipken veya topa dokunuyorken (<= 1.85m sahipsiz) yapılabilir!
    const touchesBall =
      this.ballOwner === this.userActor ||
      (this.ballOwner === null && this.ballPos.distanceTo(this.userActor.pos) <= 1.85);

    this.skill2Cd = awake ? Math.max(3.0, s.skill2.cooldown * 0.65) : s.skill2.cooldown;
    this.awakening = Math.min(100, this.awakening + 12);
    if (awake) soundEngine.playAwakenedImpact();
    else soundEngine.playSkill(740);

    if (touchesBall) {
      const goalZ = this.userActor.pos.z > 0 ? -GOAL_HALF_WIDTH * 0.68 : GOAL_HALF_WIDTH * 0.68;
      _vecA.set(PITCH_HALF_LENGTH - this.ballPos.x, 0, goalZ - this.ballPos.z).normalize();
      this.ballOwner = null;
      this.duoPass = null;
      this.lastTouchActorId = this.userActor.id;
      this.userActor.stealCooldown = 0.55;
      this.setActorAction(this.userActor, 'KICK', 0.5);
      const baseSpd = s.rarity === 'MASTER' ? 46 : s.rarity === 'WORLD CLASS' ? 42 : 37;
      const spd = baseSpd * (awake ? 1.25 : 1.0);
      this.ballVel.set(_vecA.x * spd, awake ? 5.6 : 4.8, _vecA.z * spd);
      this.ballCurve = (this.userActor.pos.z > 0 ? -0.9 : 0.9) * (awake ? 1.35 : 1.0);
      this.ballTopspin = 0.55;
      this.cameraShake = awake ? 0.44 : 0.28;
      soundEngine.playKick(0.95);
      this.spawnParticles(this.ballPos, s.auraColor, awake ? 34 : 24, 11);
      this.showToast(awake ? `UYANIK ${s.skill2.name.toUpperCase()}!!` : `${s.skill2.name}!`);
    } else {
      this.speedBoostTimer = awake ? 2.2 : 1.4;
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.55);
      this.showToast(`${s.skill2.name} — Top sende değil (Hız Patlaması)!`);
    }
  }

  private launchDuoAerialPass(passer: Actor, receiver: Actor) {
    const attackDir = passer.team === 'BLUE' ? 1 : -1;
    // Keep Musab <-> Musa aerial pass visibly long-distance across the pitch
    if (!receiver.isUser && passer.pos.distanceTo(receiver.pos) < 16) {
      receiver.pos.x = THREE.MathUtils.clamp(passer.pos.x + attackDir * 22, -PITCH_HALF_LENGTH + 8, PITCH_HALF_LENGTH - 8);
      receiver.pos.z = THREE.MathUtils.clamp(passer.pos.z >= 0 ? -12 : 12, -PITCH_HALF_WIDTH + 5, PITCH_HALF_WIDTH - 5);
      receiver.rig.root.position.copy(receiver.pos);
    }
    this.duoComboCd = 20.0;
    this.aiDuoCooldown = 20.0;
    this.ballOwner = null;
    passer.stealCooldown = 0.65;
    this.setActorAction(passer, 'KICK', 0.44);
    const dx = receiver.pos.x - passer.pos.x;
    const dz = receiver.pos.z - passer.pos.z;
    const dist = Math.hypot(dx, dz) || 1;
    const flightTime = THREE.MathUtils.clamp(dist / 17.5, 0.95, 1.72);
    this.ballPos.set(passer.pos.x + (dx / dist) * 0.9, 0.6, passer.pos.z + (dz / dist) * 0.9);
    this.ballVel.set(dx / flightTime, THREE.MathUtils.clamp(8.5 + dist * 0.14, 9.2, 13.5), dz / flightTime);
    this.ballCurve = 0;
    this.ballTopspin = 0;
    this.duoPass = {
      active: true,
      passerId: passer.id,
      receiverId: receiver.id,
      timer: 3.4,
      autoTriggerTimer: receiver.isUser ? 99 : Math.max(0.75, flightTime * 0.8),
    };
    soundEngine.playKick(0.8);
    this.spawnParticles(this.ballPos, '#facc15', 28, 9);
  }

  private triggerMusabMusaCombo(musab: Actor, musa: Actor) {
    this.duoPass = null;
    this.ballOwner = null;
    this.heldKeys.clear();
    const anchor = new THREE.Vector3(
      THREE.MathUtils.clamp(musa.pos.x, -PITCH_HALF_LENGTH + 14, PITCH_HALF_LENGTH - 14),
      0,
      THREE.MathUtils.clamp(musa.pos.z, -PITCH_HALF_WIDTH + 8, PITCH_HALF_WIDTH - 8)
    );
    this.cutsceneActorRig = musab.rig;
    this.cutscenePartnerRig = musa.rig;
    this.activeCutscene = startCutsceneState('musab', 'COMBO', anchor, anchor, this.cutsceneProps);
    this.phase = 'CUTSCENE';
    this.matchStats.shots++;
    this.emitHud();
  }

  private usePersonalSkill(fromKeyE = false) {
    const s = this.userActor.style;

    // 1) MUSA: Musab'dan uzak mesafe havadan kombine pas gelirken [E]'ye basınca İkiz Roveşata Kombosu tetiklenir!
    if (fromKeyE && this.duoPass?.active && this.duoPass.receiverId === this.userActor.id) {
      const musab = this.actors.find((a) => a.id === this.duoPass!.passerId);
      if (musab) {
        this.triggerMusabMusaCombo(musab, this.userActor);
        return;
      }
    }

    // 2) MUSAB: Top Musab'tayken ve takımda Musa varken [E] ile Uzak Mesafe Havadan Pas başlatır (20s bekleme)!
    if (fromKeyE && s.id === 'musab' && this.ballOwner === this.userActor) {
      const musaMate = this.actors.find((a) => a.team === 'BLUE' && !a.isGoalkeeper && a.style.id === 'musa');
      if (musaMate) {
        if (this.duoComboCd <= 0) {
          this.launchDuoAerialPass(this.userActor, musaMate);
          this.matchStats.passes++;
          this.awakening = Math.min(100, this.awakening + 10);
          this.showToast('[E] MUSAB -> MUSA UZAK HAVADAN PAS! ROVEŞATA HAZIR!');
          this.emitHud();
          return;
        } else if (this.personalCd > 0) {
          this.showToast(`Musab × Musa Pas Bekleme: ${Math.ceil(this.duoComboCd)}s`);
          return;
        }
      }
    }

    // [E / 3] Kişiye Özel Yetenek
    if (this.personalCd > 0) return;
    const awake = this.isAwakened;
    this.personalCd = awake ? Math.max(3.5, s.personalSkill.cooldown * 0.65) : s.personalSkill.cooldown;
    this.awakening = Math.min(100, this.awakening + 14);
    if (awake) soundEngine.playAwakenedImpact();
    else soundEngine.playSkill(860);
    this.spawnParticles(this.userActor.pos.clone().setY(1.2), s.secondaryColor, awake ? 36 : 24, awake ? 12 : 9);

    const fwdX = Math.cos(this.userActor.yaw);
    const fwdZ = -Math.sin(this.userActor.yaw);

    if (s.id === 'musab' || s.id === 'zero') {
      const range = awake ? 12.5 : 8.0;
      for (const a of this.actors) {
        if (a.team === 'RED' && a.pos.distanceTo(this.userActor.pos) < range) {
          a.stunTimer = awake ? 1.85 : 1.3;
          if (this.ballOwner === a) this.stealBall(this.userActor, a, awake);
        }
      }
      this.speedBoostTimer = awake ? 2.4 : 1.6;
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.65);
    } else if (s.id === 'musa') {
      const range = awake ? 11.5 : 7.0;
      if (this.ballOwner && this.ballOwner.team === 'RED' && this.ballOwner.pos.distanceTo(this.userActor.pos) < range) {
        this.stealBall(this.userActor, this.ballOwner, awake);
      }
      this.speedBoostTimer = awake ? 2.5 : 1.8;
      this.setActorAction(this.userActor, awake ? 'AWAKENED_STEAL' : 'SKILL_BURST', 0.65);
    } else if (s.id === 'iskender') {
      const warpDist = awake ? 13.5 : 8.5;
      this.userActor.pos.x = THREE.MathUtils.clamp(this.userActor.pos.x + fwdX * warpDist, -PITCH_HALF_LENGTH + 2, PITCH_HALF_LENGTH - 2);
      this.userActor.pos.z = THREE.MathUtils.clamp(this.userActor.pos.z + fwdZ * warpDist, -PITCH_HALF_WIDTH + 2, PITCH_HALF_WIDTH - 2);
      this.userActor.dribbleIFrame = awake ? 1.65 : 1.1;
      this.setActorAction(this.userActor, 'SKILL_LEAP', 0.65);
    } else if (s.id === 'aras') {
      this.stamina = Math.min(100, this.stamina + (awake ? 90 : 50));
      this.speedBoostTimer = awake ? 2.8 : 2.0;
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.65);
      if (awake) {
        for (const a of this.actors) {
          if (a.team === 'RED' && !a.isGoalkeeper && a.pos.distanceTo(this.userActor.pos) < 6.5) a.stunTimer = 1.2;
        }
      }
    } else if (s.id === 'ebulfez') {
      if (this.ballPos.distanceTo(this.userActor.pos) < (awake ? 25 : 16)) {
        this.ballOwner = this.userActor;
        this.duoPass = null;
        this.lastTouchActorId = this.userActor.id;
        this.lastTouchTeam = 'BLUE';
        this.lastTouchName = s.name;
      }
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.6);
    } else if (s.id === 'berk') {
      this.userActor.wallShieldTimer = awake ? 5.2 : 3.2;
      this.setActorAction(this.userActor, 'SKILL_BURST', 0.65);
      if (awake) {
        for (const a of this.actors) {
          if (a.team === 'RED' && !a.isGoalkeeper && a.pos.distanceTo(this.userActor.pos) < 7.0) {
            a.stunTimer = 1.2;
            if (this.ballOwner === a) this.stealBall(this.userActor, a, true);
          }
        }
      }
    }
    this.showToast(awake ? `UYANIK ÖZEL: ${s.personalSkill.name.toUpperCase()}!!` : `ÖZEL YETENEK: ${s.personalSkill.name}!`);
  }

  private tryActivateAwakening() {
    if (this.isAwakened || this.awakening < 100) return;
    this.awakening = 0;
    this.isAwakened = true;
    this.awakeningTimeLeft = AWAKENING_DURATION_SEC;
    this.ultiUsedInAwakening = false;
    this.skill1Cd = 0;
    this.skill2Cd = 0;
    this.personalCd = 0;
    this.stamina = 100;

    const opp = this.findNearestOpponent();
    this.cutsceneActorRig = this.userActor.rig;
    this.cutscenePartnerRig = null;
    this.activeCutscene = startCutsceneState(
      this.userActor.style.id,
      'AWAKENING',
      this.userActor.pos,
      opp ? opp.pos : new THREE.Vector3(6, 0, 0),
      this.cutsceneProps
    );
    this.phase = 'CUTSCENE';
    this.heldKeys.clear();
    this.emitHud();
  }

  private tryActivateUlti() {
    // [V] Ulti — Sadece topa sahipken/dokunurken! (Berk & Ebulfez rakipten top çalıp vurabilir)
    if (!this.isAwakened || this.ultiUsedInAwakening) return;
    const sid = this.userActor.style.id;
    const isThiefUlti = sid === 'berk' || sid === 'ebulfez';
    const ownsOrTouches =
      this.ballOwner === this.userActor ||
      (this.ballOwner === null && this.ballPos.distanceTo(this.userActor.pos) <= 2.0);
    const oppHasBall =
      this.ballOwner !== null &&
      this.ballOwner.team !== this.userActor.team &&
      !this.ballOwner.isGoalkeeper &&
      !this.ballOwner.gkBallInHands;

    if (isThiefUlti) {
      if (!ownsOrTouches && !oppHasBall) {
        this.showToast('Ulti için top sende veya rakipte olmalı!');
        return;
      }
    } else if (!ownsOrTouches) {
      this.showToast('Ulti vurmak için topa sahip olmalısın!');
      return;
    }

    const stealTarget = isThiefUlti && oppHasBall && this.ballOwner ? this.ballOwner : null;
    if (stealTarget) {
      stealTarget.stunTimer = 1.4;
      stealTarget.stealCooldown = 1.2;
    }

    this.ultiUsedInAwakening = true;
    this.matchStats.shots++;
    this.duoPass = null;
    const opp = stealTarget ?? this.findNearestOpponent();
    const targetAnchor = isThiefUlti
      ? (stealTarget ? stealTarget.pos : this.userActor.pos)
      : (opp ? opp.pos : new THREE.Vector3(6, 0, 0));

    this.ballOwner = null;
    this.cutsceneActorRig = this.userActor.rig;
    this.cutscenePartnerRig = null;
    this.activeCutscene = startCutsceneState(
      sid,
      'ULTI',
      this.userActor.pos,
      targetAnchor,
      this.cutsceneProps
    );
    this.phase = 'CUTSCENE';
    this.heldKeys.clear();
    this.emitHud();
  }

  private findNearestOpponent(): Actor | undefined {
    let best = this.actors.find((a) => a.team === 'RED' && !a.isGoalkeeper);
    let bestDist = Infinity;
    for (const a of this.actors) {
      if (a.team === 'RED' && !a.isGoalkeeper) {
        const d = a.pos.distanceTo(this.userActor.pos);
        if (d < bestDist) {
          bestDist = d;
          best = a;
        }
      }
    }
    return best ?? this.actors.find((a) => a.team === 'RED');
  }

  // ==================== MAIN LOOP ====================

  private renderScene() {
    const useComposer =
      Boolean(this.composer) &&
      !this.isSoftwareGl &&
      this.settings.bloom &&
      this.settings.quality !== 'LOW';
    if (useComposer && this.composer) {
      this.composer.render();
    } else {
      this.renderer.render(this.scene, this.camera);
    }
  }

  private stepRain(dt: number) {
    if (!this.stadium || !this.stadium.rainPoints.visible) return;
    const posAttr = this.stadium.rainPoints.geometry.getAttribute('position') as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;
    const vels = this.stadium.rainVelocities;
    for (let i = 0; i < vels.length; i++) {
      arr[i * 3 + 1] -= vels[i] * dt;
      arr[i * 3] -= dt * 2.5;
      if (arr[i * 3 + 1] < 0.1) {
        arr[i * 3] = (Math.random() - 0.5) * 136;
        arr[i * 3 + 1] = 26 + Math.random() * 6;
        arr[i * 3 + 2] = (Math.random() - 0.5) * 84;
      }
    }
    posAttr.needsUpdate = true;
  }

  private tick = () => {
    if (this.disposed) return;

    this.lastFramePerfMs = performance.now();
    const rawDt = this.clock.getDelta();
    const dtBase = Math.min(rawDt, 0.05);

    this.fpsFrames++;
    this.fpsAccum += rawDt;
    if (this.fpsAccum >= 0.4) {
      this.currentFps = Math.max(1, Math.round(this.fpsFrames / this.fpsAccum));
      this.fpsFrames = 0;
      this.fpsAccum = 0;
    }

    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dtBase;
      this.updateCamera(dtBase);
      this.renderScene();
      this.scheduleNextFrame();
      return;
    }

    let dt = dtBase;
    if (this.slowMoTimer > 0) {
      this.slowMoTimer -= dtBase;
      dt = dtBase * 0.35;
    }

    if (this.toastTimer > 0) {
      this.toastTimer -= dtBase;
      if (this.toastTimer <= 0) this.toastText = null;
    }

    if (this.phase === 'IDLE') {
      this.stepTitleShowcase(dt);
    } else if (this.phase === 'CUTSCENE' && this.activeCutscene && this.cutsceneActorRig) {
      this.stepActiveCutscene(dt);
    } else if (this.onlineMode) {
      this.stepOnlineRender(dt);
    } else if (this.phase === 'GOAL_CELEBRATION') {
      this.stepGoalCelebration(dt);
    } else if (this.phase === 'LIVE') {
      this.stepLiveMatch(dt);
    }

    this.stepRain(dtBase);
    this.stepParticles(dt);
    this.stepNetRipple(dt);
    this.renderScene();

    this.hudEmitAccum += dtBase;
    if (this.hudEmitAccum >= 0.05) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    this.scheduleNextFrame();
  };

  private computeCameraMoveVector(): { moveX: number; moveZ: number; isMoving: boolean } {
    let f = 0;
    let r = 0;
    if (this.heldKeys.has('KeyW') || this.heldKeys.has('ArrowUp')) f += 1;
    if (this.heldKeys.has('KeyS') || this.heldKeys.has('ArrowDown')) f -= 1;
    if (this.heldKeys.has('KeyD') || this.heldKeys.has('ArrowRight')) r += 1;
    if (this.heldKeys.has('KeyA') || this.heldKeys.has('ArrowLeft')) r -= 1;

    if (f === 0 && r === 0) {
      return { moveX: 0, moveZ: 0, isMoving: false };
    }

    const fwdX = Math.cos(this.camYaw);
    const fwdZ = -Math.sin(this.camYaw);
    const rightX = Math.sin(this.camYaw);
    const rightZ = Math.cos(this.camYaw);

    let mx = fwdX * f + rightX * r;
    let mz = fwdZ * f + rightZ * r;
    const len = Math.hypot(mx, mz) || 1;
    mx /= len;
    mz /= len;
    return { moveX: mx, moveZ: mz, isMoving: true };
  }

  private sendOnlineInputNow() {
    if (!this.onlineMode || !this.onlineClient || this.phase !== 'LIVE') return;
    const { moveX, moveZ } = this.computeCameraMoveVector();
    const sprint = this.heldKeys.has('ShiftLeft') || this.heldKeys.has('ShiftRight');
    this.onlineClient.sendInput(moveX, moveZ, sprint, this.shotCharging, this.camYaw, this.shiftLock);
    this.netInputAccum = 0;
  }

  private stepOnlineRender(dt: number) {
    // 50Hz steady sync (plus instant push on keydown/keyup)
    if (this.onlineClient && this.phase === 'LIVE') {
      this.netInputAccum += dt;
      if (this.netInputAccum >= 0.02) {
        this.sendOnlineInputNow();
      }
    }

    // Client-side local prediction for our player + dead-reckoning for remote actors
    const extrapDt = Math.min(dt, 0.032);
    for (const a of this.actors) {
      if (a.isUser && this.phase === 'LIVE' && a.stunTimer <= 0 && a.tackleTimer <= 0) {
        const flow = FLOWS[this.activeFlowId];
        const { moveX, moveZ, isMoving } = this.computeCameraMoveVector();
        const wantsSprint =
          (this.heldKeys.has('ShiftLeft') || this.heldKeys.has('ShiftRight')) && isMoving && this.stamina > 2;
        const baseSpeed = 9.5 + (a.style.stats.speed / 100) * 5.2;
        const maxSpeed =
          baseSpeed *
          (wantsSprint ? 1.38 : 1.0) *
          (this.isAwakened ? flow.speedMult * 1.12 : 1.0) *
          (this.netHasBall ? 0.94 : 1.0);

        if (isMoving) {
          a.vel.x = THREE.MathUtils.damp(a.vel.x, moveX * maxSpeed, 14, dt);
          a.vel.z = THREE.MathUtils.damp(a.vel.z, moveZ * maxSpeed, 14, dt);
          const predYaw = this.shiftLock ? this.camYaw : Math.atan2(-moveZ, moveX);
          let yd = predYaw - a.yaw;
          while (yd > Math.PI) yd -= Math.PI * 2;
          while (yd < -Math.PI) yd += Math.PI * 2;
          a.yaw += yd * Math.min(1, 20 * dt);
        } else {
          a.vel.x = THREE.MathUtils.damp(a.vel.x, 0, 14, dt);
          a.vel.z = THREE.MathUtils.damp(a.vel.z, 0, 14, dt);
          if (this.shiftLock) a.yaw = this.camYaw;
        }
        a.pos.x += a.vel.x * dt;
        a.pos.z += a.vel.z * dt;
        this.clampToPitch(a.pos);

        // Gentle authoritative reconciliation
        const err = Math.hypot(a.targetPos.x - a.pos.x, a.targetPos.z - a.pos.z);
        if (err > 4.5) {
          a.pos.x = a.targetPos.x;
          a.pos.z = a.targetPos.z;
        } else if (err > 0.35) {
          a.pos.x = THREE.MathUtils.damp(a.pos.x, a.targetPos.x, 6.5, dt);
          a.pos.z = THREE.MathUtils.damp(a.pos.z, a.targetPos.z, 6.5, dt);
        }
      } else {
        const predX = a.targetPos.x + a.vel.x * extrapDt;
        const predZ = a.targetPos.z + a.vel.z * extrapDt;
        a.pos.x = THREE.MathUtils.damp(a.pos.x, predX, 22, dt);
        a.pos.z = THREE.MathUtils.damp(a.pos.z, predZ, 22, dt);
        let diff = a.targetYaw - a.yaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        a.yaw += diff * Math.min(1, 20 * dt);
      }

      a.actionTimer = Math.max(0, a.actionTimer - dt);
      if (a.actionTimer === 0) a.actionAnim = 'NONE';
      this.animateActorRig(a, dt);
    }

    const gkHolder = this.actors.find((a) => a.gkBallInHands);
    if (this.netHasBall && this.userActor && this.phase === 'LIVE') {
      const fwdX = Math.cos(this.userActor.yaw);
      const fwdZ = -Math.sin(this.userActor.yaw);
      const spd = Math.hypot(this.userActor.vel.x, this.userActor.vel.z);
      const bounce = spd > 0.8 ? Math.abs(Math.sin(this.userActor.animPhase * 1.4)) * 0.14 : 0;
      const distOut = this.netGkBallInHands ? 0.72 : 0.95;
      const posY = this.netGkBallInHands ? 1.24 : 0.36 + bounce;
      this.ballPos.set(
        THREE.MathUtils.damp(this.ballPos.x, this.userActor.pos.x + fwdX * distOut, 28, dt),
        posY,
        THREE.MathUtils.damp(this.ballPos.z, this.userActor.pos.z + fwdZ * distOut, 28, dt)
      );
    } else if (gkHolder && this.phase === 'LIVE') {
      const fwdX = Math.cos(gkHolder.yaw);
      const fwdZ = -Math.sin(gkHolder.yaw);
      this.ballPos.set(
        THREE.MathUtils.damp(this.ballPos.x, gkHolder.pos.x + fwdX * 0.72, 28, dt),
        1.24,
        THREE.MathUtils.damp(this.ballPos.z, gkHolder.pos.z + fwdZ * 0.72, 28, dt)
      );
    } else {
      const bPredX = this.ballTargetPos.x + this.ballVel.x * Math.min(dt, 0.025);
      const bPredY = Math.max(0.36, this.ballTargetPos.y + this.ballVel.y * Math.min(dt, 0.025));
      const bPredZ = this.ballTargetPos.z + this.ballVel.z * Math.min(dt, 0.025);
      this.ballPos.x = THREE.MathUtils.damp(this.ballPos.x, bPredX, 26, dt);
      this.ballPos.y = THREE.MathUtils.damp(this.ballPos.y, bPredY, 26, dt);
      this.ballPos.z = THREE.MathUtils.damp(this.ballPos.z, bPredZ, 26, dt);
    }

    this.ball.group.position.copy(this.ballPos);
    this.ball.mesh.rotation.z -= this.ballVel.x * dt * 1.1;
    this.ball.mesh.rotation.x += this.ballVel.z * dt * 1.1;
    this.ball.shadow.position.set(this.ballPos.x, 0.02, this.ballPos.z);
    this.ball.shadow.scale.setScalar(Math.max(0.45, 1.0 - this.ballPos.y * 0.08));

    const trailMat = this.ball.trailRing.material as THREE.MeshBasicMaterial;
    if (this.isUltiBallActive || this.ballVel.length() > 26) {
      trailMat.opacity = 0.78;
      trailMat.color.set(this.isUltiBallActive && this.userActor ? this.userActor.style.auraColor : '#38bdf8');
      this.ball.trailRing.rotation.y += dt * 12;
    } else {
      trailMat.opacity = 0;
    }

    if (this.userActor) {
      this.updateCamera(dt);
    }
  }

  private scheduleNextFrame() {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
      return;
    }
    if (typeof document !== 'undefined' && document.hidden) {
      this.frameId = window.setTimeout(this.tick, 100);
      return;
    }
    if (
      this.settings.fpsMode === 'VSYNC' ||
      this.phase === 'IDLE' ||
      this.phase === 'ENDED' ||
      this.phase === 'PAUSED'
    ) {
      this.frameId = requestAnimationFrame(this.tick);
      return;
    }

    const targetMs =
      this.settings.fpsMode === '120'
        ? 1000 / 120
        : this.settings.fpsMode === '144'
          ? 1000 / 144
          : 0;
    const elapsed = performance.now() - this.lastFramePerfMs;
    const remaining = targetMs - elapsed;

    if (remaining > 3.5) {
      this.frameId = window.setTimeout(this.tick, Math.floor(remaining - 2));
    } else if (this.msgChannel && this.highFpsYieldCounter++ % 6 !== 0) {
      this.msgChannel.port2.postMessage(undefined);
    } else {
      this.frameId = window.setTimeout(this.tick, 0);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private stepTitleShowcase(dt: number) {
    const t = this.clock.elapsedTime;
    this.userActor.pos.set(0, 0, 0);
    this.userActor.rig.root.position.set(0, 0, 0);
    this.userActor.rig.root.rotation.y = Math.sin(t * 0.45) * 0.35;
    this.userActor.rig.auraRing.visible = true;
    (this.userActor.rig.auraRing.material as THREE.MeshBasicMaterial).opacity = 0.42;
    this.userActor.rig.auraRing.rotation.z += dt * 1.4;
    this.userActor.rig.auraPillars.visible = true;
    this.userActor.rig.auraPillars.rotation.y -= dt * 1.2;

    this.ballPos.set(1.4, 0.36 + Math.abs(Math.sin(t * 2.4)) * 0.28, 0.7);
    this.ball.group.position.copy(this.ballPos);
    this.ball.shadow.position.set(this.ballPos.x, 0.02, this.ballPos.z);

    const orbit = t * 0.22;
    _camTargetPos.set(Math.cos(orbit) * 10.5, 3.8, Math.sin(orbit) * 10.5);
    _camTargetLook.set(0, 1.5, 0);
    this.camera.position.lerp(_camTargetPos, 1 - Math.exp(-3 * dt));
    _camCurrLook.lerp(_camTargetLook, 1 - Math.exp(-3 * dt));
    this.camera.lookAt(_camCurrLook);
  }

  private stepActiveCutscene(dt: number) {
    if (!this.activeCutscene || !this.cutsceneActorRig) return;
    const res = stepCutscene(
      this.activeCutscene,
      dt,
      this.cutsceneActorRig,
      this.ball.group,
      this.cutsceneProps,
      this.cutscenePartnerRig
    );
    this.cutsceneBanner = res.banner;
    this.ball.shadow.position.set(this.ball.group.position.x, 0.02, this.ball.group.position.z);

    if (res.spawnBurst) {
      this.spawnParticles(res.spawnBurst.pos, res.spawnBurst.color, res.spawnBurst.count, 10);
    }

    this.camera.position.lerp(res.cameraPos, 1 - Math.exp(-10 * dt));
    _camCurrLook.lerp(res.cameraLook, 1 - Math.exp(-10 * dt));
    this.camera.lookAt(_camCurrLook);

    if (res.finished) {
      const finishedKind = this.activeCutscene.kind;
      resetAfterCutscene(this.cutsceneActorRig, this.cutsceneProps, false, this.cutscenePartnerRig);
      this.cutsceneBanner = null;
      this.activeCutscene = null;
      this.cutsceneActorRig = null;
      this.cutscenePartnerRig = null;

      if (this.isPreviewCutscene) {
        this.isPreviewCutscene = false;
        this.phase = 'IDLE';
        this.rebuildSoloTeams();
        this.resetKickoffPositions();
        this.emitHud();
        return;
      }

      this.phase = 'LIVE';

      if (!this.onlineMode) {
        if ((finishedKind === 'ULTI' || finishedKind === 'COMBO') && res.launchShot) {
          const shooter =
            finishedKind === 'COMBO'
              ? this.actors.find((a) => a.team === 'BLUE' && !a.isGoalkeeper && a.style.id === 'musa') ?? this.userActor
              : this.userActor;
          if (res.launchShot.stealAndTeleportPos) {
            shooter.pos.copy(res.launchShot.stealAndTeleportPos);
            shooter.rig.root.position.copy(shooter.pos);
          }
          this.launchUltiShot(res.launchShot, shooter, finishedKind === 'COMBO' ? 'MUSAB × MUSA' : undefined);
        } else {
          this.showToast(`${this.userActor.style.name} UYANIŞ AKTİF! [V] ile ULTİ Kullan!`);
        }
      }
      this.emitHud();
    }
  }

  private launchUltiShot(
    shot: NonNullable<CutsceneFrameResult['launchShot']>,
    shooter: Actor = this.userActor,
    customLabel?: string
  ) {
    this.ballPos.copy(shot.from);
    this.ballOwner = null;
    this.lastTouchActorId = shooter.id;
    shooter.stealCooldown = 0.7;
    this.lastTouchTeam = shooter.team;
    this.lastTouchName = customLabel ?? shooter.style.name;
    this.isUltiBallActive = true;

    const targetZ = shot.curve !== 0 ? (shot.curve > 0 ? -GOAL_HALF_WIDTH * 0.72 : GOAL_HALF_WIDTH * 0.72) : (Math.random() - 0.5) * 4.5;
    _vecA.set(PITCH_HALF_LENGTH + 1.5 - shot.from.x, 0, targetZ - shot.from.z);
    const distToGoal = _vecA.length();
    _vecA.normalize();

    let effectiveSpeed = shot.speed;
    if (shot.range === 'MIDFIELD' && distToGoal > 66) {
      effectiveSpeed = Math.min(shot.speed, 30);
      this.showToast('Orta saha menzili dışı — top ceza sahası önünde düştü!');
    }

    this.ballVel.set(_vecA.x * effectiveSpeed, shot.loft, _vecA.z * effectiveSpeed);
    this.ballCurve = shot.curve;
    this.ballTopspin = 0.35;
    this.hitstopTimer = 0.06;
    this.cameraShake = 0.65;
    soundEngine.playKick(1.0);
    this.spawnParticles(this.ballPos, shooter.style.auraColor, 34, 13);
  }

  private stepGoalCelebration(dt: number) {
    this.goalCelebrationTimer -= dt;
    this.stepBallPhysics(dt, false);
    for (const actor of this.actors) {
      actor.vel.multiplyScalar(Math.exp(-5 * dt));
      actor.emoteTimer = Math.max(0, actor.emoteTimer - dt);
      actor.actionTimer = Math.max(0, actor.actionTimer - dt);
      if (actor.emoteTimer === 0) actor.emote = null;
      if (actor.actionTimer === 0) actor.actionAnim = 'NONE';
      this.animateActorRig(actor, dt);
    }
    this.updateCamera(dt);
    if (this.goalCelebrationTimer <= 0) {
      this.goalBanner = null;
      this.resetKickoffPositions();
      this.phase = 'LIVE';
      soundEngine.playWhistle();
    }
  }

  private stepLiveMatch(dt: number) {
    if (!this.isTraining) {
      this.timeRemaining = Math.max(0, this.timeRemaining - dt);
      if (this.timeRemaining <= 0) {
        this.phase = 'ENDED';
        this.heldKeys.clear();
        soundEngine.setRainAmbiance(false);
        soundEngine.playWhistle();
        this.emitHud();
        this.onMatchEnd(this.blueScore, this.redScore, { ...this.matchStats });
        return;
      }
    }

    this.skill1Cd = Math.max(0, this.skill1Cd - dt);
    this.skill2Cd = Math.max(0, this.skill2Cd - dt);
    this.personalCd = Math.max(0, this.personalCd - dt);
    this.dribbleCd = Math.max(0, this.dribbleCd - dt);
    this.slideCd = Math.max(0, this.slideCd - dt);
    this.speedBoostTimer = Math.max(0, this.speedBoostTimer - dt);
    this.duoComboCd = Math.max(0, this.duoComboCd - dt);
    this.aiDuoCooldown = Math.max(0, this.aiDuoCooldown - dt);

    if (this.duoPass?.active) {
      this.duoPass.timer -= dt;
      this.duoPass.autoTriggerTimer -= dt;
      if (this.duoPass.timer <= 0) {
        this.duoPass = null;
      } else if (this.duoPass.autoTriggerTimer <= 0) {
        const passer = this.actors.find((a) => a.id === this.duoPass?.passerId);
        const receiver = this.actors.find((a) => a.id === this.duoPass?.receiverId);
        if (passer && receiver && !receiver.isUser && this.ballPos.distanceTo(receiver.pos) < 8.5) {
          this.triggerMusabMusaCombo(passer, receiver);
          return;
        }
      }
    }

    if (this.isAwakened) {
      this.awakeningTimeLeft -= dt;
      if (this.awakeningTimeLeft <= 0) {
        this.isAwakened = false;
        this.awakeningTimeLeft = 0;
        this.ultiUsedInAwakening = false;
      }
    } else {
      const rate = this.isTraining ? 12.0 : 2.2;
      this.awakening = Math.min(100, this.awakening + dt * rate);
    }

    if (this.shotCharging && this.ballOwner === this.userActor) {
      this.shotCharge = Math.min(1, this.shotCharge + dt * 1.45);
    }

    this.stepUserMovement(dt);
    for (const actor of this.actors) {
      if (!actor.isUser) {
        this.stepAiActor(actor, dt);
      }
      this.animateActorRig(actor, dt);
    }

    this.stepBallPhysics(dt, true);
    this.updateCamera(dt);
  }

  private stepUserMovement(dt: number) {
    const u = this.userActor;
    u.stunTimer = Math.max(0, u.stunTimer - dt);
    u.dribbleIFrame = Math.max(0, u.dribbleIFrame - dt);
    u.tackleTimer = Math.max(0, u.tackleTimer - dt);
    u.stealCooldown = Math.max(0, u.stealCooldown - dt);
    u.wallShieldTimer = Math.max(0, u.wallShieldTimer - dt);
    u.gkDiveTimer = Math.max(0, u.gkDiveTimer - dt);
    u.gkDiveCd = Math.max(0, u.gkDiveCd - dt);
    u.emoteTimer = Math.max(0, u.emoteTimer - dt);
    u.actionTimer = Math.max(0, u.actionTimer - dt);
    if (u.emoteTimer === 0) u.emote = null;
    if (u.actionTimer === 0) u.actionAnim = 'NONE';

    if (this.ballOwner !== u) {
      u.gkBallInHands = false;
      u.gkHoldTimer = 0;
    } else if (u.gkBallInHands) {
      const inOwnBox =
        u.team === 'BLUE'
          ? u.pos.x <= -38 && Math.abs(u.pos.z) <= 18
          : u.pos.x >= 38 && Math.abs(u.pos.z) <= 18;
      if (!inOwnBox) {
        u.gkBallInHands = false;
        u.gkHoldTimer = 0;
        this.showToast('Ceza sahası dışına çıktın — top ayakta!');
      } else {
        u.gkHoldTimer = Math.max(0, u.gkHoldTimer - dt);
        if (u.gkHoldTimer <= 0) {
          this.ballOwner = null;
          u.gkBallInHands = false;
          u.stealCooldown = 0.65;
          this.setActorAction(u, 'KICK', 0.45);
          const dirX = u.team === 'BLUE' ? 1 : -1;
          this.ballVel.set(dirX * 32, 6.2, (Math.random() - 0.5) * 6);
          this.ballCurve = 0;
          this.ballTopspin = 0.1;
          soundEngine.playKick(0.8);
          this.showToast('Süre doldu — Kaleci Degajı!');
        }
      }
    }

    const flow = FLOWS[this.activeFlowId];
    const roleDef = ROLES[u.role];
    if (u.stunTimer > 0) {
      u.vel.multiplyScalar(Math.exp(-8 * dt));
      u.pos.addScaledVector(u.vel, dt);
      return;
    }

    if (u.gkDiveTimer > 0) {
      u.pos.addScaledVector(u.vel, dt);
      u.vel.multiplyScalar(Math.exp(-2.8 * dt));
      this.clampToPitch(u.pos);
      if (!this.ballOwner && u.isGoalkeeper && !u.gkBallInHands && u.pos.distanceTo(this.ballPos) < 2.65 && this.ballPos.y < 3.4) {
        this.catchBallAsGk(u);
      }
      return;
    }

    if (u.tackleTimer > 0) {
      u.pos.addScaledVector(u.vel, dt);
      u.vel.multiplyScalar(Math.exp(-3.8 * dt));
      this.clampToPitch(u.pos);
      if (
        this.ballOwner &&
        this.ballOwner.team !== 'BLUE' &&
        !this.ballOwner.gkBallInHands &&
        this.ballOwner.pos.distanceTo(u.pos) < 2.6
      ) {
        this.stealBall(u, this.ballOwner);
      }
      return;
    }

    const { moveX, moveZ, isMoving } = this.computeCameraMoveVector();
    const wantsSprint =
      (this.heldKeys.has('ShiftLeft') || this.heldKeys.has('ShiftRight')) && isMoving && this.stamina > 2;

    if (wantsSprint) {
      this.stamina = Math.max(0, this.stamina - dt * 22);
    } else {
      this.stamina = Math.min(100, this.stamina + dt * 15 * flow.staminaRegenMult * roleDef.staminaRegenMult);
    }

    const baseSpeed = 9.5 + (u.style.stats.speed / 100) * 5.2;
    const sprintMult = wantsSprint ? 1.38 : 1.0;
    const awakeMult = this.isAwakened ? flow.speedMult * 1.12 : 1.0;
    const boostMult = this.speedBoostTimer > 0 ? 1.32 : 1.0;
    const dribbleDrag = this.ballOwner === u ? 0.94 : 1.0;
    const maxSpeed = baseSpeed * roleDef.speedMult * sprintMult * awakeMult * boostMult * dribbleDrag;

    if (isMoving) {
      _vecA.set(moveX, 0, moveZ).normalize();
      u.vel.x = THREE.MathUtils.damp(u.vel.x, _vecA.x * maxSpeed, 12, dt);
      u.vel.z = THREE.MathUtils.damp(u.vel.z, _vecA.z * maxSpeed, 12, dt);
      const targetYaw = this.shiftLock ? this.camYaw : Math.atan2(-_vecA.z, _vecA.x);
      let diff = targetYaw - u.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      u.yaw += diff * Math.min(1, this.shiftLock ? 24 * dt : 14 * dt);
    } else {
      u.vel.x = THREE.MathUtils.damp(u.vel.x, 0, 12, dt);
      u.vel.z = THREE.MathUtils.damp(u.vel.z, 0, 12, dt);
      if (this.shiftLock) {
        u.yaw = this.camYaw;
      }
    }

    u.pos.addScaledVector(u.vel, dt);
    this.clampToPitch(u.pos);
  }

  private stepAiActor(a: Actor, dt: number) {
    a.stunTimer = Math.max(0, a.stunTimer - dt);
    a.dribbleIFrame = Math.max(0, a.dribbleIFrame - dt);
    a.tackleTimer = Math.max(0, a.tackleTimer - dt);
    a.stealCooldown = Math.max(0, a.stealCooldown - dt);
    a.emoteTimer = Math.max(0, a.emoteTimer - dt);
    a.actionTimer = Math.max(0, a.actionTimer - dt);
    if (a.emoteTimer === 0) a.emote = null;
    if (a.actionTimer === 0) a.actionAnim = 'NONE';

    if (a.stunTimer > 0) {
      a.vel.multiplyScalar(Math.exp(-8 * dt));
      a.pos.addScaledVector(a.vel, dt);
      return;
    }

    if (a.isGoalkeeper) {
      // AI Kaleci Zorluğu: KOLAY / ORTA / ZOR
      const cfg =
        this.gkDifficulty === 'EASY'
          ? { speed: 6.0, reach: 1.45, saveChance: 0.48, parryChance: 0.2 }
          : this.gkDifficulty === 'HARD'
            ? { speed: 13.8, reach: 2.45, saveChance: 0.92, parryChance: 0.65 }
            : { speed: 9.6, reach: 1.92, saveChance: 0.72, parryChance: 0.42 };

      const goalX = a.team === 'BLUE' ? -PITCH_HALF_LENGTH + 1.8 : PITCH_HALF_LENGTH - 1.8;
      const targetZ = THREE.MathUtils.clamp(this.ballPos.z * 0.78, -GOAL_HALF_WIDTH + 0.5, GOAL_HALF_WIDTH - 0.5);
      _vecA.set(goalX - a.pos.x, 0, targetZ - a.pos.z);
      const dist = _vecA.length();
      if (dist > 0.08) {
        _vecA.normalize();
        a.pos.addScaledVector(_vecA, Math.min(dist, cfg.speed * dt));
      }
      a.yaw = a.team === 'BLUE' ? 0 : Math.PI;

      if (this.ballOwner === a) {
        this.ballOwner = null;
        a.stealCooldown = 0.7;
        const dirX = a.team === 'BLUE' ? 1 : -1;
        this.ballVel.set(dirX * 26, 4.6, (Math.random() - 0.5) * 14);
        this.ballCurve = 0;
        this.ballTopspin = 0.1;
        soundEngine.playKick(0.7);
      } else if (!this.ballOwner && this.ballPos.distanceTo(a.pos) < cfg.reach && this.ballPos.y < 3.0) {
        const ballSpeed = Math.hypot(this.ballVel.x, this.ballVel.z);
        if (this.isUltiBallActive && (this.gkDifficulty !== 'HARD' || Math.random() < 0.8)) {
          a.stunTimer = 0.85;
          this.spawnParticles(a.pos.clone().setY(1.2), '#fbbf24', 18, 8);
        } else if (Math.random() < cfg.saveChance) {
          this.isUltiBallActive = false;
          if (ballSpeed > 32 && Math.random() < cfg.parryChance) {
            const outDir = a.team === 'BLUE' ? 1 : -1;
            this.ballVel.set(outDir * 14, 4.2, (this.ballPos.z >= 0 ? 1 : -1) * 11);
            this.showToast('Kaleciden Kritik Çelme!');
          } else {
            this.ballOwner = a;
            this.showToast(`${a.team === 'BLUE' ? 'Mavi' : 'Rakip'} Kaleci Kurtardı!`);
          }
          soundEngine.playKick(0.65);
        }
      }
      return;
    }

    const attackDir = a.team === 'BLUE' ? 1 : -1;
    const goalX = attackDir * PITCH_HALF_LENGTH;
    const speed = 7.4 + (a.style.stats.speed / 100) * 3.8;

    // Pairwise separation force so Solo AI bots don't crowd the user or form a train
    let sepX = 0;
    let sepZ = 0;
    for (const other of this.actors) {
      if (other === a || other.isGoalkeeper) continue;
      const rx = a.pos.x - other.pos.x;
      const rz = a.pos.z - other.pos.z;
      const rdist = Math.hypot(rx, rz);
      const minSpace = other.team === a.team ? 5.2 : 2.8;
      if (rdist > 0.001 && rdist < minSpace) {
        const push = ((minSpace - rdist) / minSpace) * speed * 1.35;
        sepX += (rx / rdist) * push;
        sepZ += (rz / rdist) * push;
      }
    }

    if (this.ballOwner === a) {
      // AI Musab -> Kullanıcı Musa: Uzak mesafe havadan özel Roveşata pası gönder! (20s CD)
      if (
        a.team === 'BLUE' &&
        a.style.id === 'musab' &&
        this.userActor.style.id === 'musa' &&
        this.userActor.stunTimer <= 0 &&
        this.aiDuoCooldown <= 0 &&
        this.duoComboCd <= 0 &&
        !this.duoPass &&
        a.pos.distanceTo(this.userActor.pos) >= 8
      ) {
        this.launchDuoAerialPass(a, this.userActor);
        this.showToast("MUSAB UZAKTAN HAVADAN PAS ATTI — ROVEŞATA İÇİN [E]'YE BAS!!");
        this.emitHud();
        return;
      }

      let nearestDef: Actor | null = null;
      let nearestDefDist = Infinity;
      for (const opp of this.actors) {
        if (opp.team !== a.team && !opp.isGoalkeeper) {
          const d = a.pos.distanceTo(opp.pos);
          if (d < nearestDefDist) {
            nearestDefDist = d;
            nearestDef = opp;
          }
        }
      }

      if (
        a.team === 'BLUE' &&
        this.userActor.pos.x > a.pos.x - 4 &&
        (nearestDefDist < 5.0 || Math.random() < dt * 1.3)
      ) {
        _vecB.subVectors(this.userActor.pos, this.ballPos).normalize();
        this.ballOwner = null;
        a.stealCooldown = 0.6;
        this.setActorAction(a, 'KICK', 0.36);
        this.ballVel.set(_vecB.x * 23, 1.9, _vecB.z * 23);
        soundEngine.playKick(0.5);
        return;
      }

      const distGoal = Math.abs(goalX - a.pos.x);
      if (distGoal < 30 && Math.random() < dt * 1.7) {
        const cornerZ = (a.pos.z >= 0 ? -1 : 1) * (GOAL_HALF_WIDTH - 1.1) + (Math.random() - 0.5) * 1.4;
        _vecB.set(goalX - a.pos.x, 0, cornerZ - a.pos.z).normalize();
        this.ballOwner = null;
        this.lastTouchActorId = a.id;
        a.stealCooldown = 0.6;
        this.setActorAction(a, 'KICK', 0.42);
        this.ballVel.set(_vecB.x * 35, 3.4, _vecB.z * 35);
        this.ballCurve = (a.pos.z > 0 ? -0.35 : 0.35);
        this.ballTopspin = 0.25;
        soundEngine.playKick(0.82);
      } else {
        let dx = goalX - a.pos.x;
        let dz = -a.pos.z * 0.35;
        if (nearestDef && nearestDefDist < 7.0) {
          const dodgeSign = a.pos.z - nearestDef.pos.z >= 0 ? 1 : -1;
          dz += dodgeSign * 7.5;
        }
        const len = Math.hypot(dx, dz) || 1;
        const desVx = (dx / len) * speed * 0.92 + sepX * 0.25;
        const desVz = (dz / len) * speed * 0.92 + sepZ * 0.25;
        a.vel.x = THREE.MathUtils.damp(a.vel.x, desVx, 10, dt);
        a.vel.z = THREE.MathUtils.damp(a.vel.z, desVz, 10, dt);
        a.yaw = Math.atan2(-a.vel.z, a.vel.x);
        a.pos.addScaledVector(a.vel, dt);
      }
    } else {
      const owner = this.ballOwner;
      let tx: number;
      let tz: number;
      let isDesignatedPresser = false;

      if (owner && owner.gkBallInHands) {
        if (owner.team !== a.team) {
          // Kaleci topu elindeyken rakip botlar ceza sahasından uzaklaşır, kesinlikle dalmaz!
          tx = owner.team === 'BLUE' ? -30 : 30;
          tz = a.homePos.z;
        } else {
          // Takım arkadaşları pas almak için ileri açılır
          tx = attackDir * 12;
          tz = a.homePos.z;
        }
      } else if (owner && owner.team === a.team) {
        const spreadSide = Math.abs(a.homePos.z) > 3 ? Math.sign(a.homePos.z) : owner.pos.z >= 0 ? -1 : 1;
        const laneZ = Math.abs(owner.pos.z - a.homePos.z) < 7 ? spreadSide * 18 : a.homePos.z * 1.15;
        tx = THREE.MathUtils.clamp(owner.pos.x + attackDir * 16 + a.homePos.x * 0.12, -PITCH_HALF_LENGTH + 8, PITCH_HALF_LENGTH - 8);
        tz = THREE.MathUtils.clamp(laneZ, -PITCH_HALF_WIDTH + 4.5, PITCH_HALF_WIDTH - 4.5);
      } else {
        const distBall = a.pos.distanceTo(this.ballPos);
        let closerTeammateExists = false;
        for (const other of this.actors) {
          if (other !== a && other.team === a.team && !other.isGoalkeeper && other.stunTimer <= 0) {
            const od = other.pos.distanceTo(this.ballPos);
            if ((other.isUser && od < 6.5) || od + (other.isUser ? -1.5 : 0.4) < distBall) {
              closerTeammateExists = true;
              break;
            }
          }
        }

        if (!closerTeammateExists) {
          isDesignatedPresser = true;
          tx = this.ballPos.x;
          tz = this.ballPos.z;
        } else {
          tx = THREE.MathUtils.clamp(a.homePos.x * 0.65 + this.ballPos.x * 0.42, -PITCH_HALF_LENGTH + 7, PITCH_HALF_LENGTH - 7);
          tz = THREE.MathUtils.clamp(a.homePos.z * 0.8 + this.ballPos.z * 0.25, -PITCH_HALF_WIDTH + 3.5, PITCH_HALF_WIDTH - 3.5);
        }
      }

      const dx = tx - a.pos.x;
      const dz = tz - a.pos.z;
      const distTarget = Math.hypot(dx, dz);
      let desVx = sepX;
      let desVz = sepZ;
      if (distTarget > 0.8) {
        const moveScale = isDesignatedPresser ? speed : THREE.MathUtils.clamp(distTarget * 0.9, 2.5, speed * 0.88);
        desVx += (dx / distTarget) * moveScale;
        desVz += (dz / distTarget) * moveScale;
      }
      const totalMag = Math.hypot(desVx, desVz);
      if (totalMag > speed) {
        desVx = (desVx / totalMag) * speed;
        desVz = (desVz / totalMag) * speed;
      }
      a.vel.x = THREE.MathUtils.damp(a.vel.x, desVx, 9, dt);
      a.vel.z = THREE.MathUtils.damp(a.vel.z, desVz, 9, dt);
      a.pos.addScaledVector(a.vel, dt);

      if (Math.hypot(a.vel.x, a.vel.z) > 0.8) {
        a.yaw = Math.atan2(-a.vel.z, a.vel.x);
      } else {
        a.yaw = Math.atan2(-(this.ballPos.z - a.pos.z), this.ballPos.x - a.pos.x);
      }

      if (
        this.ballOwner &&
        !this.ballOwner.gkBallInHands &&
        this.ballOwner.team !== a.team &&
        this.ballOwner.dribbleIFrame <= 0 &&
        this.ballOwner.wallShieldTimer <= 0 &&
        a.stealCooldown <= 0 &&
        a.pos.distanceTo(this.ballOwner.pos) < 1.85 &&
        Math.random() < dt * 2.2
      ) {
        this.stealBall(a, this.ballOwner);
      }
    }

    this.clampToPitch(a.pos);
  }

  private animateActorRig(a: Actor, dt: number) {
    a.rig.root.position.copy(a.pos);
    a.rig.root.rotation.y = a.yaw;
    const rig = a.rig;
    const damp = (curr: number, target: number, lambda = 14) =>
      THREE.MathUtils.damp(curr, target, lambda, dt);

    // Subtle aura glow while awakened
    const showAura = a.isUser ? this.isAwakened : a.awakened;
    rig.auraPillars.visible = showAura;
    rig.auraPillars.position.set(0, 0, 0);
    rig.auraRing.position.set(0, 0.04, 0);
    (rig.auraRing.material as THREE.MeshBasicMaterial).opacity = showAura ? 0.62 : 0;
    if (showAura) {
      const pulse = 0.92 + Math.sin(this.clock.elapsedTime * 7) * 0.14;
      rig.auraPillars.scale.set(1, pulse, 1);
      rig.auraRing.rotation.z += dt * 2.4;
      rig.auraPillars.rotation.y -= dt * 1.8;
    } else {
      rig.auraPillars.scale.set(1, 1, 1);
    }

    // 1. EMOTE ANIMATIONS (Goal celebrations & [X] Emotes)
    if (a.emoteTimer > 0 && a.emote) {
      const et = Math.max(0, 2.6 - a.emoteTimer);
      rig.headGroup.rotation.set(0, 0, 0);
      rig.bodyPivot.rotation.x = damp(rig.bodyPivot.rotation.x, 0, 14);
      rig.bodyPivot.rotation.y = damp(rig.bodyPivot.rotation.y, 0, 14);
      rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, 0, 14);

      if (a.emote === 'SIUUU') {
        const jumpP = Math.min(1, et / 0.85);
        const airborne = et < 0.85 ? Math.sin(jumpP * Math.PI) : 0;
        rig.bodyPivot.position.y = airborne * 1.35;
        rig.bodyPivot.rotation.y = et < 0.85 ? jumpP * Math.PI * 2 : 0;
        if (et < 0.72) {
          rig.upperTorsoPivot.rotation.z = damp(rig.upperTorsoPivot.rotation.z, -0.25, 16);
          rig.leftArmPivot.rotation.set(0, 0, 1.35);
          rig.rightArmPivot.rotation.set(0, 0, 1.35);
          rig.leftElbowPivot.rotation.z = 0.85;
          rig.rightElbowPivot.rotation.z = 0.85;
          rig.leftKneePivot.rotation.z = -1.05;
          rig.rightKneePivot.rotation.z = -1.05;
        } else {
          // Explosive wide-arm SIUUU landing pose
          rig.upperTorsoPivot.rotation.set(0, 0, 0.24);
          rig.leftArmPivot.rotation.set(0.68, 0, -1.05);
          rig.rightArmPivot.rotation.set(-0.68, 0, -1.05);
          rig.leftElbowPivot.rotation.z = 0.2;
          rig.rightElbowPivot.rotation.z = 0.2;
          rig.leftLegPivot.rotation.set(0.28, 0, -0.15);
          rig.rightLegPivot.rotation.set(-0.28, 0, -0.15);
          rig.leftKneePivot.rotation.z = -0.28;
          rig.rightKneePivot.rotation.z = -0.28;
        }
        return;
      }
      if (a.emote === 'EGOIST_POSE') {
        rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0.04, 12);
        rig.upperTorsoPivot.rotation.set(0, -0.22, 0.14);
        rig.rightArmPivot.rotation.set(-0.18, 0, 2.35);
        rig.rightElbowPivot.rotation.z = 0.15;
        rig.leftArmPivot.rotation.set(0.32, 0, -0.38);
        rig.leftElbowPivot.rotation.z = 1.45;
        rig.leftLegPivot.rotation.set(0.12, 0, -0.18);
        rig.rightLegPivot.rotation.set(-0.12, 0, 0.22);
        rig.leftKneePivot.rotation.z = -0.15;
        rig.rightKneePivot.rotation.z = -0.12;
        return;
      }
      if (a.emote === 'KNEE_SLIDE') {
        rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, -0.5, 14);
        rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, 0.2, 14);
        rig.upperTorsoPivot.rotation.set(0, 0, 0.18);
        rig.leftLegPivot.rotation.set(0.12, 0, 0.45);
        rig.rightLegPivot.rotation.set(-0.12, 0, 0.45);
        rig.leftKneePivot.rotation.z = -1.48;
        rig.rightKneePivot.rotation.z = -1.48;
        const pump = Math.sin(et * 10) * 0.25;
        rig.leftArmPivot.rotation.set(0.55, 0, -0.9 + pump);
        rig.rightArmPivot.rotation.set(-0.55, 0, -0.9 - pump);
        rig.leftElbowPivot.rotation.z = 0.9;
        rig.rightElbowPivot.rotation.z = 0.9;
        return;
      }
      if (a.emote === 'ARMS_CROSSED') {
        rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0, 12);
        rig.upperTorsoPivot.rotation.set(0, 0, 0.06);
        rig.headGroup.rotation.z = -0.12;
        rig.leftArmPivot.rotation.set(-0.55, 0, 0.85);
        rig.rightArmPivot.rotation.set(0.55, 0, 0.85);
        rig.leftElbowPivot.rotation.z = 1.65;
        rig.rightElbowPivot.rotation.z = 1.65;
        rig.leftLegPivot.rotation.set(0.1, 0, 0.05);
        rig.rightLegPivot.rotation.set(-0.1, 0, -0.05);
        rig.leftKneePivot.rotation.z = -0.08;
        rig.rightKneePivot.rotation.z = -0.08;
        return;
      }
      // FLEX_ROAR
      rig.bodyPivot.position.y = Math.abs(Math.sin(et * 6)) * 0.06;
      rig.upperTorsoPivot.rotation.set(0, 0, 0.22);
      rig.leftArmPivot.rotation.set(-0.68, 0, 1.25);
      rig.rightArmPivot.rotation.set(0.68, 0, 1.25);
      rig.leftElbowPivot.rotation.z = 1.78;
      rig.rightElbowPivot.rotation.z = 1.78;
      rig.leftLegPivot.rotation.set(0.22, 0, -0.15);
      rig.rightLegPivot.rotation.set(-0.22, 0, 0.15);
      rig.leftKneePivot.rotation.z = -0.22;
      rig.rightKneePivot.rotation.z = -0.22;
      return;
    }

    const actionP =
      a.actionTimer > 0
        ? THREE.MathUtils.clamp(1 - a.actionTimer / Math.max(0.12, a.actionDuration), 0, 1)
        : 0;

    // 2. SLIDE / AWAKENED STEAL POSE (Alçalma -> Kayma -> Kalkış)
    if (a.tackleTimer > 0 || a.actionAnim === 'SLIDE' || a.actionAnim === 'AWAKENED_STEAL') {
      const isAwk = a.actionAnim === 'AWAKENED_STEAL' || showAura;
      const enterP = Math.min(1, actionP / 0.25);
      const exitP = actionP > 0.78 ? (actionP - 0.78) / 0.22 : 0;
      const slideWeight = enterP * (1 - exitP * 0.65);
      rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, 1.14 * slideWeight, 22);
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, -0.5 * slideWeight, 22);
      rig.upperTorsoPivot.rotation.set(0, isAwk ? Math.sin(this.clock.elapsedTime * 22) * 0.32 : 0, -0.22 * slideWeight);
      rig.rightLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(0.1, 0.68, slideWeight));
      rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.25, -0.08, slideWeight);
      rig.leftLegPivot.rotation.set(0, 0, -0.45 * slideWeight);
      rig.leftKneePivot.rotation.z = THREE.MathUtils.lerp(-0.2, -1.18, slideWeight);
      rig.leftArmPivot.rotation.set(0.35, 0, -0.85 * slideWeight);
      rig.leftElbowPivot.rotation.z = 0.5;
      rig.rightArmPivot.rotation.set(-0.25, 0, 0.85 * slideWeight);
      rig.rightElbowPivot.rotation.z = 0.75;
      return;
    }

    // 2.5 GK_DIVE (Kaleci Sola / Sağa Uzanma & Zıplayış)
    if (a.actionTimer > 0 && a.actionAnim === 'GK_DIVE') {
      const diveArc = Math.sin(actionP * Math.PI);
      const latVel = Math.sin(a.yaw) * a.vel.x + Math.cos(a.yaw) * a.vel.z;
      const sideSign = Math.abs(latVel) > 1.2 ? Math.sign(latVel) : 0;
      rig.bodyPivot.position.y = diveArc * (sideSign !== 0 ? 0.78 : 1.45);
      rig.bodyPivot.rotation.x = sideSign * 1.18 * diveArc;
      rig.bodyPivot.rotation.z = sideSign === 0 ? -0.14 * diveArc : 0.08 * diveArc;
      rig.upperTorsoPivot.rotation.set(sideSign * 0.25 * diveArc, 0, -0.24 * diveArc);
      rig.leftArmPivot.rotation.set(-0.32, 0, 2.55);
      rig.rightArmPivot.rotation.set(0.32, 0, 2.55);
      rig.leftElbowPivot.rotation.z = 0.14;
      rig.rightElbowPivot.rotation.z = 0.14;
      rig.leftLegPivot.rotation.set(0, 0, -0.22);
      rig.rightLegPivot.rotation.set(0, 0, 0.22);
      rig.leftKneePivot.rotation.z = -0.32 * diveArc;
      rig.rightKneePivot.rotation.z = -0.32 * diveArc;
      return;
    }

    // 3. REALISTIC KICK / POWER SHOT / PASS (Germe -> Vuruş -> Devam)
    if (a.actionTimer > 0 && a.actionAnim === 'KICK') {
      if (actionP < 0.28) {
        const w = actionP / 0.28;
        rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, -0.08 * w, 20);
        rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0.03 * w, 18);
        rig.upperTorsoPivot.rotation.set(0, 0.34 * w, -0.1 * w);
        rig.rightLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(0, -0.85, w));
        rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.1, -1.18, w);
        rig.leftLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(0, 0.38, w));
        rig.leftKneePivot.rotation.z = THREE.MathUtils.lerp(-0.1, -0.26, w);
        rig.leftArmPivot.rotation.set(0.45, 0, 0.75 * w);
        rig.rightArmPivot.rotation.set(-0.2, 0, -0.55 * w);
      } else if (actionP < 0.62) {
        const s = 1 - Math.pow(1 - (actionP - 0.28) / 0.34, 3);
        rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, -0.22 * s, 22);
        rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0.08 * Math.sin(s * Math.PI), 20);
        rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.34, -0.45, s), -0.24);
        rig.rightLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(-0.85, 1.5, s));
        rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.18, -0.08, s);
        rig.leftLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(0.38, -0.32, s));
        rig.leftKneePivot.rotation.z = -0.3;
        rig.leftArmPivot.rotation.set(0.45, 0, THREE.MathUtils.lerp(0.75, 1.05, s));
        rig.rightArmPivot.rotation.set(-0.2, 0, -0.75);
      } else {
        const f = (actionP - 0.62) / 0.38;
        rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-0.22, 0, f);
        rig.bodyPivot.position.y = THREE.MathUtils.lerp(0.05, 0, f);
        rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(-0.45, 0, f), THREE.MathUtils.lerp(-0.24, -0.06, f));
        rig.rightLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(1.5, 0.12, f));
        rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.08, -0.22, f);
        rig.leftLegPivot.rotation.set(0, 0, THREE.MathUtils.lerp(-0.32, 0, f));
        rig.leftKneePivot.rotation.z = THREE.MathUtils.lerp(-0.3, -0.1, f);
        rig.leftArmPivot.rotation.set(0.25, 0, THREE.MathUtils.lerp(1.05, 0.1, f));
        rig.rightArmPivot.rotation.set(-0.15, 0, THREE.MathUtils.lerp(-0.75, 0, f));
      }
      rig.leftElbowPivot.rotation.z = 0.75;
      rig.rightElbowPivot.rotation.z = 0.55;
      return;
    }

    // 4. SKILL LEAP / AWAKENED DRIBBLE / SKILL BURST
    if (a.actionTimer > 0 && (a.actionAnim === 'SKILL_LEAP' || a.actionAnim === 'AWAKENED_DRIBBLE' || a.actionAnim === 'SKILL_BURST')) {
      if (a.actionAnim === 'SKILL_LEAP') {
        const arc = Math.sin(actionP * Math.PI);
        rig.bodyPivot.position.y = arc * 1.25;
        rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-0.18, 0.14, actionP);
        rig.upperTorsoPivot.rotation.set(0, 0, -0.32 * arc);
        rig.leftLegPivot.rotation.z = 0.35 * arc;
        rig.rightLegPivot.rotation.z = -0.25 * arc;
        rig.leftKneePivot.rotation.z = -1.1 * arc;
        rig.rightKneePivot.rotation.z = -0.9 * arc;
        rig.leftArmPivot.rotation.set(0.28, 0, 1.55 * arc);
        rig.rightArmPivot.rotation.set(-0.28, 0, 1.55 * arc);
        return;
      }
      if (a.actionAnim === 'AWAKENED_DRIBBLE') {
        const spinP = actionP < 0.5 ? 2 * actionP * actionP : 1 - Math.pow(-2 * actionP + 2, 2) / 2;
        rig.bodyPivot.rotation.y = spinP * Math.PI * 2;
        rig.bodyPivot.position.y = -0.06;
        rig.upperTorsoPivot.rotation.set(0, 0, -0.32);
        rig.leftArmPivot.rotation.set(0.4, 0, -0.85);
        rig.rightArmPivot.rotation.set(-0.4, 0, -0.85);
        rig.leftElbowPivot.rotation.z = 1.05;
        rig.rightElbowPivot.rotation.z = 1.05;
        rig.leftLegPivot.rotation.z = Math.sin(actionP * Math.PI * 4) * 0.72;
        rig.rightLegPivot.rotation.z = -Math.sin(actionP * Math.PI * 4) * 0.72;
        rig.leftKneePivot.rotation.z = -0.82;
        rig.rightKneePivot.rotation.z = -0.82;
        return;
      }
      // SKILL_BURST
      const burstWave = Math.sin(actionP * Math.PI);
      rig.upperTorsoPivot.rotation.set(0, Math.sin(actionP * Math.PI * 4) * 0.16, -0.36 * burstWave);
      rig.leftArmPivot.rotation.set(0.22, 0, -1.05 * burstWave);
      rig.rightArmPivot.rotation.set(-0.22, 0, -1.05 * burstWave);
      rig.leftElbowPivot.rotation.z = 0.48;
      rig.rightElbowPivot.rotation.z = 0.48;
    }

    rig.bodyPivot.rotation.x = damp(rig.bodyPivot.rotation.x, 0, 14);
    rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, 0, 14);

    if (a.dribbleIFrame > 0 || a.actionAnim === 'DRIBBLE_SPIN') {
      if (a.actionAnim === 'DRIBBLE_SPIN' && a.actionTimer > 0) {
        const spinP = actionP < 0.5 ? 2 * actionP * actionP : 1 - Math.pow(-2 * actionP + 2, 2) / 2;
        rig.bodyPivot.rotation.y = spinP * Math.PI * 2;
      } else {
        rig.bodyPivot.rotation.y += dt * 13;
      }
    } else {
      rig.bodyPivot.rotation.y = damp(rig.bodyPivot.rotation.y, 0, 14);
    }

    if (a.stunTimer > 0) {
      const wobble = Math.sin(this.clock.elapsedTime * 16) * 0.22;
      rig.upperTorsoPivot.rotation.set(wobble, 0, 0.14);
      rig.headGroup.rotation.y += dt * 10;
      rig.leftArmPivot.rotation.set(0, 0, 0.25);
      rig.rightArmPivot.rotation.set(0, 0, 0.25);
      rig.leftElbowPivot.rotation.z = 0.55;
      rig.rightElbowPivot.rotation.z = 0.55;
      rig.leftKneePivot.rotation.z = -0.35;
      rig.rightKneePivot.rotation.z = -0.35;
      return;
    }
    rig.headGroup.rotation.y = damp(rig.headGroup.rotation.y, 0, 14);
    rig.headGroup.rotation.z = damp(rig.headGroup.rotation.z, 0, 14);

    // 5. REALISTIC ATHLETIC SPRINT / RUN / GOALKEEPER READY / IDLE BREATHING
    const speed = Math.hypot(a.vel.x, a.vel.z);
    if (speed > 0.55) {
      a.animPhase += dt * (4.8 + speed * 0.62);
      const spFactor = THREE.MathUtils.clamp((speed - 4) / 14, 0, 1);
      const hipAmp = 0.54 + spFactor * 0.4;
      const armAmp = 0.5 + spFactor * 0.36;
      const s = Math.sin(a.animPhase);
      const c = Math.cos(a.animPhase);

      rig.leftLegPivot.rotation.set(0, 0, s * hipAmp);
      rig.rightLegPivot.rotation.set(0, 0, -s * hipAmp);

      // Realistic asymmetric knee flexion (knee bends cleanly backward during recovery swing!)
      const lKneeTarget = -Math.max(0.08, (c * 0.5 + 0.5) * (0.78 + spFactor * 0.52));
      const rKneeTarget = -Math.max(0.08, (-c * 0.5 + 0.5) * (0.78 + spFactor * 0.52));
      rig.leftKneePivot.rotation.z = damp(rig.leftKneePivot.rotation.z, lKneeTarget, 22);
      rig.rightKneePivot.rotation.z = damp(rig.rightKneePivot.rotation.z, rKneeTarget, 22);

      rig.leftArmPivot.rotation.set(0.08, 0, -s * armAmp);
      rig.rightArmPivot.rotation.set(-0.08, 0, s * armAmp);
      const elbowBend = 0.8 + spFactor * 0.45;
      rig.leftElbowPivot.rotation.z = damp(rig.leftElbowPivot.rotation.z, elbowBend, 18);
      rig.rightElbowPivot.rotation.z = damp(rig.rightElbowPivot.rotation.z, elbowBend, 18);

      // Forward torso sprint lean + subtle counter-rotation
      if (a.actionTimer <= 0) {
        rig.upperTorsoPivot.rotation.z = damp(rig.upperTorsoPivot.rotation.z, -0.14 - spFactor * 0.22, 14);
      }
      rig.upperTorsoPivot.rotation.y = damp(rig.upperTorsoPivot.rotation.y, -s * (0.09 + spFactor * 0.1), 16);
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, Math.abs(c) * (0.045 + spFactor * 0.045), 20);
    } else if (a.isGoalkeeper) {
      // Goalkeeper athletic crouch & lateral side-shuffle ready stance
      const breathe = Math.sin(this.clock.elapsedTime * 3.4 + a.animPhase) * 0.03;
      rig.upperTorsoPivot.rotation.set(0, 0, damp(rig.upperTorsoPivot.rotation.z, -0.2, 12));
      rig.leftLegPivot.rotation.set(0.18, 0, 0.22);
      rig.rightLegPivot.rotation.set(-0.18, 0, 0.22);
      rig.leftKneePivot.rotation.z = damp(rig.leftKneePivot.rotation.z, -0.45, 14);
      rig.rightKneePivot.rotation.z = damp(rig.rightKneePivot.rotation.z, -0.45, 14);
      rig.leftArmPivot.rotation.set(-0.42, 0, 0.55 + breathe);
      rig.rightArmPivot.rotation.set(0.42, 0, 0.55 + breathe);
      rig.leftElbowPivot.rotation.z = damp(rig.leftElbowPivot.rotation.z, 0.75, 14);
      rig.rightElbowPivot.rotation.z = damp(rig.rightElbowPivot.rotation.z, 0.75, 14);
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, -0.06 + breathe, 12);
    } else {
      // Relaxed athletic idle breathing stance
      const breathe = Math.sin(this.clock.elapsedTime * 2.8 + a.animPhase) * 0.025;
      rig.leftLegPivot.rotation.set(damp(rig.leftLegPivot.rotation.x, 0.04, 10), 0, damp(rig.leftLegPivot.rotation.z, 0.05, 12));
      rig.rightLegPivot.rotation.set(damp(rig.rightLegPivot.rotation.x, -0.04, 10), 0, damp(rig.rightLegPivot.rotation.z, -0.04, 12));
      rig.leftKneePivot.rotation.z = damp(rig.leftKneePivot.rotation.z, -0.1, 12);
      rig.rightKneePivot.rotation.z = damp(rig.rightKneePivot.rotation.z, -0.08, 12);
      rig.leftArmPivot.rotation.set(damp(rig.leftArmPivot.rotation.x, -0.05, 10), 0, damp(rig.leftArmPivot.rotation.z, breathe, 12));
      rig.rightArmPivot.rotation.set(damp(rig.rightArmPivot.rotation.x, 0.05, 10), 0, damp(rig.rightArmPivot.rotation.z, -breathe, 12));
      rig.leftElbowPivot.rotation.z = damp(rig.leftElbowPivot.rotation.z, 0.28, 12);
      rig.rightElbowPivot.rotation.z = damp(rig.rightElbowPivot.rotation.z, 0.28, 12);
      rig.upperTorsoPivot.rotation.set(0, damp(rig.upperTorsoPivot.rotation.y, 0, 12), damp(rig.upperTorsoPivot.rotation.z, -0.04 + breathe * 0.5, 12));
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, breathe * 0.4, 12);
    }

    if (a.gkBallInHands && a.actionTimer <= 0) {
      rig.leftArmPivot.rotation.set(-0.34, 0, 1.05);
      rig.rightArmPivot.rotation.set(0.34, 0, 1.05);
      rig.leftElbowPivot.rotation.z = 0.72;
      rig.rightElbowPivot.rotation.z = 0.72;
    }
  }

  private stepBallPhysics(dt: number, checkGoals: boolean) {
    if (this.ballOwner) {
      const owner = this.ballOwner;
      const fwdX = Math.cos(owner.yaw);
      const fwdZ = -Math.sin(owner.yaw);
      const speed = Math.hypot(owner.vel.x, owner.vel.z);
      const bounce = speed > 0.8 ? Math.abs(Math.sin(owner.animPhase * 1.4)) * 0.14 : 0;
      if (owner.gkBallInHands) {
        this.ballPos.set(owner.pos.x + fwdX * 0.72, 1.24, owner.pos.z + fwdZ * 0.72);
      } else {
        this.ballPos.set(owner.pos.x + fwdX * 0.95, 0.36 + bounce, owner.pos.z + fwdZ * 0.95);
      }
      this.ballVel.set(owner.vel.x, 0, owner.vel.z);
      this.ball.mesh.rotation.z -= (speed / 0.36) * dt * 0.55;
      (this.ball.trailRing.material as THREE.MeshBasicMaterial).opacity = 0;
    } else {
      // Gravity + Topspin aerodynamic dip
      this.ballVel.y -= (17.5 + this.ballTopspin * 8.0) * dt;
      if (Math.abs(this.ballCurve) > 0.01) {
        const horizLen = Math.hypot(this.ballVel.x, this.ballVel.z);
        if (horizLen > 3) {
          const perpZ = this.ballVel.x / horizLen;
          const perpX = -this.ballVel.z / horizLen;
          this.ballVel.x += perpX * this.ballCurve * 15 * dt;
          this.ballVel.z += perpZ * this.ballCurve * 15 * dt;
        }
      }

      this.ballPos.addScaledVector(this.ballVel, dt);

      if (this.ballPos.y < 0.36) {
        this.ballPos.y = 0.36;
        if (Math.abs(this.ballVel.y) > 1.8) {
          this.ballVel.y = -this.ballVel.y * 0.58;
        } else {
          this.ballVel.y = 0;
        }
        const friction = Math.exp(-1.55 * dt);
        this.ballVel.x *= friction;
        this.ballVel.z *= friction;
        this.ballCurve *= Math.exp(-2 * dt);
        this.ballTopspin *= Math.exp(-2 * dt);
      } else {
        const airDrag = Math.exp(-0.26 * dt);
        this.ballVel.x *= airDrag;
        this.ballVel.z *= airDrag;
      }

      // Realistic rolling rotation v / r
      this.ball.mesh.rotation.z -= (this.ballVel.x / 0.36) * dt * 0.45;
      this.ball.mesh.rotation.x += (this.ballVel.z / 0.36) * dt * 0.45;

      // Cylindrical Goalpost Bounce + Metallic Clang
      const posts: Array<[number, number]> = [
        [-PITCH_HALF_LENGTH, -GOAL_HALF_WIDTH],
        [-PITCH_HALF_LENGTH, GOAL_HALF_WIDTH],
        [PITCH_HALF_LENGTH, -GOAL_HALF_WIDTH],
        [PITCH_HALF_LENGTH, GOAL_HALF_WIDTH],
      ];
      for (const [px, pz] of posts) {
        if (this.ballPos.y < GOAL_HEIGHT + 0.25) {
          const dx = this.ballPos.x - px;
          const dz = this.ballPos.z - pz;
          const d = Math.hypot(dx, dz);
          if (d < 0.5 && d > 0.001) {
            const nx = dx / d;
            const nz = dz / d;
            this.ballPos.x = px + nx * 0.52;
            this.ballPos.z = pz + nz * 0.52;
            const dot = this.ballVel.x * nx + this.ballVel.z * nz;
            if (dot < 0) {
              this.ballVel.x = (this.ballVel.x - 2 * dot * nx) * 0.78;
              this.ballVel.z = (this.ballVel.z - 2 * dot * nz) * 0.78;
              soundEngine.playPostClang();
              this.showToast('DİREKTEN DÖNDÜ!');
            }
          }
        }
      }

      const ballSpeed = this.ballVel.length();
      const trailMat = this.ball.trailRing.material as THREE.MeshBasicMaterial;
      if (this.isUltiBallActive || this.duoPass?.active || ballSpeed > 26) {
        trailMat.opacity = 0.85;
        trailMat.color.set(
          this.duoPass?.active
            ? '#facc15'
            : this.isUltiBallActive
              ? this.userActor.style.auraColor
              : '#38bdf8'
        );
        this.ball.trailRing.rotation.y += dt * 14;
        if ((this.isUltiBallActive || this.duoPass?.active) && Math.random() < 0.65) {
          this.spawnParticles(this.ballPos, this.duoPass?.active ? '#facc15' : this.userActor.style.auraColor, 2, 3);
        }
      } else {
        trailMat.opacity = 0;
      }

      if (checkGoals) {
        const inGoalMouthZ = Math.abs(this.ballPos.z) < GOAL_HALF_WIDTH - 0.25;
        const underCrossbar = this.ballPos.y < GOAL_HEIGHT;

        if (inGoalMouthZ && underCrossbar) {
          if (this.ballPos.x >= PITCH_HALF_LENGTH) {
            this.onGoalScored('BLUE');
            return;
          }
          if (this.ballPos.x <= -PITCH_HALF_LENGTH) {
            this.onGoalScored('RED');
            return;
          }
        }
      }

      if (Math.abs(this.ballPos.z) > PITCH_HALF_WIDTH) {
        this.ballPos.z = Math.sign(this.ballPos.z) * PITCH_HALF_WIDTH;
        this.ballVel.z *= -0.72;
      }
      if (Math.abs(this.ballPos.x) > PITCH_HALF_LENGTH) {
        if (Math.abs(this.ballPos.z) >= GOAL_HALF_WIDTH || this.ballPos.y >= GOAL_HEIGHT) {
          this.ballPos.x = Math.sign(this.ballPos.x) * PITCH_HALF_LENGTH;
          this.ballVel.x *= -0.72;
        }
      }

      if (this.ballPos.y < 2.4) {
        for (const a of this.actors) {
          if ((a.isGoalkeeper && !a.isUser) || a.stealCooldown > 0 || a.stunTimer > 0) continue;
          const reach = a.isGoalkeeper ? 1.75 : 1.45;
          const maxH = a.isGoalkeeper ? 2.4 : 1.85;
          if (this.ballPos.y < maxH && a.pos.distanceTo(this.ballPos) < reach) {
            if (this.isUltiBallActive && a.team === 'RED') {
              a.stunTimer = 0.8;
              continue;
            }
            if (this.duoPass?.active && a.team === 'RED' && this.ballPos.y > 0.95) {
              continue;
            }
            if (a.isGoalkeeper) {
              this.catchBallAsGk(a);
            } else {
              this.ballOwner = a;
              if (this.duoPass?.active && a.id !== this.duoPass.receiverId) {
                this.duoPass = null;
              }
              this.isUltiBallActive = false;
              this.lastTouchActorId = a.id;
              this.lastTouchTeam = a.team;
              this.lastTouchName = a.style.name;
            }
            break;
          }
        }
      }
    }

    this.ball.group.position.copy(this.ballPos);
    this.ball.shadow.position.set(this.ballPos.x, 0.02, this.ballPos.z);
    const shadowScale = Math.max(0.45, 1.0 - this.ballPos.y * 0.08);
    this.ball.shadow.scale.setScalar(shadowScale);
  }

  private onGoalScored(scoringTeam: 'BLUE' | 'RED') {
    if (scoringTeam === 'BLUE') {
      this.blueScore++;
      if (this.lastTouchTeam === 'BLUE') this.matchStats.goals++;
      this.awakening = Math.min(100, this.awakening + 25);
    } else {
      this.redScore++;
    }
    const emoteSpec = EMOTE_LIST[Math.floor(Math.random() * EMOTE_LIST.length)];
    let scorer =
      (this.lastTouchActorId ? this.actors.find((a) => a.id === this.lastTouchActorId) : undefined) ??
      this.actors.find((a) => a.team === scoringTeam && !a.isGoalkeeper);
    if (scorer && scorer.team !== scoringTeam) {
      scorer = this.actors.find((a) => a.team === scoringTeam && !a.isGoalkeeper) ?? scorer;
    }
    if (scorer) {
      scorer.emote = emoteSpec.id;
      scorer.emoteTimer = 2.6;
    }

    this.netRippleSide = scoringTeam;
    this.netRippleTimer = 1.0;
    this.slowMoTimer = 0.42;
    this.goalBanner = {
      scorerId: scorer?.id ?? null,
      scorerName: scorer ? scorer.style.name : scoringTeam === 'BLUE' ? this.lastTouchName : 'RAKİP EGOİST',
      team: scoringTeam,
      isUltiGoal: this.isUltiBallActive,
      emote: emoteSpec.id,
    };
    this.isUltiBallActive = false;
    this.ballVel.multiplyScalar(0.2);
    this.goalCelebrationTimer = 2.6;
    this.phase = 'GOAL_CELEBRATION';
    this.cameraShake = 0.52;
    soundEngine.playGoalHorn();
    soundEngine.playCrowdCheer();
    this.spawnParticles(
      this.ballPos.clone().setY(1.8),
      scoringTeam === 'BLUE' ? '#38bdf8' : '#ef4444',
      42,
      15
    );
    this.emitHud();
  }

  private stepNetRipple(dt: number) {
    if (this.netRippleTimer <= 0) return;
    this.netRippleTimer = Math.max(0, this.netRippleTimer - dt);
    const net = this.netRippleSide === 'BLUE' ? this.stadium.blueNet : this.stadium.redNet;
    const s = 1 + Math.sin(this.netRippleTimer * 26) * 0.14 * this.netRippleTimer;
    net.scale.set(s, 1, s);
    if (this.netRippleTimer === 0) net.scale.set(1, 1, 1);
  }

  private stepParticles(dt: number) {
    for (const p of this.particles) {
      if (p.life > 0) {
        p.life -= dt;
        p.vel.y -= 12 * dt;
        p.mesh.position.addScaledVector(p.vel, dt);
        p.mesh.rotation.x += dt * 6;
        p.mesh.rotation.y += dt * 6;
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, p.life / p.maxLife);
        if (p.life <= 0) {
          p.mesh.visible = false;
        }
      }
    }
  }

  private clampToPitch(pos: THREE.Vector3) {
    pos.x = THREE.MathUtils.clamp(pos.x, -PITCH_HALF_LENGTH - 1.5, PITCH_HALF_LENGTH + 1.5);
    pos.z = THREE.MathUtils.clamp(pos.z, -PITCH_HALF_WIDTH - 1.5, PITCH_HALF_WIDTH + 1.5);
    if (this.phase === 'GOAL_CELEBRATION') {
      pos.x = THREE.MathUtils.clamp(pos.x, -PITCH_HALF_LENGTH - GOAL_DEPTH, PITCH_HALF_LENGTH + GOAL_DEPTH);
    }
  }

  private updateCamera(dt: number) {
    // Goal Celebration: ALL players' cameras lock onto the goal scorer celebrating!
    if (this.phase === 'GOAL_CELEBRATION') {
      const scorer =
        (this.goalBanner?.scorerId
          ? this.actors.find((a) => a.id === this.goalBanner!.scorerId)
          : undefined) ??
        this.actors.find((a) => a.team === (this.goalBanner?.team ?? 'BLUE') && !a.isGoalkeeper) ??
        this.userActor;
      if (scorer) {
        const orbitAngle = scorer.yaw + (2.6 - Math.max(0, this.goalCelebrationTimer)) * 1.1;
        this.goalCelebrationTimer = Math.max(0, this.goalCelebrationTimer - (this.onlineMode ? dt : 0));
        const orbitDist = 5.4;
        _camTargetPos.set(
          scorer.pos.x + Math.cos(orbitAngle) * orbitDist,
          scorer.pos.y + 2.35,
          scorer.pos.z - Math.sin(orbitAngle) * orbitDist
        );
        _camTargetLook.set(scorer.pos.x, scorer.pos.y + 1.45, scorer.pos.z);

        this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camTargetPos.x, 7, dt);
        this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camTargetPos.y, 7, dt);
        this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camTargetPos.z, 7, dt);
        _camCurrLook.x = THREE.MathUtils.damp(_camCurrLook.x, _camTargetLook.x, 9, dt);
        _camCurrLook.y = THREE.MathUtils.damp(_camCurrLook.y, _camTargetLook.y, 9, dt);
        _camCurrLook.z = THREE.MathUtils.damp(_camCurrLook.z, _camTargetLook.z, 9, dt);
        this.camera.lookAt(_camCurrLook);
        return;
      }
    }

    const u = this.userActor;
    if (!u) return;

    const fwdX = Math.cos(this.camYaw);
    const fwdZ = -Math.sin(this.camYaw);
    const rightX = Math.sin(this.camYaw);
    const rightZ = Math.cos(this.camYaw);

    const horizDist = Math.cos(this.camPitch) * this.camDist;
    const vertDist = Math.sin(this.camPitch) * this.camDist;
    const shoulderOffset = this.shiftLock ? 1.55 : 0;

    _camTargetPos.set(
      u.pos.x - fwdX * horizDist + rightX * shoulderOffset,
      u.pos.y + 1.55 + vertDist,
      u.pos.z - fwdZ * horizDist + rightZ * shoulderOffset
    );
    _camTargetLook.set(
      u.pos.x + fwdX * 3.8 + rightX * (shoulderOffset * 0.65),
      1.45,
      u.pos.z + fwdZ * 3.8 + rightZ * (shoulderOffset * 0.65)
    );

    const posDamp = this.shiftLock || this.isRightDragging ? 18 : 10;
    const lookDamp = this.shiftLock || this.isRightDragging ? 20 : 12;

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camTargetPos.x, posDamp, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camTargetPos.y, posDamp, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camTargetPos.z, posDamp, dt);

    _camCurrLook.x = THREE.MathUtils.damp(_camCurrLook.x, _camTargetLook.x, lookDamp, dt);
    _camCurrLook.y = THREE.MathUtils.damp(_camCurrLook.y, _camTargetLook.y, lookDamp, dt);
    _camCurrLook.z = THREE.MathUtils.damp(_camCurrLook.z, _camTargetLook.z, lookDamp, dt);

    if (this.cameraShake > 0.005) {
      this.cameraShake *= Math.exp(-8 * dt);
      _vecC.set(
        (Math.random() - 0.5) * this.cameraShake,
        (Math.random() - 0.5) * this.cameraShake,
        (Math.random() - 0.5) * this.cameraShake
      );
      this.camera.position.add(_vecC);
    }

    const sprintingNow =
      (this.heldKeys.has('ShiftLeft') || this.heldKeys.has('ShiftRight')) &&
      Math.hypot(u.vel.x, u.vel.z) > 6;
    const desiredFov = this.settings.fov + (this.isAwakened ? 6 : 0) + (sprintingNow ? 4 : 0);
    if (Math.abs(this.camera.fov - desiredFov) > 0.12) {
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, desiredFov, 7, dt);
      this.camera.updateProjectionMatrix();
    }

    this.camera.lookAt(_camCurrLook);
  }

  private setShiftLock(enabled: boolean, silent = false) {
    this.shiftLock = enabled;
    this.hasLastMouse = false;
    try {
      if (enabled) {
        const res = this.renderer.domElement.requestPointerLock?.() as unknown as Promise<void> | undefined;
        if (res && typeof res.catch === 'function') {
          res.catch(() => {
            // iframe may block pointerLock; relative mouse tracking still works
          });
        }
      } else if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock?.();
      }
    } catch {
      // ignore pointerLock restrictions
    }
    if (!silent) {
      this.showToast(enabled ? 'SHIFTLOCK AÇIK [ALT]' : 'SHIFTLOCK KAPALI');
    }
    this.emitHud();
  }

  // ==================== INPUT & LIFECYCLE ====================

  private handleKeyDown = (e: KeyboardEvent) => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      if (this.phase === 'LIVE') e.preventDefault();
    }
    const wasHeld = this.heldKeys.has(e.code);
    this.heldKeys.add(e.code);

    if (
      this.onlineMode &&
      !wasHeld &&
      ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight'].includes(
        e.code
      )
    ) {
      this.sendOnlineInputNow();
    }

    if (e.repeat) return;

    if (e.code === 'AltLeft' || e.code === 'AltRight') {
      if (this.phase === 'LIVE') {
        e.preventDefault();
        this.setShiftLock(!this.shiftLock);
      }
      return;
    }

    if (e.code === 'Escape') {
      if (this.phase === 'LIVE' || this.phase === 'PAUSED') {
        this.togglePause();
      }
      return;
    }

    if (this.phase !== 'LIVE') return;

    // Requested Exact Key Bindings:
    // R = Şut, C = Pas, X = Emote, Q = Çalım (Kaleci: Sola Atla), F = Kayma, 1/2 = Yetenekler, E/3 = Kişiye Özel (Kaleci: Sağa Atla), Space = Kaleci Zıplama, G = Uyanış, V = Ulti, Alt = ShiftLock
    const isUserGk = Boolean(this.userActor?.isGoalkeeper);
    if (this.onlineMode && this.onlineClient) {
      if (e.code === 'Space' && isUserGk) {
        if (!this.netGkBallInHands && this.netGkDiveCd <= 0 && this.userActor) {
          this.setActorAction(this.userActor, 'GK_DIVE', 0.42);
        }
        this.onlineClient.sendAction('GK_JUMP');
      } else if (e.code === 'KeyQ') {
        if (isUserGk) {
          if (!this.netGkBallInHands && this.netGkDiveCd <= 0 && this.userActor) {
            this.setActorAction(this.userActor, 'GK_DIVE', 0.55);
          }
          this.onlineClient.sendAction('GK_DIVE_LEFT');
        } else {
          if (this.dribbleCd <= 0 && this.userActor) {
            this.setActorAction(this.userActor, this.isAwakened ? 'AWAKENED_DRIBBLE' : 'DRIBBLE_SPIN', 0.55);
          }
          this.onlineClient.sendAction('DRIBBLE');
        }
      } else if (e.code === 'KeyF') {
        if (this.slideCd <= 0 && this.userActor) {
          this.setActorAction(this.userActor, this.isAwakened ? 'AWAKENED_STEAL' : 'SLIDE', 0.44);
        }
        this.onlineClient.sendAction('SLIDE');
      } else if (e.code === 'KeyC') this.onlineClient.sendAction('PASS');
      else if (e.code === 'KeyX') this.onlineClient.sendAction('EMOTE');
      else if (e.code === 'Digit1') this.onlineClient.sendAction('SKILL1');
      else if (e.code === 'Digit2') this.onlineClient.sendAction('SKILL2');
      else if (e.code === 'KeyE') {
        if (isUserGk) {
          if (!this.netGkBallInHands && this.netGkDiveCd <= 0 && this.userActor) {
            this.setActorAction(this.userActor, 'GK_DIVE', 0.55);
          }
          this.onlineClient.sendAction('GK_DIVE_RIGHT');
        } else {
          this.onlineClient.sendAction('PERSONAL');
        }
      } else if (e.code === 'Digit3') this.onlineClient.sendAction('PERSONAL');
      else if (e.code === 'KeyG') this.onlineClient.sendAction('AWAKENING');
      else if (e.code === 'KeyV') this.onlineClient.sendAction('ULTI');
      else if (e.code === 'KeyR') {
        this.shotCharging = true;
        this.sendOnlineInputNow();
      }
      return;
    }

    if (e.code === 'Space' && isUserGk) this.triggerGkDive('JUMP');
    else if (e.code === 'KeyQ') {
      if (isUserGk) this.triggerGkDive('LEFT');
      else this.useDribble();
    } else if (e.code === 'KeyF') this.useSlideTackle();
    else if (e.code === 'KeyC') this.usePass();
    else if (e.code === 'KeyX') this.triggerEmote();
    else if (e.code === 'Digit1') this.useSkill1();
    else if (e.code === 'Digit2') this.useSkill2();
    else if (e.code === 'KeyE') {
      if (isUserGk) this.triggerGkDive('RIGHT');
      else this.usePersonalSkill(true);
    } else if (e.code === 'Digit3') this.usePersonalSkill(false);
    else if (e.code === 'KeyG') this.tryActivateAwakening();
    else if (e.code === 'KeyV') this.tryActivateUlti();
    else if (e.code === 'KeyR') {
      if (this.ballOwner === this.userActor) {
        this.shotCharging = true;
        this.shotCharge = 0.25;
      }
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.heldKeys.delete(e.code);
    if (
      this.onlineMode &&
      ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight'].includes(
        e.code
      )
    ) {
      this.sendOnlineInputNow();
    }
    if (e.code === 'KeyR' && this.shotCharging) {
      if (this.onlineMode && this.onlineClient) {
        this.shotCharging = false;
        this.sendOnlineInputNow();
        this.onlineClient.sendAction('SHOOT_RELEASE');
      } else {
        this.releaseShot();
      }
    }
  };

  private handlePointerDown = (e: PointerEvent) => {
    if (this.phase !== 'LIVE') return;
    if (e.button === 0) {
      if (this.onlineMode) {
        this.shotCharging = true;
        this.sendOnlineInputNow();
      } else if (this.ballOwner === this.userActor) {
        this.shotCharging = true;
        this.shotCharge = 0.22;
      }
    } else if (e.button === 2) {
      this.isRightDragging = true;
      this.hasLastMouse = true;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
    }
  };

  private handlePointerMove = (e: PointerEvent) => {
    if (this.phase !== 'LIVE') return;
    if (!this.isRightDragging && !this.shiftLock) {
      this.hasLastMouse = false;
      return;
    }
    let dx = 0;
    let dy = 0;
    if (document.pointerLockElement === this.renderer.domElement) {
      dx = e.movementX || 0;
      dy = e.movementY || 0;
    } else if (this.hasLastMouse) {
      dx = e.clientX - this.lastMouseX;
      dy = e.clientY - this.lastMouseY;
    }
    this.hasLastMouse = true;
    this.lastMouseX = e.clientX;
    this.lastMouseY = e.clientY;

    if (dx !== 0 || dy !== 0) {
      const sens = this.settings.mouseSensitivity;
      this.camYaw -= dx * 0.0055 * sens;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + dy * 0.0045 * sens, 0.14, 1.12);
    }
  };

  private handlePointerUp = (e: PointerEvent) => {
    if (e.button === 0 && this.shotCharging) {
      if (this.onlineMode && this.onlineClient) {
        this.shotCharging = false;
        this.sendOnlineInputNow();
        this.onlineClient.sendAction('SHOOT_RELEASE');
      } else {
        this.releaseShot();
      }
    } else if (e.button === 2) {
      this.isRightDragging = false;
      this.hasLastMouse = false;
    }
  };

  private handleWheel = (e: WheelEvent) => {
    if (this.phase !== 'LIVE') return;
    e.preventDefault();
    this.camDist = THREE.MathUtils.clamp(this.camDist + e.deltaY * 0.006, 6.5, 18);
  };

  private handleContextMenu = (e: MouseEvent) => {
    if (this.phase === 'LIVE') e.preventDefault();
  };

  private handleBlur = () => {
    this.heldKeys.clear();
    this.shotCharging = false;
    this.shotCharge = 0;
    this.isRightDragging = false;
    this.hasLastMouse = false;
  };

  private handleResize = () => {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
  };

  private bindEvents() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('blur', this.handleBlur);
    window.addEventListener('resize', this.handleResize);
    this.renderer.domElement.addEventListener('pointerdown', this.handlePointerDown);
    window.addEventListener('pointermove', this.handlePointerMove);
    window.addEventListener('pointerup', this.handlePointerUp);
    this.renderer.domElement.addEventListener('wheel', this.handleWheel, { passive: false });
    this.renderer.domElement.addEventListener('contextmenu', this.handleContextMenu);
  }

  private emitHud() {
    const s = this.userActor ? this.userActor.style : STYLES[this.activeStyleId];
    let duoComboPrompt: HudSnapshot['duoComboPrompt'] = null;
    if (this.onlineMode) {
      duoComboPrompt = this.netDuoPrompt ?? null;
    } else if (this.duoPass?.active && this.userActor) {
      const isReceiver = this.duoPass.receiverId === this.userActor.id;
      duoComboPrompt = {
        active: true,
        role: isReceiver ? 'RECEIVER' : 'PASSER',
        title: isReceiver ? "MUSAB'DAN UZAK HAVADAN PAS!" : 'MUSA UZAKTAN ROVEŞATA BEKLİYOR!',
        subtitle: isReceiver ? "[E]'YE BAS — İKİZ ROVEŞATA!" : 'MUSA [E] İLE ROVEŞATA VURUYOR!',
        timeLeft: Number(Math.max(0, this.duoPass.timer).toFixed(1)),
        cooldownLeft: Number(this.duoComboCd.toFixed(1)),
      };
    } else if (
      !this.onlineMode &&
      this.userActor &&
      s.id === 'musab' &&
      this.ballOwner === this.userActor &&
      this.actors.some((a) => a.team === 'BLUE' && !a.isGoalkeeper && a.style.id === 'musa')
    ) {
      duoComboPrompt = {
        active: this.duoComboCd <= 0,
        role: 'PASSER',
        title: 'MUSAB × MUSA UZAK PAS',
        subtitle:
          this.duoComboCd <= 0
            ? "[E] İLE MUSA'YA UZAKTAN HAVADAN PAS AT!"
            : `20s Bekleme: ${Math.ceil(this.duoComboCd)}s kaldı`,
        timeLeft: 0,
        cooldownLeft: Number(this.duoComboCd.toFixed(1)),
      };
    }

    const radarEntities: RadarEntity[] = this.actors.map((a) => ({
      x: a.pos.x / PITCH_HALF_LENGTH,
      z: a.pos.z / PITCH_HALF_WIDTH,
      team: a.team,
      isUser: a.isUser,
      isGoalkeeper: a.isGoalkeeper,
      yaw: a.yaw,
    }));
    radarEntities.push({
      x: this.ballPos.x / PITCH_HALF_LENGTH,
      z: this.ballPos.z / PITCH_HALF_WIDTH,
      team: 'BALL',
    });

    this.onHudUpdate({
      phase: this.phase,
      blueScore: this.blueScore,
      redScore: this.redScore,
      timeRemaining: Math.ceil(this.timeRemaining),
      stamina: Math.round(this.stamina),
      awakening: Math.round(this.awakening),
      isAwakened: this.isAwakened,
      awakeningTimeLeft: Math.max(0, Number(this.awakeningTimeLeft.toFixed(1))),
      ultiUsedInAwakening: this.ultiUsedInAwakening,
      shotCharge: this.shotCharge,
      hasBall: this.onlineMode ? this.netHasBall : this.ballOwner === this.userActor,
      skill1Cd: Number(this.skill1Cd.toFixed(1)),
      skill1MaxCd: s.skill1.cooldown,
      skill2Cd: Number(this.skill2Cd.toFixed(1)),
      skill2MaxCd: s.skill2.cooldown,
      personalCd: Number(this.personalCd.toFixed(1)),
      personalMaxCd: s.personalSkill.cooldown,
      dribbleCd: Number(this.dribbleCd.toFixed(1)),
      slideCd: Number(this.slideCd.toFixed(1)),
      gkDifficulty: this.gkDifficulty,
      matchMode: this.matchMode,
      role: this.userActor ? this.userActor.role : this.selectedRole,
      gkBallInHands: this.onlineMode ? this.netGkBallInHands : Boolean(this.userActor?.gkBallInHands),
      gkHoldLeft: this.onlineMode
        ? this.netGkHoldLeft
        : Number((this.userActor?.gkHoldTimer ?? 0).toFixed(1)),
      gkDiveCd: this.onlineMode
        ? this.netGkDiveCd
        : Number((this.userActor?.gkDiveCd ?? 0).toFixed(1)),
      isTraining: this.isTraining,
      shiftLock: this.shiftLock,
      isOnline: this.onlineMode,
      roomCode: this.onlineRoomCode,
      pingMs: this.onlineMode ? this.onlinePingMs : null,
      queueType: this.onlineMode ? this.onlineQueueType : undefined,
      fps: this.currentFps,
      duoComboCd: this.onlineMode ? (this.netDuoPrompt?.cooldownLeft ?? 0) : Number(this.duoComboCd.toFixed(1)),
      radarEntities,
      stats: { ...this.matchStats },
      cutsceneBanner: this.cutsceneBanner,
      goalBanner: this.goalBanner,
      duoComboPrompt,
      lastActionToast: this.toastText,
    });
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    if (this.msgChannel) {
      this.msgChannel.port1.onmessage = null;
      this.msgChannel.port1.close();
      this.msgChannel.port2.close();
      this.msgChannel = null;
    }
    soundEngine.setRainAmbiance(false);

    this.setShiftLock(false, true);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('blur', this.handleBlur);
    window.removeEventListener('resize', this.handleResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.handlePointerDown);
    window.removeEventListener('pointermove', this.handlePointerMove);
    window.removeEventListener('pointerup', this.handlePointerUp);
    this.renderer.domElement.removeEventListener('wheel', this.handleWheel);
    this.renderer.domElement.removeEventListener('contextmenu', this.handleContextMenu);

    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) {
        obj.geometry?.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material?.dispose();
        }
      }
    });
    this.composer?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
