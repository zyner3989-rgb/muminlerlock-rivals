import * as THREE from 'three';
import { CLEAT_OPTIONS, OUTFIT_OPTIONS, resolveDefaultHairForStyle } from '../data/cosmetics';
import type {
  BackAccessoryId,
  HairStyleId,
  StyleDefinition,
  WardrobeConfig,
} from '../types/game';
import {
  createContactShadowTexture,
  createFabricBumpTexture,
  createJerseyTexture,
  createPitchBumpTexture,
  createPitchTexture,
  createScreenTexture,
  createSoccerBallBumpTexture,
  createSoccerBallTexture,
  createStadiumLedTexture,
} from './textures';

export interface PlayerRig {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  upperTorsoPivot: THREE.Group;
  headGroup: THREE.Group;
  torsoMesh: THREE.Mesh;
  leftArmPivot: THREE.Group;
  leftElbowPivot: THREE.Group;
  rightArmPivot: THREE.Group;
  rightElbowPivot: THREE.Group;
  leftLegPivot: THREE.Group;
  leftKneePivot: THREE.Group;
  rightLegPivot: THREE.Group;
  rightKneePivot: THREE.Group;
  headsetProp?: THREE.Group;
  gauntletProp?: THREE.Group;
  auraRing: THREE.Mesh;
  auraPillars: THREE.Group;
  shadowMesh: THREE.Mesh;
  selectionRing: THREE.Mesh;
}

export interface CutscenePropPack {
  root: THREE.Group;
  bed: THREE.Group;
  desk: THREE.Group;
  monitorScreen: THREE.Mesh;
  screenTextures: {
    bluelock_game: THREE.CanvasTexture;
    aras_lose: THREE.CanvasTexture;
    ai_cheat: THREE.CanvasTexture;
    phone_musab: THREE.CanvasTexture;
    videocall_musa: THREE.CanvasTexture;
  };
  phone: THREE.Group;
  phoneScreen: THREE.Mesh;
  pillow: THREE.Group;
  sock: THREE.Group;
  coach: THREE.Group;
  hamburger: THREE.Group;
  monsterBall: THREE.Group;
  snapRing: THREE.Mesh;
  deskHeadset: THREE.Group;
}

export interface StadiumRefs {
  root: THREE.Group;
  blueNet: THREE.Mesh;
  redNet: THREE.Mesh;
  crowdInstanced: THREE.InstancedMesh;
  pitchMat: THREE.MeshPhysicalMaterial;
  apronMat: THREE.MeshStandardMaterial;
  skyMat: THREE.ShaderMaterial;
  floodBeams: THREE.Mesh[];
  ledBoards: THREE.Mesh[];
  rainPoints: THREE.Points;
  rainVelocities: Float32Array;
}

export const PITCH_HALF_LENGTH = 58; // X: -58 to +58 (116m saha)
export const PITCH_HALF_WIDTH = 34; // Z: -34 to +34 (68m genişlik)
export const GOAL_HALF_WIDTH = 5.2;
export const GOAL_HEIGHT = 3.5;
export const GOAL_DEPTH = 3.2;

/**
 * Multi-layered Roblox/Anime UGC Hairstyles without oversized round dome caps
 * so every hairstyle silhouette, part, and highlight stands out clearly. Head faces +X!
 */
function buildRobuxHair(
  headGroup: THREE.Group,
  hairStyle: Exclude<HairStyleId, 'character'>,
  baseColorHex: string,
  highlightHex: string
) {
  const hairGroup = new THREE.Group();
  const baseCol = new THREE.Color(baseColorHex);
  const baseMat = new THREE.MeshPhysicalMaterial({
    color: baseCol,
    roughness: 0.44,
    metalness: 0.05,
    clearcoat: 0.22,
    clearcoatRoughness: 0.36,
  });

  // Harmonious tonal highlight derived from actual hair color (never muddy grey/cyan-on-red!)
  const tipCol = baseCol.clone();
  const hsl = { h: 0, s: 0, l: 0 };
  tipCol.getHSL(hsl);
  if (hsl.l < 0.16) {
    // Black/very dark hair: subtle cool midnight sheen blended lightly with accent
    tipCol.lerp(new THREE.Color(highlightHex), 0.24);
  } else {
    // Colored hair (red, blonde, blue, white): vibrant brighter lock highlights without greying
    tipCol.offsetHSL(0, 0.05, hsl.l > 0.72 ? -0.1 : 0.12);
  }
  const tipMat = new THREE.MeshPhysicalMaterial({
    color: tipCol,
    roughness: 0.36,
    metalness: 0.06,
    clearcoat: 0.3,
    clearcoatRoughness: 0.3,
  });

  const addLock = (
    rx: number,
    ry: number,
    rz: number,
    radiusTop: number,
    radiusBot: number,
    len: number,
    px: number,
    py: number,
    pz: number,
    mat: THREE.Material = baseMat,
    sx = 1,
    sz = 1
  ) => {
    const geo =
      radiusTop > 0.005
        ? new THREE.CylinderGeometry(radiusTop, radiusBot, len, 8)
        : new THREE.ConeGeometry(radiusBot, len, 8);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(px, py, pz);
    mesh.rotation.set(rx, ry, rz);
    mesh.scale.set(sx, 1, sz);
    mesh.castShadow = true;
    hairGroup.add(mesh);
  };

  // Seamless full-wrap scalp & temple hair base:
  // phi=0 is -X (back of head) in Three.js SphereGeometry; ±0.76*PI wraps cleanly past ears/temples leaving only +X face open!
  const crownCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.264, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.48),
    baseMat
  );
  crownCap.scale.set(1.03, 1.11, 0.965);
  crownCap.position.set(-0.006, 0.278, 0);
  crownCap.castShadow = true;
  hairGroup.add(crownCap);

  const backShell = new THREE.Mesh(
    new THREE.SphereGeometry(0.266, 24, 16, -Math.PI * 0.76, Math.PI * 1.52, Math.PI * 0.14, Math.PI * 0.72),
    baseMat
  );
  backShell.scale.set(1.045, 1.105, 0.975);
  backShell.position.set(-0.008, 0.275, 0);
  backShell.castShadow = true;
  hairGroup.add(backShell);

  // Full nape & side-temple locks so back, ear, and side angles never show exposed skin scalp
  for (let i = -3; i <= 3; i++) {
    addLock(
      i * 0.15,
      0,
      2.32,
      0.022,
      0.074,
      0.26,
      -0.215,
      0.18 + Math.abs(i) * 0.014,
      i * 0.062,
      i === 0 && hairStyle !== 'ponytail' ? tipMat : baseMat,
      0.9,
      1.2
    );
  }
  [-1, 1].forEach((s) => {
    addLock(s * 0.14, 0, 2.86, 0.02, 0.068, 0.25, 0.05, 0.26, s * 0.236, baseMat, 1.15, 0.78);
    addLock(s * 0.18, 0, 2.7, 0.02, 0.064, 0.24, -0.09, 0.24, s * 0.232, baseMat, 1.15, 0.78);
  });

  if (hairStyle === 'wolfcut') {
    // Rich Shaggy Wolfcut: sweeping curtain bangs + temple locks + flared nape spikes
    for (let i = -3; i <= 3; i++) {
      const side = Math.sign(i) || 1;
      const absI = Math.abs(i);
      const isHighlight = i === -1 || i === 2;
      addLock(
        side * 0.16,
        0,
        2.56 - absI * 0.12,
        0.016,
        0.072,
        0.25 - absI * 0.015,
        0.215 - absI * 0.024,
        0.44 - absI * 0.01,
        i * 0.058,
        isHighlight ? tipMat : baseMat,
        0.84,
        1.28
      );
    }
    [-1, 1].forEach((s) => {
      addLock(s * 0.18, 0, 2.9, 0.02, 0.074, 0.32, 0.04, 0.27, s * 0.244, baseMat, 1.08, 0.76);
      addLock(s * 0.22, 0, 2.75, 0.016, 0.064, 0.28, -0.07, 0.24, s * 0.235, tipMat, 1.08, 0.76);
    });
    for (let i = 0; i < 8; i++) {
      const ang = (i / 8) * Math.PI * 2;
      addLock(
        Math.sin(ang) * 0.5,
        0,
        -0.42 + Math.cos(ang) * 0.38,
        0.016,
        0.076,
        0.24,
        -0.02 + Math.cos(ang) * 0.105,
        0.585,
        Math.sin(ang) * 0.105,
        i % 2 === 0 ? baseMat : tipMat
      );
    }
    for (let i = -2; i <= 2; i++) {
      addLock(
        i * 0.18,
        0,
        2.18,
        0.014,
        0.072,
        0.32,
        -0.255,
        0.14 + Math.abs(i) * 0.02,
        i * 0.082,
        i === 0 ? tipMat : baseMat,
        0.85,
        1.18
      );
    }
  } else if (hairStyle === 'spiky') {
    // Sculpted layered anime spikes rooted deeply inside crown (zero floating cone gaps!)
    const spikeConfigs: Array<[number, number, number, number, number, number, boolean]> = [
      [0.05, 0.54, 0, 0.105, 0.34, -0.42, true],
      [-0.04, 0.53, -0.1, 0.1, 0.33, -0.58, false],
      [-0.04, 0.53, 0.1, 0.1, 0.33, -0.58, false],
      [-0.12, 0.48, -0.15, 0.095, 0.3, -0.82, true],
      [-0.12, 0.48, 0.15, 0.095, 0.3, -0.82, true],
      [-0.17, 0.42, 0, 0.105, 0.32, -1.02, false],
      [-0.2, 0.36, -0.11, 0.092, 0.28, -1.18, false],
      [-0.2, 0.36, 0.11, 0.092, 0.28, -1.18, false],
      [0.11, 0.5, -0.09, 0.088, 0.27, -0.25, false],
      [0.11, 0.5, 0.09, 0.088, 0.27, -0.25, true],
      [-0.08, 0.44, 0.19, 0.085, 0.26, -0.9, false],
      [-0.08, 0.44, -0.19, 0.085, 0.26, -0.9, false],
    ];
    for (const [px, py, pz, r, l, rz, isTip] of spikeConfigs) {
      addLock(pz * 0.95, 0, rz, 0.012, r, l, px, py, pz, isTip ? tipMat : baseMat, 1.04, 0.92);
    }
    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.14, 0, 2.5, 0.014, 0.068, 0.25, 0.21, 0.42, i * 0.066, i === 0 ? tipMat : baseMat);
    }
  } else if (hairStyle === 'curtain') {
    // Sleek Middle-Parted Anime Curtain Hair sculpted with flat blade locks
    [-1, 1].forEach((s) => {
      for (let t = 0; t < 4; t++) {
        addLock(
          s * (0.28 + t * 0.12),
          0,
          -0.85 - t * 0.12,
          0.02,
          0.078,
          0.34,
          0.02 - t * 0.05,
          0.54 - t * 0.02,
          s * (0.07 + t * 0.042),
          t === 1 ? tipMat : baseMat,
          0.78,
          1.28
        );
      }
      for (let k = 0; k < 3; k++) {
        addLock(
          s * (0.36 + k * 0.14),
          0,
          2.68 + k * 0.12,
          0.022,
          0.074,
          0.28,
          0.205 - k * 0.058,
          0.38 - k * 0.03,
          s * (0.058 + k * 0.072),
          k === 1 ? tipMat : baseMat,
          0.76,
          1.32
        );
      }
      addLock(s * 0.2, 0, 2.35, 0.02, 0.072, 0.26, -0.18, 0.22, s * 0.135, baseMat);
    });
  } else if (hairStyle === 'curly') {
    // Sculpted Curly Ringlets & Coiled Hair Locks wrapping full crown & sides
    const ringletGeo = new THREE.TorusGeometry(0.068, 0.03, 7, 12, Math.PI * 1.72);
    const curlNodes: Array<[number, number, number, number, number, boolean]> = [
      [0.05, 0.57, 0.0, 0.3, 0.4, false],
      [0.0, 0.58, 0.09, -0.35, 0.2, true],
      [0.0, 0.58, -0.09, 0.35, -0.2, false],
      [0.14, 0.54, 0.09, -0.4, 0.2, true],
      [0.14, 0.54, -0.09, 0.4, -0.2, false],
      [0.21, 0.46, 0.04, 0.1, 0.6, false],
      [0.20, 0.46, -0.08, -0.2, -0.5, true],
      [-0.07, 0.56, 0.11, 0.5, 0.1, false],
      [-0.07, 0.56, -0.11, -0.5, -0.1, true],
      [-0.17, 0.49, 0.0, 0.0, 0.8, false],
      [-0.16, 0.45, 0.15, 0.6, 0.3, false],
      [-0.16, 0.45, -0.15, -0.6, -0.3, false],
      [0.02, 0.50, 0.20, 0.8, 0.0, false],
      [0.02, 0.50, -0.20, -0.8, 0.0, true],
      [-0.08, 0.38, 0.22, 0.7, 0.2, false],
      [-0.08, 0.38, -0.22, -0.7, -0.2, true],
      [-0.24, 0.34, 0.09, 0.2, 1.1, false],
      [-0.24, 0.34, -0.09, -0.2, 1.1, false],
      [-0.25, 0.24, 0.0, 0.0, 1.2, true],
    ];
    for (const [cx, cy, cz, rx, rz, hi] of curlNodes) {
      const coil = new THREE.Mesh(ringletGeo, hi ? tipMat : baseMat);
      coil.position.set(cx, cy, cz);
      coil.rotation.set(rx, cx * 2.1, rz);
      coil.castShadow = true;
      hairGroup.add(coil);
    }
    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.22, 0, 2.52, 0.016, 0.056, 0.19, 0.215, 0.43, i * 0.068, i % 2 === 0 ? tipMat : baseMat);
    }
  } else if (hairStyle === 'windswept') {
    for (let i = 0; i < 6; i++) {
      const zOff = -0.15 + i * 0.062;
      addLock(
        0.22,
        -0.18,
        -0.85 - i * 0.06,
        0.016,
        0.084,
        0.36,
        -0.05 - i * 0.02,
        0.54 - Math.abs(i - 2.5) * 0.025,
        zOff,
        i % 2 === 1 ? tipMat : baseMat,
        1.1,
        0.84
      );
    }
    addLock(0.45, 0, 2.55, 0.018, 0.066, 0.29, 0.22, 0.39, 0.075, tipMat, 0.78, 1.35);
    addLock(0.2, 0, 2.58, 0.018, 0.058, 0.23, 0.21, 0.42, -0.088, baseMat, 0.82, 1.15);
  } else if (hairStyle === 'ponytail') {
    const tieMat = new THREE.MeshStandardMaterial({
      color: highlightHex,
      emissive: highlightHex,
      emissiveIntensity: 0.45,
      roughness: 0.28,
    });
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.022, 8, 16), tieMat);
    band.position.set(-0.23, 0.5, 0);
    band.rotation.y = Math.PI / 2;
    hairGroup.add(band);

    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.12, 0, -1.35, 0.018, 0.064, 0.31, -0.02, 0.53, i * 0.068, i === 0 ? tipMat : baseMat);
    }
    addLock(0, 0, 1.92, 0.058, 0.09, 0.36, -0.34, 0.44, 0, baseMat, 0.9, 1.15);
    addLock(0.18, 0, 2.15, 0.016, 0.074, 0.31, -0.41, 0.27, 0.05, tipMat);
    addLock(-0.18, 0, 2.15, 0.016, 0.074, 0.31, -0.41, 0.27, -0.05, baseMat);

    [-1, 1].forEach((s) => {
      addLock(s * 0.22, 0, 2.7, 0.016, 0.052, 0.24, 0.185, 0.35, s * 0.165, s > 0 ? tipMat : baseMat);
    });
  } else {
    // 'frostcrown'
    for (let i = 0; i < 10; i++) {
      const ang = (i / 10) * Math.PI * 2;
      const rad = 0.165;
      addLock(
        Math.sin(ang) * 0.42,
        0,
        -Math.cos(ang) * 0.42,
        0.022,
        0.08,
        0.27,
        Math.cos(ang) * rad - 0.01,
        0.57,
        Math.sin(ang) * rad,
        i % 2 === 0 ? tipMat : baseMat
      );
    }
    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.14, 0, 2.48, 0.018, 0.064, 0.23, 0.215, 0.42, i * 0.07, i % 2 === 0 ? tipMat : baseMat);
    }
  }

  headGroup.add(hairGroup);
}

/**
 * Adds flush-mounted back accessories anchored to upperTorsoPivot (y offset -1.08 from root)
 */
function buildBackAccessory(
  upperTorsoPivot: THREE.Group,
  accessoryId: BackAccessoryId,
  chestHalfX: number,
  chestHalfZ: number,
  accentHex: string,
  secondaryHex: string
) {
  if (accessoryId === 'none') return;

  const backX = -chestHalfX - 0.03;
  const yOff = -1.08;

  if (accessoryId === 'scarf') {
    const scarfMat = new THREE.MeshPhysicalMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.22,
      roughness: 0.55,
      clearcoat: 0.12,
    });
    const loop = new THREE.Mesh(
      new THREE.TorusGeometry(chestHalfX * 0.88, 0.065, 10, 20),
      scarfMat
    );
    loop.rotation.x = Math.PI / 2;
    loop.scale.set(1.0, (chestHalfZ / chestHalfX) * 0.65, 1.0);
    loop.position.set(0, 1.88 + yOff, 0);

    const tail1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.56, 0.18), scarfMat);
    tail1.position.set(backX - 0.14, 1.56 + yOff, -0.08);
    tail1.rotation.z = -0.34;
    tail1.rotation.y = 0.14;
    tail1.castShadow = true;

    const tail2 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.42, 0.15), scarfMat);
    tail2.position.set(backX - 0.11, 1.62 + yOff, 0.08);
    tail2.rotation.z = -0.24;
    tail2.rotation.y = -0.18;
    upperTorsoPivot.add(loop, tail1, tail2);
  } else if (accessoryId === 'cape') {
    const capeMat = new THREE.MeshStandardMaterial({
      color: '#0f172a',
      roughness: 0.65,
      side: THREE.DoubleSide,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: secondaryHex,
      emissive: accentHex,
      emissiveIntensity: 0.28,
      roughness: 0.35,
    });
    const capeBody = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.92, chestHalfZ * 1.85), capeMat);
    capeBody.position.set(backX - 0.09, 1.4 + yOff, 0);
    capeBody.rotation.z = -0.12;
    capeBody.castShadow = true;

    const trim = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.08, chestHalfZ * 1.87), trimMat);
    trim.position.set(backX - 0.14, 0.96 + yOff, 0);
    trim.rotation.z = -0.12;

    const clasp = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, chestHalfZ * 1.9), trimMat);
    clasp.position.set(-chestHalfX * 0.3, 1.86 + yOff, 0);
    upperTorsoPivot.add(capeBody, trim, clasp);
  } else if (accessoryId === 'katana') {
    const scabbardMat = new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.25, metalness: 0.85 });
    const gripMat = new THREE.MeshStandardMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.45,
      roughness: 0.3,
    });
    const scabbard = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.028, 1.28, 10), scabbardMat);
    scabbard.position.set(backX - 0.04, 1.48 + yOff, 0);
    scabbard.rotation.x = 0.68;

    const guard = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.03, 12), gripMat);
    guard.position.set(backX - 0.04, 1.84 + yOff, -0.35);
    guard.rotation.x = 0.68;

    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.3, 10), gripMat);
    hilt.position.set(backX - 0.04, 1.94 + yOff, -0.45);
    hilt.rotation.x = 0.68;
    upperTorsoPivot.add(scabbard, guard, hilt);
  } else if (accessoryId === 'wings') {
    const wingMat = new THREE.MeshPhysicalMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.65,
      transparent: true,
      opacity: 0.7,
      roughness: 0.18,
      metalness: 0.2,
      side: THREE.DoubleSide,
    });
    [-1, 1].forEach((s) => {
      const featherTop = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.24, 0.78), wingMat);
      featherTop.position.set(backX - 0.15, 1.72 + yOff, s * 0.44);
      featherTop.rotation.x = s * 0.22;
      featherTop.rotation.y = s * 0.32;

      const featherMid = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.18, 0.62), wingMat);
      featherMid.position.set(backX - 0.14, 1.52 + yOff, s * 0.36);
      featherMid.rotation.x = s * 0.1;
      featherMid.rotation.y = s * 0.32;

      const featherBot = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.44), wingMat);
      featherBot.position.set(backX - 0.13, 1.36 + yOff, s * 0.28);
      featherBot.rotation.x = s * -0.05;
      featherBot.rotation.y = s * 0.32;
      upperTorsoPivot.add(featherTop, featherMid, featherBot);
    });
  }
}

export function buildRobloxPlayer(
  style: StyleDefinition,
  team: 'BLUE' | 'RED',
  maxAnisotropy: number,
  isGoalkeeper = false,
  wardrobe?: WardrobeConfig
): PlayerRig {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  // Waist-hinged upper torso pivot (y = 1.08) for realistic sprint lean, shoot twist, and emotes
  const upperTorsoPivot = new THREE.Group();
  upperTorsoPivot.position.set(0, 1.08, 0);
  bodyPivot.add(upperTorsoPivot);

  const w: WardrobeConfig = wardrobe ?? {
    outfitId: 'signature',
    hairStyleId: 'character',
    hairColor: 'character',
    cleatId: 'character',
    backAccessoryId: 'none',
  };

  let jerseyPrimary = style.primaryColor;
  let jerseySecondary = style.secondaryColor;
  if (isGoalkeeper) {
    jerseyPrimary = team === 'BLUE' ? '#0284c7' : '#b91c1c';
    jerseySecondary = '#fde047';
  } else if (w.outfitId !== 'signature') {
    const preset = OUTFIT_OPTIONS.find((o) => o.id === w.outfitId);
    if (preset) {
      jerseyPrimary = preset.previewPrimary;
      jerseySecondary = preset.previewSecondary;
    }
  }

  const isBerk = style.id === 'berk' && !isGoalkeeper;
  const torsoRadiusTop = isBerk ? 0.44 : 0.36;
  const torsoRadiusBot = isBerk ? 0.39 : 0.28;
  const torsoScaleX = 0.72;
  const torsoScaleZ = 1.18;
  const chestHalfX = torsoRadiusTop * torsoScaleX;
  const chestHalfZ = torsoRadiusTop * torsoScaleZ;
  const hipSpacing = isBerk ? 0.22 : 0.18;

  const skinMat = new THREE.MeshPhysicalMaterial({
    color: style.skinColor,
    roughness: 0.58,
    metalness: 0.01,
    clearcoat: 0.06,
    clearcoatRoughness: 0.65,
  });

  const fabricBump = createFabricBumpTexture(maxAnisotropy);
  const jerseyTex = createJerseyTexture(
    jerseyPrimary,
    jerseySecondary,
    style.jerseyNumber,
    style.name,
    maxAnisotropy,
    isGoalkeeper ? 'signature' : w.outfitId
  );
  const torsoMat = new THREE.MeshStandardMaterial({
    map: jerseyTex,
    bumpMap: fabricBump,
    bumpScale: 0.012,
    roughness: 0.62,
    metalness: 0.05,
  });

  const shortsColor =
    w.outfitId === 'royalwhite' && !isGoalkeeper
      ? '#e2e8f0'
      : w.outfitId === 'crimson' && !isGoalkeeper
        ? '#450a0a'
        : team === 'RED'
          ? '#1f2937'
          : '#090d16';

  const shortsMat = new THREE.MeshStandardMaterial({
    color: shortsColor,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.68,
    metalness: 0.05,
  });

  const teamAccentMat = new THREE.MeshStandardMaterial({
    color: team === 'BLUE' ? '#38bdf8' : '#ef4444',
    emissive: team === 'BLUE' ? '#0284c7' : '#b91c1c',
    emissiveIntensity: 0.35,
    roughness: 0.35,
  });

  const cleatPreset = CLEAT_OPTIONS.find((c) => c.id === w.cleatId);
  const cleatHex =
    isGoalkeeper || !cleatPreset || w.cleatId === 'character' ? jerseySecondary : cleatPreset.cleatHex;
  const sockHex =
    isGoalkeeper || !cleatPreset || w.cleatId === 'character'
      ? style.id === 'iskender'
        ? '#fde047'
        : '#f8fafc'
      : cleatPreset.sockHex;

  const cleatMat = new THREE.MeshPhysicalMaterial({
    color: cleatHex,
    roughness: 0.28,
    metalness: 0.35,
    clearcoat: 0.4,
    clearcoatRoughness: 0.24,
  });

  const resolvedHairColor =
    w.hairColor && w.hairColor !== 'character' ? w.hairColor : style.hairColor;
  const resolvedHairStyle: Exclude<HairStyleId, 'character'> =
    w.hairStyleId === 'character' ? resolveDefaultHairForStyle(style.id) : w.hairStyleId;

  const browMat = new THREE.MeshStandardMaterial({ color: resolvedHairColor, roughness: 0.65 });

  // 1. Athletic Pelvis / Shorts Waist (in bodyPivot)
  const pelvis = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusBot * 0.99, torsoRadiusBot * 1.04, 0.28, 18),
    shortsMat
  );
  pelvis.scale.set(torsoScaleX, 1, torsoScaleZ);
  pelvis.position.set(0, 0.98, 0);
  pelvis.castShadow = true;
  pelvis.receiveShadow = true;
  bodyPivot.add(pelvis);

  const waistband = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusBot * 1.005, torsoRadiusBot * 1.005, 0.055, 18),
    new THREE.MeshStandardMaterial({ color: jerseySecondary, roughness: 0.42 })
  );
  waistband.scale.set(torsoScaleX, 1, torsoScaleZ);
  waistband.position.set(0, 1.09, 0);
  bodyPivot.add(waistband);

  // 2. Sculpted Athletic Torso (in upperTorsoPivot, y - 1.08)
  const torsoMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusTop, torsoRadiusBot, 0.78, 20),
    torsoMat
  );
  torsoMesh.scale.set(torsoScaleX, 1, torsoScaleZ);
  torsoMesh.position.set(0, 0.4, 0);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  upperTorsoPivot.add(torsoMesh);

  const collar = new THREE.Mesh(
    new THREE.TorusGeometry(torsoRadiusTop * 0.46, 0.036, 10, 20),
    new THREE.MeshStandardMaterial({ color: jerseySecondary, roughness: 0.35, metalness: 0.25 })
  );
  collar.rotation.x = Math.PI / 2;
  collar.scale.set(torsoScaleX * 1.08, torsoScaleZ * 0.9, 1);
  collar.position.set(0, 0.795, 0);
  upperTorsoPivot.add(collar);

  if (!isGoalkeeper && w.outfitId === 'hoodie') {
    const hoodieMat = new THREE.MeshStandardMaterial({
      color: jerseyPrimary,
      bumpMap: fabricBump,
      bumpScale: 0.015,
      roughness: 0.72,
    });
    const hoodCowl = new THREE.Mesh(
      new THREE.TorusGeometry(torsoRadiusTop * 0.56, 0.085, 10, 18, Math.PI * 1.25),
      hoodieMat
    );
    hoodCowl.rotation.x = Math.PI / 2 + 0.35;
    hoodCowl.rotation.z = Math.PI * 0.88;
    hoodCowl.scale.set(torsoScaleX * 1.05, torsoScaleZ * 0.95, 1);
    hoodCowl.position.set(-chestHalfX * 0.35, 0.8, 0);
    hoodCowl.castShadow = true;
    upperTorsoPivot.add(hoodCowl);

    const hoodBack = new THREE.Mesh(
      new THREE.SphereGeometry(torsoRadiusTop * 0.48, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.6),
      hoodieMat
    );
    hoodBack.scale.set(0.75, 0.7, 1.25);
    hoodBack.position.set(-chestHalfX - 0.05, 0.7, 0);
    hoodBack.rotation.z = 1.2;
    upperTorsoPivot.add(hoodBack);
  } else if (!isGoalkeeper && w.outfitId === 'cyberjacket') {
    const lapelMat = new THREE.MeshStandardMaterial({
      color: jerseySecondary,
      emissive: jerseySecondary,
      emissiveIntensity: 0.28,
      roughness: 0.3,
      metalness: 0.45,
    });
    [-1, 1].forEach((s) => {
      const lapel = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.72, 0.055), lapelMat);
      lapel.position.set(chestHalfX * 0.94, 0.42, s * 0.095);
      lapel.rotation.z = -0.06;
      upperTorsoPivot.add(lapel);
    });
  }

  if (!isGoalkeeper) {
    buildBackAccessory(
      upperTorsoPivot,
      w.backAccessoryId,
      chestHalfX,
      chestHalfZ,
      style.auraColor,
      jerseySecondary
    );
  }

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.108, 0.128, 0.18, 12), skinMat);
  neck.position.set(0, 0.86, 0);
  upperTorsoPivot.add(neck);

  // 3. Contoured Head + Facial Features + Uncapped Hairstyles (in upperTorsoPivot)
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.94, 0);
  upperTorsoPivot.add(headGroup);

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.252, 22, 18), skinMat);
  cranium.scale.set(0.99, 1.08, 0.92);
  cranium.position.set(0, 0.275, 0);
  cranium.castShadow = true;
  headGroup.add(cranium);

  const jaw = new THREE.Mesh(new THREE.CylinderGeometry(0.185, 0.132, 0.18, 14), skinMat);
  jaw.position.set(0.04, 0.14, 0);
  headGroup.add(jaw);

  [-1, 1].forEach((zSign) => {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), skinMat);
    ear.scale.set(0.55, 1.15, 0.45);
    ear.position.set(-0.02, 0.27, zSign * 0.242);
    headGroup.add(ear);
  });

  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.082, 6), skinMat);
  nose.rotation.z = -Math.PI / 2.2;
  nose.position.set(0.258, 0.245, 0);
  headGroup.add(nose);

  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.015, 0.085),
    new THREE.MeshStandardMaterial({ color: '#9a5b4e', roughness: 0.7 })
  );
  mouth.position.set(0.232, 0.16, 0);
  headGroup.add(mouth);

  const scleraMat = new THREE.MeshPhysicalMaterial({
    color: '#f8fafc',
    roughness: 0.14,
    clearcoat: 0.65,
  });
  const irisMat = new THREE.MeshPhysicalMaterial({
    color: style.auraColor,
    emissive: style.auraColor,
    emissiveIntensity: 0.42,
    roughness: 0.18,
    clearcoat: 0.75,
  });
  const darkPupilMat = new THREE.MeshBasicMaterial({ color: '#020617' });
  const glintMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });

  [-1, 1].forEach((zSign) => {
    const sclera = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.068, 0.094), scleraMat);
    sclera.position.set(0.23, 0.302, zSign * 0.098);

    const iris = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.056, 0.056), irisMat);
    iris.position.set(0.233, 0.302, zSign * 0.095);

    const core = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.03, 0.03), darkPupilMat);
    core.position.set(0.235, 0.302, zSign * 0.095);

    const glint = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.016, 0.016), glintMat);
    glint.position.set(0.236, 0.318, zSign * 0.106);

    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.024, 0.106), browMat);
    brow.position.set(0.236, 0.368, zSign * 0.098);
    brow.rotation.x = zSign * -0.18;

    headGroup.add(sclera, iris, core, glint, brow);
  });

  // Layered Roblox / Anime Hair directly on cranium without round dome cover!
  buildRobuxHair(headGroup, resolvedHairStyle, resolvedHairColor, style.auraColor);

  let headsetProp: THREE.Group | undefined;
  let gauntletProp: THREE.Group | undefined;

  if (style.accessory === 'headset') {
    headsetProp = new THREE.Group();
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(0.31, 0.03, 8, 22, Math.PI),
      new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.28, metalness: 0.8 })
    );
    band.rotation.y = Math.PI / 2;
    band.position.set(-0.01, 0.36, 0);
    const earMat = new THREE.MeshPhysicalMaterial({
      color: '#facc15',
      emissive: '#ca8a04',
      emissiveIntensity: 0.38,
      roughness: 0.24,
      metalness: 0.72,
      clearcoat: 0.4,
    });
    const earL = new THREE.Mesh(new THREE.CylinderGeometry(0.102, 0.102, 0.075, 16), earMat);
    earL.rotation.x = Math.PI / 2;
    earL.position.set(-0.01, 0.29, -0.295);
    const earR = earL.clone();
    earR.position.set(-0.01, 0.29, 0.295);
    headsetProp.add(band, earL, earR);
    headGroup.add(headsetProp);
  } else if (style.accessory === 'shades') {
    const shadeMat = new THREE.MeshPhysicalMaterial({
      color: '#090d16',
      roughness: 0.06,
      metalness: 0.92,
      clearcoat: 1.0,
    });
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.088, 0.42), shadeMat);
    frame.position.set(0.252, 0.308, 0);
    headGroup.add(frame);
  } else if (style.accessory === 'headband') {
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(0.262, 0.262, 0.052, 20),
      new THREE.MeshStandardMaterial({ color: '#ef4444', roughness: 0.48 })
    );
    band.position.set(-0.005, 0.375, 0);
    headGroup.add(band);
  } else if (style.accessory === 'visor') {
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.064, 0.09, 0.44),
      new THREE.MeshPhysicalMaterial({
        color: '#22d3ee',
        emissive: '#06b6d4',
        emissiveIntensity: 0.8,
        roughness: 0.1,
        metalness: 0.85,
        clearcoat: 0.9,
      })
    );
    visor.position.set(0.252, 0.308, 0);
    headGroup.add(visor);
  }

  // 4. Articulated Multi-Joint Arms (Shoulder armPivot + Elbow elbowPivot in upperTorsoPivot)
  const armShoulderZ = chestHalfZ + 0.055;
  const isLongSleeve = !isGoalkeeper && (w.outfitId === 'hoodie' || w.outfitId === 'cyberjacket');
  const sleeveMat = new THREE.MeshStandardMaterial({
    color: jerseyPrimary,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.58,
    metalness: 0.06,
  });
  const sleeveTrimMat = new THREE.MeshStandardMaterial({
    color: jerseySecondary,
    roughness: 0.38,
    metalness: 0.18,
  });

  const buildArm = (zSign: number, withGauntlet: boolean) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(0, 0.71, zSign * armShoulderZ);

    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.132, 14, 12), sleeveMat);
    shoulder.scale.set(1.02, 1.0, 1.08);
    armPivot.add(shoulder);

    const sleeve = new THREE.Mesh(
      new THREE.CylinderGeometry(0.114, 0.102, isLongSleeve ? 0.31 : 0.26, 14),
      sleeveMat
    );
    sleeve.position.set(0, isLongSleeve ? -0.155 : -0.13, 0);
    sleeve.castShadow = true;
    armPivot.add(sleeve);

    if (!isLongSleeve) {
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.105, 0.04, 12), sleeveTrimMat);
      cuff.position.set(0, -0.255, 0);
      const upperArmSkin = new THREE.Mesh(new THREE.CylinderGeometry(0.088, 0.082, 0.12, 12), skinMat);
      upperArmSkin.position.set(0, -0.28, 0);
      upperArmSkin.castShadow = true;
      armPivot.add(cuff, upperArmSkin);
    }

    if (zSign < 0 && !isGoalkeeper) {
      const armband = new THREE.Mesh(new THREE.CylinderGeometry(0.118, 0.118, 0.065, 12), teamAccentMat);
      armband.position.set(0, -0.19, 0);
      armPivot.add(armband);
    }

    // Elbow pivot at y = -0.32 inside armPivot
    const elbowPivot = new THREE.Group();
    elbowPivot.position.set(0, -0.32, 0);
    armPivot.add(elbowPivot);

    const elbowJoint = new THREE.Mesh(
      new THREE.SphereGeometry(isLongSleeve ? 0.098 : 0.082, 10, 8),
      isLongSleeve ? sleeveMat : skinMat
    );
    elbowPivot.add(elbowJoint);

    if (isLongSleeve) {
      const sleeveFore = new THREE.Mesh(new THREE.CylinderGeometry(0.098, 0.086, 0.22, 12), sleeveMat);
      sleeveFore.position.set(0, -0.11, 0);
      sleeveFore.castShadow = true;
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.092, 0.092, 0.045, 12), sleeveTrimMat);
      cuff.position.set(0, -0.21, 0);
      elbowPivot.add(sleeveFore, cuff);
    }

    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.076, 0.2, 6, 10), skinMat);
    forearm.position.set(0, -0.17, 0);
    forearm.castShadow = true;

    const hand = new THREE.Mesh(
      new THREE.SphereGeometry(0.082, 12, 10),
      isGoalkeeper
        ? new THREE.MeshStandardMaterial({ color: '#fde047', roughness: 0.38 })
        : skinMat
    );
    hand.position.set(0, -0.35, 0);
    elbowPivot.add(forearm, hand);

    if (withGauntlet) {
      gauntletProp = new THREE.Group();
      const glove = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.108, 0.16, 6, 12),
        new THREE.MeshStandardMaterial({
          color: '#fbbf24',
          emissive: '#b45309',
          emissiveIntensity: 0.35,
          roughness: 0.22,
          metalness: 0.9,
        })
      );
      glove.position.set(0, -0.26, 0);
      gauntletProp.add(glove);
      const stoneColors = ['#ef4444', '#3b82f6', '#a855f7', '#22c55e', '#f97316'];
      stoneColors.forEach((sc, idx) => {
        const gem = new THREE.Mesh(
          new THREE.BoxGeometry(0.042, 0.042, 0.042),
          new THREE.MeshStandardMaterial({ color: sc, emissive: sc, emissiveIntensity: 0.95 })
        );
        gem.position.set(0.105, -0.24, -0.08 + idx * 0.04);
        gauntletProp!.add(gem);
      });
      elbowPivot.add(gauntletProp);
    }

    upperTorsoPivot.add(armPivot);
    return { armPivot, elbowPivot };
  };

  const leftArm = buildArm(-1, false);
  const rightArm = buildArm(1, style.accessory === 'gauntlet' && !isGoalkeeper);

  // 5. Articulated Multi-Joint Legs (Hip legPivot + Knee kneePivot in bodyPivot)
  const sockMat = new THREE.MeshStandardMaterial({
    color: sockHex,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.58,
  });
  const sockStripeMat = new THREE.MeshStandardMaterial({ color: cleatHex, roughness: 0.4 });
  const soleMat = new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.42, metalness: 0.3 });

  const buildLeg = (zSign: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(0, 0.92, zSign * hipSpacing);

    const thigh = new THREE.Mesh(
      new THREE.CylinderGeometry(isBerk ? 0.158 : 0.145, 0.118, 0.38, 14),
      shortsMat
    );
    thigh.position.set(0, -0.18, 0);
    thigh.castShadow = true;
    legPivot.add(thigh);

    // Knee pivot at y = -0.39 inside legPivot
    const kneePivot = new THREE.Group();
    kneePivot.position.set(0, -0.39, 0);
    legPivot.add(kneePivot);

    const kneeSkin = new THREE.Mesh(new THREE.SphereGeometry(0.104, 10, 8), skinMat);
    kneeSkin.position.set(0, 0, 0);

    const calf = new THREE.Mesh(new THREE.CylinderGeometry(0.104, 0.082, 0.36, 14), sockMat);
    calf.position.set(0, -0.19, 0);
    calf.castShadow = true;

    const sockBand = new THREE.Mesh(new THREE.CylinderGeometry(0.108, 0.106, 0.045, 14), sockStripeMat);
    sockBand.position.set(0, -0.05, 0);

    const cleatUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.088, 0.19, 8, 12), cleatMat);
    cleatUpper.rotation.z = Math.PI / 2;
    cleatUpper.position.set(0.065, -0.43, 0);
    cleatUpper.castShadow = true;

    const cleatLace = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.032, 0.075), sockStripeMat);
    cleatLace.position.set(0.07, -0.355, 0);

    const cleatSole = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.036, 0.165), soleMat);
    cleatSole.position.set(0.065, -0.498, 0);

    [
      [-0.06, -0.05],
      [-0.06, 0.05],
      [0.18, -0.05],
      [0.18, 0.05],
    ].forEach(([sx, sz]) => {
      const stud = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.012, 0.025, 6), cleatMat);
      stud.position.set(sx, -0.522, sz);
      kneePivot.add(stud);
    });

    kneePivot.add(kneeSkin, calf, sockBand, cleatUpper, cleatLace, cleatSole);
    bodyPivot.add(legPivot);
    return { legPivot, kneePivot };
  };

  const leftLeg = buildLeg(-1);
  const rightLeg = buildLeg(1);

  // 6. Contact Shadow & Team Ring
  const shadowMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(1.75, 1.75),
    new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = 0.02;
  root.add(shadowMesh);

  const selectionRing = new THREE.Mesh(
    new THREE.RingGeometry(0.62, 0.78, 32),
    new THREE.MeshBasicMaterial({
      color: team === 'BLUE' ? '#38bdf8' : '#ef4444',
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
    })
  );
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.03;
  root.add(selectionRing);

  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.86, 1.15, 6),
    new THREE.MeshBasicMaterial({
      color: style.auraColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      depthWrite: false,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.04;
  root.add(auraRing);

  const auraPillars = new THREE.Group();
  const pillarMat = new THREE.MeshBasicMaterial({
    color: style.auraColor,
    transparent: true,
    opacity: 0.2,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI * 2 * i) / 6;
    const shard = new THREE.Mesh(new THREE.ConeGeometry(0.095, 0.95, 5), pillarMat);
    shard.position.set(Math.cos(a) * 0.92, 0.48, Math.sin(a) * 0.92);
    auraPillars.add(shard);
  }
  auraPillars.visible = false;
  root.add(auraPillars);

  return {
    root,
    bodyPivot,
    upperTorsoPivot,
    headGroup,
    torsoMesh,
    leftArmPivot: leftArm.armPivot,
    leftElbowPivot: leftArm.elbowPivot,
    rightArmPivot: rightArm.armPivot,
    rightElbowPivot: rightArm.elbowPivot,
    leftLegPivot: leftLeg.legPivot,
    leftKneePivot: leftLeg.kneePivot,
    rightLegPivot: rightLeg.legPivot,
    rightKneePivot: rightLeg.kneePivot,
    headsetProp,
    gauntletProp,
    auraRing,
    auraPillars,
    shadowMesh,
    selectionRing,
  };
}

export function buildSoccerBall(maxAnisotropy: number): {
  group: THREE.Group;
  mesh: THREE.Mesh;
  shadow: THREE.Mesh;
  trailRing: THREE.Mesh;
} {
  const group = new THREE.Group();
  const ballTex = createSoccerBallTexture(maxAnisotropy);
  const ballBump = createSoccerBallBumpTexture(maxAnisotropy);
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.36, 28, 28),
    new THREE.MeshPhysicalMaterial({
      map: ballTex,
      bumpMap: ballBump,
      bumpScale: 0.015,
      roughness: 0.28,
      metalness: 0.08,
      clearcoat: 0.38,
      clearcoatRoughness: 0.22,
    })
  );
  mesh.castShadow = true;
  mesh.position.y = 0.36;
  group.add(mesh);

  const trailRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.45, 0.045, 8, 24),
    new THREE.MeshBasicMaterial({
      color: '#38bdf8',
      transparent: true,
      opacity: 0,
      depthWrite: false,
    })
  );
  trailRing.position.y = 0.36;
  group.add(trailRing);

  const shadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.1, 1.1),
    new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;

  return { group, mesh, shadow, trailRing };
}

export function buildStadium(maxAnisotropy: number): StadiumRefs {
  const root = new THREE.Group();

  // Procedural Atmospheric Sky Dome (ShaderMaterial for Night / Sunset / Rain)
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      uTopColor: { value: new THREE.Color('#020617') },
      uHorizonColor: { value: new THREE.Color('#0c2448') },
      uSunColor: { value: new THREE.Color('#38bdf8') },
      uSunDir: { value: new THREE.Vector3(0.45, 0.35, -0.6).normalize() },
      uStarIntensity: { value: 0.9 },
    },
    vertexShader: `
      varying vec3 vWorldDir;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldDir = normalize(position);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 uTopColor;
      uniform vec3 uHorizonColor;
      uniform vec3 uSunColor;
      uniform vec3 uSunDir;
      uniform float uStarIntensity;
      varying vec3 vWorldDir;

      float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
      }

      void main() {
        vec3 d = normalize(vWorldDir);
        float h = clamp(d.y * 1.15 + 0.08, 0.0, 1.0);
        vec3 col = mix(uHorizonColor, uTopColor, pow(h, 0.65));

        float sunAmt = max(dot(d, normalize(uSunDir)), 0.0);
        col += uSunColor * pow(sunAmt, 14.0) * 0.55;
        col += uSunColor * pow(sunAmt, 90.0) * 0.85;

        if (uStarIntensity > 0.01 && d.y > 0.08) {
          vec3 grid = floor(d * 180.0);
          float s = hash(grid);
          if (s > 0.9965) {
            col += vec3(0.85, 0.94, 1.0) * uStarIntensity * smoothstep(0.08, 0.35, d.y);
          }
        }
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const skyDome = new THREE.Mesh(new THREE.SphereGeometry(240, 32, 20), skyMat);
  root.add(skyDome);

  // Outer Stadium Concrete/Turf Apron extending to horizon
  const outerGround = new THREE.Mesh(
    new THREE.PlaneGeometry(360, 300),
    new THREE.MeshStandardMaterial({
      color: '#07101c',
      roughness: 0.94,
      metalness: 0.04,
    })
  );
  outerGround.rotation.x = -Math.PI / 2;
  outerGround.position.y = -0.025;
  outerGround.receiveShadow = true;
  root.add(outerGround);

  // Outer pitch apron around larger 116m x 68m field
  const apronMat = new THREE.MeshStandardMaterial({
    color: '#0f4726',
    roughness: 0.88,
    metalness: 0.02,
  });
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(148, 96), apronMat);
  apron.rotation.x = -Math.PI / 2;
  apron.position.y = -0.005;
  apron.receiveShadow = true;
  root.add(apron);

  // Main eFootball Realistic PBR Pitch
  const pitchMat = new THREE.MeshPhysicalMaterial({
    map: createPitchTexture(maxAnisotropy),
    bumpMap: createPitchBumpTexture(maxAnisotropy),
    bumpScale: 0.022,
    roughness: 0.84,
    metalness: 0.02,
    clearcoat: 0.0,
    clearcoatRoughness: 0.2,
  });
  const pitchMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(PITCH_HALF_LENGTH * 2 + 6, PITCH_HALF_WIDTH * 2 + 5),
    pitchMat
  );
  pitchMesh.rotation.x = -Math.PI / 2;
  pitchMesh.position.y = 0.004;
  pitchMesh.receiveShadow = true;
  root.add(pitchMesh);

  // Perimeter LED Boards (balanced emissive intensity so no overexposure)
  const ledTex = createStadiumLedTexture(maxAnisotropy);
  const boardMat = new THREE.MeshStandardMaterial({
    map: ledTex,
    emissiveMap: ledTex,
    emissive: '#0ea5e9',
    emissiveIntensity: 0.36,
    roughness: 0.3,
    metalness: 0.4,
  });
  const northBoard = new THREE.Mesh(new THREE.BoxGeometry(124, 1.35, 0.5), boardMat);
  northBoard.position.set(0, 0.67, -PITCH_HALF_WIDTH - 4.6);
  const southBoard = northBoard.clone();
  southBoard.position.z = PITCH_HALF_WIDTH + 4.6;
  root.add(northBoard, southBoard);

  // End-line flanking LED boards outside goals
  const ledBoards: THREE.Mesh[] = [northBoard, southBoard];
  [-1, 1].forEach((sideX) => {
    [-1, 1].forEach((sideZ) => {
      const endBoard = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.3, 27), boardMat);
      endBoard.position.set(sideX * (PITCH_HALF_LENGTH + 5.2), 0.65, sideZ * 21.5);
      root.add(endBoard);
      ledBoards.push(endBoard);
    });
  });

  // 4 Corner Flags
  const flagPoleMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.35, metalness: 0.45 });
  const cornerCoords: Array<[number, number, string]> = [
    [-PITCH_HALF_LENGTH, -PITCH_HALF_WIDTH, '#38bdf8'],
    [-PITCH_HALF_LENGTH, PITCH_HALF_WIDTH, '#38bdf8'],
    [PITCH_HALF_LENGTH, -PITCH_HALF_WIDTH, '#ef4444'],
    [PITCH_HALF_LENGTH, PITCH_HALF_WIDTH, '#ef4444'],
  ];
  cornerCoords.forEach(([cx, cz, hex]) => {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.55, 8), flagPoleMat);
    pole.position.set(cx, 0.77, cz);
    const flag = new THREE.Mesh(
      new THREE.BoxGeometry(0.46, 0.3, 0.02),
      new THREE.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: 0.18 })
    );
    flag.position.set(cx + (cx < 0 ? 0.24 : -0.24), 1.4, cz);
    root.add(pole, flag);
  });

  // Technical Dugouts / Team Benches
  const benchMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.45, metalness: 0.6 });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: '#bae6fd',
    transparent: true,
    opacity: 0.32,
    roughness: 0.12,
    clearcoat: 0.75,
  });
  [-15, 15].forEach((bx, idx) => {
    const dugout = new THREE.Group();
    dugout.position.set(bx, 0, -PITCH_HALF_WIDTH - 2.4);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.55, 0.9), benchMat);
    seat.position.y = 0.28;
    const roof = new THREE.Mesh(new THREE.BoxGeometry(8.8, 0.12, 1.8), glassMat);
    roof.position.set(0, 2.25, 0.2);
    const backGlass = new THREE.Mesh(new THREE.BoxGeometry(8.7, 2.2, 0.08), glassMat);
    backGlass.position.set(0, 1.1, -0.65);
    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(8.8, 0.14, 0.15),
      new THREE.MeshStandardMaterial({
        color: idx === 0 ? '#38bdf8' : '#ef4444',
        emissive: idx === 0 ? '#0284c7' : '#b91c1c',
        emissiveIntensity: 0.36,
      })
    );
    stripe.position.set(0, 2.32, 1.02);
    dugout.add(seat, roof, backGlass, stripe);
    root.add(dugout);
  });

  // ==================== BLUE LOCK STADIUM ARCHITECTURE ====================
  const standMat = new THREE.MeshStandardMaterial({
    color: '#111b2e',
    roughness: 0.8,
    metalness: 0.2,
  });
  const facadeWallMat = new THREE.MeshStandardMaterial({
    color: '#091120',
    roughness: 0.65,
    metalness: 0.45,
  });
  const blueLockNeonMat = new THREE.MeshStandardMaterial({
    color: '#38bdf8',
    emissive: '#0284c7',
    emissiveIntensity: 0.38,
    roughness: 0.25,
    metalness: 0.5,
  });
  const steelTrussMat = new THREE.MeshStandardMaterial({
    color: '#1e293b',
    roughness: 0.38,
    metalness: 0.78,
  });

  // 5 Stepped Stadium Tiers around the entire arena + cyan Blue Lock trim lines
  for (let tier = 0; tier < 5; tier++) {
    const h = 2.4;
    const y = 1.2 + tier * 2.35;
    const zOffset = 42.5 + tier * 3.8;
    const xOffset = 67.5 + tier * 3.8;

    const standN = new THREE.Mesh(new THREE.BoxGeometry(138 + tier * 7.6, h, 3.6), standMat);
    standN.position.set(0, y, -zOffset);
    standN.receiveShadow = true;
    const standS = standN.clone();
    standS.position.z = zOffset;
    root.add(standN, standS);

    const standW = new THREE.Mesh(new THREE.BoxGeometry(3.6, h, 86 + tier * 7.6), standMat);
    standW.position.set(-xOffset, y, 0);
    const standE = standW.clone();
    standE.position.x = xOffset;
    root.add(standW, standE);

    if (tier === 1 || tier === 3 || tier === 4) {
      const trimN = new THREE.Mesh(new THREE.BoxGeometry(138 + tier * 7.6, 0.2, 0.16), blueLockNeonMat);
      trimN.position.set(0, y + h * 0.48, -zOffset + 1.82);
      const trimS = trimN.clone();
      trimS.position.z = zOffset - 1.82;
      const trimW = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.2, 86 + tier * 7.6), blueLockNeonMat);
      trimW.position.set(-xOffset + 1.82, y + h * 0.48, 0);
      const trimE = trimW.clone();
      trimE.position.x = xOffset - 1.82;
      root.add(trimN, trimS, trimW, trimE);
    }
  }

  // Outer Stadium Shell Wall + 12 Angled Futuristic Blue Lock Roof Pylons & Cantilever Truss Canopy
  const wallN = new THREE.Mesh(new THREE.BoxGeometry(176, 16, 2.2), facadeWallMat);
  wallN.position.set(0, 8, -61);
  const wallS = wallN.clone();
  wallS.position.z = 61;
  const wallW = new THREE.Mesh(new THREE.BoxGeometry(2.2, 16, 122), facadeWallMat);
  wallW.position.set(-87, 8, 0);
  const wallE = wallW.clone();
  wallE.position.x = 87;
  root.add(wallN, wallS, wallW, wallE);

  // Overhead Rectangular/Pentagonal Stadium Roof Fascia & Glowing Sky Halo Ring
  const roofRingN = new THREE.Mesh(new THREE.BoxGeometry(168, 2.2, 14), steelTrussMat);
  roofRingN.position.set(0, 26, -54);
  const roofRingS = roofRingN.clone();
  roofRingS.position.z = 54;
  const roofRingW = new THREE.Mesh(new THREE.BoxGeometry(14, 2.2, 118), steelTrussMat);
  roofRingW.position.set(-79, 26, 0);
  const roofRingE = roofRingW.clone();
  roofRingE.position.x = 79;
  root.add(roofRingN, roofRingS, roofRingW, roofRingE);

  // Inner Glowing Blue Lock Sky Halo Band around roof opening
  const innerHaloN = new THREE.Mesh(new THREE.BoxGeometry(144, 0.55, 0.6), blueLockNeonMat);
  innerHaloN.position.set(0, 25.1, -46.8);
  const innerHaloS = innerHaloN.clone();
  innerHaloS.position.z = 46.8;
  const innerHaloW = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.55, 94), blueLockNeonMat);
  innerHaloW.position.set(-71.8, 25.1, 0);
  const innerHaloE = innerHaloW.clone();
  innerHaloE.position.x = 71.8;
  root.add(innerHaloN, innerHaloS, innerHaloW, innerHaloE);

  // 12 Angled Structural Blue Lock Rib Pylons supporting the canopy
  const pylonCoords: Array<[number, number, number]> = [
    [-55, -60, 0],
    [-18, -60, 0],
    [18, -60, 0],
    [55, -60, 0],
    [-55, 60, Math.PI],
    [-18, 60, Math.PI],
    [18, 60, Math.PI],
    [55, 60, Math.PI],
    [-86, -24, Math.PI / 2],
    [-86, 24, Math.PI / 2],
    [86, -24, -Math.PI / 2],
    [86, 24, -Math.PI / 2],
  ];
  for (const [px, pz, rotY] of pylonCoords) {
    const pylon = new THREE.Group();
    pylon.position.set(px, 0, pz);
    pylon.rotation.y = rotY;
    const column = new THREE.Mesh(new THREE.BoxGeometry(1.4, 28, 1.8), steelTrussMat);
    column.position.set(0, 14, -1);
    column.rotation.x = 0.14;
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.1, 18), steelTrussMat);
    arm.position.set(0, 26.8, 7.5);
    const armNeon = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.25, 17.6), blueLockNeonMat);
    armNeon.position.set(0, 26.15, 7.5);
    pylon.add(column, arm, armNeon);
    root.add(pylon);
  }

  // Central Hanging 4-Sided Blue Lock Jumbotron High Overhead (y = 29m, zero gameplay obstruction)
  const jumbotron = new THREE.Group();
  jumbotron.position.set(0, 29, 0);
  const jumboCore = new THREE.Mesh(new THREE.BoxGeometry(12, 4.2, 8), steelTrussMat);
  const jumboScreenMat = new THREE.MeshStandardMaterial({
    map: ledTex,
    emissiveMap: ledTex,
    emissive: '#38bdf8',
    emissiveIntensity: 0.42,
    roughness: 0.25,
  });
  const jumboFront = new THREE.Mesh(new THREE.PlaneGeometry(11.4, 3.6), jumboScreenMat);
  jumboFront.position.z = 4.05;
  const jumboBack = jumboFront.clone();
  jumboBack.rotation.y = Math.PI;
  jumboBack.position.z = -4.05;
  const jumboLeft = new THREE.Mesh(new THREE.PlaneGeometry(7.4, 3.6), jumboScreenMat);
  jumboLeft.rotation.y = -Math.PI / 2;
  jumboLeft.position.x = -6.05;
  const jumboRight = jumboLeft.clone();
  jumboRight.rotation.y = Math.PI / 2;
  jumboRight.position.x = 6.05;
  const jumboFrame = new THREE.Mesh(new THREE.BoxGeometry(12.4, 0.35, 8.4), blueLockNeonMat);
  jumboFrame.position.y = -2.25;
  jumbotron.add(jumboCore, jumboFront, jumboBack, jumboLeft, jumboRight, jumboFrame);
  root.add(jumbotron);

  // Suspension cables from Jumbotron up to stadium cross-trusses
  [
    [-5.5, -3.5],
    [5.5, -3.5],
    [-5.5, 3.5],
    [5.5, 3.5],
  ].forEach(([cx, cz]) => {
    const cable = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 12, 6), steelTrussMat);
    cable.position.set(cx, 35, cz);
    root.add(cable);
  });

  // Iconic Blue Lock Pentagonal Egoist Entrance Arch on South Stand Midfield
  const tunnelArch = new THREE.Group();
  tunnelArch.position.set(0, 0, PITCH_HALF_WIDTH + 6.5);
  const archFrame = new THREE.Mesh(
    new THREE.TorusGeometry(4.2, 0.48, 6, 5, Math.PI),
    blueLockNeonMat
  );
  archFrame.position.y = 2.6;
  const archBackdrop = new THREE.Mesh(
    new THREE.BoxGeometry(8.2, 5.2, 1.4),
    facadeWallMat
  );
  archBackdrop.position.set(0, 2.6, 0.8);
  tunnelArch.add(archFrame, archBackdrop);
  root.add(tunnelArch);

  // Instanced Crowd Spectators across all 5 expanded tiers (620 fans)
  const fanGeo = new THREE.BoxGeometry(0.65, 1.05, 0.55);
  const fanMat = new THREE.MeshStandardMaterial({ roughness: 0.68, metalness: 0.1 });
  const fanCount = 620;
  const crowdInstanced = new THREE.InstancedMesh(fanGeo, fanMat, fanCount);
  const dummy = new THREE.Object3D();
  const palette = [
    new THREE.Color('#38bdf8'),
    new THREE.Color('#f8fafc'),
    new THREE.Color('#ef4444'),
    new THREE.Color('#fbbf24'),
    new THREE.Color('#a855f7'),
    new THREE.Color('#334155'),
  ];
  for (let i = 0; i < fanCount; i++) {
    const side = i % 4;
    const tier = i % 5;
    const y = 3.0 + tier * 2.35;
    if (side === 0 || side === 1) {
      const z = (side === 0 ? -1 : 1) * (42.5 + tier * 3.8);
      dummy.position.set((Math.random() - 0.5) * 130, y, z);
    } else {
      const x = (side === 2 ? -1 : 1) * (67.5 + tier * 3.8);
      dummy.position.set(x, y, (Math.random() - 0.5) * 78);
    }
    const s = 0.85 + Math.random() * 0.3;
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    crowdInstanced.setMatrixAt(i, dummy.matrix);
    crowdInstanced.setColorAt(i, palette[i % palette.length]);
  }
  crowdInstanced.computeBoundingSphere();
  root.add(crowdInstanced);

  // 4 Floodlight Towers (balanced non-glaring emissives)
  const towerMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.42, metalness: 0.7 });
  const lampMat = new THREE.MeshStandardMaterial({
    color: '#f8fafc',
    emissive: '#bae6fd',
    emissiveIntensity: 1.05,
  });
  const floodBeams: THREE.Mesh[] = [];
  const beamGeo = new THREE.ConeGeometry(18, 56, 20, 1, true);
  beamGeo.translate(0, -28, 0);
  beamGeo.rotateX(Math.PI / 2);

  const towerCoords = [
    [-70, -48],
    [70, -48],
    [-70, 48],
    [70, 48],
  ];
  towerCoords.forEach(([tx, tz]) => {
    const tower = new THREE.Group();
    tower.position.set(tx, 0, tz);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.95, 32, 10), towerMat);
    pole.position.y = 16;
    const head = new THREE.Mesh(new THREE.BoxGeometry(5.2, 2.5, 1.2), lampMat);
    head.position.y = 32;
    head.lookAt(-tx, 0, -tz);
    tower.add(pole, head);

    const beamMat = new THREE.MeshBasicMaterial({
      color: '#bae6fd',
      transparent: true,
      opacity: 0.02,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(tx, 31.5, tz);
    beam.lookAt(tx * 0.25, 0, tz * 0.25);
    root.add(tower, beam);
    floodBeams.push(beam);
  });

  // Build 2 Goals (-X Blue Goal, +X Red Goal)
  const buildGoal = (xPos: number, dir: 1 | -1, accentHex: string) => {
    const goalGroup = new THREE.Group();
    goalGroup.position.set(xPos, 0, 0);

    const postMat = new THREE.MeshPhysicalMaterial({
      color: '#f8fafc',
      roughness: 0.26,
      metalness: 0.72,
      clearcoat: 0.25,
    });
    const postGeo = new THREE.CylinderGeometry(0.15, 0.15, GOAL_HEIGHT, 12);
    const leftPost = new THREE.Mesh(postGeo, postMat);
    leftPost.position.set(0, GOAL_HEIGHT / 2, -GOAL_HALF_WIDTH);
    leftPost.castShadow = true;

    const rightPost = new THREE.Mesh(postGeo, postMat);
    rightPost.position.set(0, GOAL_HEIGHT / 2, GOAL_HALF_WIDTH);
    rightPost.castShadow = true;

    const crossbar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 0.15, GOAL_HALF_WIDTH * 2 + 0.3, 12),
      postMat
    );
    crossbar.rotation.x = Math.PI / 2;
    crossbar.position.set(0, GOAL_HEIGHT, 0);
    crossbar.castShadow = true;

    const backBarMat = new THREE.MeshStandardMaterial({ color: accentHex, roughness: 0.35, metalness: 0.6 });
    const backTop = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, GOAL_HALF_WIDTH * 2), backBarMat);
    backTop.position.set(dir * GOAL_DEPTH, GOAL_HEIGHT, 0);
    const backSideL = new THREE.Mesh(new THREE.BoxGeometry(GOAL_DEPTH, 0.12, 0.12), backBarMat);
    backSideL.position.set((dir * GOAL_DEPTH) / 2, GOAL_HEIGHT, -GOAL_HALF_WIDTH);
    const backSideR = backSideL.clone();
    backSideR.position.z = GOAL_HALF_WIDTH;

    const netGeo = new THREE.BoxGeometry(GOAL_DEPTH, GOAL_HEIGHT, GOAL_HALF_WIDTH * 2, 4, 4, 8);
    const netMat = new THREE.MeshBasicMaterial({
      color: '#e2e8f0',
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const netMesh = new THREE.Mesh(netGeo, netMat);
    netMesh.position.set((dir * GOAL_DEPTH) / 2, GOAL_HEIGHT / 2, 0);

    goalGroup.add(leftPost, rightPost, crossbar, backTop, backSideL, backSideR, netMesh);
    root.add(goalGroup);
    return netMesh;
  };

  const blueNet = buildGoal(-PITCH_HALF_LENGTH, -1, '#38bdf8');
  const redNet = buildGoal(PITCH_HALF_LENGTH, 1, '#ef4444');

  // Dynamic 3D Rain Particle System across expanded 136m x 84m arena
  const rainCount = 1200;
  const rainPositions = new Float32Array(rainCount * 3);
  const rainVelocities = new Float32Array(rainCount);
  for (let i = 0; i < rainCount; i++) {
    rainPositions[i * 3] = (Math.random() - 0.5) * 136;
    rainPositions[i * 3 + 1] = Math.random() * 30;
    rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 84;
    rainVelocities[i] = 22 + Math.random() * 10;
  }
  const rainGeo = new THREE.BufferGeometry();
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
  const rainMat = new THREE.PointsMaterial({
    color: '#bae6fd',
    size: 0.22,
    transparent: true,
    opacity: 0.52,
    depthWrite: false,
  });
  const rainPoints = new THREE.Points(rainGeo, rainMat);
  rainPoints.visible = false;
  root.add(rainPoints);

  return {
    root,
    blueNet,
    redNet,
    crowdInstanced,
    pitchMat,
    apronMat,
    skyMat,
    floodBeams,
    ledBoards,
    rainPoints,
    rainVelocities,
  };
}

export function buildCutsceneProps(maxAnisotropy: number): CutscenePropPack {
  const root = new THREE.Group();
  root.visible = false;

  const screenTextures = {
    bluelock_game: createScreenTexture('bluelock_game', maxAnisotropy),
    aras_lose: createScreenTexture('aras_lose', maxAnisotropy),
    ai_cheat: createScreenTexture('ai_cheat', maxAnisotropy),
    phone_musab: createScreenTexture('phone_musab', maxAnisotropy),
    videocall_musa: createScreenTexture('videocall_musa', maxAnisotropy),
  };

  const bed = new THREE.Group();
  const bedFrame = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 0.45, 2.0),
    new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.65 })
  );
  bedFrame.position.y = 0.22;
  const mattress = new THREE.Mesh(
    new THREE.BoxGeometry(3.0, 0.35, 1.85),
    new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.85 })
  );
  mattress.position.y = 0.58;
  const blanket = new THREE.Mesh(
    new THREE.BoxGeometry(2.1, 0.38, 1.88),
    new THREE.MeshStandardMaterial({ color: '#1d4ed8', roughness: 0.8 })
  );
  blanket.position.set(-0.42, 0.6, 0);
  const bedPillow = new THREE.Mesh(
    new THREE.BoxGeometry(0.65, 0.24, 1.2),
    new THREE.MeshStandardMaterial({ color: '#e2e8f0', roughness: 0.9 })
  );
  bedPillow.position.set(1.05, 0.82, 0);
  bed.add(bedFrame, mattress, blanket, bedPillow);
  bed.visible = false;
  root.add(bed);

  const desk = new THREE.Group();
  const deskTop = new THREE.Mesh(
    new THREE.BoxGeometry(1.6, 0.12, 2.8),
    new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.35, metalness: 0.4 })
  );
  deskTop.position.y = 1.05;
  const deskLegL = new THREE.Mesh(
    new THREE.BoxGeometry(1.3, 1.05, 0.14),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.4, metalness: 0.6 })
  );
  deskLegL.position.set(0, 0.52, -1.22);
  const deskLegR = deskLegL.clone();
  deskLegR.position.z = 1.22;

  const monitorFrame = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 1.45, 2.3),
    new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.25, metalness: 0.7 })
  );
  monitorFrame.position.set(0.35, 2.05, 0);
  const monitorStand = new THREE.Mesh(
    new THREE.BoxGeometry(0.14, 0.4, 0.24),
    new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.8, roughness: 0.2 })
  );
  monitorStand.position.set(0.38, 1.26, 0);
  const monitorScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(2.15, 1.3),
    new THREE.MeshBasicMaterial({ map: screenTextures.bluelock_game })
  );
  monitorScreen.rotation.y = -Math.PI / 2;
  monitorScreen.position.set(0.26, 2.05, 0);

  const deskHeadset = new THREE.Group();
  const dhBand = new THREE.Mesh(
    new THREE.TorusGeometry(0.26, 0.04, 8, 16, Math.PI),
    new THREE.MeshStandardMaterial({ color: '#a855f7', metalness: 0.7, roughness: 0.25 })
  );
  dhBand.position.y = 0.16;
  const dhCupL = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 0.08, 12),
    new THREE.MeshStandardMaterial({ color: '#111827' })
  );
  dhCupL.rotation.z = Math.PI / 2;
  dhCupL.position.set(-0.24, 0.14, 0);
  const dhCupR = dhCupL.clone();
  dhCupR.position.x = 0.24;
  deskHeadset.add(dhBand, dhCupL, dhCupR);
  deskHeadset.position.set(-0.2, 1.12, 0.78);
  deskHeadset.visible = false;

  desk.add(deskTop, deskLegL, deskLegR, monitorFrame, monitorStand, monitorScreen, deskHeadset);
  desk.visible = false;
  root.add(desk);

  const phone = new THREE.Group();
  const phoneBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.56, 0.3),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.2, metalness: 0.85 })
  );
  const phoneScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.26, 0.48),
    new THREE.MeshBasicMaterial({ map: screenTextures.phone_musab })
  );
  phoneScreen.rotation.y = -Math.PI / 2;
  phoneScreen.position.x = -0.045;
  phone.add(phoneBody, phoneScreen);
  phone.visible = false;
  root.add(phone);

  const pillow = new THREE.Group();
  const pillowMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.95, 0.28, 0.72),
    new THREE.MeshStandardMaterial({ color: '#e0f2fe', roughness: 0.85 })
  );
  const pillowTrim = new THREE.Mesh(
    new THREE.BoxGeometry(0.98, 0.08, 0.75),
    new THREE.MeshStandardMaterial({ color: '#38bdf8', emissive: '#0284c7', emissiveIntensity: 0.5 })
  );
  pillow.add(pillowMesh, pillowTrim);
  pillow.visible = false;
  root.add(pillow);

  const sock = new THREE.Group();
  const sockAnkle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.16, 0.15, 0.48, 12),
    new THREE.MeshStandardMaterial({ color: '#34d399', roughness: 0.65 })
  );
  sockAnkle.position.y = 0.24;
  const sockFoot = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.22, 0.28),
    new THREE.MeshStandardMaterial({ color: '#059669', roughness: 0.65 })
  );
  sockFoot.position.set(0.12, 0.08, 0);
  const sockStripe = new THREE.Mesh(
    new THREE.CylinderGeometry(0.17, 0.17, 0.1, 12),
    new THREE.MeshStandardMaterial({ color: '#fde047', emissive: '#eab308', emissiveIntensity: 0.6 })
  );
  sockStripe.position.y = 0.38;
  sock.add(sockAnkle, sockFoot, sockStripe);
  sock.visible = false;
  root.add(sock);

  const coach = new THREE.Group();
  const coachBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.85, 1.1, 0.5),
    new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.6 })
  );
  coachBody.position.y = 1.3;
  const coachLegs = new THREE.Mesh(
    new THREE.BoxGeometry(0.75, 0.75, 0.42),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.7 })
  );
  coachLegs.position.y = 0.38;
  const coachHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.58, 0.58, 0.58),
    new THREE.MeshStandardMaterial({ color: '#eab896', roughness: 0.65 })
  );
  coachHead.position.y = 2.15;
  const coachCap = new THREE.Mesh(
    new THREE.BoxGeometry(0.64, 0.18, 0.74),
    new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.4 })
  );
  coachCap.position.set(0.06, 2.46, 0);
  coach.add(coachBody, coachLegs, coachHead, coachCap);
  coach.visible = false;
  root.add(coach);

  const hamburger = new THREE.Group();
  const bunMat = new THREE.MeshStandardMaterial({ color: '#d97706', roughness: 0.65 });
  const bottomBun = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.34, 0.14, 16), bunMat);
  bottomBun.position.y = 0.07;
  const patty = new THREE.Mesh(
    new THREE.CylinderGeometry(0.38, 0.38, 0.14, 16),
    new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.85 })
  );
  patty.position.y = 0.2;
  const cheese = new THREE.Mesh(
    new THREE.BoxGeometry(0.64, 0.05, 0.64),
    new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.4 })
  );
  cheese.position.y = 0.28;
  const lettuce = new THREE.Mesh(
    new THREE.CylinderGeometry(0.41, 0.41, 0.06, 12),
    new THREE.MeshStandardMaterial({ color: '#22c55e', roughness: 0.55 })
  );
  lettuce.position.y = 0.33;
  const topBun = new THREE.Mesh(
    new THREE.SphereGeometry(0.36, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2),
    bunMat
  );
  topBun.position.y = 0.36;
  hamburger.add(bottomBun, patty, cheese, lettuce, topBun);
  hamburger.visible = false;
  root.add(hamburger);

  const monsterBall = new THREE.Group();
  const mCore = new THREE.Mesh(
    new THREE.SphereGeometry(0.55, 24, 24),
    new THREE.MeshStandardMaterial({
      color: '#a855f7',
      emissive: '#7e22ce',
      emissiveIntensity: 1.5,
      roughness: 0.2,
    })
  );
  const mRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.82, 0.08, 10, 28),
    new THREE.MeshBasicMaterial({ color: '#fbbf24' })
  );
  monsterBall.add(mCore, mRing);
  monsterBall.visible = false;
  root.add(monsterBall);

  const snapRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.0, 0.09, 10, 36),
    new THREE.MeshBasicMaterial({
      color: '#facc15',
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
    })
  );
  snapRing.rotation.x = Math.PI / 2;
  snapRing.visible = false;
  root.add(snapRing);

  return {
    root,
    bed,
    desk,
    monitorScreen,
    screenTextures,
    phone,
    phoneScreen,
    pillow,
    sock,
    coach,
    hamburger,
    monsterBall,
    snapRing,
    deskHeadset,
  };
}
