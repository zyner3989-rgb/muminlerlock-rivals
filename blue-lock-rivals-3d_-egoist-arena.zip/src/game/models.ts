import * as THREE from 'three';
import { CLEAT_OPTIONS, OUTFIT_OPTIONS, resolveDefaultHairForStyle } from '../data/cosmetics';
import type {
  BackAccessoryId,
  HairStyleId,
  StyleDefinition,
  WardrobeConfig,
} from '../types/game';
import {
  createContactShadowTexture,
  createFabricBumpTexture,
  createJerseyTexture,
  createPitchBumpTexture,
  createPitchTexture,
  createScreenTexture,
  createSoccerBallBumpTexture,
  createSoccerBallTexture,
  createStadiumLedTexture,
} from './textures';

export interface PlayerRig {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  headGroup: THREE.Group;
  torsoMesh: THREE.Mesh;
  leftArmPivot: THREE.Group;
  rightArmPivot: THREE.Group;
  leftLegPivot: THREE.Group;
  rightLegPivot: THREE.Group;
  headsetProp?: THREE.Group;
  gauntletProp?: THREE.Group;
  auraRing: THREE.Mesh;
  auraPillars: THREE.Group;
  shadowMesh: THREE.Mesh;
  selectionRing: THREE.Mesh;
}

export interface CutscenePropPack {
  root: THREE.Group;
  bed: THREE.Group;
  desk: THREE.Group;
  monitorScreen: THREE.Mesh;
  screenTextures: {
    bluelock_game: THREE.CanvasTexture;
    aras_lose: THREE.CanvasTexture;
    ai_cheat: THREE.CanvasTexture;
    phone_musab: THREE.CanvasTexture;
    videocall_musa: THREE.CanvasTexture;
  };
  phone: THREE.Group;
  phoneScreen: THREE.Mesh;
  pillow: THREE.Group;
  sock: THREE.Group;
  coach: THREE.Group;
  hamburger: THREE.Group;
  monsterBall: THREE.Group;
  snapRing: THREE.Mesh;
  deskHeadset: THREE.Group;
}

export interface StadiumRefs {
  root: THREE.Group;
  blueNet: THREE.Mesh;
  redNet: THREE.Mesh;
  crowdInstanced: THREE.InstancedMesh;
  pitchMat: THREE.MeshPhysicalMaterial;
  apronMat: THREE.MeshStandardMaterial;
  skyMat: THREE.ShaderMaterial;
  floodBeams: THREE.Mesh[];
  ledBoards: THREE.Mesh[];
  rainPoints: THREE.Points;
  rainVelocities: Float32Array;
}

export const PITCH_HALF_LENGTH = 44; // X: -44 to +44
export const PITCH_HALF_WIDTH = 26; // Z: -26 to +26
export const GOAL_HALF_WIDTH = 4.6;
export const GOAL_HEIGHT = 3.3;
export const GOAL_DEPTH = 2.8;

/**
 * Multi-layered Roblox Robux UGC Hairstyles (sculpted tapered locks, bangs, crown tufts,
 * highlight streaks & clearcoat physical sheen). Head faces +X!
 */
function buildRobuxHair(
  headGroup: THREE.Group,
  hairStyle: Exclude<HairStyleId, 'character'>,
  baseColorHex: string,
  highlightHex: string
) {
  const hairGroup = new THREE.Group();
  const baseMat = new THREE.MeshPhysicalMaterial({
    color: baseColorHex,
    roughness: 0.42,
    metalness: 0.06,
    clearcoat: 0.28,
    clearcoatRoughness: 0.35,
  });

  // Compute an attractive highlight tint (blends base hair with accent/frost)
  const mixedTint = new THREE.Color(baseColorHex).lerp(new THREE.Color(highlightHex), 0.48);
  const tipMat = new THREE.MeshPhysicalMaterial({
    color: mixedTint,
    roughness: 0.36,
    metalness: 0.1,
    clearcoat: 0.38,
    clearcoatRoughness: 0.28,
  });

  const addLock = (
    rx: number,
    ry: number,
    rz: number,
    radiusTop: number,
    radiusBot: number,
    len: number,
    px: number,
    py: number,
    pz: number,
    mat: THREE.Material = baseMat,
    sx = 1,
    sz = 1
  ) => {
    const geo = new THREE.ConeGeometry(radiusBot, len, 7);
    if (radiusTop > 0.005) {
      geo.dispose();
      const lockGeo = new THREE.CylinderGeometry(radiusTop, radiusBot, len, 7);
      const mesh = new THREE.Mesh(lockGeo, mat);
      mesh.position.set(px, py, pz);
      mesh.rotation.set(rx, ry, rz);
      mesh.scale.set(sx, 1, sz);
      mesh.castShadow = true;
      hairGroup.add(mesh);
      return;
    }
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(px, py, pz);
    mesh.rotation.set(rx, ry, rz);
    mesh.scale.set(sx, 1, sz);
    mesh.castShadow = true;
    hairGroup.add(mesh);
  };

  // Sculpted Skull Crown Base (snug on cranium, zero forehead clipping)
  const cap = new THREE.Mesh(
    new THREE.SphereGeometry(0.292, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.58),
    baseMat
  );
  cap.scale.set(1.06, 1.12, 1.02);
  cap.position.set(-0.025, 0.31, 0);
  cap.castShadow = true;
  hairGroup.add(cap);

  // Back-of-head volume layer (nape coverage)
  const napeDome = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12), baseMat);
  napeDome.scale.set(0.85, 0.92, 0.96);
  napeDome.position.set(-0.11, 0.26, 0);
  napeDome.castShadow = true;
  hairGroup.add(napeDome);

  if (hairStyle === 'wolfcut') {
    // Rich Roblox UGC Shaggy Wolfcut: sweeping curtain bangs + long temple locks + flared nape spikes
    for (let i = -3; i <= 3; i++) {
      const side = Math.sign(i) || 1;
      const absI = Math.abs(i);
      const isHighlight = i === -1 || i === 2;
      addLock(
        side * 0.16,
        0,
        2.55 - absI * 0.12,
        0.015,
        0.068,
        0.22 - absI * 0.015,
        0.215 - absI * 0.028,
        0.43 - absI * 0.01,
        i * 0.062,
        isHighlight ? tipMat : baseMat,
        0.85,
        1.25
      );
    }
    // Side framing wolf locks down past ears
    [-1, 1].forEach((s) => {
      addLock(s * 0.18, 0, 2.9, 0.02, 0.072, 0.29, 0.05, 0.25, s * 0.275, baseMat, 1.1, 0.75);
      addLock(s * 0.22, 0, 2.75, 0.015, 0.058, 0.25, -0.05, 0.22, s * 0.26, tipMat, 1.1, 0.75);
    });
    // Fluffy crown tufts
    for (let i = 0; i < 6; i++) {
      const ang = (i / 6) * Math.PI * 2;
      addLock(
        Math.sin(ang) * 0.45,
        0,
        -0.45 + Math.cos(ang) * 0.35,
        0.015,
        0.075,
        0.2,
        -0.04 + Math.cos(ang) * 0.1,
        0.59,
        Math.sin(ang) * 0.1,
        i % 2 === 0 ? baseMat : tipMat
      );
    }
    // Signature flared wolfcut nape spikes pointing down & outward
    for (let i = -2; i <= 2; i++) {
      addLock(
        i * 0.18,
        0,
        2.25,
        0.012,
        0.068,
        0.28,
        -0.27,
        0.13 + Math.abs(i) * 0.02,
        i * 0.085,
        i === 0 ? tipMat : baseMat,
        0.8,
        1.2
      );
    }
  } else if (hairStyle === 'spiky') {
    // Fierce Swept-Back Roblox Anime Spikes (high silhouette)
    const spikeConfigs: Array<[number, number, number, number, number, number, boolean]> = [
      [0.06, 0.63, 0, 0.095, 0.36, -0.45, true],
      [-0.02, 0.61, -0.11, 0.088, 0.34, -0.58, false],
      [-0.02, 0.61, 0.11, 0.088, 0.34, -0.58, false],
      [-0.12, 0.56, -0.17, 0.082, 0.3, -0.78, true],
      [-0.12, 0.56, 0.17, 0.082, 0.3, -0.78, true],
      [-0.18, 0.48, 0, 0.095, 0.34, -1.05, false],
      [-0.22, 0.42, -0.12, 0.08, 0.28, -1.2, false],
      [-0.22, 0.42, 0.12, 0.08, 0.28, -1.2, false],
    ];
    for (const [px, py, pz, r, l, rz, isTip] of spikeConfigs) {
      addLock(pz * 0.9, 0, rz, 0.008, r, l, px, py, pz, isTip ? tipMat : baseMat, 1.0, 0.9);
    }
    // Sharp brow-grazing front locks
    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.12, 0, 2.48, 0.01, 0.055, 0.2, 0.225, 0.43, i * 0.068, i === 0 ? tipMat : baseMat);
    }
  } else if (hairStyle === 'curtain') {
    // Sleek K-Pop / Blue Lock Middle-Parted Curtain Hair
    [-1, 1].forEach((s) => {
      // Top swoop arch
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.165, 14, 10), baseMat);
      dome.scale.set(1.25, 0.72, 0.95);
      dome.position.set(0.06, 0.54, s * 0.105);
      dome.rotation.x = s * -0.22;
      dome.castShadow = true;
      hairGroup.add(dome);

      // Thick parted curtain locks framing face
      for (let k = 0; k < 3; k++) {
        addLock(
          s * (0.38 + k * 0.14),
          0,
          2.68 + k * 0.12,
          0.025,
          0.072,
          0.26,
          0.205 - k * 0.06,
          0.38 - k * 0.03,
          s * (0.065 + k * 0.075),
          k === 1 ? tipMat : baseMat,
          0.72,
          1.3
        );
      }
      // Tapered back-side sweep
      addLock(s * 0.2, 0, 2.35, 0.02, 0.07, 0.24, -0.18, 0.21, s * 0.14, baseMat);
    });
  } else if (hairStyle === 'curly') {
    // Volumetric Roblox UGC Fluffy Curly Fade (rich sculpted curly tufts)
    const curlCoords: Array<[number, number, number, number, boolean]> = [
      [0.02, 0.58, 0, 0.12, false],
      [0.14, 0.54, 0.09, 0.11, true],
      [0.14, 0.54, -0.09, 0.11, false],
      [0.21, 0.47, 0.03, 0.095, false],
      [0.21, 0.47, -0.08, 0.095, true],
      [0.19, 0.45, 0.14, 0.09, false],
      [-0.08, 0.56, 0.11, 0.115, false],
      [-0.08, 0.56, -0.11, 0.115, true],
      [-0.19, 0.49, 0, 0.12, false],
      [-0.17, 0.46, 0.16, 0.105, false],
      [-0.17, 0.46, -0.16, 0.105, false],
      [0.03, 0.52, 0.21, 0.1, false],
      [0.03, 0.52, -0.21, 0.1, true],
      [-0.25, 0.35, 0.1, 0.095, false],
      [-0.25, 0.35, -0.1, 0.095, false],
      [-0.27, 0.25, 0, 0.1, true],
      [0.24, 0.41, -0.02, 0.082, false],
      [0.22, 0.4, 0.1, 0.08, true],
    ];
    for (const [cx, cy, cz, r, hi] of curlCoords) {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 10), hi ? tipMat : baseMat);
      puff.position.set(cx, cy, cz);
      puff.castShadow = true;
      hairGroup.add(puff);
    }
  } else if (hairStyle === 'windswept') {
    // Dramatic Asymmetrical Eye-Cover Bang + Swept Back Velocity Blades
    for (let i = 0; i < 6; i++) {
      const zOff = -0.16 + i * 0.065;
      addLock(
        0.22,
        -0.18,
        -0.85 - i * 0.06,
        0.012,
        0.082,
        0.34,
        -0.06 - i * 0.02,
        0.54 - Math.abs(i - 2.5) * 0.025,
        zOff,
        i % 2 === 1 ? tipMat : baseMat,
        1.1,
        0.8
      );
    }
    // Signature diagonal emo-egoist front lock across left eye
    addLock(0.45, 0, 2.55, 0.015, 0.065, 0.29, 0.23, 0.39, 0.075, tipMat, 0.75, 1.35);
    addLock(0.2, 0, 2.58, 0.015, 0.055, 0.22, 0.22, 0.42, -0.09, baseMat, 0.8, 1.1);
  } else if (hairStyle === 'ponytail') {
    // Sleek Samurai High Ponytail + Glowing Band + Temple Locks
    const tieMat = new THREE.MeshStandardMaterial({
      color: highlightHex,
      emissive: highlightHex,
      emissiveIntensity: 0.7,
      roughness: 0.25,
    });
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.024, 8, 16), tieMat);
    band.position.set(-0.24, 0.52, 0);
    band.rotation.y = Math.PI / 2;
    hairGroup.add(band);

    // Sculpted ponytail clusters cascading down the back
    addLock(0, 0, 1.92, 0.065, 0.095, 0.34, -0.35, 0.45, 0, baseMat, 0.9, 1.15);
    addLock(0.18, 0, 2.15, 0.015, 0.075, 0.3, -0.42, 0.28, 0.05, tipMat);
    addLock(-0.18, 0, 2.15, 0.015, 0.075, 0.3, -0.42, 0.28, -0.05, baseMat);

    // Loose front temple strands framing brow
    [-1, 1].forEach((s) => {
      addLock(s * 0.22, 0, 2.7, 0.012, 0.048, 0.24, 0.19, 0.35, s * 0.17, s > 0 ? tipMat : baseMat);
    });
  } else {
    // 'frostcrown': Volumetric Robux Crown with chunky dual-tone frosted tip locks
    for (let i = 0; i < 10; i++) {
      const ang = (i / 10) * Math.PI * 2;
      const rad = 0.17;
      addLock(
        Math.sin(ang) * 0.42,
        0,
        -Math.cos(ang) * 0.42,
        0.022,
        0.082,
        0.24,
        Math.cos(ang) * rad - 0.01,
        0.57,
        Math.sin(ang) * rad,
        i % 2 === 0 ? tipMat : baseMat
      );
    }
    for (let i = -2; i <= 2; i++) {
      addLock(i * 0.14, 0, 2.48, 0.018, 0.062, 0.21, 0.22, 0.42, i * 0.072, i % 2 === 0 ? tipMat : baseMat);
    }
  }

  headGroup.add(hairGroup);
}

/**
 * Adds flush-mounted back accessories (scarf, cape, katana, cyber wings) anchored strictly
 * from parametric torso metrics so they NEVER drift across models!
 */
function buildBackAccessory(
  bodyPivot: THREE.Group,
  accessoryId: BackAccessoryId,
  chestHalfX: number,
  chestHalfZ: number,
  accentHex: string,
  secondaryHex: string
) {
  if (accessoryId === 'none') return;

  const backX = -chestHalfX - 0.03;

  if (accessoryId === 'scarf') {
    const scarfMat = new THREE.MeshPhysicalMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.25,
      roughness: 0.55,
      clearcoat: 0.12,
    });
    const loop = new THREE.Mesh(
      new THREE.TorusGeometry(chestHalfX * 0.88, 0.065, 10, 20),
      scarfMat
    );
    loop.rotation.x = Math.PI / 2;
    loop.scale.set(1.0, chestHalfZ / chestHalfX * 0.65, 1.0);
    loop.position.set(0, 1.88, 0);

    const tail1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.56, 0.18), scarfMat);
    tail1.position.set(backX - 0.14, 1.56, -0.08);
    tail1.rotation.z = -0.34;
    tail1.rotation.y = 0.14;
    tail1.castShadow = true;

    const tail2 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.42, 0.15), scarfMat);
    tail2.position.set(backX - 0.11, 1.62, 0.08);
    tail2.rotation.z = -0.24;
    tail2.rotation.y = -0.18;
    bodyPivot.add(loop, tail1, tail2);
  } else if (accessoryId === 'cape') {
    const capeMat = new THREE.MeshStandardMaterial({
      color: '#0f172a',
      roughness: 0.65,
      side: THREE.DoubleSide,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: secondaryHex,
      emissive: accentHex,
      emissiveIntensity: 0.35,
      roughness: 0.35,
    });
    const capeBody = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.92, chestHalfZ * 1.85), capeMat);
    capeBody.position.set(backX - 0.09, 1.4, 0);
    capeBody.rotation.z = -0.12;
    capeBody.castShadow = true;

    const trim = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.08, chestHalfZ * 1.87), trimMat);
    trim.position.set(backX - 0.14, 0.96, 0);
    trim.rotation.z = -0.12;

    const clasp = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, chestHalfZ * 1.9), trimMat);
    clasp.position.set(-chestHalfX * 0.3, 1.86, 0);
    bodyPivot.add(capeBody, trim, clasp);
  } else if (accessoryId === 'katana') {
    const scabbardMat = new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.25, metalness: 0.85 });
    const gripMat = new THREE.MeshStandardMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.6,
      roughness: 0.3,
    });
    const scabbard = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.028, 1.28, 10), scabbardMat);
    scabbard.position.set(backX - 0.04, 1.48, 0);
    scabbard.rotation.x = 0.68;

    const guard = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.03, 12), gripMat);
    guard.position.set(backX - 0.04, 1.84, -0.35);
    guard.rotation.x = 0.68;

    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.3, 10), gripMat);
    hilt.position.set(backX - 0.04, 1.94, -0.45);
    hilt.rotation.x = 0.68;
    bodyPivot.add(scabbard, guard, hilt);
  } else if (accessoryId === 'wings') {
    const wingMat = new THREE.MeshPhysicalMaterial({
      color: accentHex,
      emissive: accentHex,
      emissiveIntensity: 0.95,
      transparent: true,
      opacity: 0.72,
      roughness: 0.15,
      metalness: 0.2,
      side: THREE.DoubleSide,
    });
    [-1, 1].forEach((s) => {
      const featherTop = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.24, 0.78), wingMat);
      featherTop.position.set(backX - 0.08, 1.72, s * 0.44);
      featherTop.rotation.x = s * 0.25;
      featherTop.rotation.y = s * -0.35;

      const featherMid = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.18, 0.62), wingMat);
      featherMid.position.set(backX - 0.08, 1.52, s * 0.36);
      featherMid.rotation.x = s * 0.1;
      featherMid.rotation.y = s * -0.35;

      const featherBot = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.44), wingMat);
      featherBot.position.set(backX - 0.08, 1.36, s * 0.28);
      featherBot.rotation.x = s * -0.05;
      featherBot.rotation.y = s * -0.35;
      bodyPivot.add(featherTop, featherMid, featherBot);
    });
  }
}

export function buildRobloxPlayer(
  style: StyleDefinition,
  team: 'BLUE' | 'RED',
  maxAnisotropy: number,
  isGoalkeeper = false,
  wardrobe?: WardrobeConfig
): PlayerRig {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  const w: WardrobeConfig = wardrobe ?? {
    outfitId: 'signature',
    hairStyleId: 'character',
    hairColor: 'character',
    cleatId: 'character',
    backAccessoryId: 'none',
  };

  // Resolve Outfit Colors cleanly
  let jerseyPrimary = style.primaryColor;
  let jerseySecondary = style.secondaryColor;
  if (isGoalkeeper) {
    jerseyPrimary = team === 'BLUE' ? '#0284c7' : '#b91c1c';
    jerseySecondary = '#fde047';
  } else if (w.outfitId !== 'signature') {
    const preset = OUTFIT_OPTIONS.find((o) => o.id === w.outfitId);
    if (preset) {
      jerseyPrimary = preset.previewPrimary;
      jerseySecondary = preset.previewSecondary;
    }
  }

  // Parametric Body Proportions — every part derives from these constants (Zero offset/drift!)
  const isBerk = style.id === 'berk' && !isGoalkeeper;
  const torsoRadiusTop = isBerk ? 0.44 : 0.36;
  const torsoRadiusBot = isBerk ? 0.39 : 0.28;
  const torsoScaleX = 0.72;
  const torsoScaleZ = 1.18;
  const chestHalfX = torsoRadiusTop * torsoScaleX;
  const chestHalfZ = torsoRadiusTop * torsoScaleZ;
  const hipSpacing = isBerk ? 0.22 : 0.18;

  const skinMat = new THREE.MeshPhysicalMaterial({
    color: style.skinColor,
    roughness: 0.56,
    metalness: 0.01,
    clearcoat: 0.08,
    clearcoatRoughness: 0.6,
  });

  const fabricBump = createFabricBumpTexture(maxAnisotropy);
  const jerseyTex = createJerseyTexture(
    jerseyPrimary,
    jerseySecondary,
    style.jerseyNumber,
    style.name,
    maxAnisotropy,
    isGoalkeeper ? 'signature' : w.outfitId
  );
  const torsoMat = new THREE.MeshStandardMaterial({
    map: jerseyTex,
    bumpMap: fabricBump,
    bumpScale: 0.012,
    roughness: 0.58,
    metalness: 0.06,
  });

  const shortsColor =
    w.outfitId === 'royalwhite' && !isGoalkeeper
      ? '#e2e8f0'
      : w.outfitId === 'crimson' && !isGoalkeeper
        ? '#450a0a'
        : team === 'RED'
          ? '#1f2937'
          : '#090d16';

  const shortsMat = new THREE.MeshStandardMaterial({
    color: shortsColor,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.66,
    metalness: 0.05,
  });

  const teamAccentMat = new THREE.MeshStandardMaterial({
    color: team === 'BLUE' ? '#38bdf8' : '#ef4444',
    emissive: team === 'BLUE' ? '#0284c7' : '#b91c1c',
    emissiveIntensity: 0.5,
    roughness: 0.3,
  });

  const cleatPreset = CLEAT_OPTIONS.find((c) => c.id === w.cleatId);
  const cleatHex =
    isGoalkeeper || !cleatPreset || w.cleatId === 'character' ? jerseySecondary : cleatPreset.cleatHex;
  const sockHex =
    isGoalkeeper || !cleatPreset || w.cleatId === 'character'
      ? style.id === 'iskender'
        ? '#fde047'
        : '#f8fafc'
      : cleatPreset.sockHex;

  const cleatMat = new THREE.MeshPhysicalMaterial({
    color: cleatHex,
    roughness: 0.26,
    metalness: 0.38,
    clearcoat: 0.45,
    clearcoatRoughness: 0.22,
  });

  const resolvedHairColor =
    w.hairColor && w.hairColor !== 'character' ? w.hairColor : style.hairColor;
  const resolvedHairStyle: Exclude<HairStyleId, 'character'> =
    w.hairStyleId === 'character' ? resolveDefaultHairForStyle(style.id) : w.hairStyleId;

  const browMat = new THREE.MeshStandardMaterial({ color: resolvedHairColor, roughness: 0.65 });

  // 1. Athletic Pelvis / Shorts Waist (EXACT match to torsoScaleX / torsoScaleZ -> zero shift!)
  const pelvis = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusBot * 0.99, torsoRadiusBot * 1.04, 0.28, 18),
    shortsMat
  );
  pelvis.scale.set(torsoScaleX, 1, torsoScaleZ);
  pelvis.position.set(0, 0.98, 0);
  pelvis.castShadow = true;
  pelvis.receiveShadow = true;
  bodyPivot.add(pelvis);

  // Waistband stripe flush around pelvis top
  const waistband = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusBot * 1.005, torsoRadiusBot * 1.005, 0.055, 18),
    new THREE.MeshStandardMaterial({ color: jerseySecondary, roughness: 0.42 })
  );
  waistband.scale.set(torsoScaleX, 1, torsoScaleZ);
  waistband.position.set(0, 1.09, 0);
  bodyPivot.add(waistband);

  // 2. Sculpted Athletic Torso (V-tapered chest + aligned dual-sided UVs: +X chest, -X name/number)
  const torsoMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(torsoRadiusTop, torsoRadiusBot, 0.78, 20),
    torsoMat
  );
  torsoMesh.scale.set(torsoScaleX, 1, torsoScaleZ);
  torsoMesh.position.set(0, 1.48, 0);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyPivot.add(torsoMesh);

  // Elliptical Collar scaled parametrically to chestHalfX & chestHalfZ (no round-collar clip on Berk!)
  const collar = new THREE.Mesh(
    new THREE.TorusGeometry(torsoRadiusTop * 0.46, 0.036, 10, 20),
    new THREE.MeshStandardMaterial({ color: jerseySecondary, roughness: 0.35, metalness: 0.25 })
  );
  collar.rotation.x = Math.PI / 2;
  collar.scale.set(torsoScaleX * 1.08, torsoScaleZ * 0.9, 1);
  collar.position.set(0, 1.875, 0);
  bodyPivot.add(collar);

  // 3D Outfit Details (Hoodie hood / Cyberjacket open lapels) — parametrically flush!
  if (!isGoalkeeper && w.outfitId === 'hoodie') {
    const hoodieMat = new THREE.MeshStandardMaterial({
      color: jerseyPrimary,
      bumpMap: fabricBump,
      bumpScale: 0.015,
      roughness: 0.72,
    });
    const hoodCowl = new THREE.Mesh(
      new THREE.TorusGeometry(torsoRadiusTop * 0.56, 0.085, 10, 18, Math.PI * 1.25),
      hoodieMat
    );
    hoodCowl.rotation.x = Math.PI / 2 + 0.35;
    hoodCowl.rotation.z = Math.PI * 0.88;
    hoodCowl.scale.set(torsoScaleX * 1.05, torsoScaleZ * 0.95, 1);
    hoodCowl.position.set(-chestHalfX * 0.35, 1.88, 0);
    hoodCowl.castShadow = true;
    bodyPivot.add(hoodCowl);

    const hoodBack = new THREE.Mesh(
      new THREE.SphereGeometry(torsoRadiusTop * 0.48, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.6),
      hoodieMat
    );
    hoodBack.scale.set(0.75, 0.7, 1.25);
    hoodBack.position.set(-chestHalfX - 0.05, 1.78, 0);
    hoodBack.rotation.z = 1.2;
    bodyPivot.add(hoodBack);
  } else if (!isGoalkeeper && w.outfitId === 'cyberjacket') {
    const lapelMat = new THREE.MeshStandardMaterial({
      color: jerseySecondary,
      emissive: jerseySecondary,
      emissiveIntensity: 0.35,
      roughness: 0.3,
      metalness: 0.45,
    });
    [-1, 1].forEach((s) => {
      const lapel = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.72, 0.055), lapelMat);
      lapel.position.set(chestHalfX * 0.94, 1.5, s * 0.095);
      lapel.rotation.z = -0.06;
      bodyPivot.add(lapel);
    });
  }

  // Parametric Back Accessory (zero drift!)
  if (!isGoalkeeper) {
    buildBackAccessory(
      bodyPivot,
      w.backAccessoryId,
      chestHalfX,
      chestHalfZ,
      style.auraColor,
      jerseySecondary
    );
  }

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.108, 0.128, 0.18, 12), skinMat);
  neck.position.set(0, 1.94, 0);
  bodyPivot.add(neck);

  // 3. Realistic Contoured Head + Ears + Multi-Highlight Eyes + Robux Hair
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 2.02, 0);
  bodyPivot.add(headGroup);

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.268, 22, 18), skinMat);
  cranium.scale.set(1.02, 1.13, 0.94);
  cranium.position.set(0, 0.28, 0);
  cranium.castShadow = true;
  headGroup.add(cranium);

  const jaw = new THREE.Mesh(new THREE.CylinderGeometry(0.195, 0.138, 0.18, 14), skinMat);
  jaw.position.set(0.04, 0.14, 0);
  headGroup.add(jaw);

  // Realistic Ears
  [-1, 1].forEach((zSign) => {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.052, 10, 8), skinMat);
    ear.scale.set(0.55, 1.15, 0.45);
    ear.position.set(-0.02, 0.27, zSign * 0.252);
    headGroup.add(ear);
  });

  // Sculpted Nose + Subtle Mouth Expression
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.085, 6), skinMat);
  nose.rotation.z = -Math.PI / 2.2;
  nose.position.set(0.268, 0.245, 0);
  headGroup.add(nose);

  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.015, 0.085),
    new THREE.MeshStandardMaterial({ color: '#9a5b4e', roughness: 0.7 })
  );
  mouth.position.set(0.242, 0.16, 0);
  headGroup.add(mouth);

  // Expressive Contoured Anime/Roblox Eyes (+X forward) with Iris + Pupil + Specular Catchlight
  const scleraMat = new THREE.MeshPhysicalMaterial({
    color: '#f8fafc',
    roughness: 0.12,
    clearcoat: 0.8,
  });
  const irisMat = new THREE.MeshPhysicalMaterial({
    color: style.auraColor,
    emissive: style.auraColor,
    emissiveIntensity: 0.65,
    roughness: 0.15,
    clearcoat: 0.9,
  });
  const darkPupilMat = new THREE.MeshBasicMaterial({ color: '#020617' });
  const glintMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });

  [-1, 1].forEach((zSign) => {
    const sclera = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.068, 0.098), scleraMat);
    sclera.position.set(0.242, 0.305, zSign * 0.105);

    const iris = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.056, 0.058), irisMat);
    iris.position.set(0.245, 0.305, zSign * 0.102);

    const core = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.03, 0.03), darkPupilMat);
    core.position.set(0.247, 0.305, zSign * 0.102);

    const glint = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.016, 0.016), glintMat);
    glint.position.set(0.248, 0.322, zSign * 0.114);

    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.024, 0.112), browMat);
    brow.position.set(0.248, 0.372, zSign * 0.105);
    brow.rotation.x = zSign * -0.18;

    headGroup.add(sclera, iris, core, glint, brow);
  });

  // Layered Roblox Robux UGC Hairstyle
  buildRobuxHair(headGroup, resolvedHairStyle, resolvedHairColor, style.auraColor);

  // Character Signature Head Accessories
  let headsetProp: THREE.Group | undefined;
  let gauntletProp: THREE.Group | undefined;

  if (style.accessory === 'headset') {
    headsetProp = new THREE.Group();
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(0.325, 0.034, 8, 22, Math.PI),
      new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.28, metalness: 0.8 })
    );
    band.rotation.y = Math.PI / 2;
    band.position.set(-0.01, 0.36, 0);
    const earMat = new THREE.MeshPhysicalMaterial({
      color: '#facc15',
      emissive: '#ca8a04',
      emissiveIntensity: 0.55,
      roughness: 0.22,
      metalness: 0.72,
      clearcoat: 0.4,
    });
    const earL = new THREE.Mesh(new THREE.CylinderGeometry(0.108, 0.108, 0.08, 16), earMat);
    earL.rotation.x = Math.PI / 2;
    earL.position.set(-0.01, 0.29, -0.305);
    const earR = earL.clone();
    earR.position.set(-0.01, 0.29, 0.305);
    headsetProp.add(band, earL, earR);
    headGroup.add(headsetProp);
  } else if (style.accessory === 'shades') {
    const shadeMat = new THREE.MeshPhysicalMaterial({
      color: '#090d16',
      roughness: 0.06,
      metalness: 0.92,
      clearcoat: 1.0,
    });
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.09, 0.44), shadeMat);
    frame.position.set(0.265, 0.312, 0);
    headGroup.add(frame);
  } else if (style.accessory === 'headband') {
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(0.298, 0.298, 0.075, 20),
      new THREE.MeshStandardMaterial({ color: '#ef4444', roughness: 0.48 })
    );
    band.position.set(-0.01, 0.415, 0);
    headGroup.add(band);
  } else if (style.accessory === 'visor') {
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.068, 0.095, 0.46),
      new THREE.MeshPhysicalMaterial({
        color: '#22d3ee',
        emissive: '#06b6d4',
        emissiveIntensity: 1.25,
        roughness: 0.08,
        metalness: 0.85,
        clearcoat: 0.9,
      })
    );
    visor.position.set(0.265, 0.312, 0);
    headGroup.add(visor);
  }

  // 4. Sculpted Athletic Arms (Parametric Flush Shoulder Sockets -> zero gap on Berk!)
  const armShoulderZ = chestHalfZ + 0.055;
  const sleeveMat = new THREE.MeshStandardMaterial({
    color: jerseyPrimary,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.56,
    metalness: 0.06,
  });
  const sleeveTrimMat = new THREE.MeshStandardMaterial({
    color: jerseySecondary,
    roughness: 0.38,
    metalness: 0.18,
  });

  const buildArm = (zSign: number, withGauntlet: boolean) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(0, 1.79, zSign * armShoulderZ);

    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.135, 14, 12), sleeveMat);
    shoulder.scale.set(1.02, 1.0, 1.08);
    const sleeve = new THREE.Mesh(
      new THREE.CylinderGeometry(0.115, 0.102, w.outfitId === 'hoodie' || w.outfitId === 'cyberjacket' ? 0.46 : 0.28, 14),
      sleeveMat
    );
    const isLongSleeve = !isGoalkeeper && (w.outfitId === 'hoodie' || w.outfitId === 'cyberjacket');
    sleeve.position.set(0, isLongSleeve ? -0.23 : -0.14, 0);
    sleeve.castShadow = true;

    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.106, 0.106, 0.045, 12), sleeveTrimMat);
    cuff.position.set(0, isLongSleeve ? -0.45 : -0.26, 0);

    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.32, 6, 10), skinMat);
    forearm.position.set(0, -0.45, 0);
    forearm.castShadow = true;

    const hand = new THREE.Mesh(
      new THREE.SphereGeometry(0.084, 12, 10),
      isGoalkeeper
        ? new THREE.MeshStandardMaterial({ color: '#fde047', roughness: 0.38 })
        : skinMat
    );
    hand.position.set(0, -0.68, 0);
    armPivot.add(shoulder, sleeve, cuff, forearm, hand);

    if (zSign < 0 && !isGoalkeeper) {
      const armband = new THREE.Mesh(new THREE.CylinderGeometry(0.118, 0.118, 0.068, 12), teamAccentMat);
      armband.position.set(0, -0.22, 0);
      armPivot.add(armband);
    }

    if (withGauntlet) {
      gauntletProp = new THREE.Group();
      const glove = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.112, 0.18, 6, 12),
        new THREE.MeshStandardMaterial({
          color: '#fbbf24',
          emissive: '#b45309',
          emissiveIntensity: 0.45,
          roughness: 0.2,
          metalness: 0.92,
        })
      );
      glove.position.set(0, -0.58, 0);
      gauntletProp.add(glove);
      const stoneColors = ['#ef4444', '#3b82f6', '#a855f7', '#22c55e', '#f97316'];
      stoneColors.forEach((sc, idx) => {
        const gem = new THREE.Mesh(
          new THREE.BoxGeometry(0.045, 0.045, 0.045),
          new THREE.MeshStandardMaterial({ color: sc, emissive: sc, emissiveIntensity: 1.4 })
        );
        gem.position.set(0.11, -0.56, -0.08 + idx * 0.04);
        gauntletProp!.add(gem);
      });
      armPivot.add(gauntletProp);
    }
    bodyPivot.add(armPivot);
    return armPivot;
  };

  const leftArmPivot = buildArm(-1, false);
  const rightArmPivot = buildArm(1, style.accessory === 'gauntlet' && !isGoalkeeper);

  // 5. Sculpted Athletic Legs (Shorts thigh + Sock calf + Realistic Studded Soccer Cleat)
  const sockMat = new THREE.MeshStandardMaterial({
    color: sockHex,
    bumpMap: fabricBump,
    bumpScale: 0.01,
    roughness: 0.56,
  });
  const sockStripeMat = new THREE.MeshStandardMaterial({ color: cleatHex, roughness: 0.4 });
  const soleMat = new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.42, metalness: 0.3 });

  const buildLeg = (zSign: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(0, 0.92, zSign * hipSpacing);

    const thigh = new THREE.Mesh(
      new THREE.CylinderGeometry(isBerk ? 0.158 : 0.145, 0.12, 0.38, 14),
      shortsMat
    );
    thigh.position.set(0, -0.18, 0);
    thigh.castShadow = true;

    const kneeSkin = new THREE.Mesh(new THREE.SphereGeometry(0.104, 10, 8), skinMat);
    kneeSkin.position.set(0, -0.39, 0);

    const calf = new THREE.Mesh(new THREE.CylinderGeometry(0.104, 0.082, 0.36, 14), sockMat);
    calf.position.set(0, -0.58, 0);
    calf.castShadow = true;

    const sockBand = new THREE.Mesh(new THREE.CylinderGeometry(0.108, 0.106, 0.045, 14), sockStripeMat);
    sockBand.position.set(0, -0.44, 0);

    // Pro Soccer Cleat (Vamp + Tongue + Soleplate + 4 Cleat Studs)
    const cleatUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.088, 0.19, 8, 12), cleatMat);
    cleatUpper.rotation.z = Math.PI / 2;
    cleatUpper.position.set(0.065, -0.82, 0);
    cleatUpper.castShadow = true;

    const cleatLace = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.032, 0.075), sockStripeMat);
    cleatLace.position.set(0.07, -0.745, 0);

    const cleatSole = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.036, 0.165), soleMat);
    cleatSole.position.set(0.065, -0.888, 0);

    // Cleat studs
    [
      [-0.06, -0.05],
      [-0.06, 0.05],
      [0.18, -0.05],
      [0.18, 0.05],
    ].forEach(([sx, sz]) => {
      const stud = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.012, 0.025, 6), cleatMat);
      stud.position.set(sx, -0.912, sz);
      legPivot.add(stud);
    });

    legPivot.add(thigh, kneeSkin, calf, sockBand, cleatUpper, cleatLace, cleatSole);
    bodyPivot.add(legPivot);
    return legPivot;
  };

  const leftLegPivot = buildLeg(-1);
  const rightLegPivot = buildLeg(1);

  // 6. Contact Shadow & Team Ring
  const shadowMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(1.75, 1.75),
    new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = 0.02;
  root.add(shadowMesh);

  const selectionRing = new THREE.Mesh(
    new THREE.RingGeometry(0.62, 0.78, 32),
    new THREE.MeshBasicMaterial({
      color: team === 'BLUE' ? '#38bdf8' : '#ef4444',
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
      depthWrite: false,
    })
  );
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.03;
  root.add(selectionRing);

  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.86, 1.15, 6),
    new THREE.MeshBasicMaterial({
      color: style.auraColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      depthWrite: false,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.04;
  root.add(auraRing);

  const auraPillars = new THREE.Group();
  const pillarMat = new THREE.MeshBasicMaterial({
    color: style.auraColor,
    transparent: true,
    opacity: 0.35,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI * 2 * i) / 6;
    const shard = new THREE.Mesh(new THREE.ConeGeometry(0.14, 1.6, 4), pillarMat);
    shard.position.set(Math.cos(a) * 0.88, 0.85, Math.sin(a) * 0.88);
    auraPillars.add(shard);
  }
  auraPillars.visible = false;
  root.add(auraPillars);

  return {
    root,
    bodyPivot,
    headGroup,
    torsoMesh,
    leftArmPivot,
    rightArmPivot,
    leftLegPivot,
    rightLegPivot,
    headsetProp,
    gauntletProp,
    auraRing,
    auraPillars,
    shadowMesh,
    selectionRing,
  };
}

export function buildSoccerBall(maxAnisotropy: number): {
  group: THREE.Group;
  mesh: THREE.Mesh;
  shadow: THREE.Mesh;
  trailRing: THREE.Mesh;
} {
  const group = new THREE.Group();
  const ballTex = createSoccerBallTexture(maxAnisotropy);
  const ballBump = createSoccerBallBumpTexture(maxAnisotropy);
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.36, 28, 28),
    new THREE.MeshPhysicalMaterial({
      map: ballTex,
      bumpMap: ballBump,
      bumpScale: 0.015,
      roughness: 0.28,
      metalness: 0.08,
      clearcoat: 0.38,
      clearcoatRoughness: 0.22,
    })
  );
  mesh.castShadow = true;
  mesh.position.y = 0.36;
  group.add(mesh);

  const trailRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.45, 0.045, 8, 24),
    new THREE.MeshBasicMaterial({
      color: '#38bdf8',
      transparent: true,
      opacity: 0,
      depthWrite: false,
    })
  );
  trailRing.position.y = 0.36;
  group.add(trailRing);

  const shadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.1, 1.1),
    new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;

  return { group, mesh, shadow, trailRing };
}

export function buildStadium(maxAnisotropy: number): StadiumRefs {
  const root = new THREE.Group();

  // Procedural Atmospheric Sky Dome (ShaderMaterial for Night / Sunset / Rain)
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      uTopColor: { value: new THREE.Color('#020617') },
      uHorizonColor: { value: new THREE.Color('#0c2448') },
      uSunColor: { value: new THREE.Color('#38bdf8') },
      uSunDir: { value: new THREE.Vector3(0.45, 0.35, -0.6).normalize() },
      uStarIntensity: { value: 0.9 },
    },
    vertexShader: `
      varying vec3 vWorldDir;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldDir = normalize(position);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 uTopColor;
      uniform vec3 uHorizonColor;
      uniform vec3 uSunColor;
      uniform vec3 uSunDir;
      uniform float uStarIntensity;
      varying vec3 vWorldDir;

      float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
      }

      void main() {
        vec3 d = normalize(vWorldDir);
        float h = clamp(d.y * 1.15 + 0.08, 0.0, 1.0);
        vec3 col = mix(uHorizonColor, uTopColor, pow(h, 0.65));

        float sunAmt = max(dot(d, normalize(uSunDir)), 0.0);
        col += uSunColor * pow(sunAmt, 14.0) * 0.55;
        col += uSunColor * pow(sunAmt, 90.0) * 0.85;

        if (uStarIntensity > 0.01 && d.y > 0.08) {
          vec3 grid = floor(d * 180.0);
          float s = hash(grid);
          if (s > 0.9965) {
            col += vec3(0.85, 0.94, 1.0) * uStarIntensity * smoothstep(0.08, 0.35, d.y);
          }
        }
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const skyDome = new THREE.Mesh(new THREE.SphereGeometry(185, 32, 20), skyMat);
  root.add(skyDome);

  // Outer Stadium Concrete/Turf Apron extending to horizon
  const outerGround = new THREE.Mesh(
    new THREE.PlaneGeometry(260, 220),
    new THREE.MeshStandardMaterial({
      color: '#08121d',
      roughness: 0.92,
      metalness: 0.05,
    })
  );
  outerGround.rotation.x = -Math.PI / 2;
  outerGround.position.y = -0.025;
  outerGround.receiveShadow = true;
  root.add(outerGround);

  // Outer pitch apron
  const apronMat = new THREE.MeshStandardMaterial({
    color: '#114d29',
    roughness: 0.85,
    metalness: 0.02,
  });
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(110, 72), apronMat);
  apron.rotation.x = -Math.PI / 2;
  apron.position.y = -0.005;
  apron.receiveShadow = true;
  root.add(apron);

  // Main eFootball Realistic PBR Pitch (Grass texture + micro turf bump + clearcoat ready for rain!)
  const pitchMat = new THREE.MeshPhysicalMaterial({
    map: createPitchTexture(maxAnisotropy),
    bumpMap: createPitchBumpTexture(maxAnisotropy),
    bumpScale: 0.022,
    roughness: 0.82,
    metalness: 0.02,
    clearcoat: 0.0,
    clearcoatRoughness: 0.18,
  });
  const pitchMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(PITCH_HALF_LENGTH * 2 + 6, PITCH_HALF_WIDTH * 2 + 5),
    pitchMat
  );
  pitchMesh.rotation.x = -Math.PI / 2;
  pitchMesh.position.y = 0.004;
  pitchMesh.receiveShadow = true;
  root.add(pitchMesh);

  // Glowing Blue Lock Perimeter LED Boards with Stadium Text Texture
  const ledTex = createStadiumLedTexture(maxAnisotropy);
  const boardMat = new THREE.MeshStandardMaterial({
    map: ledTex,
    emissiveMap: ledTex,
    emissive: '#38bdf8',
    emissiveIntensity: 0.72,
    roughness: 0.25,
    metalness: 0.4,
  });
  const northBoard = new THREE.Mesh(new THREE.BoxGeometry(96, 1.35, 0.5), boardMat);
  northBoard.position.set(0, 0.67, -PITCH_HALF_WIDTH - 4.2);
  const southBoard = northBoard.clone();
  southBoard.position.z = PITCH_HALF_WIDTH + 4.2;
  root.add(northBoard, southBoard);
  const ledBoards = [northBoard, southBoard];

  // 4 Realistic Corner Flags
  const flagPoleMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.3, metalness: 0.5 });
  const cornerCoords: Array<[number, number, string]> = [
    [-PITCH_HALF_LENGTH, -PITCH_HALF_WIDTH, '#38bdf8'],
    [-PITCH_HALF_LENGTH, PITCH_HALF_WIDTH, '#38bdf8'],
    [PITCH_HALF_LENGTH, -PITCH_HALF_WIDTH, '#ef4444'],
    [PITCH_HALF_LENGTH, PITCH_HALF_WIDTH, '#ef4444'],
  ];
  cornerCoords.forEach(([cx, cz, hex]) => {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.45, 8), flagPoleMat);
    pole.position.set(cx, 0.72, cz);
    const flag = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.28, 0.02),
      new THREE.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: 0.25 })
    );
    flag.position.set(cx + (cx < 0 ? 0.22 : -0.22), 1.32, cz);
    root.add(pole, flag);
  });

  // Technical Dugouts / Team Benches
  const benchMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.45, metalness: 0.6 });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: '#bae6fd',
    transparent: true,
    opacity: 0.35,
    roughness: 0.1,
    clearcoat: 0.9,
  });
  [-12, 12].forEach((bx, idx) => {
    const dugout = new THREE.Group();
    dugout.position.set(bx, 0, -PITCH_HALF_WIDTH - 2.3);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.55, 0.9), benchMat);
    seat.position.y = 0.28;
    const roof = new THREE.Mesh(new THREE.BoxGeometry(7.8, 0.12, 1.8), glassMat);
    roof.position.set(0, 2.25, 0.2);
    const backGlass = new THREE.Mesh(new THREE.BoxGeometry(7.7, 2.2, 0.08), glassMat);
    backGlass.position.set(0, 1.1, -0.65);
    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(7.8, 0.14, 0.15),
      new THREE.MeshStandardMaterial({
        color: idx === 0 ? '#38bdf8' : '#ef4444',
        emissive: idx === 0 ? '#0284c7' : '#b91c1c',
        emissiveIntensity: 0.6,
      })
    );
    stripe.position.set(0, 2.32, 1.02);
    dugout.add(seat, roof, backGlass, stripe);
    root.add(dugout);
  });

  // Stepped Stadium Stands around all 4 sides
  const standMat = new THREE.MeshStandardMaterial({
    color: '#1e293b',
    roughness: 0.78,
    metalness: 0.15,
  });
  for (let tier = 0; tier < 4; tier++) {
    const h = 2.2;
    const y = 1.2 + tier * 2.1;
    const offset = 33 + tier * 3.4;

    const standN = new THREE.Mesh(new THREE.BoxGeometry(106 + tier * 6, h, 3.2), standMat);
    standN.position.set(0, y, -offset);
    standN.receiveShadow = true;
    const standS = standN.clone();
    standS.position.z = offset;
    root.add(standN, standS);

    const endOffset = 52 + tier * 3.4;
    const standW = new THREE.Mesh(new THREE.BoxGeometry(3.2, h, 64 + tier * 6), standMat);
    standW.position.set(-endOffset, y, 0);
    const standE = standW.clone();
    standE.position.x = endOffset;
    root.add(standW, standE);
  }

  // Stadium Roof Fascia Ring & Giant Jumbotron
  const roofRing = new THREE.Mesh(
    new THREE.BoxGeometry(118, 1.8, 4.5),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.4, metalness: 0.7 })
  );
  roofRing.position.set(0, 12.2, -45);
  const roofRingS = roofRing.clone();
  roofRingS.position.z = 45;
  root.add(roofRing, roofRingS);

  // Instanced Crowd Spectators
  const fanGeo = new THREE.BoxGeometry(0.65, 1.05, 0.55);
  const fanMat = new THREE.MeshStandardMaterial({ roughness: 0.65, metalness: 0.1 });
  const fanCount = 380;
  const crowdInstanced = new THREE.InstancedMesh(fanGeo, fanMat, fanCount);
  const dummy = new THREE.Object3D();
  const palette = [
    new THREE.Color('#38bdf8'),
    new THREE.Color('#f8fafc'),
    new THREE.Color('#ef4444'),
    new THREE.Color('#fbbf24'),
    new THREE.Color('#a855f7'),
    new THREE.Color('#334155'),
  ];
  for (let i = 0; i < fanCount; i++) {
    const side = i % 4;
    const tier = Math.floor(Math.random() * 4);
    const y = 2.85 + tier * 2.1;
    if (side === 0 || side === 1) {
      const z = (side === 0 ? -1 : 1) * (33 + tier * 3.4);
      dummy.position.set((Math.random() - 0.5) * 98, y, z);
    } else {
      const x = (side === 2 ? -1 : 1) * (52 + tier * 3.4);
      dummy.position.set(x, y, (Math.random() - 0.5) * 56);
    }
    const s = 0.85 + Math.random() * 0.3;
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    crowdInstanced.setMatrixAt(i, dummy.matrix);
    crowdInstanced.setColorAt(i, palette[i % palette.length]);
  }
  crowdInstanced.computeBoundingSphere();
  root.add(crowdInstanced);

  // 4 Floodlight Towers + Volumetric Light Cones
  const towerMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.4, metalness: 0.7 });
  const lampMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    emissive: '#e0f2fe',
    emissiveIntensity: 2.5,
  });
  const floodBeams: THREE.Mesh[] = [];
  const beamGeo = new THREE.ConeGeometry(16, 46, 20, 1, true);
  beamGeo.translate(0, -23, 0);
  beamGeo.rotateX(Math.PI / 2);

  const towerCoords = [
    [-56, -38],
    [56, -38],
    [-56, 38],
    [56, 38],
  ];
  towerCoords.forEach(([tx, tz]) => {
    const tower = new THREE.Group();
    tower.position.set(tx, 0, tz);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.85, 25, 10), towerMat);
    pole.position.y = 12.5;
    const head = new THREE.Mesh(new THREE.BoxGeometry(4.6, 2.3, 1.2), lampMat);
    head.position.y = 25;
    head.lookAt(-tx, 0, -tz);
    tower.add(pole, head);

    const beamMat = new THREE.MeshBasicMaterial({
      color: '#bae6fd',
      transparent: true,
      opacity: 0.045,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(tx, 24.5, tz);
    beam.lookAt(tx * 0.28, 0, tz * 0.25);
    root.add(tower, beam);
    floodBeams.push(beam);
  });

  // Build 2 Goals (-X Blue Goal, +X Red Goal)
  const buildGoal = (xPos: number, dir: 1 | -1, accentHex: string) => {
    const goalGroup = new THREE.Group();
    goalGroup.position.set(xPos, 0, 0);

    const postMat = new THREE.MeshPhysicalMaterial({
      color: '#f8fafc',
      roughness: 0.22,
      metalness: 0.78,
      clearcoat: 0.3,
    });
    const postGeo = new THREE.CylinderGeometry(0.14, 0.14, GOAL_HEIGHT, 12);
    const leftPost = new THREE.Mesh(postGeo, postMat);
    leftPost.position.set(0, GOAL_HEIGHT / 2, -GOAL_HALF_WIDTH);
    leftPost.castShadow = true;

    const rightPost = new THREE.Mesh(postGeo, postMat);
    rightPost.position.set(0, GOAL_HEIGHT / 2, GOAL_HALF_WIDTH);
    rightPost.castShadow = true;

    const crossbar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.14, GOAL_HALF_WIDTH * 2 + 0.28, 12),
      postMat
    );
    crossbar.rotation.x = Math.PI / 2;
    crossbar.position.set(0, GOAL_HEIGHT, 0);
    crossbar.castShadow = true;

    const backBarMat = new THREE.MeshStandardMaterial({ color: accentHex, roughness: 0.35, metalness: 0.6 });
    const backTop = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, GOAL_HALF_WIDTH * 2), backBarMat);
    backTop.position.set(dir * GOAL_DEPTH, GOAL_HEIGHT, 0);
    const backSideL = new THREE.Mesh(new THREE.BoxGeometry(GOAL_DEPTH, 0.12, 0.12), backBarMat);
    backSideL.position.set((dir * GOAL_DEPTH) / 2, GOAL_HEIGHT, -GOAL_HALF_WIDTH);
    const backSideR = backSideL.clone();
    backSideR.position.z = GOAL_HALF_WIDTH;

    const netGeo = new THREE.BoxGeometry(GOAL_DEPTH, GOAL_HEIGHT, GOAL_HALF_WIDTH * 2, 4, 4, 8);
    const netMat = new THREE.MeshBasicMaterial({
      color: '#e2e8f0',
      wireframe: true,
      transparent: true,
      opacity: 0.48,
    });
    const netMesh = new THREE.Mesh(netGeo, netMat);
    netMesh.position.set((dir * GOAL_DEPTH) / 2, GOAL_HEIGHT / 2, 0);

    goalGroup.add(leftPost, rightPost, crossbar, backTop, backSideL, backSideR, netMesh);
    root.add(goalGroup);
    return netMesh;
  };

  const blueNet = buildGoal(-PITCH_HALF_LENGTH, -1, '#38bdf8');
  const redNet = buildGoal(PITCH_HALF_LENGTH, 1, '#ef4444');

  // Dynamic 3D Rain Particle System (toggled cleanly by WeatherMode === 'RAIN')
  const rainCount = 950;
  const rainPositions = new Float32Array(rainCount * 3);
  const rainVelocities = new Float32Array(rainCount);
  for (let i = 0; i < rainCount; i++) {
    rainPositions[i * 3] = (Math.random() - 0.5) * 100;
    rainPositions[i * 3 + 1] = Math.random() * 26;
    rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 64;
    rainVelocities[i] = 22 + Math.random() * 10;
  }
  const rainGeo = new THREE.BufferGeometry();
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
  const rainMat = new THREE.PointsMaterial({
    color: '#bae6fd',
    size: 0.22,
    transparent: true,
    opacity: 0.58,
    depthWrite: false,
  });
  const rainPoints = new THREE.Points(rainGeo, rainMat);
  rainPoints.visible = false;
  root.add(rainPoints);

  return {
    root,
    blueNet,
    redNet,
    crowdInstanced,
    pitchMat,
    apronMat,
    skyMat,
    floodBeams,
    ledBoards,
    rainPoints,
    rainVelocities,
  };
}

export function buildCutsceneProps(maxAnisotropy: number): CutscenePropPack {
  const root = new THREE.Group();
  root.visible = false;

  const screenTextures = {
    bluelock_game: createScreenTexture('bluelock_game', maxAnisotropy),
    aras_lose: createScreenTexture('aras_lose', maxAnisotropy),
    ai_cheat: createScreenTexture('ai_cheat', maxAnisotropy),
    phone_musab: createScreenTexture('phone_musab', maxAnisotropy),
    videocall_musa: createScreenTexture('videocall_musa', maxAnisotropy),
  };

  const bed = new THREE.Group();
  const bedFrame = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 0.45, 2.0),
    new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.65 })
  );
  bedFrame.position.y = 0.22;
  const mattress = new THREE.Mesh(
    new THREE.BoxGeometry(3.0, 0.35, 1.85),
    new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.85 })
  );
  mattress.position.y = 0.58;
  const blanket = new THREE.Mesh(
    new THREE.BoxGeometry(2.1, 0.38, 1.88),
    new THREE.MeshStandardMaterial({ color: '#1d4ed8', roughness: 0.8 })
  );
  blanket.position.set(-0.42, 0.6, 0);
  const bedPillow = new THREE.Mesh(
    new THREE.BoxGeometry(0.65, 0.24, 1.2),
    new THREE.MeshStandardMaterial({ color: '#e2e8f0', roughness: 0.9 })
  );
  bedPillow.position.set(1.05, 0.82, 0);
  bed.add(bedFrame, mattress, blanket, bedPillow);
  bed.visible = false;
  root.add(bed);

  const desk = new THREE.Group();
  const deskTop = new THREE.Mesh(
    new THREE.BoxGeometry(1.6, 0.12, 2.8),
    new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.35, metalness: 0.4 })
  );
  deskTop.position.y = 1.05;
  const deskLegL = new THREE.Mesh(
    new THREE.BoxGeometry(1.3, 1.05, 0.14),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.4, metalness: 0.6 })
  );
  deskLegL.position.set(0, 0.52, -1.22);
  const deskLegR = deskLegL.clone();
  deskLegR.position.z = 1.22;

  const monitorFrame = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 1.45, 2.3),
    new THREE.MeshStandardMaterial({ color: '#090d16', roughness: 0.25, metalness: 0.7 })
  );
  monitorFrame.position.set(0.35, 2.05, 0);
  const monitorStand = new THREE.Mesh(
    new THREE.BoxGeometry(0.14, 0.4, 0.24),
    new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.8, roughness: 0.2 })
  );
  monitorStand.position.set(0.38, 1.26, 0);
  const monitorScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(2.15, 1.3),
    new THREE.MeshBasicMaterial({ map: screenTextures.bluelock_game })
  );
  monitorScreen.rotation.y = -Math.PI / 2;
  monitorScreen.position.set(0.26, 2.05, 0);

  const deskHeadset = new THREE.Group();
  const dhBand = new THREE.Mesh(
    new THREE.TorusGeometry(0.26, 0.04, 8, 16, Math.PI),
    new THREE.MeshStandardMaterial({ color: '#a855f7', metalness: 0.7, roughness: 0.25 })
  );
  dhBand.position.y = 0.16;
  const dhCupL = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 0.08, 12),
    new THREE.MeshStandardMaterial({ color: '#111827' })
  );
  dhCupL.rotation.z = Math.PI / 2;
  dhCupL.position.set(-0.24, 0.14, 0);
  const dhCupR = dhCupL.clone();
  dhCupR.position.x = 0.24;
  deskHeadset.add(dhBand, dhCupL, dhCupR);
  deskHeadset.position.set(-0.2, 1.12, 0.78);
  deskHeadset.visible = false;

  desk.add(deskTop, deskLegL, deskLegR, monitorFrame, monitorStand, monitorScreen, deskHeadset);
  desk.visible = false;
  root.add(desk);

  const phone = new THREE.Group();
  const phoneBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.56, 0.3),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.2, metalness: 0.85 })
  );
  const phoneScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.26, 0.48),
    new THREE.MeshBasicMaterial({ map: screenTextures.phone_musab })
  );
  phoneScreen.rotation.y = -Math.PI / 2;
  phoneScreen.position.x = -0.045;
  phone.add(phoneBody, phoneScreen);
  phone.visible = false;
  root.add(phone);

  const pillow = new THREE.Group();
  const pillowMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.95, 0.28, 0.72),
    new THREE.MeshStandardMaterial({ color: '#e0f2fe', roughness: 0.85 })
  );
  const pillowTrim = new THREE.Mesh(
    new THREE.BoxGeometry(0.98, 0.08, 0.75),
    new THREE.MeshStandardMaterial({ color: '#38bdf8', emissive: '#0284c7', emissiveIntensity: 0.5 })
  );
  pillow.add(pillowMesh, pillowTrim);
  pillow.visible = false;
  root.add(pillow);

  const sock = new THREE.Group();
  const sockAnkle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.16, 0.15, 0.48, 12),
    new THREE.MeshStandardMaterial({ color: '#34d399', roughness: 0.65 })
  );
  sockAnkle.position.y = 0.24;
  const sockFoot = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.22, 0.28),
    new THREE.MeshStandardMaterial({ color: '#059669', roughness: 0.65 })
  );
  sockFoot.position.set(0.12, 0.08, 0);
  const sockStripe = new THREE.Mesh(
    new THREE.CylinderGeometry(0.17, 0.17, 0.1, 12),
    new THREE.MeshStandardMaterial({ color: '#fde047', emissive: '#eab308', emissiveIntensity: 0.6 })
  );
  sockStripe.position.y = 0.38;
  sock.add(sockAnkle, sockFoot, sockStripe);
  sock.visible = false;
  root.add(sock);

  const coach = new THREE.Group();
  const coachBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.85, 1.1, 0.5),
    new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.6 })
  );
  coachBody.position.y = 1.3;
  const coachLegs = new THREE.Mesh(
    new THREE.BoxGeometry(0.75, 0.75, 0.42),
    new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.7 })
  );
  coachLegs.position.y = 0.38;
  const coachHead = new THREE.Mesh(
    new THREE.BoxGeometry(0.58, 0.58, 0.58),
    new THREE.MeshStandardMaterial({ color: '#eab896', roughness: 0.65 })
  );
  coachHead.position.y = 2.15;
  const coachCap = new THREE.Mesh(
    new THREE.BoxGeometry(0.64, 0.18, 0.74),
    new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.4 })
  );
  coachCap.position.set(0.06, 2.46, 0);
  coach.add(coachBody, coachLegs, coachHead, coachCap);
  coach.visible = false;
  root.add(coach);

  const hamburger = new THREE.Group();
  const bunMat = new THREE.MeshStandardMaterial({ color: '#d97706', roughness: 0.65 });
  const bottomBun = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.34, 0.14, 16), bunMat);
  bottomBun.position.y = 0.07;
  const patty = new THREE.Mesh(
    new THREE.CylinderGeometry(0.38, 0.38, 0.14, 16),
    new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.85 })
  );
  patty.position.y = 0.2;
  const cheese = new THREE.Mesh(
    new THREE.BoxGeometry(0.64, 0.05, 0.64),
    new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.4 })
  );
  cheese.position.y = 0.28;
  const lettuce = new THREE.Mesh(
    new THREE.CylinderGeometry(0.41, 0.41, 0.06, 12),
    new THREE.MeshStandardMaterial({ color: '#22c55e', roughness: 0.55 })
  );
  lettuce.position.y = 0.33;
  const topBun = new THREE.Mesh(
    new THREE.SphereGeometry(0.36, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2),
    bunMat
  );
  topBun.position.y = 0.36;
  hamburger.add(bottomBun, patty, cheese, lettuce, topBun);
  hamburger.visible = false;
  root.add(hamburger);

  const monsterBall = new THREE.Group();
  const mCore = new THREE.Mesh(
    new THREE.SphereGeometry(0.55, 24, 24),
    new THREE.MeshStandardMaterial({
      color: '#a855f7',
      emissive: '#7e22ce',
      emissiveIntensity: 1.5,
      roughness: 0.2,
    })
  );
  const mRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.82, 0.08, 10, 28),
    new THREE.MeshBasicMaterial({ color: '#fbbf24' })
  );
  monsterBall.add(mCore, mRing);
  monsterBall.visible = false;
  root.add(monsterBall);

  const snapRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.0, 0.09, 10, 36),
    new THREE.MeshBasicMaterial({
      color: '#facc15',
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
    })
  );
  snapRing.rotation.x = Math.PI / 2;
  snapRing.visible = false;
  root.add(snapRing);

  return {
    root,
    bed,
    desk,
    monitorScreen,
    screenTextures,
    phone,
    phoneScreen,
    pillow,
    sock,
    coach,
    hamburger,
    monsterBall,
    snapRing,
    deskHeadset,
  };
}
