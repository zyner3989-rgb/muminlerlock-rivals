export type StyleId =
  | 'musab'
  | 'musa'
  | 'iskender'
  | 'aras'
  | 'ebulfez'
  | 'zero'
  | 'berk';

export type Rarity = 'MASTER' | 'WORLD CLASS' | 'MYTHIC' | 'RARE';

export type FlowId = 'egoist' | 'godspeed' | 'prodigy' | 'wildcard' | 'dribbler';

export type UltiRange = 'FULL_PITCH' | 'MIDFIELD';

export type GkDifficulty = 'EASY' | 'MEDIUM' | 'HARD';

export type MatchMode = '1V1' | '3V3';

export type GameScreen = 'TITLE' | 'PLAYING';

export type MatchPhase =
  | 'IDLE'
  | 'KICKOFF'
  | 'LIVE'
  | 'CUTSCENE'
  | 'GOAL_CELEBRATION'
  | 'PAUSED'
  | 'ENDED';

export type OutfitId =
  | 'signature'
  | 'neoblack'
  | 'royalwhite'
  | 'cyberjacket'
  | 'hoodie'
  | 'crimson';

export type HairStyleId =
  | 'character'
  | 'wolfcut'
  | 'spiky'
  | 'curtain'
  | 'curly'
  | 'windswept'
  | 'ponytail'
  | 'frostcrown';

export type CleatId =
  | 'character'
  | 'gold_pro'
  | 'cyber_cyan'
  | 'crimson_speed'
  | 'phantom_black';

export type BackAccessoryId = 'none' | 'scarf' | 'cape' | 'katana' | 'wings';

export interface WardrobeConfig {
  outfitId: OutfitId;
  hairStyleId: HairStyleId;
  hairColor: string; // 'character' or hex color
  cleatId: CleatId;
  backAccessoryId: BackAccessoryId;
}

export type GraphicsQuality = 'LOW' | 'MEDIUM' | 'HIGH' | 'ULTRA';

export type WeatherMode = 'NIGHT' | 'SUNSET' | 'RAIN';

export interface GameSettings {
  quality: GraphicsQuality;
  bloom: boolean;
  shadows: boolean;
  particles: boolean;
  weather: WeatherMode;
  fov: number;
  cameraDistance: number;
  mouseSensitivity: number;
  masterVolume: number; // 0..100
  showFps: boolean;
}

export interface MatchStats {
  goals: number;
  shots: number;
  passes: number;
  dribbles: number;
  steals: number;
}

export interface SkillMeta {
  key: string;
  name: string;
  description: string;
  cooldown: number;
}

export interface StyleDefinition {
  id: StyleId;
  name: string;
  jerseyNumber: number;
  rarity: Rarity;
  title: string;
  primaryColor: string;
  secondaryColor: string;
  auraColor: string;
  hairColor: string;
  skinColor: string;
  accessory:
    | 'headset'
    | 'spiky'
    | 'shades'
    | 'headband'
    | 'gauntlet'
    | 'visor'
    | 'relaxed';
  stats: {
    speed: number;
    shotPower: number;
    dribble: number;
    steal: number;
  };
  skill1: SkillMeta;
  skill2: SkillMeta;
  personalSkill: SkillMeta; // [E / 3] Kişiye Özel Yetenek
  awakeningName: string;
  awakeningSummary: string;
  awakeningQuote: string;
  ultiName: string;
  ultiSummary: string;
  ultiRange: UltiRange;
  ultiRangeLabel: string;
}

export interface FlowDefinition {
  id: FlowId;
  name: string;
  rarity: Rarity;
  color: string;
  bonusText: string;
  speedMult: number;
  shotMult: number;
  staminaRegenMult: number;
}

export interface HudSnapshot {
  phase: MatchPhase;
  blueScore: number;
  redScore: number;
  timeRemaining: number;
  stamina: number;
  awakening: number;
  isAwakened: boolean;
  awakeningTimeLeft: number;
  ultiUsedInAwakening: boolean;
  shotCharge: number;
  hasBall: boolean;
  skill1Cd: number;
  skill1MaxCd: number;
  skill2Cd: number;
  skill2MaxCd: number;
  personalCd: number;
  personalMaxCd: number;
  dribbleCd: number;
  slideCd: number;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  isTraining: boolean;
  shiftLock: boolean;
  isOnline: boolean;
  roomCode: string | null;
  fps: number;
  stats: MatchStats;
  cutsceneBanner: {
    active: boolean;
    speaker: string;
    subtitle: string;
    badge: string;
    accentColor: string;
  } | null;
  goalBanner: {
    scorerName: string;
    team: 'BLUE' | 'RED';
    isUltiGoal: boolean;
  } | null;
  lastActionToast: string | null;
}

// ==================== ONLINE MULTIPLAYER PROTOCOL ====================

export interface RoomPlayerInfo {
  clientId: string;
  name: string;
  team: 'BLUE' | 'RED';
  styleId: StyleId;
  flowId: FlowId;
  isHost: boolean;
  ready: boolean;
}

export interface RoomLobbyState {
  roomCode: string;
  hostId: string;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  status: 'LOBBY' | 'PLAYING';
  players: RoomPlayerInfo[];
}

export interface NetActorState {
  id: string;
  clientId?: string;
  name: string;
  team: 'BLUE' | 'RED';
  styleId: StyleId;
  isGoalkeeper: boolean;
  x: number;
  z: number;
  vx: number;
  vz: number;
  yaw: number;
  stun: number;
  slide: number;
  dribble: number;
  awakened: boolean;
}

export interface NetWorldSnapshot {
  phase: MatchPhase;
  blueScore: number;
  redScore: number;
  timeRemaining: number;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  ball: {
    x: number;
    y: number;
    z: number;
    vx: number;
    vy: number;
    vz: number;
    ownerId: string | null;
    isUlti: boolean;
  };
  actors: NetActorState[];
  selfHud?: {
    stamina: number;
    awakening: number;
    isAwakened: boolean;
    awakeningTimeLeft: number;
    ultiUsedInAwakening: boolean;
    shotCharge: number;
    skill1Cd: number;
    skill2Cd: number;
    personalCd: number;
    dribbleCd: number;
    slideCd: number;
  };
  goalBanner: HudSnapshot['goalBanner'];
  toast: string | null;
}

export interface NetCutsceneEvent {
  actorId: string;
  styleId: StyleId;
  kind: 'AWAKENING' | 'ULTI';
  anchorX: number;
  anchorZ: number;
  oppX: number;
  oppZ: number;
}
