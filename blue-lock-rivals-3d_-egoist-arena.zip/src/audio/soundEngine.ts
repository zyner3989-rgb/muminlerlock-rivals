import type { StyleId } from '../types/game';

const STYLE_IDS: StyleId[] = ['musab', 'musa', 'iskender', 'aras', 'ebulfez', 'zero', 'berk'];

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private busOut: AudioNode | null = null;
  private muted = false;
  private masterVolume = 0.9;

  private voiceBufferCache = new Map<string, AudioBuffer>();
  private voiceFetchPromises = new Map<string, Promise<AudioBuffer | null>>();
  private activeVoiceSource: AudioBufferSourceNode | null = null;
  private activeHtmlAudio: HTMLAudioElement | null = null;
  private rainSource: AudioBufferSourceNode | null = null;
  private rainGain: GainNode | null = null;
  private preloaded = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const unlockOnce = () => {
        this.unlock();
      };
      window.addEventListener('pointerdown', unlockOnce, { passive: true });
      window.addEventListener('keydown', unlockOnce, { passive: true });
    }
  }

  public unlock() {
    if (this.muted || typeof window === 'undefined') return;
    const ctx = this.ensureContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    if (!this.preloaded) {
      this.preloaded = true;
      this.preloadCutsceneVoices();
    }
  }

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const compressor = ctx.createDynamicsCompressor();
        compressor.threshold.setValueAtTime(-12, ctx.currentTime);
        compressor.knee.setValueAtTime(14, ctx.currentTime);
        compressor.ratio.setValueAtTime(5, ctx.currentTime);
        compressor.attack.setValueAtTime(0.004, ctx.currentTime);
        compressor.release.setValueAtTime(0.18, ctx.currentTime);

        const master = ctx.createGain();
        master.gain.setValueAtTime(this.muted ? 0.0001 : 1.35 * this.masterVolume, ctx.currentTime);
        master.connect(compressor);
        compressor.connect(ctx.destination);

        this.ctx = ctx;
        this.masterGain = master;
        this.busOut = master;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getOutputNode(ctx: AudioContext): AudioNode {
    return this.busOut ?? ctx.destination;
  }

  private getNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const len = ctx.sampleRate * 1.5;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buf;
  }

  private clipKey(styleId: StyleId, kind: 'AWAKENING' | 'ULTI'): string {
    return `${styleId}_${kind === 'AWAKENING' ? 'awakening' : 'ulti'}`;
  }

  private clipUrl(key: string): string {
    return `/audio/cutscenes/${key}.mp3`;
  }

  private loadVoiceBuffer(key: string): Promise<AudioBuffer | null> {
    const cached = this.voiceBufferCache.get(key);
    if (cached) return Promise.resolve(cached);
    const existing = this.voiceFetchPromises.get(key);
    if (existing) return existing;

    const ctx = this.ensureContext();
    if (!ctx) return Promise.resolve(null);

    const p = fetch(this.clipUrl(key))
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.arrayBuffer();
      })
      .then((arr) => ctx.decodeAudioData(arr))
      .then((decoded) => {
        this.voiceBufferCache.set(key, decoded);
        return decoded;
      })
      .catch(() => null);

    this.voiceFetchPromises.set(key, p);
    return p;
  }

  public preloadCutsceneVoices() {
    if (typeof window === 'undefined' || this.muted) return;
    for (const styleId of STYLE_IDS) {
      void this.loadVoiceBuffer(this.clipKey(styleId, 'AWAKENING'));
      void this.loadVoiceBuffer(this.clipKey(styleId, 'ULTI'));
    }
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (muted) {
      this.stopCutsceneAudio();
      this.setRainAmbiance(false);
      if (this.masterGain && this.ctx) {
        this.masterGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);
      }
    } else if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(1.35 * this.masterVolume, this.ctx.currentTime);
    }
  }

  public setMasterVolume(percent: number) {
    this.masterVolume = Math.max(0, Math.min(1, percent / 100));
    if (!this.muted && this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(1.35 * this.masterVolume, this.ctx.currentTime);
    }
    if (this.activeHtmlAudio) {
      this.activeHtmlAudio.volume = this.masterVolume;
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public stopCutsceneAudio() {
    if (this.activeVoiceSource) {
      try {
        this.activeVoiceSource.stop();
      } catch {
        // ignore
      }
      this.activeVoiceSource = null;
    }
    if (this.activeHtmlAudio) {
      try {
        this.activeHtmlAudio.pause();
        this.activeHtmlAudio.currentTime = 0;
      } catch {
        // ignore
      }
      this.activeHtmlAudio = null;
    }
  }

  public stopSpeech() {
    this.stopCutsceneAudio();
  }

  /**
   * Plays the pre-mastered original Japanese Anime Male Seiyuu voice clip
   * with instant HTMLAudio fallback if decoded buffer is still loading.
   */
  public playCutsceneVoice(styleId: StyleId, kind: 'AWAKENING' | 'ULTI', delaySec = 0.08) {
    if (this.muted || typeof window === 'undefined') return;
    this.stopCutsceneAudio();

    const key = this.clipKey(styleId, kind);
    const ctx = this.ensureContext();
    const cached = this.voiceBufferCache.get(key);

    if (ctx && cached) {
      const src = ctx.createBufferSource();
      src.buffer = cached;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(1.2, ctx.currentTime);
      src.connect(gain);
      gain.connect(this.getOutputNode(ctx));
      src.start(ctx.currentTime + Math.max(0, delaySec));
      src.onended = () => {
        if (this.activeVoiceSource === src) {
          this.activeVoiceSource = null;
        }
      };
      this.activeVoiceSource = src;
      return;
    }

    try {
      const audio = new Audio(this.clipUrl(key));
      audio.volume = this.masterVolume;
      this.activeHtmlAudio = audio;
      audio.play().catch(() => {});
    } catch {
      // ignore
    }
    void this.loadVoiceBuffer(key);
  }

  /**
   * Cinematic Blue Lock sub-bass boom + heartbeat + aura sweep paired with the real anime male voice!
   */
  public playAnimeAwakeningIntro(styleId: StyleId, kind: 'AWAKENING' | 'ULTI') {
    this.unlock();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    // 1. Deep Heartbeat Double-Thump (0.00s & 0.16s)
    [0, 0.16].forEach((offset, idx) => {
      const hb = ctx.createOscillator();
      const hg = ctx.createGain();
      hb.type = 'sine';
      hb.frequency.setValueAtTime(idx === 0 ? 88 : 108, now + offset);
      hb.frequency.exponentialRampToValueAtTime(30, now + offset + 0.14);
      hg.gain.setValueAtTime(idx === 0 ? 0.55 : 0.65, now + offset);
      hg.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.16);
      hb.connect(hg);
      hg.connect(out);
      hb.start(now + offset);
      hb.stop(now + offset + 0.17);
    });

    // 2. Crisp Aura Wind Whoosh underneath voice (kept clean so voice stays crystal clear!)
    const noise = ctx.createBufferSource();
    noise.buffer = this.getNoiseBuffer(ctx);
    const sweep = ctx.createBiquadFilter();
    sweep.type = 'bandpass';
    sweep.Q.setValueAtTime(2.0, now);
    sweep.frequency.setValueAtTime(220, now);
    sweep.frequency.exponentialRampToValueAtTime(2600, now + 0.55);
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.01, now);
    ng.gain.linearRampToValueAtTime(0.22, now + 0.28);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.72);
    noise.connect(sweep);
    sweep.connect(ng);
    ng.connect(out);
    noise.start(now);
    noise.stop(now + 0.75);

    // 3. Play real cocky anime male seiyuu voice clip!
    this.playCutsceneVoice(styleId, kind, 0.12);

    // 4. Cinematic Bass Drop at 0.42s
    const drop = ctx.createOscillator();
    const dropGain = ctx.createGain();
    drop.type = 'sine';
    drop.frequency.setValueAtTime(kind === 'ULTI' ? 145 : 125, now + 0.4);
    drop.frequency.exponentialRampToValueAtTime(26, now + 1.25);
    dropGain.gain.setValueAtTime(0.001, now + 0.39);
    dropGain.gain.linearRampToValueAtTime(0.55, now + 0.43);
    dropGain.gain.exponentialRampToValueAtTime(0.001, now + 1.28);
    drop.connect(dropGain);
    dropGain.connect(out);
    drop.start(now + 0.39);
    drop.stop(now + 1.3);
  }

  public playKick(power = 0.6) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    const startFreq = 140 + power * 90;
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.14);

    gain.gain.setValueAtTime(0.32 + power * 0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playWhistle() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(2850, now);

    lfo.frequency.setValueAtTime(42, now);
    lfoGain.gain.setValueAtTime(140, now);
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.03);
    gain.gain.setValueAtTime(0.18, now + 0.28);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    lfo.start(now);
    osc.stop(now + 0.44);
    lfo.stop(now + 0.44);
  }

  public playSkill(pitch = 420) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(pitch, now);
    osc.frequency.exponentialRampToValueAtTime(pitch * 2.1, now + 0.18);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.23);
  }

  public playAwakeningBoom() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(150, now);
    sub.frequency.exponentialRampToValueAtTime(28, now + 0.8);
    subGain.gain.setValueAtTime(0.55, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    sub.connect(subGain);
    subGain.connect(out);
    sub.start(now);
    sub.stop(now + 0.88);
  }

  public playSnap() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.1);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.012));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2450, now);
    filter.Q.setValueAtTime(2.2, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.85, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    noise.start(now);
  }

  public playThanosSnap() {
    this.playSnap();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(120, now + 0.02);
    sub.frequency.exponentialRampToValueAtTime(26, now + 0.95);
    subGain.gain.setValueAtTime(0.65, now + 0.02);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.98);
    sub.connect(subGain);
    subGain.connect(out);
    sub.start(now + 0.02);
    sub.stop(now + 1.0);
  }

  public playPhoneRing() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [0, 0.26].forEach((offset) => {
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc2.type = 'sine';
      osc.frequency.setValueAtTime(1180, now + offset);
      osc2.frequency.setValueAtTime(1480, now + offset);
      gain.gain.setValueAtTime(0.16, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.19);
      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(out);
      osc.start(now + offset);
      osc2.start(now + offset);
      osc.stop(now + offset + 0.2);
      osc2.stop(now + offset + 0.2);
    });
  }

  public playPhonePickup() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(860, now);
    osc.frequency.setValueAtTime(1320, now + 0.05);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playCensorBeep() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, now);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.setValueAtTime(0.24, now + 0.42);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.52);
  }

  public playSnore() {
    // Kept subtle so it never clashes with the real voice clip
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(92, now);
    osc.frequency.linearRampToValueAtTime(72, now + 0.35);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.44);
  }

  public playHorrorMonitorBurst() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const bufSize = Math.floor(ctx.sampleRate * 0.25);
    const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < bufSize; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.06));
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(2000, now);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.45, now);
    src.connect(hp);
    hp.connect(g);
    g.connect(out);
    src.start(now);
  }

  public playDeskThud() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.14);
    gain.gain.setValueAtTime(0.48, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playPillowTransform() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(860, now + 0.32);
    gain.gain.setValueAtTime(0.32, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  public playTeleportWhoosh() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(1450, now + 0.16);
    osc.frequency.exponentialRampToValueAtTime(170, now + 0.38);
    gain.gain.setValueAtTime(0.38, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.44);
  }

  public playBurgerSplat() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.16);
    gain.gain.setValueAtTime(0.34, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.19);
  }

  public playAiHackComplete() {
    this.playGlitchBeep();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [660, 880, 1100, 1320].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + 0.16 + i * 0.055);
      gain.gain.setValueAtTime(0.16, now + 0.16 + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16 + i * 0.055 + 0.15);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + 0.16 + i * 0.055);
      osc.stop(now + 0.16 + i * 0.055 + 0.17);
    });
  }

  public playGlitchBeep() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const freqs = [520, 880, 1240, 1760];
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(f, now + i * 0.045);
      gain.gain.setValueAtTime(0.1, now + i * 0.045);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.04);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.045);
      osc.stop(now + i * 0.045 + 0.045);
    });
  }

  public playGoalHorn() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const freqs = [196, 246.94, 293.66, 392];
    freqs.forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.06);
      gain.gain.setValueAtTime(0.12, now + 0.55);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.05);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now);
      osc.stop(now + 1.1);
    });
  }

  public playSpinTick(isFinal = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = isFinal ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(isFinal ? 880 : 620, now);
    if (isFinal) {
      osc.frequency.exponentialRampToValueAtTime(1320, now + 0.25);
    }
    gain.gain.setValueAtTime(isFinal ? 0.26 : 0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isFinal ? 0.35 : 0.04));
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + (isFinal ? 0.36 : 0.05));
  }

  public playPostClang() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [420, 685, 1120].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.22 / (i + 1), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now);
      osc.stop(now + 0.46);
    });
  }

  public playSlide() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.24);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(950, now);
    filter.frequency.exponentialRampToValueAtTime(280, now + 0.24);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    noise.start(now);
  }

  public playCrowdCheer() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    // Swelling stadium crowd roar
    const buf = this.getNoiseBuffer(ctx);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(650, now);
    bp.frequency.linearRampToValueAtTime(1250, now + 0.45);
    bp.frequency.exponentialRampToValueAtTime(480, now + 2.3);
    bp.Q.setValueAtTime(0.85, now);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.42, now + 0.25);
    g.gain.setValueAtTime(0.38, now + 1.1);
    g.gain.exponentialRampToValueAtTime(0.001, now + 2.4);

    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start(now);
    src.stop(now + 2.45);
  }

  public setRainAmbiance(active: boolean) {
    if (!active || this.muted) {
      if (this.rainSource) {
        try {
          this.rainSource.stop();
        } catch {
          // ignore
        }
        this.rainSource = null;
        this.rainGain = null;
      }
      return;
    }
    if (this.rainSource) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const src = ctx.createBufferSource();
    src.buffer = this.getNoiseBuffer(ctx);
    src.loop = true;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1800, ctx.currentTime);
    bp.Q.setValueAtTime(0.65, ctx.currentTime);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.055, ctx.currentTime);
    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start();
    this.rainSource = src;
    this.rainGain = g;
  }

  public playEmoteChime() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.055);
      gain.gain.setValueAtTime(0.16, now + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.22);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.055);
      osc.stop(now + i * 0.055 + 0.24);
    });
  }

  public playAwakenedImpact() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.26);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.3);
  }
}

export const soundEngine = new SoundEngine();
