import { useState } from 'react';
import { Award, CheckCircle2, Gift, History, KeyRound, Trophy, X } from 'lucide-react';
import {
  DAILY_QUESTS,
  getRankProgress,
  PROMO_CODES,
} from '../data/ranked';
import { STYLES } from '../data/styles';
import type { DailyQuestProgress, RankedProfile } from '../types/game';

interface QuestsModalProps {
  profile: RankedProfile;
  questProgress: DailyQuestProgress;
  onClaimQuest: (questId: string) => void;
  onRedeemCode: (code: string) => { ok: boolean; message: string };
  onClose: () => void;
}

export function QuestsModal({
  profile,
  questProgress,
  onClaimQuest,
  onRedeemCode,
  onClose,
}: QuestsModalProps) {
  const [tab, setTab] = useState<'QUESTS' | 'RANKED'>('QUESTS');
  const [codeInput, setCodeInput] = useState('');
  const [codeFeedback, setCodeFeedback] = useState<{ ok: boolean; msg: string } | null>(null);

  const progress = getRankProgress(profile.rp);

  const handleRedeem = () => {
    const trimmed = codeInput.trim().toUpperCase();
    if (!trimmed) return;
    const res = onRedeemCode(trimmed);
    setCodeFeedback({ ok: res.ok, msg: res.message });
    if (res.ok) setCodeInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="w-full max-w-3xl max-h-[90vh] bg-[#090f1e] border border-amber-400/45 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#050811]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-400/15 border border-amber-400/40 text-amber-300">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">GÖREVLER, KODLAR & DERECE KARNESİ</h2>
              <p className="text-xs text-slate-400">
                Günlük görevlerden Yen & Şanslı Spin kazan, promosyon kodlarını kullan!
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Kapat"
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subtabs */}
        <div className="flex gap-2 px-6 pt-4">
          <button
            type="button"
            onClick={() => setTab('QUESTS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black border cursor-pointer ${
              tab === 'QUESTS'
                ? 'bg-amber-400 border-amber-200 text-slate-950'
                : 'bg-[#060b16] border-slate-800 text-slate-300 hover:bg-slate-900'
            }`}
          >
            <Gift className="w-4 h-4" /> GÖREVLER & KODLAR
          </button>
          <button
            type="button"
            onClick={() => setTab('RANKED')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black border cursor-pointer ${
              tab === 'RANKED'
                ? 'bg-sky-500 border-sky-300 text-slate-950'
                : 'bg-[#060b16] border-slate-800 text-slate-300 hover:bg-slate-900'
            }`}
          >
            <Trophy className="w-4 h-4" /> DERECE & MAÇ GEÇMİŞİ
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-6 space-y-5">
          {tab === 'QUESTS' ? (
            <>
              {/* Daily Quests */}
              <div className="space-y-3">
                <div className="text-xs font-black tracking-wider text-amber-300 uppercase">
                  GÜNLÜK EGOİST GÖREVLERİ
                </div>
                {DAILY_QUESTS.map((q) => {
                  const val = questProgress[q.field];
                  const pct = Math.min(100, Math.round((val / q.target) * 100));
                  const completed = val >= q.target;
                  const claimed = questProgress.claimedIds.includes(q.id);
                  return (
                    <div
                      key={q.id}
                      className="bg-[#060b16] border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4"
                    >
                      <div className="flex-1 min-w-[220px] space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-white">{q.title}</span>
                          <span className="text-[11px] font-bold text-amber-300">
                            +{q.rewardYen} Yen · +{q.rewardSpins} Spin
                            {q.rewardLucky > 0 ? ` · +${q.rewardLucky} Şanslı` : ''}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400">{q.desc}</div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-slate-800 rounded overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-sky-400 to-amber-400"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="text-xs font-black text-slate-300 tabular-nums">
                            {Math.min(val, q.target)}/{q.target}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={!completed || claimed}
                        onClick={() => onClaimQuest(q.id)}
                        className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer disabled:cursor-default ${
                          claimed
                            ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
                            : completed
                              ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 animate-pulse'
                              : 'bg-slate-800 text-slate-500 opacity-60'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        {claimed ? 'ALINDI' : completed ? 'ÖDÜLÜ AL' : 'DEVAM ET'}
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Promo Codes */}
              <div className="bg-[#060b16] border border-sky-500/35 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-xs font-black tracking-wider text-sky-300 uppercase">
                  <KeyRound className="w-4 h-4" /> PROMOSYON KODU KULLAN
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === 'Enter' && handleRedeem()}
                    placeholder="KOD GİR (ÖRN: BLUELOCK)"
                    className="flex-1 bg-[#090f1e] border border-slate-700 focus:border-sky-400 rounded-xl px-4 py-2.5 text-sm font-black tracking-widest text-white uppercase outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleRedeem}
                    className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-5 rounded-xl cursor-pointer"
                  >
                    KULLAN
                  </button>
                </div>

                {codeFeedback && (
                  <div
                    className={`text-xs font-bold px-3 py-2 rounded-lg border ${
                      codeFeedback.ok
                        ? 'bg-emerald-500/15 border-emerald-400/50 text-emerald-300'
                        : 'bg-red-950/60 border-red-500/50 text-red-200'
                    }`}
                  >
                    {codeFeedback.msg}
                  </div>
                )}

                <div className="pt-1 flex flex-wrap gap-2 items-center">
                  <span className="text-[11px] font-bold text-slate-400">AKTİF KODLAR:</span>
                  {Object.keys(PROMO_CODES).map((c) => {
                    const used = questProgress.redeemedCodes.includes(c);
                    return (
                      <button
                        key={c}
                        type="button"
                        disabled={used}
                        onClick={() => setCodeInput(c)}
                        className={`text-[11px] font-black px-2.5 py-1 rounded-lg border cursor-pointer disabled:opacity-45 ${
                          used
                            ? 'bg-slate-900 border-slate-800 text-slate-500 line-through'
                            : 'bg-slate-900 hover:bg-slate-800 border-amber-400/40 text-amber-300'
                        }`}
                      >
                        {c}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Ranked Career Summary */}
              <div className="bg-[#060b16] border border-sky-500/40 rounded-2xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="px-3.5 py-2 rounded-xl font-black text-sm text-slate-950 shadow-lg"
                      style={{ background: progress.tier.bg }}
                    >
                      {progress.tier.badgeText}
                    </div>
                    <div>
                      <div className="text-base font-black text-white">{progress.tier.name}</div>
                      <div className="text-xs font-bold text-sky-300 tabular-nums">
                        {profile.rp} RP · Seri: {profile.winStreak} (En İyi: {profile.bestStreak})
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3 text-center">
                    {[
                      { label: 'GALİBİYET', val: profile.wins, color: 'text-emerald-300' },
                      { label: 'MAĞLUBİYET', val: profile.losses, color: 'text-red-300' },
                      { label: 'GOL', val: profile.goals, color: 'text-amber-300' },
                      { label: 'MVP', val: profile.mvps, color: 'text-purple-300' },
                    ].map((s) => (
                      <div key={s.label} className="bg-[#090f1e] border border-slate-800 rounded-xl px-3 py-2">
                        <div className="text-[10px] font-bold text-slate-400">{s.label}</div>
                        <div className={`text-base font-black tabular-nums ${s.color}`}>{s.val}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {progress.nextTier && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-400">
                      <span>Sonraki Lig: {progress.nextTier.name}</span>
                      <span className="text-amber-300 tabular-nums">
                        {progress.nextTier.minRp - profile.rp} RP kaldı
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-sky-400 via-amber-400 to-purple-500"
                        style={{ width: `${progress.percent}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Match History */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-black tracking-wider text-slate-300 uppercase">
                  <History className="w-4 h-4 text-sky-400" /> SON MAÇ GEÇMİŞİ
                </div>

                {profile.history.length === 0 ? (
                  <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
                    Henüz kayıtlı maç geçmişin yok. Dereceli veya Hızlı maç oyna!
                  </div>
                ) : (
                  profile.history.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between bg-[#060b16] border border-slate-800 rounded-xl px-4 py-3"
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`text-[10px] font-black px-2 py-1 rounded ${
                            m.result === 'WIN'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                              : m.result === 'LOSS'
                                ? 'bg-red-500/20 text-red-300 border border-red-400/40'
                                : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {m.result === 'WIN' ? 'ZAFER' : m.result === 'LOSS' ? 'MAĞLUP' : 'BERABERE'}
                        </span>
                        <div>
                          <div className="text-xs font-black text-white">
                            BLUE {m.blueScore} — {m.redScore} RED · {STYLES[m.styleId]?.name ?? m.styleId}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {m.queueType === 'RANKED' ? 'DERECELİ' : 'SERBEST'} · {m.matchMode} · {m.goals} Gol
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs font-black tabular-nums">
                        <Award className="w-3.5 h-3.5 text-amber-400" />
                        <span
                          className={
                            m.rpDelta > 0
                              ? 'text-emerald-300'
                              : m.rpDelta < 0
                                ? 'text-red-300'
                                : 'text-slate-400'
                          }
                        >
                          {m.queueType === 'RANKED'
                            ? `${m.rpDelta >= 0 ? '+' : ''}${m.rpDelta} RP`
                            : 'Derecesiz'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
