import { Flame, Pause, Play, RotateCcw, Settings, Trophy, Volume2, VolumeX, Zap } from 'lucide-react';
import { RARITY_COLORS, STYLES } from '../data/styles';
import type { HudSnapshot, StyleId } from '../types/game';

interface GameHUDProps {
  hud: HudSnapshot;
  activeStyleId: StyleId;
  muted: boolean;
  showFps: boolean;
  onToggleMute: () => void;
  onTogglePause: () => void;
  onOpenSettings: () => void;
  onRestart: () => void;
  onExitToLobby: () => void;
  onTriggerAction: (
    action: 'SKILL1' | 'SKILL2' | 'PERSONAL' | 'DRIBBLE' | 'SLIDE' | 'PASS' | 'AWAKENING' | 'ULTI'
  ) => void;
}

const GK_LABELS = { EASY: 'Kolay', MEDIUM: 'Orta', HARD: 'Zor' };

export function GameHUD({
  hud,
  activeStyleId,
  muted,
  showFps,
  onToggleMute,
  onTogglePause,
  onOpenSettings,
  onRestart,
  onExitToLobby,
  onTriggerAction,
}: GameHUDProps) {
  const style = STYLES[activeStyleId];
  const rarity = RARITY_COLORS[style.rarity];

  const mins = Math.floor(hud.timeRemaining / 60);
  const secs = hud.timeRemaining % 60;
  const clockStr = `${mins}:${secs < 10 ? '0' : ''}${secs}`;

  const canAwaken = !hud.isAwakened && hud.awakening >= 100;
  const canUlti = hud.isAwakened && !hud.ultiUsedInAwakening;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4">
      {/* TOP PERIMETER: Scoreboard & Status */}
      <div className="flex items-start justify-between gap-4">
        <div className="bg-[#090f1e]/92 border border-slate-700/80 rounded-xl px-3.5 py-2">
          <div className="flex items-center gap-2">
            <span className="font-black text-sm text-white">{style.name}</span>
            <span
              className="text-[10px] font-black px-1.5 py-0.5 rounded text-slate-950"
              style={{ background: rarity.badgeBg }}
            >
              {style.rarity}
            </span>
            <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-slate-800 border border-slate-600 text-slate-200">
              {hud.matchMode === '1V1' ? '1v1' : '3v3'}
            </span>
            {hud.shiftLock && (
              <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-sky-500 text-slate-950">
                SHIFTLOCK [ALT]
              </span>
            )}
            {hud.isOnline && hud.roomCode && (
              <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-400/50 text-emerald-300">
                ONLİNE · {hud.roomCode}
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-300 font-semibold mt-0.5">
            {hud.hasBall
              ? '[R] Şut · [X] Pas · [Q] Çalım · Sağ Tık: Kamera · [Alt] ShiftLock'
              : `[F] Kayma · [Q] Çalım · Sağ Tık: Kamera · [Alt] ShiftLock · Kaleci: ${GK_LABELS[hud.gkDifficulty]}`}
          </div>
        </div>

        {/* Scoreboard */}
        <div className="flex items-center bg-[#090f1e]/95 border border-sky-500/40 rounded-xl overflow-hidden shadow-lg">
          <div className="px-4 py-2 bg-sky-600/25 border-r border-slate-800 text-center">
            <div className="text-[10px] font-black text-sky-300 tracking-wider">BLUE LOCK</div>
            <div className="text-2xl font-black text-white tabular-nums leading-tight">
              {hud.blueScore}
            </div>
          </div>
          <div className="px-4 py-2 text-center min-w-[84px]">
            <div className="text-[10px] font-bold text-slate-400">
              {hud.isTraining ? 'MOD' : 'SÜRE'}
            </div>
            <div className="text-lg font-black text-amber-300 tabular-nums">
              {hud.isTraining ? 'ANTRENMAN' : clockStr}
            </div>
          </div>
          <div className="px-4 py-2 bg-red-600/25 border-l border-slate-800 text-center">
            <div className="text-[10px] font-black text-red-300 tracking-wider">RAKİPLER</div>
            <div className="text-2xl font-black text-white tabular-nums leading-tight">
              {hud.redScore}
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          {showFps && (
            <div className="bg-[#090f1e]/92 border border-slate-700 rounded-xl px-2.5 py-2 text-[11px] font-black text-emerald-300 tabular-nums">
              {hud.fps} FPS
            </div>
          )}
          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="Ayarlar"
            className="bg-[#090f1e]/92 hover:bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-slate-200 cursor-pointer"
          >
            <Settings className="w-4 h-4 text-sky-400" />
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'Sesi Aç' : 'Sesi Kapat'}
            className="bg-[#090f1e]/92 hover:bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-slate-200 cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-sky-400" />}
          </button>
          {hud.isOnline || hud.isTraining ? (
            <button
              type="button"
              onClick={onExitToLobby}
              className="bg-[#090f1e]/92 hover:bg-slate-800 border border-red-500/40 rounded-xl px-3 py-2 text-xs font-black text-red-300 cursor-pointer"
            >
              ÇIK
            </button>
          ) : (
            <button
              type="button"
              onClick={onTogglePause}
              aria-label="Duraklat"
              className="bg-[#090f1e]/92 hover:bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-slate-200 cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* SHIFTLOCK CENTER CROSSHAIR */}
      {hud.shiftLock && hud.phase === 'LIVE' && (
        <div className="fixed inset-0 pointer-events-none flex items-center justify-center">
          <div className="relative w-7 h-7 flex items-center justify-center">
            <div className="w-6 h-6 rounded-full border-2 border-sky-300/85 shadow-[0_0_8px_rgba(56,189,248,0.85)]" />
            <div className="absolute w-2.5 h-0.5 bg-white" />
            <div className="absolute h-2.5 w-0.5 bg-white" />
          </div>
        </div>
      )}

      {/* CENTER OVERLAYS */}
      <div className="flex flex-col items-center justify-center gap-3 my-auto">
        {hud.lastActionToast && hud.phase === 'LIVE' && (
          <div className="bg-[#090f1e]/92 border border-sky-400/50 text-sky-200 text-xs font-black tracking-wide px-4 py-1.5 rounded-lg">
            {hud.lastActionToast}
          </div>
        )}

        {hud.goalBanner && (
          <div className="bg-[#050811]/95 border-2 border-amber-400 rounded-2xl px-8 py-5 text-center shadow-2xl">
            <div className="text-xs font-black tracking-[0.3em] text-amber-300">
              {hud.goalBanner.isUltiGoal ? 'ULTİ SÜPER GOL!' : 'GOOOOL!'}
            </div>
            <div className="text-4xl font-black italic text-white mt-1">
              {hud.goalBanner.team === 'BLUE' ? 'BLUE LOCK SKOR!' : 'RAKİP GOL ATTI!'}
            </div>
            <div className="text-sm font-bold text-sky-300 mt-1">
              Golcü: {hud.goalBanner.scorerName}
            </div>
          </div>
        )}
      </div>

      {/* CUTSCENE SUBTITLE BAR */}
      {hud.cutsceneBanner && hud.cutsceneBanner.active && (
        <div
          className="mb-3 mx-auto max-w-2xl w-full bg-[#050811]/95 border-2 rounded-2xl px-6 py-4 text-center shadow-2xl"
          style={{ borderColor: hud.cutsceneBanner.accentColor }}
        >
          <div className="flex items-center justify-center gap-2">
            <span
              className="text-[11px] font-black px-2.5 py-0.5 rounded text-slate-950"
              style={{ backgroundColor: hud.cutsceneBanner.accentColor }}
            >
              {hud.cutsceneBanner.badge}
            </span>
            <span className="text-sm font-black text-white">{hud.cutsceneBanner.speaker}</span>
          </div>
          <div className="text-lg md:text-xl font-black italic text-amber-200 mt-1.5">
            “{hud.cutsceneBanner.subtitle}”
          </div>
        </div>
      )}

      {/* BOTTOM DOCK: Shot Charge, Stamina, Awakening & All Action Keys */}
      {hud.phase !== 'CUTSCENE' && (
        <div className="mx-auto w-full max-w-5xl flex flex-col items-center gap-2">
          {hud.shotCharge > 0 && (
            <div className="w-64 bg-[#050811]/95 border border-amber-400/60 rounded-lg p-1.5">
              <div className="flex justify-between text-[10px] font-black text-amber-300 mb-1">
                <span>ŞUT GÜCÜ [R]</span>
                <span className="tabular-nums">{Math.round(hud.shotCharge * 100)}%</span>
              </div>
              <div className="h-2 bg-slate-800 rounded overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-sky-400 via-amber-400 to-red-500"
                  style={{ width: `${Math.round(hud.shotCharge * 100)}%` }}
                />
              </div>
            </div>
          )}

          <div className="pointer-events-auto w-full bg-[#090f1e]/94 border border-slate-700/80 rounded-2xl px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2.5">
            {/* Bars */}
            <div className="flex items-center gap-3">
              <div className="w-20">
                <div className="flex justify-between text-[10px] font-bold text-slate-300 mb-1">
                  <span>STAMİNA</span>
                  <span className="tabular-nums">{hud.stamina}</span>
                </div>
                <div className="h-2 bg-slate-800 rounded overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{ width: `${hud.stamina}%` }} />
                </div>
              </div>

              <div className="w-24">
                <div className="flex justify-between text-[10px] font-bold text-amber-300 mb-1">
                  <span>{hud.isAwakened ? 'SÜRE' : 'UYANIŞ'}</span>
                  <span className="tabular-nums">
                    {hud.isAwakened ? `${hud.awakeningTimeLeft}s` : `${hud.awakening}%`}
                  </span>
                </div>
                <div className="h-2 bg-slate-800 rounded overflow-hidden">
                  <div
                    className="h-full"
                    style={{
                      width: hud.isAwakened
                        ? `${Math.min(100, (hud.awakeningTimeLeft / 18) * 100)}%`
                        : `${hud.awakening}%`,
                      backgroundColor: hud.isAwakened ? '#a855f7' : '#fbbf24',
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons matching exact requested keys */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => onTriggerAction('DRIBBLE')}
                disabled={hud.dribbleCd > 0}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-600 disabled:opacity-50 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-amber-300">[Q]</div>
                <div className="text-[11px] font-extrabold text-white">
                  {hud.dribbleCd > 0 ? `${hud.dribbleCd}s` : 'Çalım'}
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('SLIDE')}
                disabled={hud.slideCd > 0}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-600 disabled:opacity-50 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-emerald-300">[F]</div>
                <div className="text-[11px] font-extrabold text-white">
                  {hud.slideCd > 0 ? `${hud.slideCd}s` : 'Kayma'}
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('PASS')}
                disabled={!hud.hasBall}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-600 disabled:opacity-45 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-sky-300">[X]</div>
                <div className="text-[11px] font-extrabold text-white">Pas</div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('SKILL1')}
                disabled={hud.skill1Cd > 0}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-sky-500/50 disabled:opacity-50 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-sky-300">[1]</div>
                <div className="text-[11px] font-extrabold text-white truncate max-w-[92px]">
                  {hud.skill1Cd > 0 ? `${hud.skill1Cd}s` : style.skill1.name}
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('SKILL2')}
                disabled={hud.skill2Cd > 0}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-sky-500/50 disabled:opacity-50 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-sky-300">[2]</div>
                <div className="text-[11px] font-extrabold text-white truncate max-w-[92px]">
                  {hud.skill2Cd > 0 ? `${hud.skill2Cd}s` : style.skill2.name}
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('PERSONAL')}
                disabled={hud.personalCd > 0}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-emerald-400/60 disabled:opacity-50 text-left cursor-pointer"
              >
                <div className="text-[10px] font-black text-emerald-300">[E / 3]</div>
                <div className="text-[11px] font-extrabold text-white truncate max-w-[96px]">
                  {hud.personalCd > 0 ? `${hud.personalCd}s` : style.personalSkill.name}
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('AWAKENING')}
                disabled={!canAwaken}
                className={`px-3 py-1.5 rounded-xl border text-left cursor-pointer flex items-center gap-1.5 ${
                  canAwaken
                    ? 'bg-amber-400 border-amber-200 text-slate-950 font-black'
                    : 'bg-slate-900 border-slate-700 text-slate-400 opacity-60'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <div>
                  <div className="text-[10px] font-black">[G] UYANIŞ</div>
                  <div className="text-[11px] font-black tabular-nums">
                    {hud.isAwakened ? 'AKTİF' : canAwaken ? 'HAZIR!' : `${hud.awakening}%`}
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onTriggerAction('ULTI')}
                disabled={!canUlti}
                className={`px-3 py-1.5 rounded-xl border text-left cursor-pointer flex items-center gap-1.5 ${
                  canUlti
                    ? 'bg-purple-500 border-purple-300 text-white font-black'
                    : 'bg-slate-900 border-slate-700 text-slate-400 opacity-55'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <div>
                  <div className="text-[10px] font-black">[V] ULTİ</div>
                  <div className="text-[11px] font-black">
                    {canUlti ? 'VUR!' : hud.ultiUsedInAwakening ? 'BİTTİ' : 'KİLİTLİ'}
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PAUSE MODAL */}
      {hud.phase === 'PAUSED' && (
        <div className="fixed inset-0 z-30 pointer-events-auto flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-md bg-[#090f1e] border border-sky-500/40 rounded-2xl p-6 text-center space-y-4">
            <h2 className="text-2xl font-black text-white">MAÇ DURAKLATILDI</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              WASD: Koş · Sağ Tık Sürükle: Kamera · Alt: ShiftLock · Shift: Sprint · R: Şut · X: Pas · Q: Çalım · F: Kayma · 1/2: Yetenek · E/3: Kişiye Özel · G: Uyanış · V: Ulti
            </p>
            <div className="flex flex-col gap-2.5 pt-2">
              <button
                type="button"
                onClick={onTogglePause}
                className="w-full flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black py-3 rounded-xl cursor-pointer"
              >
                <Play className="w-4 h-4 fill-slate-950" /> DEVAM ET
              </button>
              <button
                type="button"
                onClick={onRestart}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" /> MAÇI YENİDEN BAŞLAT
              </button>
              <button
                type="button"
                onClick={onOpenSettings}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold py-3 rounded-xl cursor-pointer"
              >
                <Settings className="w-4 h-4" /> GRAFİK & SES AYARLARI
              </button>
              <button
                type="button"
                onClick={onExitToLobby}
                className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold py-3 rounded-xl cursor-pointer"
              >
                LOBİYE DÖN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MATCH END MODAL WITH STATS & BONUS REWARD */}
      {hud.phase === 'ENDED' && (
        <div className="fixed inset-0 z-30 pointer-events-auto flex items-center justify-center bg-slate-950/85 p-4">
          <div className="w-full max-w-md bg-[#090f1e] border-2 border-amber-400/60 rounded-2xl p-7 text-center space-y-4">
            <Trophy className="w-12 h-12 text-amber-400 mx-auto" />
            <div className="text-xs font-black tracking-widest text-amber-300">MAÇ SONA ERDİ</div>
            <h2 className="text-3xl font-black text-white">
              {hud.blueScore > hud.redScore
                ? 'ZAFER! EGOİST KAZANDI!'
                : hud.blueScore === hud.redScore
                  ? 'BERABERLİK!'
                  : 'MAĞLUBİYET — TEKRAR DENE!'}
            </h2>
            <div className="text-2xl font-black text-sky-300 tabular-nums">
              BLUE LOCK {hud.blueScore} — {hud.redScore} RAKİPLER
            </div>

            {/* Detailed Match Performance Grid */}
            <div className="grid grid-cols-5 gap-1.5 bg-[#060b16] border border-slate-800 rounded-xl p-3">
              {[
                { label: 'GOL', val: hud.stats.goals },
                { label: 'ŞUT', val: hud.stats.shots },
                { label: 'PAS', val: hud.stats.passes },
                { label: 'ÇALIM', val: hud.stats.dribbles },
                { label: 'KAPMA', val: hud.stats.steals },
              ].map((st) => (
                <div key={st.label}>
                  <div className="text-[10px] font-bold text-slate-400">{st.label}</div>
                  <div className="text-base font-black text-white tabular-nums">{st.val}</div>
                </div>
              ))}
            </div>

            <div className="bg-amber-500/10 border border-amber-400/40 rounded-xl py-2.5 px-4 text-xs font-black text-amber-200">
              ÖDÜL: +
              {((hud.blueScore > hud.redScore ? 1200 : 500) + hud.stats.goals * 150).toLocaleString(
                'tr-TR'
              )}{' '}
              YEN & +2 SPİN!
            </div>
            <div className="flex gap-3 pt-2">
              {!hud.isOnline && (
                <button
                  type="button"
                  onClick={onRestart}
                  className="flex-1 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black py-3 rounded-xl cursor-pointer"
                >
                  YENİDEN OYNA
                </button>
              )}
              <button
                type="button"
                onClick={onExitToLobby}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl cursor-pointer"
              >
                STİL LOBİSİ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
