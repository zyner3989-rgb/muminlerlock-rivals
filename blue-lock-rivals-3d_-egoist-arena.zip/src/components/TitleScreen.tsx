import { useState } from 'react';
import { Film, Flame, Gift, Play, Settings, Shield, Shirt, Sparkles, Swords, Target, Users, Volume2, VolumeX, Zap } from 'lucide-react';
import { getRankTier } from '../data/ranked';
import { ROLE_LIST, ROLES } from '../data/roles';
import { FLOWS, RARITY_COLORS, STYLE_LIST, STYLES } from '../data/styles';
import type { FlowId, GkDifficulty, MatchMode, PlayerRole, RankedProfile, StyleId } from '../types/game';

interface TitleScreenProps {
  selectedStyle: StyleId;
  selectedFlow: FlowId;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  selectedRole: PlayerRole;
  yen: number;
  spins: number;
  luckySpins: number;
  muted: boolean;
  rankedProfile: RankedProfile;
  claimableQuestsCount: number;
  onSelectGkDifficulty: (lvl: GkDifficulty) => void;
  onSelectMatchMode: (mode: MatchMode) => void;
  onSelectRole: (role: PlayerRole) => void;
  onStartMatch: () => void;
  onStartTraining: () => void;
  onOpenOnlineLobby: () => void;
  onOpenSpinLobby: () => void;
  onOpenWardrobe: () => void;
  onOpenQuests: () => void;
  onOpenSettings: () => void;
  onPreviewCutscene: (styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO') => void;
  onToggleMute: () => void;
}

const GK_OPTIONS: Array<{ id: GkDifficulty; label: string }> = [
  { id: 'EASY', label: 'Kolay' },
  { id: 'MEDIUM', label: 'Orta' },
  { id: 'HARD', label: 'Zor' },
];

const MODE_OPTIONS: Array<{ id: MatchMode; label: string }> = [
  { id: '1V1', label: '1v1' },
  { id: '3V3', label: '3v3' },
];

export function TitleScreen({
  selectedStyle,
  selectedFlow,
  gkDifficulty,
  matchMode,
  selectedRole,
  yen,
  spins,
  luckySpins,
  muted,
  rankedProfile,
  claimableQuestsCount,
  onSelectGkDifficulty,
  onSelectMatchMode,
  onSelectRole,
  onStartMatch,
  onStartTraining,
  onOpenOnlineLobby,
  onOpenSpinLobby,
  onOpenWardrobe,
  onOpenQuests,
  onOpenSettings,
  onPreviewCutscene,
  onToggleMute,
}: TitleScreenProps) {
  const [showViewer, setShowViewer] = useState(false);
  const [viewerStyle, setViewerStyle] = useState<StyleId>(selectedStyle);

  const style = STYLES[selectedStyle];
  const flow = FLOWS[selectedFlow];
  const roleDef = ROLES[selectedRole];
  const rarityStyle = RARITY_COLORS[style.rarity];
  const vStyle = STYLES[viewerStyle];
  const rankTier = getRankTier(rankedProfile.rp);

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between pointer-events-none p-5 md:p-8">
      {/* Top Bar */}
      <div className="flex items-start justify-between gap-4">
        <div className="pointer-events-auto flex items-center gap-3 bg-[#090f1e]/92 border border-sky-500/35 rounded-xl px-4 py-2.5 shadow-lg">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-sky-300/80 font-bold">
              AKTİF STİL · FLOW · MEVKİ
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="font-black text-base tracking-wide text-white">{style.name}</span>
              <span
                className="text-[10px] font-black px-2 py-0.5 rounded text-slate-950"
                style={{ background: rarityStyle.badgeBg }}
              >
                {style.rarity}
              </span>
              <span className="text-xs font-bold text-slate-300">· {flow.name}</span>
              <span
                className="text-[10px] font-black px-2 py-0.5 rounded text-slate-950"
                style={{ background: roleDef.accentColor }}
              >
                {roleDef.name}
              </span>
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2.5 flex-wrap justify-end">
          <button
            type="button"
            onClick={onOpenQuests}
            className="bg-[#090f1e]/92 hover:bg-slate-800 border border-sky-500/40 rounded-xl px-3.5 py-2 text-left cursor-pointer"
          >
            <div className="text-[10px] uppercase tracking-wider text-sky-300/80 font-bold">
              DERECELİ LİG
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className="text-[10px] font-black px-1.5 py-0.5 rounded text-slate-950"
                style={{ background: rankTier.bg }}
              >
                {rankTier.badgeText}
              </span>
              <span className="text-sm font-black text-white tabular-nums">{rankedProfile.rp} RP</span>
            </div>
          </button>
          <div className="bg-[#090f1e]/92 border border-amber-400/35 rounded-xl px-3.5 py-2 text-right">
            <div className="text-[10px] uppercase tracking-wider text-amber-300/80 font-bold">YEN / ÇARK</div>
            <div className="text-sm font-black text-amber-300 tabular-nums">
              ¥{yen.toLocaleString('tr-TR')} · {spins} Spin · {luckySpins} Şanslı
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenQuests}
            className="relative flex items-center gap-1.5 bg-[#090f1e]/92 hover:bg-slate-800 border border-amber-400/50 rounded-xl px-3 py-2.5 text-xs font-black text-amber-300 transition-colors cursor-pointer"
          >
            <Gift className="w-4 h-4" />
            GÖREVLER
            {claimableQuestsCount > 0 && (
              <span className="ml-0.5 w-4 h-4 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black flex items-center justify-center">
                {claimableQuestsCount}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="Ayarlar"
            className="flex items-center gap-1.5 bg-[#090f1e]/92 hover:bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-black text-slate-200 transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4 text-sky-400" />
            AYARLAR
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'Sesi Aç' : 'Sesi Kapat'}
            className="bg-[#090f1e]/92 hover:bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-slate-200 transition-colors cursor-pointer"
          >
            {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5 text-sky-400" />}
          </button>
        </div>
      </div>

      {/* Left-aligned Title Lockup & Match Launch */}
      <div className="max-w-2xl pointer-events-auto my-auto">
        <svg
          viewBox="0 0 540 165"
          className="w-full max-w-[460px] drop-shadow-[0_8px_24px_rgba(2,6,23,0.9)]"
          aria-label="Blue Lock Rivals 3D Egoist Arena"
        >
          <defs>
            <linearGradient id="blTitleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#a855f7" />
            </linearGradient>
            <linearGradient id="blGoldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#f97316" />
            </linearGradient>
          </defs>
          <polygon points="10,18 46,18 30,52 2,52" fill="#0ea5e9" opacity="0.9" />
          <text x="56" y="43" fill="#7dd3fc" fontSize="16" fontWeight="900" letterSpacing="5">
            ONLİNE × EFOOTBALL 3D
          </text>
          <text
            x="6"
            y="108"
            fill="url(#blTitleGrad)"
            fontSize="56"
            fontWeight="900"
            fontStyle="italic"
            letterSpacing="-1"
          >
            BLUE LOCK
          </text>
          <text
            x="8"
            y="152"
            fill="url(#blGoldGrad)"
            fontSize="40"
            fontWeight="900"
            fontStyle="italic"
            letterSpacing="3"
          >
            RIVALS ARENA
          </text>
        </svg>

        {/* Mevki Seçimi (Santrafor, Kanat, Orta Saha, Kaleci) */}
        <div className="mt-3 bg-[#090f1e]/92 border border-slate-700/80 rounded-xl px-3.5 py-2.5 inline-flex flex-col gap-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-black text-emerald-300">MEVKİ:</span>
            <div className="flex flex-wrap gap-1.5">
              {ROLE_LIST.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => onSelectRole(r.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black cursor-pointer transition-colors ${
                    selectedRole === r.id
                      ? r.id === 'GK'
                        ? 'bg-emerald-400 text-slate-950'
                        : 'bg-sky-400 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {r.name}
                </button>
              ))}
            </div>
          </div>
          <div className="text-[11px] font-semibold text-slate-300">
            <span className="font-black" style={{ color: roleDef.accentColor }}>
              {roleDef.name}:
            </span>{' '}
            {roleDef.description}
          </div>
        </div>

        {/* AI Kaleci & Maç Modu (1v1 / 3v3) Seçiciler */}
        <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
          <div className="inline-flex items-center gap-2 bg-[#090f1e]/92 border border-slate-700/80 rounded-xl px-3.5 py-2">
            <Shield className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-black text-slate-300">KALECİ:</span>
            <div className="flex gap-1.5">
              {GK_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onSelectGkDifficulty(opt.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black cursor-pointer transition-colors ${
                    gkDifficulty === opt.id
                      ? 'bg-sky-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="inline-flex items-center gap-2 bg-[#090f1e]/92 border border-slate-700/80 rounded-xl px-3.5 py-2">
            <Swords className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-black text-slate-300">MOD:</span>
            <div className="flex gap-1.5">
              {MODE_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onSelectMatchMode(opt.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black cursor-pointer transition-colors ${
                    matchMode === opt.id
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Primary CTA & Lobby Actions */}
        <div className="mt-4 flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onStartMatch}
            className="flex items-center gap-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-sm px-6 py-3.5 rounded-xl shadow-[0_0_24px_rgba(56,189,248,0.45)] transition-transform active:scale-95 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            SOLO MAÇ ({matchMode === '1V1' ? '1v1' : '3v3'})
          </button>

          <button
            type="button"
            onClick={onOpenOnlineLobby}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm px-5 py-3.5 rounded-xl shadow-[0_0_22px_rgba(16,185,129,0.4)] cursor-pointer"
          >
            <Users className="w-4 h-4" />
            ONLİNE OYNA
          </button>

          <button
            type="button"
            onClick={onOpenSpinLobby}
            className="flex items-center gap-2 bg-[#0f172a]/95 hover:bg-slate-800 border border-amber-400/60 text-amber-300 font-extrabold text-sm px-4 py-3.5 rounded-xl transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            STİL ÇARKI
          </button>

          <button
            type="button"
            onClick={onOpenWardrobe}
            className="flex items-center gap-2 bg-[#0f172a]/95 hover:bg-slate-800 border border-sky-400/60 text-sky-300 font-extrabold text-sm px-4 py-3.5 rounded-xl transition-colors cursor-pointer"
          >
            <Shirt className="w-4 h-4" />
            KIYAFET
          </button>

          <button
            type="button"
            onClick={onStartTraining}
            className="flex items-center gap-2 bg-[#0f172a]/95 hover:bg-slate-800 border border-cyan-400/50 text-cyan-300 font-extrabold text-sm px-4 py-3.5 rounded-xl transition-colors cursor-pointer"
          >
            <Target className="w-4 h-4" />
            ANTRENMAN
          </button>

          <button
            type="button"
            onClick={() => setShowViewer((v) => !v)}
            className={`flex items-center gap-2 border font-extrabold text-sm px-4 py-3.5 rounded-xl transition-colors cursor-pointer ${
              showViewer
                ? 'bg-purple-600 border-purple-300 text-white'
                : 'bg-[#0f172a]/95 hover:bg-slate-800 border-purple-400/60 text-purple-300'
            }`}
          >
            <Film className="w-4 h-4" />
            UYANIŞ & ULTİ İZLE
          </button>
        </div>

        {/* Interactive 3D Awakening & Ulti Viewer Drawer */}
        {showViewer && (
          <div className="mt-3 bg-[#090f1e]/96 border border-purple-500/50 rounded-2xl p-4 shadow-2xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs font-black tracking-wider text-purple-300">
                3D SİNEMATİK İZLEYİCİ — KARAKTER SEÇ VE İZLE
              </div>
              <div className="text-[11px] font-bold text-slate-400">
                {vStyle.name} ({vStyle.rarity}) · {vStyle.ultiRangeLabel}
              </div>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
              {STYLE_LIST.map((s) => {
                const active = viewerStyle === s.id;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setViewerStyle(s.id)}
                    className={`px-2 py-2 rounded-xl border text-center cursor-pointer transition-all ${
                      active
                        ? 'bg-purple-500/25 border-purple-400 text-white'
                        : 'bg-[#060b16] hover:bg-slate-800 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="font-black text-xs truncate">{s.name}</div>
                    <div className="text-[9px] font-bold text-slate-400 truncate">{s.rarity}</div>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-800">
              <div className="text-[11px] text-slate-300 space-y-0.5 max-w-sm">
                <div>
                  <span className="text-amber-300 font-black">Uyanış:</span> {vStyle.awakeningSummary}
                </div>
                <div>
                  <span className="text-purple-300 font-black">Ulti:</span> {vStyle.ultiSummary}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onPreviewCutscene(viewerStyle, 'AWAKENING')}
                  className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs px-3.5 py-2.5 rounded-xl cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" /> UYANIŞ İZLE
                </button>
                <button
                  type="button"
                  onClick={() => onPreviewCutscene(viewerStyle, 'ULTI')}
                  className="flex items-center gap-1.5 bg-purple-500 hover:bg-purple-400 text-white font-black text-xs px-3.5 py-2.5 rounded-xl cursor-pointer"
                >
                  <Flame className="w-3.5 h-3.5" /> ULTİ İZLE
                </button>
                <button
                  type="button"
                  onClick={() => onPreviewCutscene('musab', 'COMBO')}
                  className="flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-sky-400 hover:brightness-110 text-slate-950 font-black text-xs px-3.5 py-2.5 rounded-xl cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" /> MUSAB × MUSA ROVEŞATA İZLE
                </button>
              </div>
            </div>
            <div className="text-[10px] text-slate-400 font-semibold">
              Anime Seslendirme: VOICEVOX (青山龍星・玄野武宏・剣崎雌雄・†聖騎士 紅桜†)
            </div>
          </div>
        )}
      </div>

      {/* Single Flat Control-Hint Line */}
      <div className="flex justify-center">
        <div className="bg-[#090f1e]/92 border border-slate-700/70 rounded-xl px-4 py-2 text-[11px] md:text-xs text-slate-300 font-semibold tracking-wide text-center">
          WASD Hareket · Sağ Tık Sürükle: Kamera · Alt: ShiftLock · Shift Sprint · R Şut · C Pas · X Emote · Q Çalım · F Kayma · 1/2 Yetenek · E/3 Özel · G Uyanış · V Ulti
        </div>
      </div>
    </div>
  );
}
