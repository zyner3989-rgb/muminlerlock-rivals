import { RotateCcw, Shirt, Sparkles, X } from 'lucide-react';
import {
  BACK_ACCESSORY_OPTIONS,
  CLEAT_OPTIONS,
  DEFAULT_WARDROBE,
  HAIR_COLOR_OPTIONS,
  HAIR_STYLE_OPTIONS,
  OUTFIT_OPTIONS,
} from '../data/cosmetics';
import { STYLES } from '../data/styles';
import type { StyleId, WardrobeConfig } from '../types/game';

interface WardrobeModalProps {
  activeStyleId: StyleId;
  wardrobe: WardrobeConfig;
  onChangeWardrobe: (next: WardrobeConfig) => void;
  onClose: () => void;
}

export function WardrobeModal({
  activeStyleId,
  wardrobe,
  onChangeWardrobe,
  onClose,
}: WardrobeModalProps) {
  const style = STYLES[activeStyleId];

  return (
    <div className="fixed inset-0 z-40 pointer-events-none flex items-center justify-end p-4 md:p-6">
      <div className="pointer-events-auto w-full max-w-lg max-h-[92vh] overflow-y-auto bg-[#090f1e]/96 border border-sky-500/45 rounded-2xl shadow-2xl p-5 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/15 border border-sky-400/40 text-sky-300">
              <Shirt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-wide">
                KIYAFET & ROBUX SAÇ DOLABI
              </h2>
              <p className="text-xs text-slate-400 font-semibold">
                {style.name} #{style.jerseyNumber} — Soldaki 3D modelde anında güncellenir
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onChangeWardrobe({ ...DEFAULT_WARDROBE })}
              title="Varsayılana Sıfırla"
              className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold px-2.5 py-2 rounded-xl cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Sıfırla
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Kapat"
              className="bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl p-2 text-slate-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 1. Üst Kıyafet / Forma Tarzı */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-sky-300 uppercase">
            1. Üst Kıyafet & Forma Stili
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {OUTFIT_OPTIONS.map((opt) => {
              const active = wardrobe.outfitId === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeWardrobe({ ...wardrobe, outfitId: opt.id })}
                  className={`p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-sky-500/20 border-sky-400 text-white'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className="w-4 h-4 rounded-md border border-white/25 inline-block shrink-0"
                      style={{
                        background: `linear-gradient(135deg, ${
                          opt.id === 'signature' ? style.primaryColor : opt.previewPrimary
                        } 55%, ${
                          opt.id === 'signature' ? style.secondaryColor : opt.previewSecondary
                        } 55%)`,
                      }}
                    />
                    <span className="font-black text-xs truncate">{opt.name}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 leading-tight">{opt.subtitle}</div>
                </button>
              );
            })}
          </div>
        </section>

        {/* 2. Roblox Robux Saç Stili */}
        <section className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs font-black tracking-wider text-amber-300 uppercase flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> 2. Roblox Robux UGC Saçlar
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {HAIR_STYLE_OPTIONS.map((opt) => {
              const active = wardrobe.hairStyleId === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeWardrobe({ ...wardrobe, hairStyleId: opt.id })}
                  className={`p-2 rounded-xl border text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-amber-400/20 border-amber-400 text-white'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="font-black text-[11px] truncate">{opt.name}</div>
                  <div className="text-[9px] text-slate-400 leading-tight mt-0.5">{opt.subtitle}</div>
                </button>
              );
            })}
          </div>
        </section>

        {/* 3. Saç Rengi */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-purple-300 uppercase">
            3. Saç Rengi
          </div>
          <div className="flex flex-wrap gap-2">
            {HAIR_COLOR_OPTIONS.map((opt) => {
              const active = wardrobe.hairColor === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onChangeWardrobe({ ...wardrobe, hairColor: opt.value })}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold cursor-pointer ${
                    active
                      ? 'bg-purple-500/25 border-purple-400 text-white'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-white/30"
                    style={{ background: opt.swatch }}
                  />
                  {opt.label}
                </button>
              );
            })}
          </div>
        </section>

        {/* 4. Krampon & Çorap Seti */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-emerald-300 uppercase">
            4. Krampon & Çorap Seti
          </div>
          <div className="flex flex-wrap gap-2">
            {CLEAT_OPTIONS.map((opt) => {
              const active = wardrobe.cleatId === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeWardrobe({ ...wardrobe, cleatId: opt.id })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold cursor-pointer ${
                    active
                      ? 'bg-emerald-500/20 border-emerald-400 text-white'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <span
                    className="w-3 h-3 rounded-sm border border-white/25"
                    style={{ backgroundColor: opt.cleatHex }}
                  />
                  {opt.name}
                </button>
              );
            })}
          </div>
        </section>

        {/* 5. Sırt Aksesuarı */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-rose-300 uppercase">
            5. Sırt Aksesuarı
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {BACK_ACCESSORY_OPTIONS.map((opt) => {
              const active = wardrobe.backAccessoryId === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeWardrobe({ ...wardrobe, backAccessoryId: opt.id })}
                  className={`p-2 rounded-xl border text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-rose-500/20 border-rose-400 text-white'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="font-black text-xs">{opt.name}</div>
                  <div className="text-[10px] text-slate-400 leading-tight">{opt.subtitle}</div>
                </button>
              );
            })}
          </div>
        </section>

        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-5 py-2.5 rounded-xl cursor-pointer"
          >
            KAYDET VE KAPAT
          </button>
        </div>
      </div>
    </div>
  );
}
