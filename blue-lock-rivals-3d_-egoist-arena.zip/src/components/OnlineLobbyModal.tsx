import { useEffect, useState } from 'react';
import { Check, Copy, Crown, Play, RefreshCw, Shield, Swords, Users, Wifi, X } from 'lucide-react';
import { FLOWS, RARITY_COLORS, STYLE_LIST, STYLES } from '../data/styles';
import type { FlowId, GkDifficulty, MatchMode, RoomLobbyState, StyleId } from '../types/game';

interface PublicRoomSummary {
  roomCode: string;
  playerCount: number;
  gkDifficulty: GkDifficulty;
  matchMode?: MatchMode;
  status: string;
}

export type OnlineTransportMode = 'p2p' | 'ws';

interface OnlineLobbyModalProps {
  mode: OnlineTransportMode;
  connected: boolean;
  clientId: string | null;
  room: RoomLobbyState | null;
  errorMsg: string | null;
  defaultStyle: StyleId;
  defaultFlow: FlowId;
  defaultGk: GkDifficulty;
  defaultMatchMode: MatchMode;
  onChangeMode: (mode: OnlineTransportMode) => void;
  onCreateRoom: (name: string, styleId: StyleId, flowId: FlowId, gk: GkDifficulty, matchMode: MatchMode) => void;
  onJoinRoom: (code: string, name: string, styleId: StyleId, flowId: FlowId) => void;
  onLeaveRoom: () => void;
  onUpdatePlayer: (patch: { name?: string; styleId?: StyleId; flowId?: FlowId; team?: 'BLUE' | 'RED' }) => void;
  onSetGk: (gk: GkDifficulty) => void;
  onSetMatchMode: (mode: MatchMode) => void;
  onStartOnlineMatch: () => void;
  onClose: () => void;
}

const GK_LABELS: Record<GkDifficulty, string> = {
  EASY: 'KOLAY',
  MEDIUM: 'ORTA',
  HARD: 'ZOR',
};

export function OnlineLobbyModal({
  mode,
  connected,
  clientId,
  room,
  errorMsg,
  defaultStyle,
  defaultFlow,
  defaultGk,
  defaultMatchMode,
  onChangeMode,
  onCreateRoom,
  onJoinRoom,
  onLeaveRoom,
  onUpdatePlayer,
  onSetGk,
  onSetMatchMode,
  onStartOnlineMatch,
  onClose,
}: OnlineLobbyModalProps) {
  const [playerName, setPlayerName] = useState('Egoist');
  const [joinCode, setJoinCode] = useState('');
  const [publicRooms, setPublicRooms] = useState<PublicRoomSummary[]>([]);
  const [copiedCode, setCopiedCode] = useState(false);

  const fetchRooms = async () => {
    if (mode !== 'ws') return;
    try {
      const res = await fetch('/api/rooms');
      const data = await res.json();
      if (Array.isArray(data?.rooms)) {
        setPublicRooms(data.rooms);
      }
    } catch {
      // ignore fetch errors
    }
  };

  useEffect(() => {
    if (!room && mode === 'ws') {
      fetchRooms();
    }
  }, [room, mode]);

  const me = room?.players.find((p) => p.clientId === clientId);
  const isHost = Boolean(room && clientId && room.hostId === clientId);

  const handleCopyCode = async () => {
    if (!room) return;
    try {
      await navigator.clipboard.writeText(room.roomCode);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 1800);
    } catch {
      // ignore clipboard restrictions inside iframes
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="w-full max-w-4xl max-h-[90vh] bg-[#090f1e] border border-sky-500/40 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#050811]">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-sky-400" />
            <div>
              <h2 className="text-lg font-black text-white">ONLİNE ÇOK OYUNCULU ARENA</h2>
              <p className="text-xs text-slate-400">
                {mode === 'p2p'
                  ? 'P2P Paylaşım Modu (Share linki ve her tarayıcıdan direkt bağlanır)'
                  : connected
                    ? 'Sunucuya bağlı — Oda kur veya kodla katıl'
                    : 'Sunucuya bağlanılıyor...'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              if (room) onLeaveRoom();
              onClose();
            }}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
            aria-label="Kapat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-6 space-y-5">
          {/* Transport Mode Selector (shown before entering a room) */}
          {!room && (
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#060b16] border border-slate-800 rounded-2xl p-3.5">
              <div className="flex items-center gap-2 text-xs text-slate-300 font-semibold">
                <Wifi className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  {mode === 'p2p'
                    ? 'Share linkiyle arkadaşınla girmek için P2P Modu aktif (farklı linklerden bile bağlanır).'
                    : 'Aynı Node.js sunucusundaki oyuncular için WebSocket Sunucu Modu aktif.'}
                </span>
              </div>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => onChangeMode('p2p')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                    mode === 'p2p'
                      ? 'bg-emerald-500 border-emerald-300 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  P2P (Share Uyumlu)
                </button>
                <button
                  type="button"
                  onClick={() => onChangeMode('ws')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                    mode === 'ws'
                      ? 'bg-sky-500 border-sky-300 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  Sunucu (WS)
                </button>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="bg-red-950/70 border border-red-500/50 text-red-200 text-xs font-bold rounded-xl px-4 py-3">
              {errorMsg}
            </div>
          )}

          {!room ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Create / Join Box */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div>
                  <label className="block text-[11px] font-black text-slate-400 uppercase mb-1.5">
                    OYUNCU ADIN
                  </label>
                  <input
                    type="text"
                    value={playerName}
                    maxLength={14}
                    onChange={(e) => setPlayerName(e.target.value)}
                    className="w-full bg-[#090f1e] border border-slate-700 focus:border-sky-400 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none"
                    placeholder="Örn: MusabPro"
                  />
                </div>

                <button
                  type="button"
                  disabled={mode === 'ws' && !connected}
                  onClick={() => onCreateRoom(playerName, defaultStyle, defaultFlow, defaultGk, defaultMatchMode)}
                  className="w-full bg-sky-500 hover:bg-sky-400 disabled:opacity-45 text-slate-950 font-black text-sm py-3 rounded-xl cursor-pointer"
                >
                  YENİ ODA KUR ({defaultMatchMode === '1V1' ? '1v1' : '3v3'})
                </button>

                <div className="pt-2 border-t border-slate-800">
                  <label className="block text-[11px] font-black text-slate-400 uppercase mb-1.5">
                    ODA KODU İLE KATIL
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={joinCode}
                      maxLength={8}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                      placeholder="KOD (ÖRN: A7B2K)"
                      className="flex-1 bg-[#090f1e] border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-sm font-black tracking-widest text-white uppercase outline-none"
                    />
                    <button
                      type="button"
                      disabled={(mode === 'ws' && !connected) || !joinCode.trim()}
                      onClick={() => onJoinRoom(joinCode, playerName, defaultStyle, defaultFlow)}
                      className="bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-slate-950 font-black text-xs px-5 rounded-xl cursor-pointer"
                    >
                      KATIL
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Panel: Instructions for P2P or Active Rooms for WS */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 flex flex-col">
                {mode === 'p2p' ? (
                  <div className="space-y-3">
                    <div className="text-xs font-black tracking-wider text-emerald-300">
                      ARKADAŞINLA SHARE LİNKİNDEN NASIL GİRİLİR?
                    </div>
                    <ol className="space-y-2 text-xs text-slate-300 leading-relaxed list-decimal list-inside">
                      <li>
                        Sen soldan <strong className="text-white">YENİ ODA KUR</strong> butonuna bas. Ekranda 5 haneli bir oda kodu çıkacak.
                      </li>
                      <li>
                        AI Studio’nun <strong className="text-sky-300">Share</strong> linkini ve bu <strong className="text-amber-300">5 haneli kodu</strong> arkadaşına gönder.
                      </li>
                      <li>
                        Arkadaşın linki açıp <strong className="text-white">ONLİNE OYNA → ODA KODU İLE KATIL</strong> kısmına kodu yazsın (ikisiniz de P2P modunda olmalısınız).
                      </li>
                      <li>
                        İkiniz de karakterinizi ve takımınızı seçin, sen <strong className="text-emerald-300">MAÇI BAŞLAT</strong>’a bas!
                      </li>
                    </ol>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-black tracking-wider text-slate-300">
                        AÇIK ODALAR ({publicRooms.length})
                      </span>
                      <button
                        type="button"
                        onClick={fetchRooms}
                        className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Yenile
                      </button>
                    </div>

                    {publicRooms.length === 0 ? (
                      <div className="flex-1 flex items-center justify-center text-xs text-slate-500 py-8 text-center">
                        Şu anda açık oda yok. Yeni bir oda kurup arkadaşlarına kodu paylaş!
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {publicRooms.map((r) => (
                          <div
                            key={r.roomCode}
                            className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3.5 py-2.5"
                          >
                            <div>
                              <div className="text-sm font-black text-white tracking-wider">
                                ODA: {r.roomCode}
                              </div>
                              <div className="text-[11px] text-slate-400">
                                {r.matchMode === '1V1' ? '1v1' : '3v3'} · {r.playerCount}/6 Oyuncu · Kaleci: {GK_LABELS[r.gkDifficulty]}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => onJoinRoom(r.roomCode, playerName, defaultStyle, defaultFlow)}
                              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-3.5 py-2 rounded-lg cursor-pointer"
                            >
                              KATIL
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          ) : (
            /* INSIDE ROOM LOBBY: Every player picks Style, Flow, Team; Host picks GK Difficulty & Starts */
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-[#060b16] border border-sky-500/40 rounded-2xl p-4">
                <div>
                  <div className="text-[10px] font-black text-sky-300 tracking-widest uppercase">
                    ODA KODU (ARKADAŞINLA PAYLAŞ · {mode === 'p2p' ? 'P2P' : 'SUNUCU'})
                  </div>
                  <div className="flex items-center gap-2.5 mt-0.5">
                    <span className="text-3xl font-black tracking-[0.2em] text-amber-300">
                      {room.roomCode}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 text-xs font-bold px-2.5 py-1.5 rounded-lg cursor-pointer"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCode ? 'Kopyalandı' : 'Kopyala'}
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div>
                    <div className="text-[10px] font-black text-slate-400 mb-1 flex items-center gap-1">
                      <Swords className="w-3 h-3 text-amber-400" /> MOD
                    </div>
                    <div className="flex gap-1.5">
                      {(['1V1', '3V3'] as MatchMode[]).map((mm) => (
                        <button
                          key={mm}
                          type="button"
                          disabled={!isHost}
                          onClick={() => onSetMatchMode(mm)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:cursor-default ${
                            (room.matchMode ?? '3V3') === mm
                              ? 'bg-amber-400 border-amber-200 text-slate-950'
                              : 'bg-slate-900 border-slate-700 text-slate-300'
                          }`}
                        >
                          {mm === '1V1' ? '1v1' : '3v3'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] font-black text-slate-400 mb-1 flex items-center gap-1">
                      <Shield className="w-3 h-3 text-sky-400" /> AI KALECİ SEVİYESİ
                    </div>
                    <div className="flex gap-1.5">
                      {(['EASY', 'MEDIUM', 'HARD'] as GkDifficulty[]).map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          disabled={!isHost}
                          onClick={() => onSetGk(lvl)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:cursor-default ${
                            room.gkDifficulty === lvl
                              ? 'bg-sky-500 border-sky-300 text-slate-950'
                              : 'bg-slate-900 border-slate-700 text-slate-300'
                          }`}
                        >
                          {GK_LABELS[lvl]}
                        </button>
                      ))}
                    </div>
                  </div>

                  {isHost && (
                    <button
                      type="button"
                      onClick={onStartOnlineMatch}
                      className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm px-6 py-3 rounded-xl cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-slate-950" /> MAÇI BAŞLAT
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={onLeaveRoom}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs px-4 py-3 rounded-xl cursor-pointer"
                  >
                    ODADAN ÇIK
                  </button>
                </div>
              </div>

              {/* Pick Your Own Character Style & Team */}
              {me && (
                <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-black text-white">
                      KARAKTERİNİ VE TAKIMINI SEÇ
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onUpdatePlayer({ team: 'BLUE' })}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                          me.team === 'BLUE'
                            ? 'bg-sky-500 border-sky-300 text-slate-950'
                            : 'bg-slate-900 border-slate-700 text-slate-300'
                        }`}
                      >
                        MAVİ TAKIM
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdatePlayer({ team: 'RED' })}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                          me.team === 'RED'
                            ? 'bg-red-500 border-red-300 text-white'
                            : 'bg-slate-900 border-slate-700 text-slate-300'
                        }`}
                      >
                        KIRMIZI TAKIM
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                    {STYLE_LIST.map((s) => {
                      const active = me.styleId === s.id;
                      const r = RARITY_COLORS[s.rarity];
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => onUpdatePlayer({ styleId: s.id })}
                          className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                            active
                              ? 'bg-slate-800 border-amber-400'
                              : 'bg-[#090f1e] hover:bg-slate-800/70 border-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs text-white">{s.name}</span>
                            <span
                              className="w-3 h-3 rounded-full border border-white/30"
                              style={{ backgroundColor: s.primaryColor }}
                            />
                          </div>
                          <div
                            className="text-[9px] font-black px-1.5 py-0.5 rounded text-slate-950 inline-block mt-1"
                            style={{ background: r.badgeBg }}
                          >
                            {s.rarity}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] font-bold text-slate-400">FLOW:</span>
                    {Object.values(FLOWS).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => onUpdatePlayer({ flowId: f.id })}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer ${
                          me.flowId === f.id
                            ? 'bg-purple-500 border-purple-300 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        {f.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Connected Roster */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(['BLUE', 'RED'] as const).map((team) => {
                  const list = room.players.filter((p) => p.team === team);
                  return (
                    <div
                      key={team}
                      className={`rounded-2xl p-4 border ${
                        team === 'BLUE'
                          ? 'bg-sky-950/25 border-sky-500/40'
                          : 'bg-red-950/25 border-red-500/40'
                      }`}
                    >
                      <div className="text-xs font-black tracking-wider mb-2.5 text-white">
                        {team === 'BLUE' ? 'MAVİ TAKIM (BLUE LOCK)' : 'KIRMIZI TAKIM (RAKİPLER)'}
                      </div>
                      <div className="space-y-2">
                        {list.length === 0 ? (
                          <div className="text-xs text-slate-500">Boş slotlar AI bot ile doldurulur.</div>
                        ) : (
                          list.map((p) => {
                            const st = STYLES[p.styleId];
                            return (
                              <div
                                key={p.clientId}
                                className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3 py-2"
                              >
                                <div className="flex items-center gap-2">
                                  {p.isHost && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                                  <span className="text-xs font-black text-white">{p.name}</span>
                                  {p.clientId === clientId && (
                                    <span className="text-[10px] font-bold text-sky-300">(Sen)</span>
                                  )}
                                </div>
                                <div className="text-xs font-black text-amber-300">
                                  {st.name} · {FLOWS[p.flowId].name}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
