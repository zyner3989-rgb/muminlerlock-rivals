import { CloudRain, Gauge, Moon, RotateCcw, Sliders, Sun, Volume2, VolumeX, X } from 'lucide-react';
import { DEFAULT_SETTINGS } from '../data/cosmetics';
import type { FpsCapMode, GameSettings, GraphicsQuality, WeatherMode } from '../types/game';

interface SettingsModalProps {
  settings: GameSettings;
  muted: boolean;
  onChangeSettings: (next: GameSettings) => void;
  onToggleMute: () => void;
  onClose: () => void;
}

const QUALITY_OPTIONS: Array<{ id: GraphicsQuality; label: string; desc: string }> = [
  { id: 'LOW', label: 'Düşük', desc: 'Maksimum FPS' },
  { id: 'MEDIUM', label: 'Orta', desc: 'Dengeli' },
  { id: 'HIGH', label: 'Yüksek', desc: 'Net PBR & Bloom' },
  { id: 'ULTRA', label: 'Ultra', desc: 'Tam Stadyum Kalitesi' },
];

const FPS_OPTIONS: Array<{ id: FpsCapMode; label: string; desc: string }> = [
  { id: 'VSYNC', label: 'VSync 60', desc: 'Ekran yenilemesi' },
  { id: '120', label: '120 FPS', desc: 'Yüksek akıcılık' },
  { id: '144', label: '144 FPS', desc: 'E-Spor hızı' },
  { id: 'UNLIMITED', label: 'Sınırsız', desc: '120+ Maksimum' },
];

const WEATHER_OPTIONS: Array<{ id: WeatherMode; label: string; icon: typeof Moon }> = [
  { id: 'NIGHT', label: 'Gece Arenası', icon: Moon },
  { id: 'SUNSET', label: 'Gün Batımı', icon: Sun },
  { id: 'RAIN', label: 'Yağmurlu Fırtına', icon: CloudRain },
];

export function SettingsModal({
  settings,
  muted,
  onChangeSettings,
  onToggleMute,
  onClose,
}: SettingsModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/82 p-4">
      <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto bg-[#090f1e] border border-sky-500/45 rounded-2xl shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/15 border border-sky-400/40 text-sky-300">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-wide">OYUN & GRAFİK AYARLARI</h2>
              <p className="text-xs text-slate-400 font-semibold">
                Değişiklikler maça ara vermeden anında uygulanır
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onChangeSettings({ ...DEFAULT_SETTINGS })}
              className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold px-2.5 py-2 rounded-xl cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Sıfırla
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Kapat"
              className="bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl p-2 text-slate-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Grafik Kalitesi */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-sky-300 uppercase">
            Grafik Kalitesi
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {QUALITY_OPTIONS.map((opt) => {
              const active = settings.quality === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() =>
                    onChangeSettings({
                      ...settings,
                      quality: opt.id,
                      bloom: opt.id !== 'LOW',
                      shadows: opt.id !== 'LOW',
                    })
                  }
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                    active
                      ? 'bg-sky-500 text-slate-950 border-sky-300'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="font-black text-xs">{opt.label}</div>
                  <div
                    className={`text-[10px] font-semibold ${
                      active ? 'text-slate-900' : 'text-slate-400'
                    }`}
                  >
                    {opt.desc}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* FPS Limiti */}
        <section className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-black tracking-wider text-emerald-300 uppercase">
            <Gauge className="w-3.5 h-3.5" /> FPS Limiti (120+ Kilit Açma)
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {FPS_OPTIONS.map((opt) => {
              const active = (settings.fpsMode ?? 'UNLIMITED') === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeSettings({ ...settings, fpsMode: opt.id })}
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                    active
                      ? 'bg-emerald-400 text-slate-950 border-emerald-200'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="font-black text-xs">{opt.label}</div>
                  <div
                    className={`text-[10px] font-semibold ${
                      active ? 'text-slate-900' : 'text-slate-400'
                    }`}
                  >
                    {opt.desc}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Stadyum Hava Durumu */}
        <section className="space-y-2">
          <div className="text-xs font-black tracking-wider text-amber-300 uppercase">
            Stadyum Atmosferi & Hava Durumu
          </div>
          <div className="grid grid-cols-3 gap-2">
            {WEATHER_OPTIONS.map((opt) => {
              const Icon = opt.icon;
              const active = settings.weather === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeSettings({ ...settings, weather: opt.id })}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border text-xs font-black cursor-pointer transition-colors ${
                    active
                      ? 'bg-amber-400 text-slate-950 border-amber-200'
                      : 'bg-[#060b16] hover:bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {opt.label}
                </button>
              );
            })}
          </div>
        </section>

        {/* Efekt Anahtarları */}
        <section className="grid grid-cols-2 gap-2.5">
          {[
            { key: 'bloom' as const, label: 'Bloom (Sinematik Parlama)' },
            { key: 'shadows' as const, label: 'Dinamik Gölgeler' },
            { key: 'particles' as const, label: 'Parçacık & Yağmur Efektleri' },
            { key: 'showFps' as const, label: 'FPS Göstergesi' },
          ].map((item) => {
            const on = settings[item.key];
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onChangeSettings({ ...settings, [item.key]: !on })}
                className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-xs font-bold cursor-pointer ${
                  on
                    ? 'bg-emerald-500/15 border-emerald-400/50 text-white'
                    : 'bg-[#060b16] border-slate-800 text-slate-400'
                }`}
              >
                <span>{item.label}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-black ${
                    on ? 'bg-emerald-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {on ? 'AÇIK' : 'KAPALI'}
                </span>
              </button>
            );
          })}
        </section>

        {/* Sliders: FOV, Kamera Mesafesi, Fare Hassasiyeti, Ses */}
        <section className="space-y-3 bg-[#060b16] border border-slate-800 rounded-xl p-4">
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold text-slate-300">
              <span>Kamera Görüş Açısı (FOV)</span>
              <span className="text-sky-300 font-black tabular-nums">{settings.fov}°</span>
            </div>
            <input
              type="range"
              min={48}
              max={78}
              step={1}
              value={settings.fov}
              onChange={(e) => onChangeSettings({ ...settings, fov: Number(e.target.value) })}
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold text-slate-300">
              <span>Kamera Uzaklığı</span>
              <span className="text-sky-300 font-black tabular-nums">
                {settings.cameraDistance.toFixed(1)}m
              </span>
            </div>
            <input
              type="range"
              min={8}
              max={20}
              step={0.5}
              value={settings.cameraDistance}
              onChange={(e) =>
                onChangeSettings({ ...settings, cameraDistance: Number(e.target.value) })
              }
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold text-slate-300">
              <span>Fare Hassasiyeti</span>
              <span className="text-sky-300 font-black tabular-nums">
                {settings.mouseSensitivity.toFixed(1)}x
              </span>
            </div>
            <input
              type="range"
              min={0.4}
              max={2.2}
              step={0.1}
              value={settings.mouseSensitivity}
              onChange={(e) =>
                onChangeSettings({ ...settings, mouseSensitivity: Number(e.target.value) })
              }
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-2">
                Ses Seviyesi
                <button
                  type="button"
                  onClick={onToggleMute}
                  className="text-[11px] font-black px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer inline-flex items-center gap-1"
                >
                  {muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                  {muted ? 'SUSTURULDU' : 'AÇIK'}
                </button>
              </span>
              <span className="text-sky-300 font-black tabular-nums">
                {muted ? '0%' : `${settings.masterVolume}%`}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={settings.masterVolume}
              onChange={(e) =>
                onChangeSettings({ ...settings, masterVolume: Number(e.target.value) })
              }
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>
        </section>

        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-5 py-2.5 rounded-xl cursor-pointer"
          >
            TAMAM
          </button>
        </div>
      </div>
    </div>
  );
}
