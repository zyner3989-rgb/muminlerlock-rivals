import { ROLES } from '../data/roles.ts';
import { FLOWS, STYLES } from '../data/styles.ts';
import type {
  FlowId,
  GkDifficulty,
  MatchMode,
  NetCutsceneEvent,
  NetWorldSnapshot,
  PlayerRole,
  QueueType,
  RoomLobbyState,
  StyleId,
} from '../types/game.ts';
import { MqttWsClient } from './mqttWs.ts';
import type { MultiplayerClient, OnlineActionType, OnlineClientCallbacks } from './onlineClient.ts';
import {
  applySimPlayerInput,
  buildSimActors,
  buildSimWorldSnapshot,
  createSimRoom,
  handleSimDiscreteAction,
  serializeSimLobby,
  type SimBroadcastSink,
  type SimRoomState,
  startSimMatch,
  stepSimRoom,
} from './roomSimulation.ts';

const RELAY_URLS = [
  'wss://broker.emqx.io:8084/mqtt',
  'wss://broker.hivemq.com:8884/mqtt',
  'wss://test.mosquitto.org:8081/mqtt',
];

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' },
  ],
  iceCandidatePoolSize: 3,
};

function genRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 5; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

interface HostPeerRtc {
  pc: RTCPeerConnection;
  dcFast: RTCDataChannel | null;
  dcRel: RTCDataChannel | null;
  pendingIce: RTCIceCandidateInit[];
  remoteDescSet: boolean;
  lastInputSeq: number;
}

export class P2POnlineClient implements MultiplayerClient {
  private callbacks: OnlineClientCallbacks;
  public clientId: string | null = null;
  public pingMs: number | null = null;

  // Signaling relays (Host uses all 3 concurrently so any guest finds Host immediately; Guest races all 3 and keeps the winner)
  private hostRelays: Array<MqttWsClient | null> = [];
  private guestProbes: Array<MqttWsClient | null> = [];
  private guestMqtt: MqttWsClient | null = null;
  private guestRelayMap = new Map<string, number>();

  // Direct WebRTC PeerConnections (Host -> per-guest; Guest -> single Host PC)
  private hostPeers = new Map<string, HostPeerRtc>();
  private guestPc: RTCPeerConnection | null = null;
  private guestDcFast: RTCDataChannel | null = null;
  private guestDcRel: RTCDataChannel | null = null;
  private pendingGuestIce: RTCIceCandidateInit[] = [];
  private guestRemoteDescSet = false;

  private roomCode: string | null = null;
  private isHost = false;
  private hostRoom: SimRoomState | null = null;
  private simInterval: ReturnType<typeof setInterval> | null = null;
  private joinRetryTimer: ReturnType<typeof setInterval> | null = null;
  private joinTimeoutTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private matchmakingTimer: ReturnType<typeof setInterval> | null = null;
  private pendingQuickMatch: {
    name: string;
    styleId: StyleId;
    flowId: FlowId;
    role: PlayerRole;
    matchMode: MatchMode;
    queueType: QueueType;
    rp: number;
    startedAt: number;
  } | null = null;
  private joinedConfirmed = false;
  private hostAnnounced = false;
  private lastTickMs = 0;
  private mqttWorldAccum = 0;
  private lastInputKey = '';
  private lastMqttInputSentMs = 0;
  private guestInputSeq = 0;
  private lastAppliedWorldSeq = 0;

  constructor(callbacks: OnlineClientCallbacks) {
    this.callbacks = callbacks;
  }

  private topicC2H(code: string): string {
    return `blr3d/v3/${code}/c2h`;
  }

  private topicH2C(code: string): string {
    return `blr3d/v3/${code}/h2c`;
  }

  public connect() {
    if (!this.clientId) {
      this.clientId = `p2p_${Math.random().toString(36).slice(2, 9)}`;
    }
    this.callbacks.onConnected(this.clientId);
  }

  public disconnect() {
    this.cleanup();
    this.callbacks.onDisconnected();
  }

  private cleanup() {
    if (this.simInterval !== null) {
      clearInterval(this.simInterval);
      this.simInterval = null;
    }
    if (this.joinRetryTimer !== null) {
      clearInterval(this.joinRetryTimer);
      this.joinRetryTimer = null;
    }
    if (this.joinTimeoutTimer !== null) {
      clearTimeout(this.joinTimeoutTimer);
      this.joinTimeoutTimer = null;
    }
    if (this.pingTimer !== null) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    if (this.matchmakingTimer !== null) {
      clearInterval(this.matchmakingTimer);
      this.matchmakingTimer = null;
    }

    for (const r of this.hostRelays) r?.close();
    this.hostRelays = [];
    for (const p of this.guestProbes) p?.close();
    this.guestProbes = [];
    if (this.guestMqtt) {
      this.guestMqtt.close();
      this.guestMqtt = null;
    }
    this.guestRelayMap.clear();

    for (const peer of this.hostPeers.values()) {
      try {
        peer.dcFast?.close();
        peer.dcRel?.close();
        peer.pc.close();
      } catch {
        // ignore
      }
    }
    this.hostPeers.clear();

    if (this.guestPc) {
      try {
        this.guestDcFast?.close();
        this.guestDcRel?.close();
        this.guestPc.close();
      } catch {
        // ignore
      }
      this.guestPc = null;
    }
    this.guestDcFast = null;
    this.guestDcRel = null;
    this.pendingGuestIce = [];
    this.guestRemoteDescSet = false;

    this.pendingQuickMatch = null;
    this.hostRoom = null;
    this.roomCode = null;
    this.isHost = false;
    this.joinedConfirmed = false;
    this.hostAnnounced = false;
    this.pingMs = null;
    this.mqttWorldAccum = 0;
    this.lastInputKey = '';
    this.lastMqttInputSentMs = 0;
    this.guestInputSeq = 0;
    this.lastAppliedWorldSeq = 0;
  }

  private makeHostSink(): SimBroadcastSink {
    return {
      broadcastLobby: (lobby) => this.broadcastAsHost('room:state', lobby, true),
      broadcastCutscene: (evt) => this.broadcastAsHost('match:cutscene', evt, true),
      broadcastSound: (sound, power, pitch) =>
        this.broadcastAsHost('match:sound', { sound, power, pitch }, true),
    };
  }

  private sendSignalingToGuest(guestId: string, type: string, payload: Record<string, unknown>) {
    if (!this.roomCode) return;
    const raw = JSON.stringify({ type, payload: { ...payload, target: guestId } });
    const relayIdx = this.guestRelayMap.get(guestId);
    if (relayIdx !== undefined) {
      const r = this.hostRelays[relayIdx];
      if (r && r.connected) {
        r.publish(this.topicH2C(this.roomCode), raw);
        return;
      }
    }
    for (const r of this.hostRelays) {
      if (r && r.connected) {
        r.publish(this.topicH2C(this.roomCode), raw);
      }
    }
  }

  private broadcastAsHost(type: string, payload: unknown, reliable = false) {
    if (type === 'room:state') {
      this.callbacks.onRoomState(payload as RoomLobbyState);
    } else if (type === 'match:cutscene') {
      this.callbacks.onCutscene(payload as NetCutsceneEvent);
    } else if (type === 'match:sound') {
      const p = payload as { sound: string; power?: number; pitch?: number };
      this.callbacks.onSound(p.sound, p.power, p.pitch);
    }

    if (!this.roomCode) return;
    const encoded = JSON.stringify({ type, payload });
    const fallbackGuestRelays = new Set<number>();

    if (this.hostRoom) {
      for (const pl of this.hostRoom.players.values()) {
        if (pl.clientId === this.clientId) continue;
        const peer = this.hostPeers.get(pl.clientId);
        const ch = reliable ? peer?.dcRel : peer?.dcFast;
        if (ch && ch.readyState === 'open') {
          try {
            ch.send(encoded);
            continue;
          } catch {
            // fallback to MQTT below
          }
        }
        const rIdx = this.guestRelayMap.get(pl.clientId);
        if (rIdx !== undefined) fallbackGuestRelays.add(rIdx);
      }
    }

    if (fallbackGuestRelays.size > 0) {
      for (const idx of fallbackGuestRelays) {
        const r = this.hostRelays[idx];
        if (r && r.connected) {
          r.publish(this.topicH2C(this.roomCode), encoded);
        }
      }
    }
  }

  private startHostRtcForGuest(guestId: string) {
    if (this.hostPeers.has(guestId) || typeof RTCPeerConnection === 'undefined') return;
    try {
      const pc = new RTCPeerConnection(RTC_CONFIG);
      const dcFast = pc.createDataChannel('fast', { ordered: false, maxRetransmits: 0 });
      const dcRel = pc.createDataChannel('rel', { ordered: true });
      const peer: HostPeerRtc = {
        pc,
        dcFast,
        dcRel,
        pendingIce: [],
        remoteDescSet: false,
        lastInputSeq: 0,
      };
      this.hostPeers.set(guestId, peer);

      const wireChannel = (dc: RTCDataChannel) => {
        dc.onmessage = (ev) => {
          this.handleHostMessage(String(ev.data), -1, guestId);
        };
      };
      wireChannel(dcFast);
      wireChannel(dcRel);

      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          this.sendSignalingToGuest(guestId, 'rtc:ice', {
            candidate: ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate,
          });
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
          if (this.hostPeers.get(guestId)?.pc === pc) {
            this.hostPeers.delete(guestId);
          }
        }
      };

      pc.createOffer()
        .then((offer) => pc.setLocalDescription(offer))
        .then(() => {
          if (pc.localDescription) {
            this.sendSignalingToGuest(guestId, 'rtc:offer', { sdp: pc.localDescription });
          }
        })
        .catch(() => {
          // MQTT fallback remains active automatically
        });
    } catch {
      // WebRTC unavailable, MQTT fallback remains active
    }
  }

  public createRoom(
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    gkDifficulty: GkDifficulty,
    matchMode: MatchMode = '3V3',
    queueType: QueueType = 'CASUAL',
    rp?: number,
    role: PlayerRole = 'CF',
    autoStart = false
  ) {
    this.cleanup();
    const code = genRoomCode();
    const hostClientId = `host_${Math.random().toString(36).slice(2, 8)}`;
    this.clientId = hostClientId;
    this.roomCode = code;
    this.isHost = true;
    this.pingMs = 1;
    this.callbacks.onPing?.(1);

    const cleanName = name.trim() ? name.trim().slice(0, 14) : 'Egoist';
    const room = createSimRoom(code, hostClientId, gkDifficulty, matchMode, queueType);
    room.players.set(hostClientId, {
      clientId: hostClientId,
      name: cleanName,
      team: 'BLUE',
      styleId,
      flowId,
      role,
      isHost: true,
      ready: true,
      rp,
    });
    this.hostRoom = room;

    if (autoStart) {
      this.hostAnnounced = true;
      this.callbacks.onConnected(hostClientId);
      this.callbacks.onMatchmakingMatched?.(serializeSimLobby(room));
      startSimMatch(room, this.makeHostSink());
      this.callbacks.onWorldState(buildSimWorldSnapshot(room, hostClientId));
    }

    let failedRelays = 0;
    this.hostRelays = RELAY_URLS.map((url, rIdx) => {
      const mqtt = new MqttWsClient([url], `blr_h_${hostClientId}_${rIdx}`, {
        onReady: () => {
          mqtt.subscribe(this.topicC2H(code));
        },
        onSubscribed: () => {
          if (!this.hostAnnounced && this.hostRoom === room) {
            this.hostAnnounced = true;
            this.callbacks.onConnected(hostClientId);
            this.callbacks.onRoomState(serializeSimLobby(room));
          }
        },
        onMessage: (_topic, raw) => {
          this.handleHostMessage(raw, rIdx);
        },
        onFail: () => {
          failedRelays++;
          if (failedRelays >= RELAY_URLS.length && !this.hostAnnounced) {
            this.callbacks.onRoomError('Aktif P2P röle sunucularına bağlanılamadı.');
          }
        },
      });
      mqtt.connect();
      return mqtt;
    });

    this.lastTickMs = Date.now();
    let rtcWorldAccum = 0;
    this.simInterval = setInterval(() => {
      if (!this.hostRoom || this.hostRoom.status !== 'PLAYING') return;
      const now = Date.now();
      const dt = Math.min(0.05, Math.max(0.004, (now - this.lastTickMs) / 1000));
      this.lastTickMs = now;
      stepSimRoom(this.hostRoom, dt, this.makeHostSink());

      rtcWorldAccum += dt;
      this.mqttWorldAccum += dt;
      if (rtcWorldAccum >= 0.028) {
        rtcWorldAccum = 0;
        this.hostRoom.worldSeq++;
        const baseSnap = buildSimWorldSnapshot(this.hostRoom, hostClientId);
        this.callbacks.onWorldState(baseSnap);

        const remotePlayers = Array.from(this.hostRoom.players.values()).filter(
          (pl) => pl.clientId !== hostClientId
        );
        if (remotePlayers.length > 0) {
          const huds: Record<string, NetWorldSnapshot['selfHud']> = {};
          for (const pl of remotePlayers) {
            huds[pl.clientId] = buildSimWorldSnapshot(this.hostRoom, pl.clientId).selfHud;
          }
          const { selfHud: _drop, ...sharedWorld } = baseSnap;
          const bundleStr = JSON.stringify({
            type: 'world:bundle',
            payload: { world: sharedWorld, huds },
          });

          const mqttFallbackRelays = new Set<number>();
          for (const pl of remotePlayers) {
            const peer = this.hostPeers.get(pl.clientId);
            if (peer?.dcFast && peer.dcFast.readyState === 'open') {
              try {
                peer.dcFast.send(bundleStr);
                continue;
              } catch {
                // fall back to MQTT below
              }
            }
            const rIdx = this.guestRelayMap.get(pl.clientId);
            if (rIdx !== undefined) mqttFallbackRelays.add(rIdx);
          }

          // Only send via MQTT at conservative 18Hz if any peer has no direct WebRTC DataChannel
          if (mqttFallbackRelays.size > 0 && this.mqttWorldAccum >= 0.055) {
            this.mqttWorldAccum = 0;
            for (const rIdx of mqttFallbackRelays) {
              const r = this.hostRelays[rIdx];
              if (r && r.connected) {
                r.publish(this.topicH2C(this.hostRoom.roomCode), bundleStr);
              }
            }
          }
        }
      }
    }, 16);
  }

  public joinMatchmaking(
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    matchMode: MatchMode,
    queueType: QueueType,
    rp: number,
    role: PlayerRole = 'CF'
  ) {
    this.cleanup();
    const startedAt = Date.now();
    this.pendingQuickMatch = { name, styleId, flowId, role, matchMode, queueType, rp, startedAt };
    this.callbacks.onMatchmakingStatus?.({
      searching: true,
      queueType,
      matchMode,
      elapsedSec: 0,
      playersInQueue: 1,
    });
    this.matchmakingTimer = setInterval(() => {
      if (!this.pendingQuickMatch) return;
      const elapsedSec = Math.floor((Date.now() - this.pendingQuickMatch.startedAt) / 1000);
      if (elapsedSec >= 3) {
        this.forceStartMatchmaking();
      } else {
        this.callbacks.onMatchmakingStatus?.({
          searching: true,
          queueType: this.pendingQuickMatch.queueType,
          matchMode: this.pendingQuickMatch.matchMode,
          elapsedSec,
          playersInQueue: 1,
        });
      }
    }, 800);
  }

  public cancelMatchmaking() {
    if (this.matchmakingTimer !== null) {
      clearInterval(this.matchmakingTimer);
      this.matchmakingTimer = null;
    }
    this.pendingQuickMatch = null;
    this.callbacks.onMatchmakingStatus?.({
      searching: false,
      queueType: 'CASUAL',
      matchMode: '3V3',
      elapsedSec: 0,
      playersInQueue: 0,
    });
  }

  public forceStartMatchmaking() {
    const q = this.pendingQuickMatch;
    if (!q) return;
    if (this.matchmakingTimer !== null) {
      clearInterval(this.matchmakingTimer);
      this.matchmakingTimer = null;
    }
    this.pendingQuickMatch = null;
    const gkDiff: GkDifficulty = q.queueType === 'RANKED' ? 'HARD' : 'MEDIUM';
    this.createRoom(q.name, q.styleId, q.flowId, gkDiff, q.matchMode, q.queueType, q.rp, q.role, true);
  }

  private handleHostMessage(raw: string, relayIdx: number, fixedSenderId?: string) {
    if (!this.hostRoom) return;
    let msg: { from?: string; type?: string; payload?: Record<string, unknown> };
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const senderId = fixedSenderId || (typeof msg.from === 'string' ? msg.from : '');
    if (!senderId || senderId === this.clientId) return;
    if (relayIdx >= 0) {
      this.guestRelayMap.set(senderId, relayIdx);
    }
    const p = msg.payload ?? {};
    const room = this.hostRoom;

    if (msg.type === 'room:join_req') {
      if (!room.players.has(senderId)) {
        if (room.players.size >= 6) {
          this.sendSignalingToGuest(senderId, 'room:error_for', {
            message: 'Oda dolu (Maksimum 6 oyuncu).',
          });
          return;
        }
        const blueCount = Array.from(room.players.values()).filter((pl) => pl.team === 'BLUE').length;
        const redCount = Array.from(room.players.values()).filter((pl) => pl.team === 'RED').length;
        const autoTeam: 'BLUE' | 'RED' = redCount < blueCount ? 'RED' : 'BLUE';
        const playerName =
          typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Oyuncu';
        const styleId = (
          typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'iskender'
        ) as StyleId;
        const flowId = (
          typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist'
        ) as FlowId;
        const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : undefined;
        const role: PlayerRole = typeof p.role === 'string' && p.role in ROLES ? (p.role as PlayerRole) : 'CF';

        room.players.set(senderId, {
          clientId: senderId,
          name: playerName,
          team: autoTeam,
          styleId,
          flowId,
          role,
          isHost: false,
          ready: true,
          rp,
        });
      }
      this.broadcastAsHost('room:state', serializeSimLobby(room), true);
      this.startHostRtcForGuest(senderId);

      if (room.status === 'PLAYING') {
        room.actors = buildSimActors(room);
        const snap = buildSimWorldSnapshot(room, senderId);
        const { selfHud, ...sharedWorld } = snap;
        this.broadcastAsHost('world:bundle', {
          world: sharedWorld,
          huds: { [senderId]: selfHud },
        });
      }
    } else if (msg.type === 'rtc:answer') {
      const peer = this.hostPeers.get(senderId);
      const sdp = p.sdp as RTCSessionDescriptionInit | undefined;
      if (peer && sdp && !peer.remoteDescSet) {
        peer.pc
          .setRemoteDescription(new RTCSessionDescription(sdp))
          .then(() => {
            peer.remoteDescSet = true;
            for (const c of peer.pendingIce) {
              peer.pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => {});
            }
            peer.pendingIce = [];
          })
          .catch(() => {});
      }
    } else if (msg.type === 'rtc:ice') {
      const peer = this.hostPeers.get(senderId);
      const candidate = p.candidate as RTCIceCandidateInit | undefined;
      if (peer && candidate) {
        if (peer.remoteDescSet) {
          peer.pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
        } else {
          peer.pendingIce.push(candidate);
        }
      }
    } else if (msg.type === 'ping:req') {
      const peer = this.hostPeers.get(senderId);
      const replyStr = JSON.stringify({ type: 'ping:res', payload: { target: senderId, ts: p.ts } });
      if (peer?.dcFast && peer.dcFast.readyState === 'open') {
        try {
          peer.dcFast.send(replyStr);
          return;
        } catch {
          // fall back
        }
      }
      this.sendSignalingToGuest(senderId, 'ping:res', { ts: p.ts });
    } else if (msg.type === 'room:leave_req') {
      this.guestRelayMap.delete(senderId);
      const peer = this.hostPeers.get(senderId);
      if (peer) {
        try {
          peer.dcFast?.close();
          peer.dcRel?.close();
          peer.pc.close();
        } catch {
          // ignore
        }
        this.hostPeers.delete(senderId);
      }
      if (room.players.delete(senderId)) {
        this.broadcastAsHost('room:state', serializeSimLobby(room), true);
      }
    } else if (msg.type === 'room:update_player') {
      const info = room.players.get(senderId);
      if (!info) return;
      if (typeof p.styleId === 'string' && p.styleId in STYLES) info.styleId = p.styleId as StyleId;
      if (typeof p.flowId === 'string' && p.flowId in FLOWS) info.flowId = p.flowId as FlowId;
      if (p.team === 'BLUE' || p.team === 'RED') info.team = p.team;
      if (typeof p.role === 'string' && p.role in ROLES) info.role = p.role as PlayerRole;
      if (typeof p.name === 'string' && p.name.trim()) info.name = p.name.trim().slice(0, 14);
      if (typeof p.rp === 'number' && Number.isFinite(p.rp)) info.rp = Math.max(0, Math.round(p.rp));
      this.broadcastAsHost('room:state', serializeSimLobby(room), true);
    } else if (msg.type === 'player:input') {
      const seq = typeof p.seq === 'number' ? p.seq : 0;
      const peer = this.hostPeers.get(senderId);
      if (peer && seq > 0) {
        if (seq <= peer.lastInputSeq) return;
        peer.lastInputSeq = seq;
      }
      applySimPlayerInput(
        room,
        senderId,
        Number(p.moveX),
        Number(p.moveZ),
        Boolean(p.sprint),
        Boolean(p.chargingShot),
        typeof p.aimYaw === 'number' ? p.aimYaw : undefined,
        Boolean(p.lockYaw)
      );
    } else if (msg.type === 'player:action' && typeof p.action === 'string') {
      handleSimDiscreteAction(room, senderId, p.action, this.makeHostSink());
    }
  }

  public joinRoom(
    roomCode: string,
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    rp?: number,
    role: PlayerRole = 'CF'
  ) {
    const cleanCode = roomCode.trim().toUpperCase();
    if (!cleanCode) {
      this.callbacks.onRoomError('Lütfen oda kodunu gir.');
      return;
    }

    this.cleanup();
    this.isHost = false;
    this.roomCode = cleanCode;
    const myId = `g_${Math.random().toString(36).slice(2, 9)}`;
    this.clientId = myId;
    this.callbacks.onConnected(myId);

    const joinPayload = JSON.stringify({
      from: myId,
      type: 'room:join_req',
      payload: { name, styleId, flowId, rp, role },
    });

    let failedProbes = 0;
    const subscribedProbes: MqttWsClient[] = [];

    this.guestProbes = RELAY_URLS.map((url, idx) => {
      const probe = new MqttWsClient([url], `blr_g_${myId}_${idx}`, {
        onReady: () => {
          if (this.joinedConfirmed || this.roomCode !== cleanCode) return;
          probe.subscribe(this.topicH2C(cleanCode));
        },
        onSubscribed: () => {
          if (this.joinedConfirmed || this.roomCode !== cleanCode) return;
          subscribedProbes.push(probe);
          probe.publish(this.topicC2H(cleanCode), joinPayload);
        },
        onMessage: (_topic, raw) => {
          this.handleGuestMessage(raw, myId, probe);
        },
        onFail: () => {
          failedProbes++;
          if (!this.joinedConfirmed && failedProbes >= RELAY_URLS.length) {
            this.callbacks.onRoomError('Röle sunucularına bağlanılamadı.');
          }
        },
      });
      probe.connect();
      return probe;
    });

    this.joinRetryTimer = setInterval(() => {
      if (this.joinedConfirmed || this.roomCode !== cleanCode) return;
      for (const p of subscribedProbes) {
        if (p.connected) {
          p.publish(this.topicC2H(cleanCode), joinPayload);
        }
      }
    }, 650);

    this.joinTimeoutTimer = setTimeout(() => {
      if (!this.joinedConfirmed) {
        if (this.joinRetryTimer) {
          clearInterval(this.joinRetryTimer);
          this.joinRetryTimer = null;
        }
        for (const p of this.guestProbes) p?.close();
        this.guestProbes = [];
        this.callbacks.onRoomError(
          `"${cleanCode}" kodlu P2P odasından yanıt gelmedi. Oda kurucusunun lobi/maç ekranının açık olduğundan ve 5 haneli P2P kodunu verdiğinden emin ol.`
        );
      }
    }, 11000);
  }

  private handleGuestRtcOffer(sdp: RTCSessionDescriptionInit, myId: string) {
    if (typeof RTCPeerConnection === 'undefined') return;
    if (this.guestPc) {
      try {
        this.guestPc.close();
      } catch {
        // ignore
      }
    }
    this.guestDcFast = null;
    this.guestDcRel = null;
    this.guestRemoteDescSet = false;
    this.pendingGuestIce = [];

    const pc = new RTCPeerConnection(RTC_CONFIG);
    this.guestPc = pc;

    pc.ondatachannel = (ev) => {
      const ch = ev.channel;
      if (ch.label === 'fast') {
        this.guestDcFast = ch;
        ch.onopen = () => {
          this.publishAsGuest('ping:req', { ts: performance.now() }, false);
        };
        ch.onclose = () => {
          if (this.guestDcFast === ch) this.guestDcFast = null;
        };
        ch.onmessage = (msgEv) => this.handleGuestMessage(String(msgEv.data), myId);
      } else if (ch.label === 'rel') {
        this.guestDcRel = ch;
        ch.onclose = () => {
          if (this.guestDcRel === ch) this.guestDcRel = null;
        };
        ch.onmessage = (msgEv) => this.handleGuestMessage(String(msgEv.data), myId);
      }
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        this.publishViaMqttOnly('rtc:ice', {
          candidate: ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate,
        });
      }
    };

    pc.setRemoteDescription(new RTCSessionDescription(sdp))
      .then(() => {
        this.guestRemoteDescSet = true;
        for (const c of this.pendingGuestIce) {
          pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => {});
        }
        this.pendingGuestIce = [];
        return pc.createAnswer();
      })
      .then((ans) => pc.setLocalDescription(ans))
      .then(() => {
        if (pc.localDescription) {
          this.publishViaMqttOnly('rtc:answer', { sdp: pc.localDescription });
        }
      })
      .catch(() => {
        // stay on MQTT fallback cleanly
      });
  }

  private handleGuestMessage(raw: string, myId: string, sourceProbe?: MqttWsClient) {
    let msg: { type?: string; payload?: unknown };
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const p = msg.payload as Record<string, unknown>;
    if (typeof p?.target === 'string' && p.target !== myId) {
      return;
    }

    if (sourceProbe && !this.joinedConfirmed && msg.type === 'room:state') {
      this.joinedConfirmed = true;
      this.guestMqtt = sourceProbe;
      for (const other of this.guestProbes) {
        if (other && other !== sourceProbe) other.close();
      }
      this.guestProbes = [];
      if (this.joinRetryTimer) {
        clearInterval(this.joinRetryTimer);
        this.joinRetryTimer = null;
      }
      if (this.joinTimeoutTimer) {
        clearTimeout(this.joinTimeoutTimer);
        this.joinTimeoutTimer = null;
      }
      if (this.pingTimer) clearInterval(this.pingTimer);
      this.publishAsGuest('ping:req', { ts: performance.now() }, false);
      this.pingTimer = setInterval(() => {
        this.publishAsGuest('ping:req', { ts: performance.now() }, false);
      }, 2000);
    }

    if (msg.type === 'room:state') {
      this.callbacks.onRoomState(msg.payload as RoomLobbyState);
    } else if (msg.type === 'rtc:offer' && p?.sdp) {
      this.handleGuestRtcOffer(p.sdp as RTCSessionDescriptionInit, myId);
    } else if (msg.type === 'rtc:ice' && p?.candidate && this.guestPc) {
      const cand = p.candidate as RTCIceCandidateInit;
      if (this.guestRemoteDescSet) {
        this.guestPc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
      } else {
        this.pendingGuestIce.push(cand);
      }
    } else if (msg.type === 'ping:res') {
      if (typeof p?.ts === 'number') {
        const rtt = Math.max(1, Math.round(performance.now() - p.ts));
        this.pingMs = rtt;
        this.callbacks.onPing?.(rtt);
      }
    } else if (msg.type === 'room:error_for') {
      if (typeof p?.message === 'string') {
        this.callbacks.onRoomError(p.message);
      }
    } else if (msg.type === 'world:bundle') {
      const bundle = msg.payload as {
        world: Omit<NetWorldSnapshot, 'selfHud'>;
        huds: Record<string, NetWorldSnapshot['selfHud']>;
      };
      if (bundle?.world) {
        const seq = bundle.world.seq ?? 0;
        if (seq > 0 && seq <= this.lastAppliedWorldSeq) return;
        if (seq > 0) this.lastAppliedWorldSeq = seq;
        this.callbacks.onWorldState({
          ...bundle.world,
          selfHud: bundle.huds?.[myId],
        });
      }
    } else if (msg.type === 'match:cutscene') {
      this.callbacks.onCutscene(msg.payload as NetCutsceneEvent);
    } else if (msg.type === 'match:sound' && typeof p?.sound === 'string') {
      this.callbacks.onSound(
        p.sound,
        typeof p.power === 'number' ? p.power : undefined,
        typeof p.pitch === 'number' ? p.pitch : undefined
      );
    }
  }

  private publishViaMqttOnly(type: string, payload: Record<string, unknown>) {
    if (this.guestMqtt && this.guestMqtt.connected && this.roomCode && this.clientId) {
      this.guestMqtt.publish(
        this.topicC2H(this.roomCode),
        JSON.stringify({ from: this.clientId, type, payload })
      );
    }
  }

  private publishAsGuest(type: string, payload: Record<string, unknown>, reliable = true) {
    if (!this.clientId) return;
    const raw = JSON.stringify({ from: this.clientId, type, payload });
    const ch = reliable ? this.guestDcRel : this.guestDcFast;
    if (ch && ch.readyState === 'open') {
      try {
        ch.send(raw);
        return;
      } catch {
        // fallback to MQTT below
      }
    }
    if (this.guestMqtt && this.guestMqtt.connected && this.roomCode) {
      this.guestMqtt.publish(this.topicC2H(this.roomCode), raw);
    }
  }

  public leaveRoom() {
    if (!this.isHost) {
      this.publishAsGuest('room:leave_req', {}, true);
    }
    this.cleanup();
    if (!this.clientId) this.clientId = `p2p_${Math.random().toString(36).slice(2, 9)}`;
    this.callbacks.onConnected(this.clientId);
  }

  public updatePlayer(patch: {
    name?: string;
    styleId?: StyleId;
    flowId?: FlowId;
    team?: 'BLUE' | 'RED';
    role?: PlayerRole;
    rp?: number;
  }) {
    if (this.isHost && this.hostRoom && this.clientId) {
      const info = this.hostRoom.players.get(this.clientId);
      if (!info) return;
      if (patch.styleId) info.styleId = patch.styleId;
      if (patch.flowId) info.flowId = patch.flowId;
      if (patch.team) info.team = patch.team;
      if (patch.role) info.role = patch.role;
      if (patch.name?.trim()) info.name = patch.name.trim().slice(0, 14);
      if (typeof patch.rp === 'number') info.rp = patch.rp;
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom), true);
    } else {
      this.publishAsGuest('room:update_player', patch, true);
    }
  }

  public setGkDifficulty(gkDifficulty: GkDifficulty) {
    if (this.isHost && this.hostRoom) {
      this.hostRoom.gkDifficulty = gkDifficulty;
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom), true);
    }
  }

  public setMatchMode(matchMode: MatchMode) {
    if (this.isHost && this.hostRoom) {
      this.hostRoom.matchMode = matchMode;
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom), true);
    }
  }

  public startMatch() {
    if (this.isHost && this.hostRoom) {
      startSimMatch(this.hostRoom, this.makeHostSink());
    }
  }

  public sendInput(moveX: number, moveZ: number, sprint: boolean, chargingShot: boolean, aimYaw?: number, lockYaw?: boolean) {
    if (this.isHost && this.hostRoom && this.clientId) {
      applySimPlayerInput(this.hostRoom, this.clientId, moveX, moveZ, sprint, chargingShot, aimYaw, lockYaw);
      return;
    }

    const qMoveX = Math.round(moveX * 100) / 100;
    const qMoveZ = Math.round(moveZ * 100) / 100;
    const qAim = aimYaw !== undefined ? Math.round(aimYaw * 100) / 100 : undefined;
    const key = `${qMoveX},${qMoveZ},${sprint ? 1 : 0},${chargingShot ? 1 : 0},${qAim ?? ''},${lockYaw ? 1 : 0}`;
    if (key === this.lastInputKey && Math.abs(qMoveX) < 0.02 && Math.abs(qMoveZ) < 0.02 && !chargingShot) {
      return;
    }

    const usingDirectRtc = Boolean(this.guestDcFast && this.guestDcFast.readyState === 'open');
    if (!usingDirectRtc) {
      // Prevent public MQTT broker throttling when WebRTC isn't open yet
      const now = performance.now();
      const urgent = key !== this.lastInputKey && (Math.abs(qMoveX) < 0.02 && Math.abs(qMoveZ) < 0.02 || chargingShot);
      if (!urgent && now - this.lastMqttInputSentMs < 46) {
        return;
      }
      this.lastMqttInputSentMs = now;
    }

    this.lastInputKey = key;
    this.guestInputSeq++;
    this.publishAsGuest(
      'player:input',
      {
        seq: this.guestInputSeq,
        moveX: qMoveX,
        moveZ: qMoveZ,
        sprint,
        chargingShot,
        aimYaw: qAim,
        lockYaw,
      },
      false
    );
  }

  public sendAction(action: OnlineActionType) {
    if (this.isHost && this.hostRoom && this.clientId) {
      handleSimDiscreteAction(this.hostRoom, this.clientId, action, this.makeHostSink());
    } else {
      this.publishAsGuest('player:action', { action }, true);
    }
  }
}
