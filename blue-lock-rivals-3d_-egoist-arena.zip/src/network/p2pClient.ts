import { FLOWS, STYLES } from '../data/styles.ts';
import type {
  FlowId,
  GkDifficulty,
  MatchMode,
  NetCutsceneEvent,
  NetWorldSnapshot,
  RoomLobbyState,
  StyleId,
} from '../types/game.ts';
import { MqttWsClient } from './mqttWs.ts';
import type { MultiplayerClient, OnlineActionType, OnlineClientCallbacks } from './onlineClient.ts';
import {
  applySimPlayerInput,
  buildSimActors,
  buildSimWorldSnapshot,
  createSimRoom,
  handleSimDiscreteAction,
  serializeSimLobby,
  type SimBroadcastSink,
  type SimRoomState,
  startSimMatch,
  stepSimRoom,
} from './roomSimulation.ts';

const RELAY_URLS = [
  'wss://test.mosquitto.org:8081/mqtt',
  'wss://broker.emqx.io:8084/mqtt',
  'wss://broker.hivemq.com:8884/mqtt',
];

function genRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 5; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

export class P2POnlineClient implements MultiplayerClient {
  private callbacks: OnlineClientCallbacks;
  public clientId: string | null = null;

  private mqtt: MqttWsClient | null = null;
  private roomCode: string | null = null;
  private isHost = false;
  private hostRoom: SimRoomState | null = null;
  private simInterval: ReturnType<typeof setInterval> | null = null;
  private joinRetryTimer: ReturnType<typeof setInterval> | null = null;
  private joinTimeoutTimer: ReturnType<typeof setTimeout> | null = null;
  private joinedConfirmed = false;
  private lastTickMs = 0;

  constructor(callbacks: OnlineClientCallbacks) {
    this.callbacks = callbacks;
  }

  private topicC2H(code: string): string {
    return `blr3d/v2/${code}/c2h`;
  }

  private topicH2C(code: string): string {
    return `blr3d/v2/${code}/h2c`;
  }

  public connect() {
    if (!this.clientId) {
      this.clientId = `p2p_${Math.random().toString(36).slice(2, 9)}`;
    }
    this.callbacks.onConnected(this.clientId);
  }

  public disconnect() {
    this.cleanup();
    this.callbacks.onDisconnected();
  }

  private cleanup() {
    if (this.simInterval !== null) {
      clearInterval(this.simInterval);
      this.simInterval = null;
    }
    if (this.joinRetryTimer !== null) {
      clearInterval(this.joinRetryTimer);
      this.joinRetryTimer = null;
    }
    if (this.joinTimeoutTimer !== null) {
      clearTimeout(this.joinTimeoutTimer);
      this.joinTimeoutTimer = null;
    }
    if (this.mqtt) {
      this.mqtt.close();
      this.mqtt = null;
    }
    this.hostRoom = null;
    this.roomCode = null;
    this.isHost = false;
    this.joinedConfirmed = false;
  }

  private makeHostSink(): SimBroadcastSink {
    return {
      broadcastLobby: (lobby) => this.broadcastAsHost('room:state', lobby),
      broadcastCutscene: (evt) => this.broadcastAsHost('match:cutscene', evt),
      broadcastSound: (sound, power, pitch) =>
        this.broadcastAsHost('match:sound', { sound, power, pitch }),
    };
  }

  private broadcastAsHost(type: string, payload: unknown) {
    if (type === 'room:state') {
      this.callbacks.onRoomState(payload as RoomLobbyState);
    } else if (type === 'match:cutscene') {
      this.callbacks.onCutscene(payload as NetCutsceneEvent);
    } else if (type === 'match:sound') {
      const p = payload as { sound: string; power?: number; pitch?: number };
      this.callbacks.onSound(p.sound, p.power, p.pitch);
    }
    if (this.mqtt && this.mqtt.connected && this.roomCode) {
      this.mqtt.publish(this.topicH2C(this.roomCode), JSON.stringify({ type, payload }));
    }
  }

  public createRoom(name: string, styleId: StyleId, flowId: FlowId, gkDifficulty: GkDifficulty, matchMode: MatchMode = '3V3') {
    this.cleanup();
    const code = genRoomCode();
    const hostClientId = `host_${Math.random().toString(36).slice(2, 8)}`;
    this.clientId = hostClientId;
    this.roomCode = code;
    this.isHost = true;

    const cleanName = name.trim() ? name.trim().slice(0, 14) : 'Egoist';
    const room = createSimRoom(code, hostClientId, gkDifficulty, matchMode);
    room.players.set(hostClientId, {
      clientId: hostClientId,
      name: cleanName,
      team: 'BLUE',
      styleId,
      flowId,
      isHost: true,
      ready: true,
    });
    this.hostRoom = room;

    const mqtt = new MqttWsClient(RELAY_URLS, `blr_${hostClientId}`, {
      onReady: () => {
        mqtt.subscribe(this.topicC2H(code));
        this.callbacks.onConnected(hostClientId);
        this.callbacks.onRoomState(serializeSimLobby(room));
      },
      onMessage: (_topic, raw) => {
        this.handleHostMessage(raw);
      },
      onFail: (reason) => {
        this.callbacks.onRoomError(reason);
      },
    });
    this.mqtt = mqtt;
    mqtt.connect();

    this.lastTickMs = Date.now();
    this.simInterval = setInterval(() => {
      if (!this.hostRoom || this.hostRoom.status !== 'PLAYING') return;
      const now = Date.now();
      const dt = Math.min(0.05, (now - this.lastTickMs) / 1000);
      this.lastTickMs = now;
      stepSimRoom(this.hostRoom, dt, this.makeHostSink());
      this.hostRoom.tickAccum += dt;
      if (this.hostRoom.tickAccum >= 0.05) {
        this.hostRoom.tickAccum = 0;
        const baseSnap = buildSimWorldSnapshot(this.hostRoom, hostClientId);
        this.callbacks.onWorldState(baseSnap);

        if (this.mqtt && this.mqtt.connected && this.roomCode) {
          const huds: Record<string, NetWorldSnapshot['selfHud']> = {};
          for (const pl of this.hostRoom.players.values()) {
            if (pl.clientId !== hostClientId) {
              huds[pl.clientId] = buildSimWorldSnapshot(this.hostRoom, pl.clientId).selfHud;
            }
          }
          const { selfHud: _drop, ...sharedWorld } = baseSnap;
          this.mqtt.publish(
            this.topicH2C(this.roomCode),
            JSON.stringify({
              type: 'world:bundle',
              payload: { world: sharedWorld, huds },
            })
          );
        }
      }
    }, 33);
  }

  private handleHostMessage(raw: string) {
    if (!this.hostRoom) return;
    let msg: { from?: string; type?: string; payload?: Record<string, unknown> };
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const senderId = typeof msg.from === 'string' ? msg.from : '';
    if (!senderId || senderId === this.clientId) return;
    const p = msg.payload ?? {};
    const room = this.hostRoom;

    if (msg.type === 'room:join_req') {
      if (!room.players.has(senderId)) {
        if (room.players.size >= 6) {
          this.broadcastAsHost('room:error_for', {
            target: senderId,
            message: 'Oda dolu (Maksimum 6 oyuncu).',
          });
          return;
        }
        const blueCount = Array.from(room.players.values()).filter((pl) => pl.team === 'BLUE').length;
        const redCount = Array.from(room.players.values()).filter((pl) => pl.team === 'RED').length;
        const autoTeam: 'BLUE' | 'RED' = redCount < blueCount ? 'RED' : 'BLUE';
        const playerName =
          typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Oyuncu';
        const styleId = (
          typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'iskender'
        ) as StyleId;
        const flowId = (
          typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist'
        ) as FlowId;

        room.players.set(senderId, {
          clientId: senderId,
          name: playerName,
          team: autoTeam,
          styleId,
          flowId,
          isHost: false,
          ready: true,
        });
      }
      this.broadcastAsHost('room:state', serializeSimLobby(room));
      if (room.status === 'PLAYING') {
        room.actors = buildSimActors(room);
        const snap = buildSimWorldSnapshot(room, senderId);
        const { selfHud, ...sharedWorld } = snap;
        this.broadcastAsHost('world:bundle', {
          world: sharedWorld,
          huds: { [senderId]: selfHud },
        });
      }
    } else if (msg.type === 'room:leave_req') {
      if (room.players.delete(senderId)) {
        this.broadcastAsHost('room:state', serializeSimLobby(room));
      }
    } else if (msg.type === 'room:update_player') {
      const info = room.players.get(senderId);
      if (!info) return;
      if (typeof p.styleId === 'string' && p.styleId in STYLES) info.styleId = p.styleId as StyleId;
      if (typeof p.flowId === 'string' && p.flowId in FLOWS) info.flowId = p.flowId as FlowId;
      if (p.team === 'BLUE' || p.team === 'RED') info.team = p.team;
      if (typeof p.name === 'string' && p.name.trim()) info.name = p.name.trim().slice(0, 14);
      this.broadcastAsHost('room:state', serializeSimLobby(room));
    } else if (msg.type === 'player:input') {
      applySimPlayerInput(
        room,
        senderId,
        Number(p.moveX),
        Number(p.moveZ),
        Boolean(p.sprint),
        Boolean(p.chargingShot),
        typeof p.aimYaw === 'number' ? p.aimYaw : undefined,
        Boolean(p.lockYaw)
      );
    } else if (msg.type === 'player:action' && typeof p.action === 'string') {
      handleSimDiscreteAction(room, senderId, p.action, this.makeHostSink());
    }
  }

  public joinRoom(roomCode: string, name: string, styleId: StyleId, flowId: FlowId) {
    const cleanCode = roomCode.trim().toUpperCase();
    if (!cleanCode) {
      this.callbacks.onRoomError('Lütfen oda kodunu gir.');
      return;
    }

    this.cleanup();
    this.isHost = false;
    this.roomCode = cleanCode;
    const myId = `g_${Math.random().toString(36).slice(2, 9)}`;
    this.clientId = myId;

    const sendJoin = () => {
      if (this.mqtt && this.mqtt.connected) {
        this.mqtt.publish(
          this.topicC2H(cleanCode),
          JSON.stringify({
            from: myId,
            type: 'room:join_req',
            payload: { name, styleId, flowId },
          })
        );
      }
    };

    const mqtt = new MqttWsClient(RELAY_URLS, `blr_${myId}`, {
      onReady: () => {
        mqtt.subscribe(this.topicH2C(cleanCode));
        this.callbacks.onConnected(myId);
        // Send immediately and retry every 1.2s until host responds
        setTimeout(sendJoin, 150);
        this.joinRetryTimer = setInterval(() => {
          if (!this.joinedConfirmed) sendJoin();
        }, 1200);
        this.joinTimeoutTimer = setTimeout(() => {
          if (!this.joinedConfirmed) {
            if (this.joinRetryTimer) clearInterval(this.joinRetryTimer);
            this.callbacks.onRoomError(
              `"${cleanCode}" kodlu P2P odasından yanıt gelmedi. Oda kurucusunun lobi/maç ekranının açık olduğundan emin ol.`
            );
          }
        }, 8000);
      },
      onMessage: (_topic, raw) => {
        this.handleGuestMessage(raw, myId);
      },
      onFail: (reason) => {
        this.callbacks.onRoomError(reason);
      },
    });
    this.mqtt = mqtt;
    mqtt.connect();
  }

  private handleGuestMessage(raw: string, myId: string) {
    let msg: { type?: string; payload?: unknown };
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const p = msg.payload as Record<string, unknown>;
    if (msg.type === 'room:state') {
      if (!this.joinedConfirmed) {
        this.joinedConfirmed = true;
        if (this.joinRetryTimer) {
          clearInterval(this.joinRetryTimer);
          this.joinRetryTimer = null;
        }
        if (this.joinTimeoutTimer) {
          clearTimeout(this.joinTimeoutTimer);
          this.joinTimeoutTimer = null;
        }
      }
      this.callbacks.onRoomState(msg.payload as RoomLobbyState);
    } else if (msg.type === 'room:error_for') {
      if (p?.target === myId && typeof p?.message === 'string') {
        this.callbacks.onRoomError(p.message);
      }
    } else if (msg.type === 'world:bundle') {
      const bundle = msg.payload as {
        world: Omit<NetWorldSnapshot, 'selfHud'>;
        huds: Record<string, NetWorldSnapshot['selfHud']>;
      };
      if (bundle?.world) {
        this.callbacks.onWorldState({
          ...bundle.world,
          selfHud: bundle.huds?.[myId],
        });
      }
    } else if (msg.type === 'match:cutscene') {
      this.callbacks.onCutscene(msg.payload as NetCutsceneEvent);
    } else if (msg.type === 'match:sound' && typeof p?.sound === 'string') {
      this.callbacks.onSound(
        p.sound,
        typeof p.power === 'number' ? p.power : undefined,
        typeof p.pitch === 'number' ? p.pitch : undefined
      );
    }
  }

  private publishAsGuest(type: string, payload: Record<string, unknown>) {
    if (this.mqtt && this.mqtt.connected && this.roomCode && this.clientId) {
      this.mqtt.publish(
        this.topicC2H(this.roomCode),
        JSON.stringify({ from: this.clientId, type, payload })
      );
    }
  }

  public leaveRoom() {
    if (!this.isHost) {
      this.publishAsGuest('room:leave_req', {});
    }
    this.cleanup();
    if (!this.clientId) this.clientId = `p2p_${Math.random().toString(36).slice(2, 9)}`;
    this.callbacks.onConnected(this.clientId);
  }

  public updatePlayer(patch: {
    name?: string;
    styleId?: StyleId;
    flowId?: FlowId;
    team?: 'BLUE' | 'RED';
  }) {
    if (this.isHost && this.hostRoom && this.clientId) {
      const info = this.hostRoom.players.get(this.clientId);
      if (!info) return;
      if (patch.styleId) info.styleId = patch.styleId;
      if (patch.flowId) info.flowId = patch.flowId;
      if (patch.team) info.team = patch.team;
      if (patch.name?.trim()) info.name = patch.name.trim().slice(0, 14);
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom));
    } else {
      this.publishAsGuest('room:update_player', patch);
    }
  }

  public setGkDifficulty(gkDifficulty: GkDifficulty) {
    if (this.isHost && this.hostRoom) {
      this.hostRoom.gkDifficulty = gkDifficulty;
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom));
    }
  }

  public setMatchMode(matchMode: MatchMode) {
    if (this.isHost && this.hostRoom) {
      this.hostRoom.matchMode = matchMode;
      this.broadcastAsHost('room:state', serializeSimLobby(this.hostRoom));
    }
  }

  public startMatch() {
    if (this.isHost && this.hostRoom) {
      startSimMatch(this.hostRoom, this.makeHostSink());
    }
  }

  public sendInput(moveX: number, moveZ: number, sprint: boolean, chargingShot: boolean, aimYaw?: number, lockYaw?: boolean) {
    if (this.isHost && this.hostRoom && this.clientId) {
      applySimPlayerInput(this.hostRoom, this.clientId, moveX, moveZ, sprint, chargingShot, aimYaw, lockYaw);
    } else {
      this.publishAsGuest('player:input', { moveX, moveZ, sprint, chargingShot, aimYaw, lockYaw });
    }
  }

  public sendAction(action: OnlineActionType) {
    if (this.isHost && this.hostRoom && this.clientId) {
      handleSimDiscreteAction(this.hostRoom, this.clientId, action, this.makeHostSink());
    } else {
      this.publishAsGuest('player:action', { action });
    }
  }
}
