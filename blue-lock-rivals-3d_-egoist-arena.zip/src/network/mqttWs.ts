// Minimal, dependency-free MQTT 3.1.1 client over WebSocket (TCP/TLS port 443).
// Works through symmetric NAT, CGNAT, mobile networks, and AI Studio Share iframes.

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function encodeUtf8String(str: string): Uint8Array {
  const bytes = encoder.encode(str);
  const out = new Uint8Array(2 + bytes.length);
  out[0] = (bytes.length >> 8) & 0xff;
  out[1] = bytes.length & 0xff;
  out.set(bytes, 2);
  return out;
}

function encodeRemainingLength(len: number): number[] {
  const digits: number[] = [];
  let x = len;
  do {
    let encodedByte = x % 128;
    x = Math.floor(x / 128);
    if (x > 0) encodedByte |= 0x80;
    digits.push(encodedByte);
  } while (x > 0);
  return digits;
}

function buildPacket(headerByte: number, bodyParts: Uint8Array[]): Uint8Array {
  let bodyLen = 0;
  for (const p of bodyParts) bodyLen += p.length;
  const rem = encodeRemainingLength(bodyLen);
  const out = new Uint8Array(1 + rem.length + bodyLen);
  out[0] = headerByte;
  out.set(rem, 1);
  let offset = 1 + rem.length;
  for (const p of bodyParts) {
    out.set(p, offset);
    offset += p.length;
  }
  return out;
}

function sendRaw(ws: WebSocket, bytes: Uint8Array) {
  ws.send(bytes.slice().buffer);
}

export class MqttWsClient {
  private ws: WebSocket | null = null;
  private buffer: Uint8Array = new Uint8Array(0);
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private packetId = 1;
  private closed = false;
  public connected = false;

  private urls: string[];
  private clientId: string;
  private onReady: () => void;
  private onMessage: (topic: string, payload: string) => void;
  private onFail: (reason: string) => void;

  constructor(
    urls: string[],
    clientId: string,
    handlers: {
      onReady: () => void;
      onMessage: (topic: string, payload: string) => void;
      onFail: (reason: string) => void;
    }
  ) {
    this.urls = urls;
    this.clientId = clientId;
    this.onReady = handlers.onReady;
    this.onMessage = handlers.onMessage;
    this.onFail = handlers.onFail;
  }

  public connect(urlIndex = 0) {
    if (this.closed) return;
    if (urlIndex >= this.urls.length) {
      this.onFail('Aktif röle sunucularına bağlanılamadı.');
      return;
    }
    const url = this.urls[urlIndex];
    let settled = false;

    try {
      const ws = new WebSocket(url, 'mqtt');
      ws.binaryType = 'arraybuffer';
      this.ws = ws;

      const connectTimeout = setTimeout(() => {
        if (!settled && !this.closed) {
          settled = true;
          try {
            ws.close();
          } catch {
            // ignore
          }
          this.connect(urlIndex + 1);
        }
      }, 4500);

      ws.onopen = () => {
        const proto = encodeUtf8String('MQTT');
        const flags = new Uint8Array([0x04, 0x02, 0x00, 0x3c]); // level 4, clean session, 60s keepalive
        const cid = encodeUtf8String(this.clientId);
        sendRaw(ws, buildPacket(0x10, [proto, flags, cid]));
      };

      ws.onmessage = (ev) => {
        const chunk =
          ev.data instanceof ArrayBuffer
            ? new Uint8Array(ev.data)
            : ev.data instanceof Uint8Array
              ? ev.data
              : null;
        if (!chunk) return;
        this.appendAndParse(chunk, () => {
          if (!settled) {
            settled = true;
            clearTimeout(connectTimeout);
            this.connected = true;
            this.startKeepalive();
            this.onReady();
          }
        });
      };

      ws.onerror = () => {
        if (!settled && !this.closed) {
          settled = true;
          clearTimeout(connectTimeout);
          this.connect(urlIndex + 1);
        }
      };

      ws.onclose = () => {
        clearTimeout(connectTimeout);
        this.stopKeepalive();
        const wasConnected = this.connected;
        this.connected = false;
        if (!settled && !this.closed) {
          settled = true;
          this.connect(urlIndex + 1);
        } else if (wasConnected && !this.closed) {
          this.onFail('Röle bağlantısı kesildi.');
        }
      };
    } catch {
      this.connect(urlIndex + 1);
    }
  }

  private startKeepalive() {
    this.stopKeepalive();
    this.pingTimer = setInterval(() => {
      if (this.ws && this.ws.readyState === 1) {
        this.ws.send(new Uint8Array([0xc0, 0x00]));
      }
    }, 25000);
  }

  private stopKeepalive() {
    if (this.pingTimer !== null) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  public subscribe(topic: string) {
    if (!this.ws || this.ws.readyState !== 1) return;
    const pid = this.packetId++;
    if (this.packetId > 65000) this.packetId = 1;
    const pidBytes = new Uint8Array([(pid >> 8) & 0xff, pid & 0xff]);
    const topicBytes = encodeUtf8String(topic);
    const qosByte = new Uint8Array([0x00]);
    sendRaw(this.ws, buildPacket(0x82, [pidBytes, topicBytes, qosByte]));
  }

  public publish(topic: string, payload: string) {
    if (!this.ws || this.ws.readyState !== 1) return;
    const topicBytes = encodeUtf8String(topic);
    const payloadBytes = encoder.encode(payload);
    sendRaw(this.ws, buildPacket(0x30, [topicBytes, payloadBytes]));
  }

  public close() {
    this.closed = true;
    this.connected = false;
    this.stopKeepalive();
    try {
      if (this.ws && this.ws.readyState === 1) {
        this.ws.send(new Uint8Array([0xe0, 0x00])); // DISCONNECT
      }
      this.ws?.close();
    } catch {
      // ignore
    }
    this.ws = null;
  }

  private appendAndParse(chunk: Uint8Array, onConnAck: () => void) {
    const merged = new Uint8Array(this.buffer.length + chunk.length);
    merged.set(this.buffer, 0);
    merged.set(chunk, this.buffer.length);
    this.buffer = merged;

    while (this.buffer.length >= 2) {
      let multiplier = 1;
      let remLen = 0;
      let pos = 1;
      let hasFullHeader = true;

      while (true) {
        if (pos >= this.buffer.length) {
          hasFullHeader = false;
          break;
        }
        const byte = this.buffer[pos++];
        remLen += (byte & 0x7f) * multiplier;
        if ((byte & 0x80) === 0) break;
        multiplier *= 128;
        if (pos > 5) {
          this.buffer = new Uint8Array(0);
          return;
        }
      }

      if (!hasFullHeader || this.buffer.length < pos + remLen) {
        break;
      }

      const header0 = this.buffer[0];
      const packetType = header0 >> 4;
      const body = this.buffer.slice(pos, pos + remLen);
      this.buffer = this.buffer.slice(pos + remLen);

      if (packetType === 2) {
        // CONNACK
        if (body.length >= 2 && body[1] === 0) {
          onConnAck();
        } else {
          this.onFail('Röle sunucusu bağlantıyı reddetti.');
        }
      } else if (packetType === 3) {
        // PUBLISH
        const qos = (header0 & 0x06) >> 1;
        if (body.length >= 2) {
          const topicLen = (body[0] << 8) | body[1];
          const payloadStart = 2 + topicLen + (qos > 0 ? 2 : 0);
          if (payloadStart <= body.length) {
            const topic = decoder.decode(body.slice(2, 2 + topicLen));
            const payload = decoder.decode(body.slice(payloadStart));
            this.onMessage(topic, payload);
          }
        }
      }
    }
  }
}
