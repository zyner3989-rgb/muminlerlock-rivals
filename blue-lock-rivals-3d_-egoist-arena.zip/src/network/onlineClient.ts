import type {
  FlowId,
  GkDifficulty,
  MatchMode,
  NetCutsceneEvent,
  NetWorldSnapshot,
  RoomLobbyState,
  StyleId,
} from '../types/game';

export type OnlineActionType =
  | 'DRIBBLE'
  | 'SLIDE'
  | 'PASS'
  | 'SHOOT_RELEASE'
  | 'SKILL1'
  | 'SKILL2'
  | 'PERSONAL'
  | 'AWAKENING'
  | 'ULTI';

export interface OnlineClientCallbacks {
  onConnected: (clientId: string) => void;
  onDisconnected: () => void;
  onRoomState: (room: RoomLobbyState) => void;
  onRoomError: (message: string) => void;
  onWorldState: (snapshot: NetWorldSnapshot) => void;
  onCutscene: (evt: NetCutsceneEvent) => void;
  onSound: (sound: string, power?: number, pitch?: number) => void;
}

export interface MultiplayerClient {
  clientId: string | null;
  connect: () => void;
  disconnect: () => void;
  createRoom: (name: string, styleId: StyleId, flowId: FlowId, gkDifficulty: GkDifficulty, matchMode?: MatchMode) => void;
  joinRoom: (roomCode: string, name: string, styleId: StyleId, flowId: FlowId) => void;
  leaveRoom: () => void;
  updatePlayer: (patch: {
    name?: string;
    styleId?: StyleId;
    flowId?: FlowId;
    team?: 'BLUE' | 'RED';
  }) => void;
  setGkDifficulty: (gkDifficulty: GkDifficulty) => void;
  setMatchMode: (matchMode: MatchMode) => void;
  startMatch: () => void;
  sendInput: (moveX: number, moveZ: number, sprint: boolean, chargingShot: boolean, aimYaw?: number, lockYaw?: boolean) => void;
  sendAction: (action: OnlineActionType) => void;
}

export class OnlineClient implements MultiplayerClient {
  private ws: WebSocket | null = null;
  private callbacks: OnlineClientCallbacks;
  public clientId: string | null = null;
  private intentionalClose = false;
  private pingTimer: number | null = null;

  constructor(callbacks: OnlineClientCallbacks) {
    this.callbacks = callbacks;
  }

  public connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    this.intentionalClose = false;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      if (this.pingTimer) window.clearInterval(this.pingTimer);
      this.pingTimer = window.setInterval(() => {
        this.send('ws:ping');
      }, 15000);
    };

    ws.onmessage = (ev) => {
      let msg: { type?: string; payload?: unknown };
      try {
        msg = JSON.parse(String(ev.data));
      } catch {
        return;
      }
      const p = msg.payload as Record<string, unknown>;
      if (msg.type === 'ws:welcome' && typeof p?.clientId === 'string') {
        this.clientId = p.clientId;
        this.callbacks.onConnected(p.clientId);
      } else if (msg.type === 'room:state') {
        this.callbacks.onRoomState(msg.payload as RoomLobbyState);
      } else if (msg.type === 'room:error' && typeof p?.message === 'string') {
        this.callbacks.onRoomError(p.message);
      } else if (msg.type === 'world:state') {
        this.callbacks.onWorldState(msg.payload as NetWorldSnapshot);
      } else if (msg.type === 'match:cutscene') {
        this.callbacks.onCutscene(msg.payload as NetCutsceneEvent);
      } else if (msg.type === 'match:sound' && typeof p?.sound === 'string') {
        this.callbacks.onSound(
          p.sound,
          typeof p.power === 'number' ? p.power : undefined,
          typeof p.pitch === 'number' ? p.pitch : undefined
        );
      }
    };

    ws.onerror = () => {
      this.callbacks.onRoomError(
        'Sunucu WebSocket bağlantısı kurulamadı. Share linki için P2P (Her Link) modunu kullanabilirsin!'
      );
    };

    ws.onclose = () => {
      if (this.pingTimer) {
        window.clearInterval(this.pingTimer);
        this.pingTimer = null;
      }
      this.ws = null;
      this.callbacks.onDisconnected();
      if (!this.intentionalClose) {
        window.setTimeout(() => this.connect(), 2200);
      }
    };
  }

  public disconnect() {
    this.intentionalClose = true;
    if (this.pingTimer) {
      window.clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this.ws?.close();
    this.ws = null;
  }

  private send(type: string, payload: Record<string, unknown> = {}) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload }));
    }
  }

  public createRoom(name: string, styleId: StyleId, flowId: FlowId, gkDifficulty: GkDifficulty, matchMode: MatchMode = '3V3') {
    this.send('room:create', { name, styleId, flowId, gkDifficulty, matchMode });
  }

  public joinRoom(roomCode: string, name: string, styleId: StyleId, flowId: FlowId) {
    this.send('room:join', { roomCode, name, styleId, flowId });
  }

  public leaveRoom() {
    this.send('room:leave');
  }

  public updatePlayer(patch: {
    name?: string;
    styleId?: StyleId;
    flowId?: FlowId;
    team?: 'BLUE' | 'RED';
  }) {
    this.send('room:update_player', patch);
  }

  public setGkDifficulty(gkDifficulty: GkDifficulty) {
    this.send('room:set_gk', { gkDifficulty });
  }

  public setMatchMode(matchMode: MatchMode) {
    this.send('room:set_mode', { matchMode });
  }

  public startMatch() {
    this.send('room:start');
  }

  public sendInput(moveX: number, moveZ: number, sprint: boolean, chargingShot: boolean, aimYaw?: number, lockYaw?: boolean) {
    this.send('player:input', { moveX, moveZ, sprint, chargingShot, aimYaw, lockYaw });
  }

  public sendAction(action: OnlineActionType) {
    this.send('player:action', { action });
  }
}
