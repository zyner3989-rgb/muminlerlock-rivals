import { useEffect, useRef, useState } from 'react';
import { soundEngine } from './audio/soundEngine';
import { GameHUD } from './components/GameHUD';
import { OnlineLobbyModal, type OnlineTransportMode } from './components/OnlineLobbyModal';
import { SettingsModal } from './components/SettingsModal';
import { SpinLobbyModal } from './components/SpinLobbyModal';
import { TitleScreen } from './components/TitleScreen';
import { WardrobeModal } from './components/WardrobeModal';
import { DEFAULT_SETTINGS, DEFAULT_WARDROBE } from './data/cosmetics';
import { BlueLockEngine } from './game/Engine';
import { OnlineClient, type MultiplayerClient, type OnlineClientCallbacks } from './network/onlineClient';
import { P2POnlineClient } from './network/p2pClient';
import type {
  FlowId,
  GameScreen,
  GameSettings,
  GkDifficulty,
  HudSnapshot,
  MatchMode,
  RoomLobbyState,
  StyleId,
  WardrobeConfig,
} from './types/game';

const INITIAL_HUD: HudSnapshot = {
  phase: 'IDLE',
  blueScore: 0,
  redScore: 0,
  timeRemaining: 180,
  stamina: 100,
  awakening: 40,
  isAwakened: false,
  awakeningTimeLeft: 0,
  ultiUsedInAwakening: false,
  shotCharge: 0,
  hasBall: false,
  skill1Cd: 0,
  skill1MaxCd: 6,
  skill2Cd: 0,
  skill2MaxCd: 8,
  personalCd: 0,
  personalMaxCd: 10,
  dribbleCd: 0,
  slideCd: 0,
  gkDifficulty: 'MEDIUM',
  matchMode: '3V3',
  isTraining: false,
  shiftLock: false,
  isOnline: false,
  roomCode: null,
  fps: 60,
  stats: { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 },
  cutsceneBanner: null,
  goalBanner: null,
  lastActionToast: null,
};

function detectDefaultOnlineMode(): OnlineTransportMode {
  if (typeof window !== 'undefined') {
    const h = window.location.hostname;
    if (h.includes('ais-dev-') || h.includes('ais-pre-')) {
      return 'p2p';
    }
  }
  return 'ws';
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BlueLockEngine | null>(null);
  const wsClientRef = useRef<OnlineClient | null>(null);
  const p2pClientRef = useRef<P2POnlineClient | null>(null);
  const onlineSessionActiveRef = useRef<boolean>(false);

  const [onlineMode, setOnlineMode] = useState<OnlineTransportMode>(detectDefaultOnlineMode);
  const onlineModeRef = useRef<OnlineTransportMode>(onlineMode);
  onlineModeRef.current = onlineMode;

  const [screen, setScreen] = useState<GameScreen>('TITLE');
  const [selectedStyle, setSelectedStyle] = useState<StyleId>(() => {
    const saved = localStorage.getItem('blr_style') as StyleId | null;
    return saved || 'musab';
  });
  const [selectedFlow, setSelectedFlow] = useState<FlowId>(() => {
    const saved = localStorage.getItem('blr_flow') as FlowId | null;
    return saved || 'egoist';
  });
  const [gkDifficulty, setGkDifficulty] = useState<GkDifficulty>(() => {
    const saved = localStorage.getItem('blr_gk') as GkDifficulty | null;
    return saved === 'EASY' || saved === 'MEDIUM' || saved === 'HARD' ? saved : 'MEDIUM';
  });
  const [matchMode, setMatchMode] = useState<MatchMode>(() => {
    const saved = localStorage.getItem('blr_mode') as MatchMode | null;
    return saved === '1V1' || saved === '3V3' ? saved : '3V3';
  });
  const [wardrobe, setWardrobe] = useState<WardrobeConfig>(() => {
    try {
      const raw = localStorage.getItem('blr_wardrobe');
      if (raw) return { ...DEFAULT_WARDROBE, ...(JSON.parse(raw) as Partial<WardrobeConfig>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_WARDROBE };
  });
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const raw = localStorage.getItem('blr_settings');
      if (raw) return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_SETTINGS };
  });

  const [unlockedStyles, setUnlockedStyles] = useState<StyleId[]>(() => {
    try {
      const raw = localStorage.getItem('blr_unlocked');
      if (raw) return JSON.parse(raw) as StyleId[];
    } catch {
      // ignore storage errors
    }
    return ['berk', 'musab'];
  });
  const [sandboxAllUnlocked, setSandboxAllUnlocked] = useState<boolean>(true);
  const [yen, setYen] = useState<number>(3500);
  const [spins, setSpins] = useState<number>(8);
  const [luckySpins, setLuckySpins] = useState<number>(3);
  const [muted, setMuted] = useState<boolean>(false);

  const [showSpinModal, setShowSpinModal] = useState<boolean>(false);
  const [showOnlineModal, setShowOnlineModal] = useState<boolean>(false);
  const [showWardrobeModal, setShowWardrobeModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);

  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [wsClientId, setWsClientId] = useState<string | null>(null);
  const [onlineRoom, setOnlineRoom] = useState<RoomLobbyState | null>(null);
  const [onlineError, setOnlineError] = useState<string | null>(null);

  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);

  const getActiveClient = (): MultiplayerClient | null => {
    return onlineModeRef.current === 'p2p' ? p2pClientRef.current : wsClientRef.current;
  };

  useEffect(() => {
    localStorage.setItem('blr_style', selectedStyle);
  }, [selectedStyle]);

  useEffect(() => {
    localStorage.setItem('blr_flow', selectedFlow);
  }, [selectedFlow]);

  useEffect(() => {
    localStorage.setItem('blr_gk', gkDifficulty);
  }, [gkDifficulty]);

  useEffect(() => {
    localStorage.setItem('blr_mode', matchMode);
  }, [matchMode]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_wardrobe', JSON.stringify(wardrobe));
    } catch {
      // ignore
    }
    engineRef.current?.setWardrobe(wardrobe);
  }, [wardrobe]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
    engineRef.current?.applySettings(settings);
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_unlocked', JSON.stringify(unlockedStyles));
    } catch {
      // ignore
    }
  }, [unlockedStyles]);

  // Mount Three.js Engine once in isolated ref container
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new BlueLockEngine(
      mount,
      selectedStyle,
      selectedFlow,
      gkDifficulty,
      matchMode,
      wardrobe,
      settings,
      (snap) => setHud(snap),
      (blue, red, stats) => {
        const rewardYen = (blue > red ? 1200 : 500) + stats.goals * 150;
        setYen((prev) => prev + rewardYen);
        setSpins((prev) => prev + 2);
      }
    );
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Initialize both WebSocket and WebRTC P2P clients once
  useEffect(() => {
    const makeCallbacks = (sourceMode: OnlineTransportMode): OnlineClientCallbacks => ({
      onConnected: (id) => {
        if (onlineModeRef.current !== sourceMode) return;
        setWsConnected(true);
        setWsClientId(id);
        setOnlineError(null);
      },
      onDisconnected: () => {
        if (onlineModeRef.current !== sourceMode) return;
        setWsConnected(false);
        setWsClientId(null);
      },
      onRoomState: (room) => {
        if (onlineModeRef.current !== sourceMode) return;
        const activeClient = sourceMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
        setOnlineRoom(room);
        setOnlineError(null);

        const me = room.players.find((p) => p.clientId === activeClient?.clientId);
        if (me) {
          setSelectedStyle(me.styleId);
          setSelectedFlow(me.flowId);
        }

        if (room.status === 'PLAYING' && !onlineSessionActiveRef.current && activeClient) {
          onlineSessionActiveRef.current = true;
          setShowOnlineModal(false);
          setShowSpinModal(false);
          setShowWardrobeModal(false);
          setScreen('PLAYING');
          engineRef.current?.startOnlineSession(activeClient, room.roomCode);
        } else if (room.status === 'LOBBY' && onlineSessionActiveRef.current) {
          onlineSessionActiveRef.current = false;
          setScreen('TITLE');
          engineRef.current?.returnToTitle();
        }
      },
      onRoomError: (message) => {
        if (onlineModeRef.current !== sourceMode) return;
        setOnlineError(message);
      },
      onWorldState: (snapshot) => {
        if (onlineModeRef.current !== sourceMode) return;
        const activeClient = sourceMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
        engineRef.current?.applyNetworkWorld(snapshot, activeClient?.clientId ?? null);
      },
      onCutscene: (evt) => {
        if (onlineModeRef.current !== sourceMode) return;
        engineRef.current?.triggerNetworkCutscene(evt);
      },
      onSound: (sound, power, pitch) => {
        if (onlineModeRef.current !== sourceMode) return;
        if (sound === 'WHISTLE') soundEngine.playWhistle();
        else if (sound === 'KICK') soundEngine.playKick(power ?? 0.6);
        else if (sound === 'SLIDE') soundEngine.playSlide();
        else if (sound === 'SKILL') soundEngine.playSkill(pitch ?? 440);
        else if (sound === 'POST_CLANG') soundEngine.playPostClang();
        else if (sound === 'GOAL') {
          soundEngine.playGoalHorn();
          soundEngine.playCrowdCheer();
        }
      },
    });

    const wsClient = new OnlineClient(makeCallbacks('ws'));
    const p2pClient = new P2POnlineClient(makeCallbacks('p2p'));
    wsClientRef.current = wsClient;
    p2pClientRef.current = p2pClient;

    return () => {
      wsClient.disconnect();
      p2pClient.disconnect();
      wsClientRef.current = null;
      p2pClientRef.current = null;
    };
  }, []);

  // Sync style/flow/GK difficulty/match mode selection to live 3D showcase
  useEffect(() => {
    engineRef.current?.setLoadout(selectedStyle, selectedFlow, gkDifficulty, matchMode);
  }, [selectedStyle, selectedFlow, gkDifficulty, matchMode]);

  const handleStartMatch = (trainingMode = false) => {
    onlineSessionActiveRef.current = false;
    setShowSpinModal(false);
    setShowOnlineModal(false);
    setShowWardrobeModal(false);
    setShowSettingsModal(false);
    setScreen('PLAYING');
    engineRef.current?.startNewMatch(gkDifficulty, matchMode, trainingMode);
  };

  const handleOpenOnlineLobby = () => {
    setOnlineError(null);
    setShowOnlineModal(true);
    getActiveClient()?.connect();
  };

  const handleChangeOnlineMode = (nextMode: OnlineTransportMode) => {
    if (nextMode === onlineMode) return;
    getActiveClient()?.leaveRoom();
    getActiveClient()?.disconnect();
    setOnlineRoom(null);
    setOnlineError(null);
    setWsConnected(false);
    setWsClientId(null);
    onlineModeRef.current = nextMode;
    setOnlineMode(nextMode);
    const nextClient = nextMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
    nextClient?.connect();
  };

  const handleExitToLobby = () => {
    if (onlineSessionActiveRef.current) {
      onlineSessionActiveRef.current = false;
      getActiveClient()?.leaveRoom();
      setOnlineRoom(null);
    }
    setScreen('TITLE');
    engineRef.current?.returnToTitle();
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundEngine.setMuted(next);
  };

  // Enter/Space starts match directly from Title Screen when no modal/preview is open
  useEffect(() => {
    if (
      screen !== 'TITLE' ||
      showSpinModal ||
      showOnlineModal ||
      showWardrobeModal ||
      showSettingsModal ||
      hud.phase === 'CUTSCENE'
    ) {
      return;
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        handleStartMatch(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    screen,
    showSpinModal,
    showOnlineModal,
    showWardrobeModal,
    showSettingsModal,
    gkDifficulty,
    matchMode,
    hud.phase,
  ]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050811]">
      {/* Isolated WebGL Mount */}
      <div ref={canvasMountRef} className="fixed inset-0 w-full h-full z-0" />

      {screen === 'TITLE' && hud.phase !== 'CUTSCENE' && (
        <TitleScreen
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          gkDifficulty={gkDifficulty}
          matchMode={matchMode}
          yen={yen}
          spins={spins}
          luckySpins={luckySpins}
          muted={muted}
          onSelectGkDifficulty={setGkDifficulty}
          onSelectMatchMode={setMatchMode}
          onStartMatch={() => handleStartMatch(false)}
          onStartTraining={() => handleStartMatch(true)}
          onOpenOnlineLobby={handleOpenOnlineLobby}
          onOpenSpinLobby={() => setShowSpinModal(true)}
          onOpenWardrobe={() => setShowWardrobeModal((v) => !v)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onPreviewCutscene={(st, kind) => {
            soundEngine.unlock();
            engineRef.current?.previewCutscene(st, kind);
          }}
          onToggleMute={handleToggleMute}
        />
      )}

      {screen === 'TITLE' && hud.phase === 'CUTSCENE' && (
        <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6">
          <div className="flex justify-end pointer-events-auto">
            <button
              type="button"
              onClick={() => engineRef.current?.stopPreviewCutscene()}
              className="bg-[#090f1e]/95 hover:bg-slate-800 border border-slate-600 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
            >
              ÖNİZLEMEYİ KAPAT
            </button>
          </div>

          {hud.cutsceneBanner && hud.cutsceneBanner.active && (
            <div
              className="mb-3 mx-auto max-w-2xl w-full bg-[#050811]/95 border-2 rounded-2xl px-6 py-4 text-center shadow-2xl"
              style={{ borderColor: hud.cutsceneBanner.accentColor }}
            >
              <div className="flex items-center justify-center gap-2">
                <span
                  className="text-[11px] font-black px-2.5 py-0.5 rounded text-slate-950"
                  style={{ backgroundColor: hud.cutsceneBanner.accentColor }}
                >
                  {hud.cutsceneBanner.badge}
                </span>
                <span className="text-sm font-black text-white">{hud.cutsceneBanner.speaker}</span>
              </div>
              <div className="text-lg md:text-xl font-black italic text-amber-200 mt-1.5">
                “{hud.cutsceneBanner.subtitle}”
              </div>
            </div>
          )}
        </div>
      )}

      {screen === 'PLAYING' && (
        <GameHUD
          hud={hud}
          activeStyleId={selectedStyle}
          muted={muted}
          showFps={settings.showFps}
          onToggleMute={handleToggleMute}
          onTogglePause={() => engineRef.current?.togglePause()}
          onOpenSettings={() => setShowSettingsModal(true)}
          onRestart={() => engineRef.current?.startNewMatch(gkDifficulty, matchMode, hud.isTraining)}
          onExitToLobby={handleExitToLobby}
          onTriggerAction={(act) => engineRef.current?.triggerActionFromHud(act)}
        />
      )}

      {showWardrobeModal && (
        <WardrobeModal
          activeStyleId={selectedStyle}
          wardrobe={wardrobe}
          onChangeWardrobe={setWardrobe}
          onClose={() => setShowWardrobeModal(false)}
        />
      )}

      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          muted={muted}
          onChangeSettings={setSettings}
          onToggleMute={handleToggleMute}
          onClose={() => setShowSettingsModal(false)}
        />
      )}

      {showOnlineModal && (
        <OnlineLobbyModal
          mode={onlineMode}
          connected={wsConnected}
          clientId={wsClientId}
          room={onlineRoom}
          errorMsg={onlineError}
          defaultStyle={selectedStyle}
          defaultFlow={selectedFlow}
          defaultGk={gkDifficulty}
          defaultMatchMode={matchMode}
          onChangeMode={handleChangeOnlineMode}
          onCreateRoom={(name, styleId, flowId, gk, mm) => {
            setOnlineError(null);
            getActiveClient()?.createRoom(name, styleId, flowId, gk, mm);
          }}
          onJoinRoom={(code, name, styleId, flowId) => {
            setOnlineError(null);
            getActiveClient()?.joinRoom(code, name, styleId, flowId);
          }}
          onLeaveRoom={() => {
            getActiveClient()?.leaveRoom();
            setOnlineRoom(null);
          }}
          onUpdatePlayer={(patch) => getActiveClient()?.updatePlayer(patch)}
          onSetGk={(gk) => getActiveClient()?.setGkDifficulty(gk)}
          onSetMatchMode={(mm) => getActiveClient()?.setMatchMode(mm)}
          onStartOnlineMatch={() => getActiveClient()?.startMatch()}
          onClose={() => setShowOnlineModal(false)}
        />
      )}

      {showSpinModal && (
        <SpinLobbyModal
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          unlockedStyles={unlockedStyles}
          sandboxAllUnlocked={sandboxAllUnlocked}
          spins={spins}
          luckySpins={luckySpins}
          yen={yen}
          onSelectStyle={setSelectedStyle}
          onSelectFlow={(f) => {
            setSelectedFlow(f);
            setYen((prev) => Math.max(0, prev - 250));
          }}
          onUnlockStyle={(id) =>
            setUnlockedStyles((prev) => (prev.includes(id) ? prev : [...prev, id]))
          }
          onConsumeSpin={(lucky) => {
            if (lucky) setLuckySpins((p) => Math.max(0, p - 1));
            else setSpins((p) => Math.max(0, p - 1));
          }}
          onBuySpins={(kind) => {
            if (kind === 'NORMAL' && yen >= 300) {
              setYen((p) => p - 300);
              setSpins((p) => p + 1);
            } else if (kind === 'LUCKY' && yen >= 900) {
              setYen((p) => p - 900);
              setLuckySpins((p) => p + 1);
            }
          }}
          onToggleSandbox={() => setSandboxAllUnlocked((v) => !v)}
          onClose={() => setShowSpinModal(false)}
        />
      )}
    </div>
  );
}
