import { useEffect, useRef, useState } from 'react';
import { soundEngine } from './audio/soundEngine';
import { GameHUD } from './components/GameHUD';
import { OnlineLobbyModal, type OnlineTransportMode } from './components/OnlineLobbyModal';
import { QuestsModal } from './components/QuestsModal';
import { SettingsModal } from './components/SettingsModal';
import { SpinLobbyModal } from './components/SpinLobbyModal';
import { TitleScreen } from './components/TitleScreen';
import { WardrobeModal } from './components/WardrobeModal';
import { DEFAULT_SETTINGS, DEFAULT_WARDROBE } from './data/cosmetics';
import {
  computeRankedOutcome,
  DAILY_QUESTS,
  DEFAULT_QUEST_PROGRESS,
  DEFAULT_RANKED_PROFILE,
  PROMO_CODES,
} from './data/ranked';
import { BlueLockEngine } from './game/Engine';
import { OnlineClient, type MultiplayerClient, type OnlineClientCallbacks } from './network/onlineClient';
import { P2POnlineClient } from './network/p2pClient';
import type {
  DailyQuestProgress,
  FlowId,
  GameScreen,
  GameSettings,
  GkDifficulty,
  HudSnapshot,
  MatchMode,
  MatchmakingStatus,
  PlayerRole,
  QueueType,
  RankedProfile,
  RoomLobbyState,
  StyleId,
  WardrobeConfig,
} from './types/game';

const INITIAL_HUD: HudSnapshot = {
  phase: 'IDLE',
  blueScore: 0,
  redScore: 0,
  timeRemaining: 180,
  stamina: 100,
  awakening: 40,
  isAwakened: false,
  awakeningTimeLeft: 0,
  ultiUsedInAwakening: false,
  shotCharge: 0,
  hasBall: false,
  skill1Cd: 0,
  skill1MaxCd: 6,
  skill2Cd: 0,
  skill2MaxCd: 8,
  personalCd: 0,
  personalMaxCd: 10,
  dribbleCd: 0,
  slideCd: 0,
  gkDifficulty: 'MEDIUM',
  matchMode: '3V3',
  role: 'CF',
  gkBallInHands: false,
  gkHoldLeft: 0,
  gkDiveCd: 0,
  isTraining: false,
  shiftLock: false,
  isOnline: false,
  roomCode: null,
  pingMs: null,
  queueType: 'CASUAL',
  fps: 60,
  duoComboCd: 0,
  radarEntities: [],
  stats: { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 },
  cutsceneBanner: null,
  goalBanner: null,
  duoComboPrompt: null,
  lastActionToast: null,
};

function detectDefaultOnlineMode(): OnlineTransportMode {
  // Share links (ais-pre-...) and dev links (ais-dev-...) run on isolated servers;
  // default to cross-origin P2P bridge there so host & friend always find each other.
  try {
    const params = new URLSearchParams(window.location.search);
    const netParam = params.get('net');
    if (netParam === 'p2p' || netParam === 'ws') return netParam;
    const host = window.location.hostname || '';
    if (host.startsWith('ais-dev-') || host.startsWith('ais-pre-')) {
      return 'p2p';
    }
  } catch {
    // ignore URL access restrictions
  }
  return 'ws';
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BlueLockEngine | null>(null);
  const wsClientRef = useRef<OnlineClient | null>(null);
  const p2pClientRef = useRef<P2POnlineClient | null>(null);
  const onlineSessionActiveRef = useRef<boolean>(false);

  const [onlineMode, setOnlineMode] = useState<OnlineTransportMode>(detectDefaultOnlineMode);
  const onlineModeRef = useRef<OnlineTransportMode>(onlineMode);
  onlineModeRef.current = onlineMode;

  const safeGet = (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  };
  const safeSet = (key: string, val: string) => {
    try {
      localStorage.setItem(key, val);
    } catch {
      // ignore storage restrictions
    }
  };

  const [screen, setScreen] = useState<GameScreen>('TITLE');
  const [selectedStyle, setSelectedStyle] = useState<StyleId>(() => {
    const saved = safeGet('blr_style') as StyleId | null;
    return saved || 'musab';
  });
  const [selectedFlow, setSelectedFlow] = useState<FlowId>(() => {
    const saved = safeGet('blr_flow') as FlowId | null;
    return saved || 'egoist';
  });
  const [gkDifficulty, setGkDifficulty] = useState<GkDifficulty>(() => {
    const saved = safeGet('blr_gk') as GkDifficulty | null;
    return saved === 'EASY' || saved === 'MEDIUM' || saved === 'HARD' ? saved : 'MEDIUM';
  });
  const [matchMode, setMatchMode] = useState<MatchMode>(() => {
    const saved = safeGet('blr_mode') as MatchMode | null;
    return saved === '1V1' || saved === '3V3' ? saved : '3V3';
  });
  const [selectedRole, setSelectedRole] = useState<PlayerRole>(() => {
    const saved = safeGet('blr_role') as PlayerRole | null;
    return saved === 'CF' || saved === 'LW' || saved === 'RW' || saved === 'CM' || saved === 'GK' ? saved : 'CF';
  });
  const [wardrobe, setWardrobe] = useState<WardrobeConfig>(() => {
    try {
      const raw = localStorage.getItem('blr_wardrobe');
      if (raw) return { ...DEFAULT_WARDROBE, ...(JSON.parse(raw) as Partial<WardrobeConfig>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_WARDROBE };
  });
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const raw = localStorage.getItem('blr_settings');
      if (raw) return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_SETTINGS };
  });

  const [unlockedStyles, setUnlockedStyles] = useState<StyleId[]>(() => {
    try {
      const raw = localStorage.getItem('blr_unlocked');
      if (raw) return JSON.parse(raw) as StyleId[];
    } catch {
      // ignore storage errors
    }
    return ['berk', 'musab'];
  });
  const [sandboxAllUnlocked, setSandboxAllUnlocked] = useState<boolean>(true);
  const [yen, setYen] = useState<number>(3500);
  const [spins, setSpins] = useState<number>(8);
  const [luckySpins, setLuckySpins] = useState<number>(3);
  const [muted, setMuted] = useState<boolean>(false);

  const [showSpinModal, setShowSpinModal] = useState<boolean>(false);
  const [showOnlineModal, setShowOnlineModal] = useState<boolean>(false);
  const [showWardrobeModal, setShowWardrobeModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showQuestsModal, setShowQuestsModal] = useState<boolean>(false);

  const [rankedProfile, setRankedProfile] = useState<RankedProfile>(() => {
    try {
      const raw = localStorage.getItem('blr_ranked');
      if (raw) return { ...DEFAULT_RANKED_PROFILE, ...(JSON.parse(raw) as Partial<RankedProfile>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_RANKED_PROFILE };
  });
  const [questProgress, setQuestProgress] = useState<DailyQuestProgress>(() => {
    try {
      const raw = localStorage.getItem('blr_quests');
      if (raw) return { ...DEFAULT_QUEST_PROGRESS, ...(JSON.parse(raw) as Partial<DailyQuestProgress>) };
    } catch {
      // ignore
    }
    return { ...DEFAULT_QUEST_PROGRESS };
  });
  const [lastMatchSummary, setLastMatchSummary] = useState<{
    rpDelta: number;
    isMvp: boolean;
    queueType: QueueType;
  } | null>(null);

  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [wsClientId, setWsClientId] = useState<string | null>(null);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [onlineRoom, setOnlineRoom] = useState<RoomLobbyState | null>(null);
  const [onlineError, setOnlineError] = useState<string | null>(null);
  const [matchmakingStatus, setMatchmakingStatus] = useState<MatchmakingStatus | null>(null);
  const [activeQueueType, setActiveQueueType] = useState<QueueType>('CASUAL');

  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);

  const rankedProfileRef = useRef<RankedProfile>(rankedProfile);
  rankedProfileRef.current = rankedProfile;
  const selectedStyleRef = useRef<StyleId>(selectedStyle);
  selectedStyleRef.current = selectedStyle;
  const selectedFlowRef = useRef<FlowId>(selectedFlow);
  selectedFlowRef.current = selectedFlow;
  const selectedRoleRef = useRef<PlayerRole>(selectedRole);
  selectedRoleRef.current = selectedRole;
  const matchModeRef = useRef<MatchMode>(matchMode);
  matchModeRef.current = matchMode;
  const activeQueueTypeRef = useRef<QueueType>(activeQueueType);
  activeQueueTypeRef.current = activeQueueType;
  const pendingAutoJoinRef = useRef<{
    code: string;
    name: string;
    styleId: StyleId;
    flowId: FlowId;
    rp: number;
    role: PlayerRole;
  } | null>(null);

  const getActiveClient = (): MultiplayerClient | null => {
    return onlineModeRef.current === 'p2p' ? p2pClientRef.current : wsClientRef.current;
  };

  useEffect(() => {
    safeSet('blr_style', selectedStyle);
  }, [selectedStyle]);

  useEffect(() => {
    safeSet('blr_flow', selectedFlow);
  }, [selectedFlow]);

  useEffect(() => {
    safeSet('blr_gk', gkDifficulty);
  }, [gkDifficulty]);

  useEffect(() => {
    safeSet('blr_mode', matchMode);
  }, [matchMode]);

  useEffect(() => {
    safeSet('blr_role', selectedRole);
  }, [selectedRole]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_wardrobe', JSON.stringify(wardrobe));
    } catch {
      // ignore
    }
    engineRef.current?.setWardrobe(wardrobe);
  }, [wardrobe]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
    engineRef.current?.applySettings(settings);
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_unlocked', JSON.stringify(unlockedStyles));
    } catch {
      // ignore
    }
  }, [unlockedStyles]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_ranked', JSON.stringify(rankedProfile));
    } catch {
      // ignore
    }
  }, [rankedProfile]);

  useEffect(() => {
    try {
      localStorage.setItem('blr_quests', JSON.stringify(questProgress));
    } catch {
      // ignore
    }
  }, [questProgress]);

  // Mount Three.js Engine once in isolated ref container
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    let engine: BlueLockEngine | null = null;
    try {
      engine = new BlueLockEngine(
        mount,
        selectedStyle,
        selectedFlow,
        gkDifficulty,
        matchMode,
        wardrobe,
        settings,
        (snap) => setHud(snap),
        (blue, red, stats) => {
          const queueType: QueueType = onlineSessionActiveRef.current
            ? activeQueueTypeRef.current
            : 'CASUAL';
          const outcome = computeRankedOutcome(
            rankedProfileRef.current,
            blue,
            red,
            stats,
            queueType,
            matchModeRef.current,
            selectedStyleRef.current
          );
          const rewardYen =
            (blue > red ? 1200 : 500) +
            stats.goals * 150 +
            (queueType === 'RANKED' ? 400 : 0);
          setYen((prev) => prev + rewardYen);
          setSpins((prev) => prev + (queueType === 'RANKED' && outcome.result === 'WIN' ? 3 : 2));
          setRankedProfile(outcome.nextProfile);
          setLastMatchSummary({
            rpDelta: outcome.rpDelta,
            isMvp: outcome.isMvp,
            queueType,
          });
          setQuestProgress((prev) => ({
            ...prev,
            goals: prev.goals + stats.goals,
            skillsOrDribbles: prev.skillsOrDribbles + stats.dribbles + stats.passes,
            matchesPlayed: prev.matchesPlayed + 1,
          }));

          if (queueType === 'RANKED') {
            fetch('/api/leaderboard', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                playerName: outcome.nextProfile.playerName,
                rp: outcome.nextProfile.rp,
                wins: outcome.nextProfile.wins,
                losses: outcome.nextProfile.losses,
                goals: outcome.nextProfile.goals,
                favoriteStyle: selectedStyleRef.current,
              }),
            }).catch(() => {});
          }
        },
        selectedRole
      );
      engineRef.current = engine;
    } catch (err) {
      console.error('3D Engine initialization error:', err);
    }

    return () => {
      engine?.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Initialize both WebSocket and WebRTC P2P clients once
  useEffect(() => {
    const makeCallbacks = (sourceMode: OnlineTransportMode): OnlineClientCallbacks => ({
      onConnected: (id) => {
        if (onlineModeRef.current !== sourceMode) return;
        setWsConnected(true);
        setWsClientId(id);
        setOnlineError(null);
        const pending = pendingAutoJoinRef.current;
        if (pending) {
          pendingAutoJoinRef.current = null;
          const activeClient = sourceMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
          activeClient?.joinRoom(
            pending.code,
            pending.name,
            pending.styleId,
            pending.flowId,
            pending.rp,
            pending.role
          );
        }
      },
      onDisconnected: () => {
        if (onlineModeRef.current !== sourceMode) return;
        setWsConnected(false);
        setWsClientId(null);
        setPingMs(null);
        setMatchmakingStatus(null);
      },
      onPing: (rtt) => {
        if (onlineModeRef.current !== sourceMode) return;
        setPingMs(rtt);
        engineRef.current?.setOnlineMeta(rtt);
      },
      onMatchmakingStatus: (status) => {
        if (onlineModeRef.current !== sourceMode) return;
        setMatchmakingStatus(status.searching ? status : null);
      },
      onMatchmakingMatched: (room) => {
        if (onlineModeRef.current !== sourceMode) return;
        setMatchmakingStatus(null);
        const qType = room.queueType ?? 'CASUAL';
        setActiveQueueType(qType);
        activeQueueTypeRef.current = qType;
      },
      onRoomState: (room) => {
        if (onlineModeRef.current !== sourceMode) return;
        const activeClient = sourceMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
        setOnlineRoom(room);
        setOnlineError(null);
        const qType = room.queueType ?? 'CASUAL';
        setActiveQueueType(qType);
        activeQueueTypeRef.current = qType;

        const me = room.players.find((p) => p.clientId === activeClient?.clientId);
        if (me) {
          setSelectedStyle(me.styleId);
          setSelectedFlow(me.flowId);
          if (me.role) setSelectedRole(me.role);
        }

        if (room.status === 'PLAYING' && !onlineSessionActiveRef.current && activeClient) {
          onlineSessionActiveRef.current = true;
          setLastMatchSummary(null);
          setMatchmakingStatus(null);
          setShowOnlineModal(false);
          setShowSpinModal(false);
          setShowWardrobeModal(false);
          setShowQuestsModal(false);
          setScreen('PLAYING');
          engineRef.current?.startOnlineSession(activeClient, room.roomCode, qType);
          engineRef.current?.setOnlineMeta(activeClient.pingMs, qType);
        } else if (room.status === 'LOBBY' && onlineSessionActiveRef.current) {
          onlineSessionActiveRef.current = false;
          setScreen('TITLE');
          engineRef.current?.returnToTitle();
        }
      },
      onRoomError: (message) => {
        if (onlineModeRef.current !== sourceMode) return;
        setOnlineError(message);
      },
      onWorldState: (snapshot) => {
        if (onlineModeRef.current !== sourceMode) return;
        const activeClient = sourceMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
        engineRef.current?.applyNetworkWorld(snapshot, activeClient?.clientId ?? null);
      },
      onCutscene: (evt) => {
        if (onlineModeRef.current !== sourceMode) return;
        engineRef.current?.triggerNetworkCutscene(evt);
      },
      onSound: (sound, power, pitch) => {
        if (onlineModeRef.current !== sourceMode) return;
        if (sound === 'WHISTLE') soundEngine.playWhistle();
        else if (sound === 'KICK') soundEngine.playKick(power ?? 0.6);
        else if (sound === 'SLIDE') soundEngine.playSlide();
        else if (sound === 'SKILL') soundEngine.playSkill(pitch ?? 440);
        else if (sound === 'EMOTE') soundEngine.playEmoteChime();
        else if (sound === 'AWAKENED_IMPACT') soundEngine.playAwakenedImpact();
        else if (sound === 'POST_CLANG') soundEngine.playPostClang();
        else if (sound === 'GOAL') {
          soundEngine.playGoalHorn();
          soundEngine.playCrowdCheer();
        }
      },
    });

    const wsClient = new OnlineClient(makeCallbacks('ws'));
    const p2pClient = new P2POnlineClient(makeCallbacks('p2p'));
    wsClientRef.current = wsClient;
    p2pClientRef.current = p2pClient;

    // Auto-join invite links (?room=CODE&net=p2p|ws)
    try {
      const params = new URLSearchParams(window.location.search);
      const inviteRoom = params.get('room')?.trim().toUpperCase();
      if (inviteRoom) {
        const inviteNet = params.get('net');
        const targetMode: OnlineTransportMode =
          inviteNet === 'ws' || inviteNet === 'p2p'
            ? inviteNet
            : inviteRoom.length === 5
              ? 'p2p'
              : 'ws';
        onlineModeRef.current = targetMode;
        setOnlineMode(targetMode);
        setShowOnlineModal(true);
        pendingAutoJoinRef.current = {
          code: inviteRoom,
          name: rankedProfileRef.current.playerName || 'Egoist',
          styleId: selectedStyleRef.current,
          flowId: selectedFlowRef.current,
          rp: rankedProfileRef.current.rp,
          role: selectedRoleRef.current,
        };
        const targetClient = targetMode === 'p2p' ? p2pClient : wsClient;
        targetClient.connect();
      }
    } catch {
      // ignore URL parsing errors
    }

    return () => {
      wsClient.disconnect();
      p2pClient.disconnect();
      wsClientRef.current = null;
      p2pClientRef.current = null;
    };
  }, []);

  // Sync style/flow/GK difficulty/match mode/role selection to live 3D showcase
  useEffect(() => {
    engineRef.current?.setLoadout(selectedStyle, selectedFlow, gkDifficulty, matchMode, selectedRole);
  }, [selectedStyle, selectedFlow, gkDifficulty, matchMode, selectedRole]);

  const handleStartMatch = (trainingMode = false) => {
    onlineSessionActiveRef.current = false;
    setActiveQueueType('CASUAL');
    activeQueueTypeRef.current = 'CASUAL';
    setLastMatchSummary(null);
    setShowSpinModal(false);
    setShowOnlineModal(false);
    setShowWardrobeModal(false);
    setShowSettingsModal(false);
    setShowQuestsModal(false);
    setScreen('PLAYING');
    engineRef.current?.startNewMatch(gkDifficulty, matchMode, trainingMode);
  };

  const handleOpenOnlineLobby = () => {
    setOnlineError(null);
    setShowOnlineModal(true);
    getActiveClient()?.connect();
  };

  const handleChangeOnlineMode = (nextMode: OnlineTransportMode) => {
    if (nextMode === onlineMode) return;
    getActiveClient()?.cancelMatchmaking();
    getActiveClient()?.leaveRoom();
    getActiveClient()?.disconnect();
    setOnlineRoom(null);
    setOnlineError(null);
    setMatchmakingStatus(null);
    setPingMs(null);
    setWsConnected(false);
    setWsClientId(null);
    onlineModeRef.current = nextMode;
    setOnlineMode(nextMode);
    const nextClient = nextMode === 'p2p' ? p2pClientRef.current : wsClientRef.current;
    nextClient?.connect();
  };

  const handleExitToLobby = () => {
    if (onlineSessionActiveRef.current) {
      onlineSessionActiveRef.current = false;
      getActiveClient()?.leaveRoom();
      setOnlineRoom(null);
    }
    setScreen('TITLE');
    engineRef.current?.returnToTitle();
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundEngine.setMuted(next);
  };

  const handleClaimQuest = (questId: string) => {
    const q = DAILY_QUESTS.find((item) => item.id === questId);
    if (!q) return;
    if (questProgress.claimedIds.includes(questId)) return;
    if (questProgress[q.field] < q.target) return;

    setYen((prev) => prev + q.rewardYen);
    setSpins((prev) => prev + q.rewardSpins);
    setLuckySpins((prev) => prev + q.rewardLucky);
    setQuestProgress((prev) => ({
      ...prev,
      claimedIds: [...prev.claimedIds, questId],
    }));
  };

  const handleRedeemCode = (rawCode: string): { ok: boolean; message: string } => {
    const code = rawCode.trim().toUpperCase();
    const reward = PROMO_CODES[code];
    if (!reward) {
      return { ok: false, message: 'Geçersiz promosyon kodu.' };
    }
    if (questProgress.redeemedCodes.includes(code)) {
      return { ok: false, message: 'Bu kod zaten kullanıldı.' };
    }
    setYen((prev) => prev + reward.yen);
    setSpins((prev) => prev + reward.spins);
    setLuckySpins((prev) => prev + reward.luckySpins);
    setQuestProgress((prev) => ({
      ...prev,
      redeemedCodes: [...prev.redeemedCodes, code],
    }));
    return {
      ok: true,
      message: `${reward.label}: +${reward.yen}¥, +${reward.spins} Spin, +${reward.luckySpins} Şanslı!`,
    };
  };

  const claimableQuestsCount = DAILY_QUESTS.filter(
    (q) => questProgress[q.field] >= q.target && !questProgress.claimedIds.includes(q.id)
  ).length;

  // Enter/Space starts match directly from Title Screen when no modal/preview is open
  useEffect(() => {
    if (
      screen !== 'TITLE' ||
      showSpinModal ||
      showOnlineModal ||
      showWardrobeModal ||
      showSettingsModal ||
      showQuestsModal ||
      hud.phase === 'CUTSCENE'
    ) {
      return;
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        handleStartMatch(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    screen,
    showSpinModal,
    showOnlineModal,
    showWardrobeModal,
    showSettingsModal,
    showQuestsModal,
    gkDifficulty,
    matchMode,
    hud.phase,
  ]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050811]">
      {/* Isolated WebGL Mount */}
      <div ref={canvasMountRef} className="fixed inset-0 w-full h-full z-0" />

      {screen === 'TITLE' && hud.phase !== 'CUTSCENE' && (
        <TitleScreen
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          gkDifficulty={gkDifficulty}
          matchMode={matchMode}
          selectedRole={selectedRole}
          yen={yen}
          spins={spins}
          luckySpins={luckySpins}
          muted={muted}
          rankedProfile={rankedProfile}
          claimableQuestsCount={claimableQuestsCount}
          onSelectGkDifficulty={setGkDifficulty}
          onSelectMatchMode={setMatchMode}
          onSelectRole={setSelectedRole}
          onStartMatch={() => handleStartMatch(false)}
          onStartTraining={() => handleStartMatch(true)}
          onOpenOnlineLobby={handleOpenOnlineLobby}
          onOpenSpinLobby={() => setShowSpinModal(true)}
          onOpenWardrobe={() => setShowWardrobeModal((v) => !v)}
          onOpenQuests={() => setShowQuestsModal(true)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onPreviewCutscene={(st, kind) => {
            soundEngine.unlock();
            engineRef.current?.previewCutscene(st, kind);
          }}
          onToggleMute={handleToggleMute}
        />
      )}

      {screen === 'TITLE' && hud.phase === 'CUTSCENE' && (
        <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6">
          <div className="flex justify-end pointer-events-auto">
            <button
              type="button"
              onClick={() => engineRef.current?.stopPreviewCutscene()}
              className="bg-[#090f1e]/95 hover:bg-slate-800 border border-slate-600 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
            >
              ÖNİZLEMEYİ KAPAT
            </button>
          </div>

          {hud.cutsceneBanner && hud.cutsceneBanner.active && (
            <div
              className="mb-3 mx-auto max-w-2xl w-full bg-[#050811]/95 border-2 rounded-2xl px-6 py-4 text-center shadow-2xl"
              style={{ borderColor: hud.cutsceneBanner.accentColor }}
            >
              <div className="flex items-center justify-center gap-2">
                <span
                  className="text-[11px] font-black px-2.5 py-0.5 rounded text-slate-950"
                  style={{ backgroundColor: hud.cutsceneBanner.accentColor }}
                >
                  {hud.cutsceneBanner.badge}
                </span>
                <span className="text-sm font-black text-white">{hud.cutsceneBanner.speaker}</span>
              </div>
              <div className="text-lg md:text-xl font-black italic text-amber-200 mt-1.5">
                “{hud.cutsceneBanner.subtitle}”
              </div>
            </div>
          )}
        </div>
      )}

      {screen === 'PLAYING' && (
        <GameHUD
          hud={hud}
          activeStyleId={selectedStyle}
          muted={muted}
          showFps={settings.showFps}
          rankedProfile={rankedProfile}
          lastMatchSummary={lastMatchSummary}
          onToggleMute={handleToggleMute}
          onTogglePause={() => engineRef.current?.togglePause()}
          onOpenSettings={() => setShowSettingsModal(true)}
          onRestart={() => {
            setLastMatchSummary(null);
            engineRef.current?.startNewMatch(gkDifficulty, matchMode, hud.isTraining);
          }}
          onExitToLobby={handleExitToLobby}
          onTriggerAction={(act) => engineRef.current?.triggerActionFromHud(act)}
        />
      )}

      {showWardrobeModal && (
        <WardrobeModal
          activeStyleId={selectedStyle}
          wardrobe={wardrobe}
          onChangeWardrobe={setWardrobe}
          onClose={() => setShowWardrobeModal(false)}
        />
      )}

      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          muted={muted}
          onChangeSettings={setSettings}
          onToggleMute={handleToggleMute}
          onClose={() => setShowSettingsModal(false)}
        />
      )}

      {showQuestsModal && (
        <QuestsModal
          profile={rankedProfile}
          questProgress={questProgress}
          onClaimQuest={handleClaimQuest}
          onRedeemCode={handleRedeemCode}
          onClose={() => setShowQuestsModal(false)}
        />
      )}

      {showOnlineModal && (
        <OnlineLobbyModal
          mode={onlineMode}
          connected={wsConnected}
          pingMs={pingMs}
          clientId={wsClientId}
          room={onlineRoom}
          errorMsg={onlineError}
          defaultStyle={selectedStyle}
          defaultFlow={selectedFlow}
          defaultGk={gkDifficulty}
          defaultMatchMode={matchMode}
          defaultRole={selectedRole}
          rankedProfile={rankedProfile}
          matchmakingStatus={matchmakingStatus}
          onChangeMode={handleChangeOnlineMode}
          onSelectRole={setSelectedRole}
          onUpdatePlayerName={(name) =>
            setRankedProfile((prev) => ({ ...prev, playerName: name.slice(0, 16) || 'Egoist' }))
          }
          onStartMatchmaking={(name, styleId, flowId, mm, qType, role) => {
            setOnlineError(null);
            setActiveQueueType(qType);
            activeQueueTypeRef.current = qType;
            getActiveClient()?.joinMatchmaking(name, styleId, flowId, mm, qType, rankedProfile.rp, role);
          }}
          onCancelMatchmaking={() => {
            getActiveClient()?.cancelMatchmaking();
            setMatchmakingStatus(null);
          }}
          onForceStartMatchmaking={() => {
            getActiveClient()?.forceStartMatchmaking();
          }}
          onCreateRoom={(name, styleId, flowId, gk, mm, role) => {
            setOnlineError(null);
            getActiveClient()?.createRoom(name, styleId, flowId, gk, mm, 'CASUAL', rankedProfile.rp, role);
          }}
          onJoinRoom={(rawCode, name, styleId, flowId, role) => {
            setOnlineError(null);
            const code = rawCode.trim().toUpperCase();
            if (code.length === 5 && onlineModeRef.current !== 'p2p') {
              handleChangeOnlineMode('p2p');
              p2pClientRef.current?.joinRoom(code, name, styleId, flowId, rankedProfile.rp, role);
              return;
            }
            if (code.length === 4 && onlineModeRef.current !== 'ws') {
              pendingAutoJoinRef.current = {
                code,
                name,
                styleId,
                flowId,
                rp: rankedProfile.rp,
                role,
              };
              handleChangeOnlineMode('ws');
              return;
            }
            getActiveClient()?.joinRoom(code, name, styleId, flowId, rankedProfile.rp, role);
          }}
          onLeaveRoom={() => {
            getActiveClient()?.leaveRoom();
            setOnlineRoom(null);
          }}
          onUpdatePlayer={(patch) => getActiveClient()?.updatePlayer(patch)}
          onSetGk={(gk) => getActiveClient()?.setGkDifficulty(gk)}
          onSetMatchMode={(mm) => getActiveClient()?.setMatchMode(mm)}
          onStartOnlineMatch={() => getActiveClient()?.startMatch()}
          onClose={() => {
            if (matchmakingStatus?.searching) {
              getActiveClient()?.cancelMatchmaking();
              setMatchmakingStatus(null);
            }
            setShowOnlineModal(false);
          }}
        />
      )}

      {showSpinModal && (
        <SpinLobbyModal
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          unlockedStyles={unlockedStyles}
          sandboxAllUnlocked={sandboxAllUnlocked}
          spins={spins}
          luckySpins={luckySpins}
          yen={yen}
          onSelectStyle={setSelectedStyle}
          onSelectFlow={(f) => {
            setSelectedFlow(f);
            setYen((prev) => Math.max(0, prev - 250));
          }}
          onUnlockStyle={(id) =>
            setUnlockedStyles((prev) => (prev.includes(id) ? prev : [...prev, id]))
          }
          onConsumeSpin={(lucky) => {
            if (lucky) setLuckySpins((p) => Math.max(0, p - 1));
            else setSpins((p) => Math.max(0, p - 1));
          }}
          onBuySpins={(kind) => {
            if (kind === 'NORMAL' && yen >= 300) {
              setYen((p) => p - 300);
              setSpins((p) => p + 1);
            } else if (kind === 'LUCKY' && yen >= 900) {
              setYen((p) => p - 900);
              setLuckySpins((p) => p + 1);
            }
          }}
          onToggleSandbox={() => setSandboxAllUnlocked((v) => !v)}
          onClose={() => setShowSpinModal(false)}
        />
      )}
    </div>
  );
}
