import 'dotenv/config';
import fs from 'fs';
import http from 'http';
import path from 'path';
import express from 'express';
import { WebSocketServer } from 'ws';
import { handleWsConnection, listPublicRooms } from './server/onlineRooms.ts';
import { getOrGenerateCutsceneVoice, prewarmNewCharacterVoices } from './server/voiceGenerator.ts';
import { STYLES } from './src/data/styles.ts';
import type { LeaderboardEntry, StyleId } from './src/types/game.ts';

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), '.data');
const LEADERBOARD_FILE = path.join(DATA_DIR, 'leaderboard.json');

const leaderboardMap = new Map<string, LeaderboardEntry>();

function loadLeaderboard() {
  try {
    if (fs.existsSync(LEADERBOARD_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(LEADERBOARD_FILE, 'utf8'));
      if (Array.isArray(parsed)) {
        for (const item of parsed) {
          if (item && typeof item.playerName === 'string' && typeof item.rp === 'number') {
            leaderboardMap.set(item.playerName.toLowerCase(), item);
          }
        }
      }
    }
  } catch {
    // Ignore corrupt file
  }
}

function saveLeaderboard() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    const sorted = Array.from(leaderboardMap.values())
      .sort((a, b) => b.rp - a.rp)
      .slice(0, 50);
    fs.writeFileSync(LEADERBOARD_FILE, JSON.stringify(sorted, null, 2), 'utf8');
  } catch {
    // Non-fatal in read-only environments
  }
}

loadLeaderboard();

const app = express();
app.use(express.json({ limit: '1mb' }));

app.get('/api/rooms', (_req, res) => {
  res.json({ rooms: listPublicRooms() });
});

app.get('/api/leaderboard', (_req, res) => {
  const entries = Array.from(leaderboardMap.values())
    .sort((a, b) => b.rp - a.rp)
    .slice(0, 25);
  res.json({ entries });
});

app.post('/api/leaderboard', (req, res) => {
  const body = req.body as Partial<LeaderboardEntry> | undefined;
  const rawName = typeof body?.playerName === 'string' ? body.playerName.trim().slice(0, 14) : '';
  if (!rawName) {
    res.status(400).json({ error: 'playerName required' });
    return;
  }
  const favoriteStyle = (
    typeof body?.favoriteStyle === 'string' && body.favoriteStyle in STYLES
      ? body.favoriteStyle
      : 'musab'
  ) as StyleId;

  const entry: LeaderboardEntry = {
    playerName: rawName,
    rp: Math.max(0, Math.round(Number(body?.rp) || 1000)),
    wins: Math.max(0, Math.round(Number(body?.wins) || 0)),
    losses: Math.max(0, Math.round(Number(body?.losses) || 0)),
    goals: Math.max(0, Math.round(Number(body?.goals) || 0)),
    favoriteStyle,
  };
  leaderboardMap.set(rawName.toLowerCase(), entry);
  saveLeaderboard();
  const entries = Array.from(leaderboardMap.values())
    .sort((a, b) => b.rp - a.rp)
    .slice(0, 25);
  res.json({ ok: true, entries });
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

app.get('/api/voice/:key', async (req, res) => {
  const result = await getOrGenerateCutsceneVoice(req.params.key || '');
  if (result.status !== 200) {
    res.status(result.status).json({ error: result.error ?? 'Voice unavailable' });
    return;
  }
  res.setHeader('Content-Type', result.mimeType);
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(result.buffer);
});

async function startServer() {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });
  wss.on('connection', (ws) => {
    handleWsConnection(ws);
  });

  // Keep WebSocket connections alive behind reverse proxies
  const heartbeat = setInterval(() => {
    for (const client of wss.clients) {
      if (client.readyState === 1) {
        client.ping();
      }
    }
  }, 20000);
  wss.on('close', () => clearInterval(heartbeat));

  const distPath = path.resolve(process.cwd(), 'dist');
  const distIndex = path.join(distPath, 'index.html');
  const isDevLifecycle = process.env.npm_lifecycle_event === 'dev';
  const useStaticDist =
    fs.existsSync(distIndex) &&
    (!isDevLifecycle || process.env.NODE_ENV === 'production');

  if (useStaticDist) {
    app.use(
      '/assets',
      express.static(path.join(distPath, 'assets'), {
        maxAge: '1y',
        immutable: true,
      })
    );
    app.use(
      express.static(distPath, {
        index: false,
        maxAge: '1h',
      })
    );
    const publicPath = path.resolve(process.cwd(), 'public');
    if (fs.existsSync(publicPath)) {
      app.use(express.static(publicPath, { index: false, maxAge: '1h' }));
    }
    app.get('*', (_req, res) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(distIndex);
    });
  } else {
    let viteMiddlewares: express.RequestHandler | null = null;
    const viteReady = import('vite')
      .then(({ createServer: createViteServer }) =>
        createViteServer({
          server: {
            middlewareMode: true,
            hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
          },
          appType: 'spa',
        })
      )
      .then((vite) => {
        viteMiddlewares = vite.middlewares;
      })
      .catch((err) => {
        console.error('Vite middleware initialization failed:', err);
      });

    app.use(async (req, res, next) => {
      if (!viteMiddlewares) {
        await viteReady;
      }
      if (viteMiddlewares) {
        return viteMiddlewares(req, res, next);
      }
      if (fs.existsSync(distIndex)) {
        return res.sendFile(distIndex);
      }
      next();
    });
  }

  // Listen immediately so platform healthchecks and Share URLs never wait for Vite cold-start
  server.listen(PORT, '0.0.0.0', () => {
    console.log(
      `MüminRivals (${useStaticDist ? 'static-dist' : 'vite-dev'} + WS) on http://0.0.0.0:${PORT}`
    );
    void prewarmNewCharacterVoices();
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
