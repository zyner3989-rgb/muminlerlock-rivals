import fs from 'fs';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { TURKISH_VOICE_SCRIPTS } from '../src/data/voiceScripts.ts';

const CACHE_DIR = path.resolve(process.cwd(), '.data', 'voices');

const NEW_VOICE_KEYS = [
  'umidi_awakening',
  'umidi_ulti',
  'musab_musa_combo',
  'esref_tek_awakening',
  'esref_tek_ulti',
  'arap_kavuncu_awakening',
  'arap_kavuncu_ulti',
  'hamzac5_awakening',
  'hamzac5_ulti',
  'memud_awakening',
  'memud_ulti',
];

let aiClient: GoogleGenAI | null = null;
const memoryCache = new Map<string, { buffer: Buffer; mimeType: string }>();
const inFlight = new Map<string, Promise<{ buffer: Buffer; mimeType: string }>>();

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function synthesizeWithGemini(key: string): Promise<{ buffer: Buffer; mimeType: string }> {
  const spec = TURKISH_VOICE_SCRIPTS[key];
  if (!spec) {
    throw new Error(`Unknown voice script key: ${key}`);
  }

  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured');
  }

  const models = ['gemini-3.8-flash-tts', 'gemini-3.8-flash-lite-tts'];
  let lastErr: unknown = null;

  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const speechConfig = spec.multiSpeakerTurns?.length
          ? {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs: spec.multiSpeakerTurns.map((t) => ({
                  speaker: t.speaker,
                  voiceConfig: { prebuiltVoiceConfig: { voiceName: t.voiceName } },
                })),
              },
            }
          : {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: spec.voiceName },
              },
            };

        const promptText = spec.multiSpeakerTurns?.length
          ? spec.multiSpeakerTurns.map((t) => `${t.speaker}: ${t.line}`).join('\n')
          : spec.text;

        const response = await ai.models.generateContent({
          model,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: promptText,
                  speechMetadata: {
                    style: `${spec.stylePrompt} Erkek anime seslendirmeni (shonen seiyuu) enerjisiyle, gür ve net söyle.`,
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig,
          },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          const buffer = Buffer.from(base64Audio, 'base64');
          try {
            if (!fs.existsSync(CACHE_DIR)) {
              fs.mkdirSync(CACHE_DIR, { recursive: true });
            }
            fs.writeFileSync(path.join(CACHE_DIR, `${key}_v2.wav`), buffer);
          } catch {
            // Non-fatal in read-only environments; still cached in memory
          }
          const result = { buffer, mimeType: 'audio/wav' };
          memoryCache.set(key, result);
          return result;
        }
        lastErr = new Error('Empty audio payload returned by Gemini TTS');
      } catch (err) {
        lastErr = err;
        await new Promise((r) => setTimeout(r, 350 * (attempt + 1)));
      }
    }
  }

  throw lastErr instanceof Error ? lastErr : new Error('Gemini TTS synthesis failed');
}

export async function getOrGenerateCutsceneVoice(
  rawKey: string
): Promise<{ buffer: Buffer; mimeType: string; status: number; error?: string }> {
  const key = rawKey.replace(/[^a-z0-9_]/gi, '').toLowerCase();
  if (!key || !(key in TURKISH_VOICE_SCRIPTS)) {
    return { buffer: Buffer.alloc(0), mimeType: 'application/json', status: 404, error: 'Voice key not found' };
  }

  const memHit = memoryCache.get(key);
  if (memHit) {
    return { ...memHit, status: 200 };
  }

  const cachedWavPath = path.join(CACHE_DIR, `${key}_v2.wav`);
  if (fs.existsSync(cachedWavPath)) {
    const buffer = fs.readFileSync(cachedWavPath);
    const result = { buffer, mimeType: 'audio/wav' };
    memoryCache.set(key, result);
    return { ...result, status: 200 };
  }

  if (!getAiClient()) {
    return {
      buffer: Buffer.alloc(0),
      mimeType: 'application/json',
      status: 503,
      error: 'GEMINI_API_KEY is not configured for voice synthesis',
    };
  }

  let pending = inFlight.get(key);
  if (!pending) {
    pending = synthesizeWithGemini(key).finally(() => {
      inFlight.delete(key);
    });
    inFlight.set(key, pending);
  }

  try {
    const generated = await pending;
    return { ...generated, status: 200 };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'TTS generation failed';
    return { buffer: Buffer.alloc(0), mimeType: 'application/json', status: 502, error: message };
  }
}

export async function prewarmNewCharacterVoices(): Promise<void> {
  if (!getAiClient()) return;
  for (const key of NEW_VOICE_KEYS) {
    const cachedWavPath = path.join(CACHE_DIR, `${key}_v2.wav`);
    if (fs.existsSync(cachedWavPath)) continue;
    try {
      await getOrGenerateCutsceneVoice(key);
      await new Promise((r) => setTimeout(r, 200));
    } catch {
      // Keep warming remaining voices
    }
  }
}
