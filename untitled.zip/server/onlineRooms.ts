import type { WebSocket } from 'ws';
import { ROLES } from '../src/data/roles.ts';
import { FLOWS, STYLES } from '../src/data/styles.ts';
import {
  applySimPlayerInput,
  buildSimActors,
  buildSimWorldSnapshot,
  createSimRoom,
  handleSimDiscreteAction,
  returnSimToLobby,
  serializeSimLobby,
  setSimMatchDuration,
  type SimBroadcastSink,
  type SimRoomState,
  startSimMatch,
  stepSimRoom,
} from '../src/network/roomSimulation.ts';
import type {
  ChatMessage,
  FlowId,
  GkDifficulty,
  MatchMode,
  PlayerRole,
  QueueType,
  StyleId,
  VoicePeerState,
} from '../src/types/game.ts';

function parseRole(raw: unknown): PlayerRole {
  return typeof raw === 'string' && raw in ROLES ? (raw as PlayerRole) : 'CF';
}

interface WsRoom extends SimRoomState {
  sockets: Map<string, WebSocket>;
  voicePeers: Map<string, VoicePeerState>;
}

interface QueueEntry {
  clientId: string;
  ws: WebSocket;
  name: string;
  styleId: StyleId;
  flowId: FlowId;
  role: PlayerRole;
  matchMode: MatchMode;
  queueType: QueueType;
  rp: number;
  joinedAt: number;
}

const rooms = new Map<string, WsRoom>();
const clientToRoom = new Map<string, string>();
const matchmakingQueue = new Map<string, QueueEntry>();

function genRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? genRoomCode() : code;
}

function sendJson(ws: WebSocket | undefined, type: string, payload: unknown) {
  if (!ws || ws.readyState !== 1) return;
  ws.send(JSON.stringify({ type, payload }));
}

function broadcastRoom(room: WsRoom, type: string, payload: unknown) {
  const msg = JSON.stringify({ type, payload });
  for (const ws of room.sockets.values()) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

function broadcastVoicePeers(room: WsRoom) {
  broadcastRoom(room, 'voice:peers', Array.from(room.voicePeers.values()));
}

function makeSink(room: WsRoom): SimBroadcastSink {
  return {
    broadcastLobby: (lobby) => broadcastRoom(room, 'room:state', lobby),
    broadcastCutscene: (evt) => broadcastRoom(room, 'match:cutscene', evt),
    broadcastSound: (sound, power, pitch) =>
      broadcastRoom(room, 'match:sound', { sound, power, pitch }),
  };
}

export function listPublicRooms() {
  const list: Array<{
    roomCode: string;
    playerCount: number;
    gkDifficulty: GkDifficulty;
    matchMode: MatchMode;
    queueType: QueueType;
    status: string;
  }> = [];
  for (const room of rooms.values()) {
    list.push({
      roomCode: room.roomCode,
      playerCount: room.players.size,
      gkDifficulty: room.gkDifficulty,
      matchMode: room.matchMode,
      queueType: room.queueType,
      status: room.status,
    });
  }
  return list;
}

function launchMatchedRoom(entries: QueueEntry[], matchMode: MatchMode, queueType: QueueType) {
  if (entries.length === 0) return;
  const code = genRoomCode();
  const host = entries[0];
  const gkDifficulty: GkDifficulty = queueType === 'RANKED' ? 'HARD' : 'MEDIUM';
  const base = createSimRoom(code, host.clientId, gkDifficulty, matchMode, queueType);
  const room: WsRoom = {
    ...base,
    sockets: new Map(),
    voicePeers: new Map(),
  };

  const maxPerTeam = matchMode === '1V1' ? 1 : 3;
  let blueCount = 0;
  let redCount = 0;

  entries.forEach((entry, idx) => {
    matchmakingQueue.delete(entry.clientId);
    const oldCode = clientToRoom.get(entry.clientId);
    if (oldCode && oldCode !== code) {
      const oldRoom = rooms.get(oldCode);
      if (oldRoom) {
        oldRoom.players.delete(entry.clientId);
        oldRoom.sockets.delete(entry.clientId);
        oldRoom.voicePeers.delete(entry.clientId);
      }
    }

    let team: 'BLUE' | 'RED' = idx % 2 === 0 ? 'BLUE' : 'RED';
    if (team === 'BLUE' && blueCount >= maxPerTeam) team = 'RED';
    if (team === 'RED' && redCount >= maxPerTeam) team = 'BLUE';
    if (team === 'BLUE') blueCount++;
    else redCount++;

    room.players.set(entry.clientId, {
      clientId: entry.clientId,
      name: entry.name,
      team,
      styleId: entry.styleId,
      flowId: entry.flowId,
      role: entry.role,
      isHost: entry.clientId === host.clientId,
      ready: true,
      rp: entry.rp,
    });
    room.sockets.set(entry.clientId, entry.ws);
    clientToRoom.set(entry.clientId, code);
  });

  rooms.set(code, room);
  const lobby = serializeSimLobby(room);
  for (const entry of entries) {
    sendJson(entry.ws, 'matchmaking:matched', lobby);
  }
  startSimMatch(room, makeSink(room));
  for (const [cid, ws] of room.sockets.entries()) {
    sendJson(ws, 'world:state', buildSimWorldSnapshot(room, cid));
  }
}

function processMatchmaking(nowMs: number) {
  if (matchmakingQueue.size === 0) return;

  const buckets = new Map<string, QueueEntry[]>();
  for (const [cid, entry] of matchmakingQueue.entries()) {
    if (entry.ws.readyState !== 1) {
      matchmakingQueue.delete(cid);
      continue;
    }
    const key = `${entry.queueType}:${entry.matchMode}`;
    const list = buckets.get(key) ?? [];
    list.push(entry);
    buckets.set(key, list);
  }

  for (const list of buckets.values()) {
    list.sort((a, b) => a.joinedAt - b.joinedAt);
    const maxHumans = list[0].matchMode === '1V1' ? 2 : 6;

    while (list.length >= 2) {
      const batch = list.splice(0, Math.min(maxHumans, list.length));
      launchMatchedRoom(batch, batch[0].matchMode, batch[0].queueType);
    }

    for (const solo of list) {
      const elapsedSec = Math.floor((nowMs - solo.joinedAt) / 1000);
      if (nowMs - solo.joinedAt >= 6500) {
        launchMatchedRoom([solo], solo.matchMode, solo.queueType);
      } else {
        sendJson(solo.ws, 'matchmaking:status', {
          searching: true,
          queueType: solo.queueType,
          matchMode: solo.matchMode,
          elapsedSec,
          playersInQueue: matchmakingQueue.size,
        });
      }
    }
  }
}

let loopStarted = false;
function ensureSimulationLoop() {
  if (loopStarted) return;
  loopStarted = true;
  let lastTime = Date.now();
  let queueAccum = 0;

  setInterval(() => {
    const now = Date.now();
    const dt = Math.min(0.05, Math.max(0.004, (now - lastTime) / 1000));
    lastTime = now;

    queueAccum += dt;
    if (queueAccum >= 0.75) {
      queueAccum = 0;
      processMatchmaking(now);
    }

    for (const room of rooms.values()) {
      if (room.status === 'PLAYING') {
        stepSimRoom(room, dt, makeSink(room));
        room.tickAccum += dt;
        if (room.tickAccum >= 0.024) {
          room.tickAccum = 0;
          room.worldSeq++;
          for (const [cid, ws] of room.sockets.entries()) {
            sendJson(ws, 'world:state', buildSimWorldSnapshot(room, cid));
          }
        }
      }
    }
  }, 16);
}

export function handleWsConnection(ws: WebSocket) {
  ensureSimulationLoop();
  const rawSocket = (ws as unknown as { _socket?: { setNoDelay?: (b: boolean) => void } })._socket;
  rawSocket?.setNoDelay?.(true);

  const clientId = Math.random().toString(36).slice(2, 10);
  sendJson(ws, 'ws:welcome', { clientId });

  const leaveCurrentRoom = () => {
    matchmakingQueue.delete(clientId);
    const oldCode = clientToRoom.get(clientId);
    if (!oldCode) return;
    clientToRoom.delete(clientId);
    const room = rooms.get(oldCode);
    if (!room) return;
    const leavingPlayer = room.players.get(clientId);
    room.players.delete(clientId);
    room.sockets.delete(clientId);
    const hadVoice = room.voicePeers.delete(clientId);
    if (room.players.size === 0) {
      rooms.delete(oldCode);
      return;
    }
    if (room.hostId === clientId) {
      const nextHost = room.players.values().next().value;
      if (nextHost) {
        room.hostId = nextHost.clientId;
        nextHost.isHost = true;
      }
    }
    broadcastRoom(room, 'room:state', serializeSimLobby(room));
    if (hadVoice) broadcastVoicePeers(room);
    if (leavingPlayer) {
      const sysMsg: ChatMessage = {
        id: `sys_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        senderId: 'system',
        senderName: 'SİSTEM',
        text: `${leavingPlayer.name} gruptan ayrıldı.`,
        timestamp: Date.now(),
        system: true,
      };
      broadcastRoom(room, 'chat:message', sysMsg);
    }
  };

  ws.on('message', (raw) => {
    let msg: { type?: string; payload?: Record<string, unknown> };
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    const type = msg.type;
    const p = msg.payload ?? {};

    if (type === 'ws:ping') {
      sendJson(ws, 'ws:pong', { ts: typeof p.ts === 'number' ? p.ts : Date.now() });
      return;
    }

    if (type === 'matchmaking:join') {
      leaveCurrentRoom();
      const playerName =
        typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Egoist';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'musab') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const matchMode: MatchMode = p.matchMode === '1V1' ? '1V1' : '3V3';
      const queueType: QueueType = p.queueType === 'RANKED' ? 'RANKED' : 'CASUAL';
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : 1000;

      const entry: QueueEntry = {
        clientId,
        ws,
        name: playerName,
        styleId,
        flowId,
        role: parseRole(p.role),
        matchMode,
        queueType,
        rp,
        joinedAt: Date.now(),
      };
      matchmakingQueue.set(clientId, entry);
      sendJson(ws, 'matchmaking:status', {
        searching: true,
        queueType,
        matchMode,
        elapsedSec: 0,
        playersInQueue: matchmakingQueue.size,
      });
      processMatchmaking(Date.now());
      return;
    }

    if (type === 'matchmaking:cancel') {
      const removed = matchmakingQueue.delete(clientId);
      if (removed) {
        sendJson(ws, 'matchmaking:status', {
          searching: false,
          queueType: 'CASUAL',
          matchMode: '3V3',
          elapsedSec: 0,
          playersInQueue: matchmakingQueue.size,
        });
      }
      return;
    }

    if (type === 'matchmaking:force_start') {
      const entry = matchmakingQueue.get(clientId);
      if (entry) {
        launchMatchedRoom([entry], entry.matchMode, entry.queueType);
      }
      return;
    }

    if (type === 'room:create') {
      leaveCurrentRoom();
      const code = genRoomCode();
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Egoist';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'musab') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const gkDifficulty = (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'HARD' ? p.gkDifficulty : 'MEDIUM') as GkDifficulty;
      const matchMode: MatchMode = p.matchMode === '1V1' ? '1V1' : '3V3';
      const queueType: QueueType = p.queueType === 'RANKED' ? 'RANKED' : 'CASUAL';
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : undefined;

      const base = createSimRoom(code, clientId, gkDifficulty, matchMode, queueType);
      const room: WsRoom = {
        ...base,
        sockets: new Map(),
        voicePeers: new Map(),
      };
      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: 'BLUE',
        styleId,
        flowId,
        role: parseRole(p.role),
        isHost: true,
        ready: true,
        rp,
      });
      room.sockets.set(clientId, ws);
      rooms.set(code, room);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
      broadcastVoicePeers(room);
    } else if (type === 'room:join') {
      const code = typeof p.roomCode === 'string' ? p.roomCode.trim().toUpperCase() : '';
      const room = rooms.get(code);
      if (!room) {
        sendJson(ws, 'room:error', {
          message: `"${code}" kodlu sunucu odası bulunamadı. Share linkinden bağlanıyorsan P2P (Share Uyumlu) modunu seç!`,
        });
        return;
      }
      if (room.players.size >= 6) {
        sendJson(ws, 'room:error', { message: 'Oda dolu (Maksimum 6 oyuncu).' });
        return;
      }
      leaveCurrentRoom();
      const blueCount = Array.from(room.players.values()).filter((pl) => pl.team === 'BLUE').length;
      const redCount = Array.from(room.players.values()).filter((pl) => pl.team === 'RED').length;
      const autoTeam: 'BLUE' | 'RED' = redCount < blueCount ? 'RED' : 'BLUE';
      const playerName = typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 14) : 'Oyuncu';
      const styleId = (typeof p.styleId === 'string' && p.styleId in STYLES ? p.styleId : 'iskender') as StyleId;
      const flowId = (typeof p.flowId === 'string' && p.flowId in FLOWS ? p.flowId : 'egoist') as FlowId;
      const rp = typeof p.rp === 'number' && Number.isFinite(p.rp) ? Math.max(0, Math.round(p.rp)) : undefined;

      room.players.set(clientId, {
        clientId,
        name: playerName,
        team: autoTeam,
        styleId,
        flowId,
        role: parseRole(p.role),
        isHost: false,
        ready: true,
        rp,
      });
      room.sockets.set(clientId, ws);
      clientToRoom.set(clientId, code);
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
      sendJson(ws, 'voice:peers', Array.from(room.voicePeers.values()));
      const sysMsg: ChatMessage = {
        id: `sys_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        senderId: 'system',
        senderName: 'SİSTEM',
        text: `${playerName} gruba katıldı.`,
        timestamp: Date.now(),
        system: true,
      };
      broadcastRoom(room, 'chat:message', sysMsg);
      if (room.status === 'PLAYING') {
        room.actors = buildSimActors(room);
        sendJson(ws, 'world:state', buildSimWorldSnapshot(room, clientId));
      }
    } else if (type === 'room:leave') {
      leaveCurrentRoom();
    } else if (type === 'room:update_player') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const info = room?.players.get(clientId);
      if (!room || !info) return;
      if (typeof p.styleId === 'string' && p.styleId in STYLES) info.styleId = p.styleId as StyleId;
      if (typeof p.flowId === 'string' && p.flowId in FLOWS) info.flowId = p.flowId as FlowId;
      if (p.team === 'BLUE' || p.team === 'RED') info.team = p.team;
      if (typeof p.role === 'string' && p.role in ROLES) info.role = p.role as PlayerRole;
      if (typeof p.name === 'string' && p.name.trim()) {
        info.name = p.name.trim().slice(0, 14);
        const vp = room.voicePeers.get(clientId);
        if (vp) {
          vp.name = info.name;
          broadcastVoicePeers(room);
        }
      }
      if (typeof p.rp === 'number' && Number.isFinite(p.rp)) info.rp = Math.max(0, Math.round(p.rp));
      broadcastRoom(room, 'room:state', serializeSimLobby(room));
    } else if (type === 'room:set_gk') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.gkDifficulty === 'EASY' || p.gkDifficulty === 'MEDIUM' || p.gkDifficulty === 'HARD') {
        room.gkDifficulty = p.gkDifficulty;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:set_mode') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (p.matchMode === '1V1' || p.matchMode === '3V3') {
        room.matchMode = p.matchMode;
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:set_duration') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      if (typeof p.durationSec === 'number') {
        setSimMatchDuration(room, p.durationSec);
        broadcastRoom(room, 'room:state', serializeSimLobby(room));
      }
    } else if (type === 'room:start') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      startSimMatch(room, makeSink(room));
      room.worldSeq++;
      for (const [cid, sock] of room.sockets.entries()) {
        sendJson(sock, 'world:state', buildSimWorldSnapshot(room, cid));
      }
    } else if (type === 'room:return_to_lobby') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || room.hostId !== clientId) return;
      returnSimToLobby(room, makeSink(room));
      broadcastRoom(room, 'chat:message', {
        id: `sys_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        senderId: 'system',
        senderName: 'SİSTEM',
        text: 'Grup lobiye döndü. Yeni maç ayarlanabilir!',
        timestamp: Date.now(),
        system: true,
      } satisfies ChatMessage);
    } else if (type === 'chat:send') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const sender = room?.players.get(clientId);
      if (!room || !sender || typeof p.text !== 'string') return;
      const text = p.text.trim().slice(0, 220);
      if (!text) return;
      const chatMsg: ChatMessage = {
        id: `c_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        senderId: clientId,
        senderName: sender.name,
        team: sender.team,
        text,
        timestamp: Date.now(),
      };
      broadcastRoom(room, 'chat:message', chatMsg);
    } else if (type === 'voice:join') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const sender = room?.players.get(clientId);
      if (!room || !sender) return;
      room.voicePeers.set(clientId, {
        clientId,
        name: sender.name,
        joined: true,
        muted: false,
        speaking: false,
      });
      broadcastVoicePeers(room);
    } else if (type === 'voice:leave') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room) return;
      if (room.voicePeers.delete(clientId)) {
        broadcastVoicePeers(room);
      }
    } else if (type === 'voice:state') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      const vp = room?.voicePeers.get(clientId);
      if (!room || !vp) return;
      if (typeof p.muted === 'boolean') vp.muted = p.muted;
      if (typeof p.speaking === 'boolean') vp.speaking = p.speaking;
      broadcastVoicePeers(room);
    } else if (type === 'voice:signal') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || typeof p.targetId !== 'string') return;
      const targetWs = room.sockets.get(p.targetId);
      if (targetWs) {
        sendJson(targetWs, 'voice:signal', {
          fromId: clientId,
          targetId: p.targetId,
          signalType: p.signalType,
          sdp: p.sdp,
          candidate: p.candidate,
        });
      }
    } else if (type === 'player:input') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room) return;
      applySimPlayerInput(
        room,
        clientId,
        Number(p.moveX),
        Number(p.moveZ),
        Boolean(p.sprint),
        Boolean(p.chargingShot),
        typeof p.aimYaw === 'number' ? p.aimYaw : undefined,
        Boolean(p.lockYaw),
        typeof p.aimPitch === 'number' ? p.aimPitch : undefined
      );
    } else if (type === 'player:action') {
      const code = clientToRoom.get(clientId);
      const room = code ? rooms.get(code) : undefined;
      if (!room || typeof p.action !== 'string') return;
      handleSimDiscreteAction(room, clientId, p.action, makeSink(room));
    }
  });

  ws.on('close', () => {
    leaveCurrentRoom();
  });
}
