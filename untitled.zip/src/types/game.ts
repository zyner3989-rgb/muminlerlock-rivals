export type StyleId =
  | 'musab'
  | 'musa'
  | 'iskender'
  | 'aras'
  | 'ebulfez'
  | 'zero'
  | 'berk'
  | 'esref_tek'
  | 'arap_kavuncu'
  | 'hamzac5'
  | 'memud'
  | 'umidi';

export type Rarity = 'MASTER' | 'WORLD CLASS' | 'MYTHIC' | 'RARE';

export type FlowId = 'egoist' | 'godspeed' | 'prodigy' | 'wildcard' | 'dribbler';

export type UltiRange = 'FULL_PITCH' | 'MIDFIELD';

export type GkDifficulty = 'EASY' | 'MEDIUM' | 'HARD';

export type MatchMode = '1V1' | '3V3';

export type PlayerRole = 'CF' | 'LW' | 'RW' | 'CM' | 'GK';

export type GameScreen = 'TITLE' | 'PLAYING';

export type MatchPhase =
  | 'IDLE'
  | 'KICKOFF'
  | 'LIVE'
  | 'SET_PIECE'
  | 'CUTSCENE'
  | 'GOAL_CELEBRATION'
  | 'PAUSED'
  | 'ENDED';

export type SetPieceKind = 'THROW_IN' | 'CORNER';

export interface SetPieceHudInfo {
  kind: SetPieceKind;
  team: 'BLUE' | 'RED';
  takerName: string;
  isUserTaker: boolean;
  timeLeft: number;
}

export type OutfitId =
  | 'signature'
  | 'neoblack'
  | 'royalwhite'
  | 'cyberjacket'
  | 'hoodie'
  | 'crimson';

export type HairStyleId =
  | 'character'
  | 'wolfcut'
  | 'spiky'
  | 'curtain'
  | 'curly'
  | 'windswept'
  | 'ponytail'
  | 'frostcrown';

export type CleatId =
  | 'character'
  | 'gold_pro'
  | 'cyber_cyan'
  | 'crimson_speed'
  | 'phantom_black';

export type BackAccessoryId = 'none' | 'scarf' | 'cape' | 'katana' | 'wings';

export interface WardrobeConfig {
  outfitId: OutfitId;
  hairStyleId: HairStyleId;
  hairColor: string; // 'character' or hex color
  cleatId: CleatId;
  backAccessoryId: BackAccessoryId;
}

export type GraphicsQuality = 'LOW' | 'MEDIUM' | 'HIGH' | 'ULTRA';

export type WeatherMode = 'NIGHT' | 'SUNSET' | 'RAIN';

export type FpsCapMode = 'VSYNC' | '120' | '144' | 'UNLIMITED';

export type QueueType = 'CASUAL' | 'RANKED';

export type RankTierId = 'BRONZE' | 'SILVER' | 'GOLD' | 'DIAMOND' | 'PRODIGY' | 'WORLD_XI';

export interface GameSettings {
  quality: GraphicsQuality;
  fpsMode: FpsCapMode;
  bloom: boolean;
  shadows: boolean;
  particles: boolean;
  weather: WeatherMode;
  fov: number;
  cameraDistance: number;
  mouseSensitivity: number;
  masterVolume: number; // 0..100
  showFps: boolean;
}

export interface MatchHistoryEntry {
  id: string;
  timestamp: number;
  queueType: QueueType;
  matchMode: MatchMode;
  styleId: StyleId;
  blueScore: number;
  redScore: number;
  goals: number;
  rpDelta: number;
  result: 'WIN' | 'LOSS' | 'DRAW';
}

export interface RankedProfile {
  playerName: string;
  rp: number;
  wins: number;
  losses: number;
  draws: number;
  goals: number;
  mvps: number;
  winStreak: number;
  bestStreak: number;
  history: MatchHistoryEntry[];
}

export interface LeaderboardEntry {
  playerName: string;
  rp: number;
  wins: number;
  losses: number;
  goals: number;
  favoriteStyle: StyleId;
}

export interface MatchmakingStatus {
  searching: boolean;
  queueType: QueueType;
  matchMode: MatchMode;
  elapsedSec: number;
  playersInQueue: number;
}

export interface DailyQuestProgress {
  goals: number;
  skillsOrDribbles: number;
  matchesPlayed: number;
  claimedIds: string[];
  redeemedCodes: string[];
}

export interface RadarEntity {
  x: number;
  z: number;
  team: 'BLUE' | 'RED' | 'BALL';
  isUser?: boolean;
  isGoalkeeper?: boolean;
  yaw?: number;
}

export interface MatchStats {
  goals: number;
  shots: number;
  passes: number;
  dribbles: number;
  steals: number;
}

export interface SkillMeta {
  key: string;
  name: string;
  description: string;
  cooldown: number;
}

export interface StyleDefinition {
  id: StyleId;
  name: string;
  jerseyNumber: number;
  rarity: Rarity;
  title: string;
  primaryColor: string;
  secondaryColor: string;
  auraColor: string;
  hairColor: string;
  skinColor: string;
  accessory:
    | 'headset'
    | 'spiky'
    | 'shades'
    | 'headband'
    | 'gauntlet'
    | 'visor'
    | 'relaxed';
  stats: {
    speed: number;
    shotPower: number;
    dribble: number;
    steal: number;
  };
  skill1: SkillMeta;
  skill2: SkillMeta;
  personalSkill: SkillMeta; // [E / 3] Kişiye Özel Yetenek
  awakeningName: string;
  awakeningSummary: string;
  awakeningQuote: string;
  ultiName: string;
  ultiSummary: string;
  ultiRange: UltiRange;
  ultiRangeLabel: string;
}

export interface FlowDefinition {
  id: FlowId;
  name: string;
  rarity: Rarity;
  color: string;
  bonusText: string;
  speedMult: number;
  shotMult: number;
  staminaRegenMult: number;
}

export type EmoteId =
  | 'SIUUU'
  | 'EGOIST_POSE'
  | 'ARMS_CROSSED'
  | 'KNEE_SLIDE'
  | 'FLEX_ROAR';

export type ActionAnimId =
  | 'NONE'
  | 'DRIBBLE_SPIN'
  | 'AWAKENED_DRIBBLE'
  | 'SLIDE'
  | 'AWAKENED_STEAL'
  | 'KICK'
  | 'SKILL_BURST'
  | 'SKILL_LEAP'
  | 'GK_DIVE'
  | 'THROW_IN'
  | 'HEADER';

export interface HudSnapshot {
  phase: MatchPhase;
  blueScore: number;
  redScore: number;
  timeRemaining: number;
  stamina: number;
  awakening: number;
  isAwakened: boolean;
  awakeningTimeLeft: number;
  ultiUsedInAwakening: boolean;
  shotCharge: number;
  hasBall: boolean;
  skill1Cd: number;
  skill1MaxCd: number;
  skill2Cd: number;
  skill2MaxCd: number;
  personalCd: number;
  personalMaxCd: number;
  dribbleCd: number;
  slideCd: number;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  role: PlayerRole;
  gkBallInHands: boolean;
  gkHoldLeft: number;
  gkDiveCd: number;
  gkInBox?: boolean;
  kickoffLockLeft?: number;
  isTraining: boolean;
  shiftLock: boolean;
  isOnline: boolean;
  roomCode: string | null;
  pingMs?: number | null;
  queueType?: QueueType;
  fps: number;
  duoComboCd?: number;
  radarEntities?: RadarEntity[];
  stats: MatchStats;
  cutsceneBanner: {
    active: boolean;
    speaker: string;
    subtitle: string;
    badge: string;
    accentColor: string;
  } | null;
  goalBanner: {
    scorerId?: string | null;
    scorerName: string;
    scorerStyleId?: StyleId;
    team: 'BLUE' | 'RED';
    isUltiGoal: boolean;
    emote?: EmoteId;
  } | null;
  duoComboPrompt?: {
    active: boolean;
    role: 'PASSER' | 'RECEIVER';
    title: string;
    subtitle: string;
    timeLeft: number;
    cooldownLeft?: number;
  } | null;
  setPiece?: SetPieceHudInfo | null;
  lastActionToast: string | null;
}

// ==================== ONLINE MULTIPLAYER PROTOCOL ====================

export interface RoomPlayerInfo {
  clientId: string;
  name: string;
  team: 'BLUE' | 'RED';
  styleId: StyleId;
  flowId: FlowId;
  role?: PlayerRole;
  isHost: boolean;
  ready: boolean;
  rp?: number;
}

export interface RoomLobbyState {
  roomCode: string;
  hostId: string;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  matchDurationSec?: number;
  queueType?: QueueType;
  status: 'LOBBY' | 'PLAYING';
  players: RoomPlayerInfo[];
}

export interface NetActorState {
  id: string;
  clientId?: string;
  name: string;
  team: 'BLUE' | 'RED';
  styleId: StyleId;
  role?: PlayerRole;
  isGoalkeeper: boolean;
  gkBallInHands?: boolean;
  x: number;
  y?: number;
  z: number;
  vx: number;
  vz: number;
  yaw: number;
  stun: number;
  slide: number;
  dribble: number;
  awakened: boolean;
  emote?: EmoteId | null;
  emoteTimer?: number;
  actionAnim?: ActionAnimId;
  actionTimer?: number;
  wallShield?: number;
  requestPassTimer?: number;
}

export interface NetWorldSnapshot {
  seq?: number;
  phase: MatchPhase;
  blueScore: number;
  redScore: number;
  timeRemaining: number;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  kickoffLockLeft?: number;
  ball: {
    x: number;
    y: number;
    z: number;
    vx: number;
    vy: number;
    vz: number;
    ownerId: string | null;
    isUlti: boolean;
  };
  actors: NetActorState[];
  selfHud?: {
    stamina: number;
    awakening: number;
    isAwakened: boolean;
    awakeningTimeLeft: number;
    ultiUsedInAwakening: boolean;
    shotCharge: number;
    skill1Cd: number;
    skill2Cd: number;
    personalCd: number;
    dribbleCd: number;
    slideCd: number;
    gkBallInHands?: boolean;
    gkHoldLeft?: number;
    gkDiveCd?: number;
    gkInBox?: boolean;
  };
  goalBanner: HudSnapshot['goalBanner'];
  setPiece?: SetPieceHudInfo | null;
  duoComboPrompt?: HudSnapshot['duoComboPrompt'];
  toast: string | null;
}

export interface NetCutsceneEvent {
  actorId: string;
  partnerId?: string;
  styleId: StyleId;
  kind: 'AWAKENING' | 'ULTI' | 'COMBO';
  team?: 'BLUE' | 'RED';
  anchorX: number;
  anchorZ: number;
  oppX: number;
  oppZ: number;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  team?: 'BLUE' | 'RED';
  text: string;
  timestamp: number;
  system?: boolean;
}

export interface VoicePeerState {
  clientId: string;
  name: string;
  joined: boolean;
  muted: boolean;
  speaking: boolean;
}

export interface VoiceSignalPayload {
  fromId: string;
  targetId: string;
  signalType: 'offer' | 'answer' | 'ice';
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
}

export interface StyleCareerStats {
  matches: number;
  wins: number;
  goals: number;
  shots: number;
  passes: number;
  steals: number;
}
