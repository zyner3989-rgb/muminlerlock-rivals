import type { EmoteId, StyleId } from '../types/game';

export interface VoiceClipSpec {
  key: string;
  text: string;
  voiceName: 'Puck' | 'Charon' | 'Fenrir';
  stylePrompt: string;
  pitchFallback: number;
  rateFallback: number;
  multiSpeakerTurns?: Array<{ speaker: string; voiceName: 'Puck' | 'Charon' | 'Fenrir'; line: string }>;
}

export const TURKISH_VOICE_SCRIPTS: Record<string, VoiceClipSpec> = {
  musab_awakening: {
    key: 'musab_awakening',
    text: 'Oyun şimdi başlıyor! Musa, hattın ucunda kal — sahanın kontrolü artık bizde!',
    voiceName: 'Puck',
    stylePrompt:
      'Enerjik, kendinden emin ve karizmatik genç Türk anime erkek oyun kurucu (shonen striker), net ve güçlü ton.',
    pitchFallback: 1.04,
    rateFallback: 1.1,
  },
  musab_ulti: {
    key: 'musab_ulti',
    text: 'Kulaklığı bıraktım... Monitörden fırlayan güçle kaleden kaleye durdurulamaz vole!',
    voiceName: 'Puck',
    stylePrompt:
      'Dramatik ve patlayıcı Türk anime erkek ana karakteri, önce soğukkanlı başlangıç ardından güçlü şut haykırışı.',
    pitchFallback: 1.02,
    rateFallback: 1.1,
  },
  musa_awakening: {
    key: 'musa_awakening',
    text: 'Tam zamanında aradın Musab! Şimdi tüm savunmayı buz gibi yarıp geçiyorum!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Hırslı, derin ve gür sesli Türk anime erkek forvet, agresif ama doğal shonen rakip tonlaması.',
    pitchFallback: 0.92,
    rateFallback: 1.12,
  },
  musa_ulti: {
    key: 'musa_ulti',
    text: 'Bunu durdurabilecek bir kaleci henüz doğmadı! Sonik hızda ateşle!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Çok güçlü, tutkulu ve keskin Türk anime erkek savaşçı/futbolcu haykırışı.',
    pitchFallback: 0.9,
    rateFallback: 1.14,
  },
  iskender_awakening: {
    key: 'iskender_awakening',
    text: 'İyi izle Musa... Parlayan imza hamlem geliyor, gözlerinizi ayırmayın!',
    voiceName: 'Puck',
    stylePrompt:
      'Özgüveni yüksek, cool ve stil sahibi genç Türk anime erkek dahi futbolcu.',
    pitchFallback: 1.08,
    rateFallback: 1.08,
  },
  iskender_ulti: {
    key: 'iskender_ulti',
    text: 'Söz bitti, şimdi sahne benim... Boyut yaran ışınlanma rovaşatası!',
    voiceName: 'Puck',
    stylePrompt:
      'Keskin, şovmen ve heyecan verici Türk anime erkek futbolcu, net bitirici bağırış.',
    pitchFallback: 1.06,
    rateFallback: 1.12,
  },
  aras_awakening: {
    key: 'aras_awakening',
    text: 'Bu skor burada bitmeyecek İskender! Şimdi gerçek maçı başlatıyorum!',
    voiceName: 'Charon',
    stylePrompt:
      'Kararlı, gür sesli ve patlamaya hazır Türk anime erkek forvet, yüksek rekabet enerjisi.',
    pitchFallback: 0.88,
    rateFallback: 1.12,
  },
  aras_ulti: {
    key: 'aras_ulti',
    text: 'Tam güç yüklendi! Topun yanına ışınlandım — kaleden kaleye alev füzesi!',
    voiceName: 'Charon',
    stylePrompt:
      'Tutkulu ve güçlü Türk anime erkek karakter, şut vururken yükselen enerji.',
    pitchFallback: 0.92,
    rateFallback: 1.12,
  },
  ebulfez_awakening: {
    key: 'ebulfez_awakening',
    text: 'Zamanı kendi lehime çeviriyorum... Tek bir parmak şıklatması yeter!',
    voiceName: 'Charon',
    stylePrompt:
      'Soğukkanlı, gizemli ve derin sesli Türk anime erkek anti-kahraman karizması.',
    pitchFallback: 0.84,
    rateFallback: 1.0,
  },
  ebulfez_ulti: {
    key: 'ebulfez_ulti',
    text: 'Geri döndüm! Topu havada yakalayıp kaleye gönderiyorum!',
    voiceName: 'Charon',
    stylePrompt:
      'Karizmatik, etkileyici ve keskin Türk anime erkek sesi.',
    pitchFallback: 0.86,
    rateFallback: 1.1,
  },
  zero_awakening: {
    key: 'zero_awakening',
    text: 'Tüm açılar ve pas hatları hesaplandı. Savunmanızın artık bir şansı yok!',
    voiceName: 'Puck',
    stylePrompt:
      'Zeki, hızlı konuşan dijital deha havasında genç Türk anime erkek oyuncu.',
    pitchFallback: 1.1,
    rateFallback: 1.12,
  },
  zero_ulti: {
    key: 'zero_ulti',
    text: 'Hedef kilitlendi! Orta sahadan kusursuz falsolu yörünge!',
    voiceName: 'Puck',
    stylePrompt:
      'Cool, keskin ve yüksek tempolu Türk anime erkek dahi tonu, net telaffuz.',
    pitchFallback: 1.08,
    rateFallback: 1.12,
  },
  berk_awakening: {
    key: 'berk_awakening',
    text: 'Dinlenme vakti bitti... Şimdi bu demir savunmadan kimse geçemez!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Sakin başlayıp aniden ciddileşerek gürleyen kalın sesli Türk anime erkek savunmacı.',
    pitchFallback: 0.82,
    rateFallback: 1.02,
  },
  berk_ulti: {
    key: 'berk_ulti',
    text: 'Topu söktüm! Orta sahadan gök gürültüsü gibi şut geliyor!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Ağırbaşlı, güçlü ve sarsıcı kalın erkek Türk anime karakter sesi.',
    pitchFallback: 0.8,
    rateFallback: 1.06,
  },
  esref_tek_awakening: {
    key: 'esref_tek_awakening',
    text: 'Bu sahada kuralı ben koyarım... Tek başıma yeterim!',
    voiceName: 'Charon',
    stylePrompt:
      'Karizmatik, ağırbaşlı ve soğukkanlı Türk anime erkek yıldız futbolcu tonu.',
    pitchFallback: 0.8,
    rateFallback: 1.04,
  },
  esref_tek_ulti: {
    key: 'esref_tek_ulti',
    text: 'Tek tabanca yıldırım vole! Kimse durduramaz!',
    voiceName: 'Charon',
    stylePrompt:
      'Keskin, patlayıcı ve özgüven dolu Türk anime erkek bitirici haykırışı.',
    pitchFallback: 0.82,
    rateFallback: 1.12,
  },
  arap_kavuncu_awakening: {
    key: 'arap_kavuncu_awakening',
    text: 'Çöl rüzgarı arkamda! Bu hızda tozuma bile yetişemeyeceksiniz!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Coşkulu, meydan okuyan, gür sesli ve enerjik Türk anime erkek forvet.',
    pitchFallback: 0.88,
    rateFallback: 1.12,
  },
  arap_kavuncu_ulti: {
    key: 'arap_kavuncu_ulti',
    text: 'Altın kasırga başlıyor! Kaleden kaleye durdurulamaz fırtına!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Coşkulu, güçlü ve aksiyon dolu Türk anime erkek şut haykırışı.',
    pitchFallback: 0.86,
    rateFallback: 1.14,
  },
  hamzac5_awakening: {
    key: 'hamzac5_awakening',
    text: 'Vites beşe geçti, motor tam güçte! Bu hızı kimse yakalayamaz!',
    voiceName: 'Puck',
    stylePrompt:
      'Hızlı, adrenalin yüklü genç Türk anime erkek hız canavarı tonu.',
    pitchFallback: 0.96,
    rateFallback: 1.15,
  },
  hamzac5_ulti: {
    key: 'hamzac5_ulti',
    text: 'C5 nitro rovaşata! Tam gaz filelere!',
    voiceName: 'Puck',
    stylePrompt:
      'Yüksek tempolu, heyecanlı ve patlayıcı Türk anime erkek rovaşata haykırışı.',
    pitchFallback: 0.94,
    rateFallback: 1.15,
  },
  memud_awakening: {
    key: 'memud_awakening',
    text: 'Hesap tamam, açı net... Sıradaki gol benim!',
    voiceName: 'Charon',
    stylePrompt:
      'Zeki, sakin ama kendinden emin derin Türk anime erkek taktisyen tonu.',
    pitchFallback: 0.86,
    rateFallback: 1.08,
  },
  memud_ulti: {
    key: 'memud_ulti',
    text: 'Doksan dereceye kilitlendim! Akrep vole füzesi!',
    voiceName: 'Charon',
    stylePrompt:
      'Keskin, şık ve kendinden emin Türk anime erkek bitirici sesi.',
    pitchFallback: 0.88,
    rateFallback: 1.12,
  },
  umidi_awakening: {
    key: 'umidi_awakening',
    text: 'Lan... YouTube kanalımızı çaldın ve eline ne geçti lan!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Şaşkın ve öfkeli ama karizmatik Türk anime erkek yayıncı haykırışı, net ve vurgulu tonlama.',
    pitchFallback: 0.94,
    rateFallback: 1.06,
  },
  umidi_ulti: {
    key: 'umidi_ulti',
    text: 'Dandik paket dediler... İçinden Messi çıktı, kaleyi yıkıyor!',
    voiceName: 'Fenrir',
    stylePrompt:
      'Coşkudan patlayan heyecanlı Türk anime erkek gol haykırışı.',
    pitchFallback: 0.96,
    rateFallback: 1.12,
  },
  musab_musa_combo: {
    key: 'musab_musa_combo',
    text: 'Musab: Musa, sol kanattan uç — top havada! Musa: Pasını aldım Musab, arka direkte bitiriyorum!',
    voiceName: 'Puck',
    stylePrompt:
      'İki enerjik Türk anime erkek futbolcu (Musab ve Musa) arasında doğal, heyecanlı ve karizmatik saha içi pas ve roveşata diyaloğu.',
    pitchFallback: 1.0,
    rateFallback: 1.12,
    multiSpeakerTurns: [
      { speaker: 'Musab', voiceName: 'Puck', line: 'Musa, sol kanattan uç — top havada!' },
      { speaker: 'Musa', voiceName: 'Fenrir', line: 'Pasını aldım Musab, arka direkte bitiriyorum!' },
    ],
  },
};

export function getVoiceClipKey(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO'): string {
  if (kind === 'COMBO') return 'musab_musa_combo';
  return `${styleId}_${kind === 'AWAKENING' ? 'awakening' : 'ulti'}`;
}

export const EMOTE_LIST: Array<{ id: EmoteId; label: string; shout: string }> = [
  { id: 'SIUUU', label: 'SİUUU SIÇRAYIŞI', shout: 'SİUUU!!' },
  { id: 'EGOIST_POSE', label: 'EGOİST ZİRVE POZU', shout: 'BEN EGOİSTİM!' },
  { id: 'KNEE_SLIDE', label: 'DİZ KAYMA KUTLAMASI', shout: 'İŞTE BU!' },
  { id: 'ARMS_CROSSED', label: 'SOĞUK KRAL POZU', shout: 'ÇOK KOLAY.' },
  { id: 'FLEX_ROAR', label: 'ÇİFT KOL KÜKREME', shout: 'DURDURULAMAZ!' },
];
