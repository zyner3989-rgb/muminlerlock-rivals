import type { StyleCareerStats, StyleId } from '../types/game';

export type FcCardTier = 'ICON' | 'HERO' | 'TOTS' | 'GOLD';

export interface PlayerCardMeta {
  styleId: StyleId;
  ovr: number;
  position: 'ST' | 'LW' | 'RW' | 'CAM' | 'CDM' | 'CB';
  tier: FcCardTier;
  tierLabel: string;
  nationFlag: string;
  clubTag: string;
  traitName: string;
  /** 6 canonical FC attributes: HIZ, ŞUT, PAS, DRİB, DEF, FİZ */
  attributes: {
    pace: number;
    shooting: number;
    passing: number;
    dribbling: number;
    defending: number;
    physical: number;
  };
  palette: {
    bgTop: string;
    bgMid: string;
    bgBottom: string;
    border: string;
    accent: string;
    textPrimary: string;
    textSecondary: string;
    divider: string;
  };
}

export const TIER_PALETTES: Record<FcCardTier, PlayerCardMeta['palette']> = {
  ICON: {
    bgTop: '#f5ecd4',
    bgMid: '#d6be86',
    bgBottom: '#1c1917',
    border: '#fde68a',
    accent: '#92400e',
    textPrimary: '#1e1b18',
    textSecondary: '#451a03',
    divider: 'rgba(146, 64, 14, 0.32)',
  },
  HERO: {
    bgTop: '#4c0519',
    bgMid: '#881337',
    bgBottom: '#0f172a',
    border: '#fb7185',
    accent: '#fde047',
    textPrimary: '#fffbeb',
    textSecondary: '#fecdd3',
    divider: 'rgba(251, 113, 133, 0.35)',
  },
  TOTS: {
    bgTop: '#082f49',
    bgMid: '#0e7490',
    bgBottom: '#090d1e',
    border: '#38bdf8',
    accent: '#22d3ee',
    textPrimary: '#f0f9ff',
    textSecondary: '#7dd3fc',
    divider: 'rgba(56, 189, 248, 0.35)',
  },
  GOLD: {
    bgTop: '#1e3a8a',
    bgMid: '#1d4ed8',
    bgBottom: '#090d1c',
    border: '#93c5fd',
    accent: '#fbbf24',
    textPrimary: '#f8fafc',
    textSecondary: '#bfdbfe',
    divider: 'rgba(147, 197, 253, 0.32)',
  },
};

export const PLAYER_CARD_META: Record<StyleId, PlayerCardMeta> = {
  musab: {
    styleId: 'musab',
    ovr: 98,
    position: 'ST',
    tier: 'ICON',
    tierLabel: 'MASTER EGOİST',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Kâbus Vole+',
    attributes: { pace: 98, shooting: 99, passing: 95, dribbling: 97, defending: 74, physical: 93 },
    palette: TIER_PALETTES.ICON,
  },
  musa: {
    styleId: 'musa',
    ovr: 97,
    position: 'LW',
    tier: 'ICON',
    tierLabel: 'MASTER AS',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Sonik Füze+',
    attributes: { pace: 99, shooting: 99, passing: 91, dribbling: 96, defending: 75, physical: 94 },
    palette: TIER_PALETTES.ICON,
  },
  iskender: {
    styleId: 'iskender',
    ovr: 96,
    position: 'CAM',
    tier: 'ICON',
    tierLabel: 'MASTER TEKNİK',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Boyut Rovaşata+',
    attributes: { pace: 95, shooting: 95, passing: 96, dribbling: 99, defending: 68, physical: 87 },
    palette: TIER_PALETTES.ICON,
  },
  aras: {
    styleId: 'aras',
    ovr: 93,
    position: 'ST',
    tier: 'HERO',
    tierLabel: 'WORLD CLASS',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Güçlü Bitirici+',
    attributes: { pace: 92, shooting: 96, passing: 84, dribbling: 89, defending: 70, physical: 96 },
    palette: TIER_PALETTES.HERO,
  },
  umidi: {
    styleId: 'umidi',
    ovr: 94,
    position: 'RW',
    tier: 'HERO',
    tierLabel: 'PAKET KRALI',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Dandik Paketten Messi+',
    attributes: { pace: 93, shooting: 96, passing: 91, dribbling: 94, defending: 75, physical: 88 },
    palette: TIER_PALETTES.HERO,
  },
  ebulfez: {
    styleId: 'ebulfez',
    ovr: 89,
    position: 'CDM',
    tier: 'HERO',
    tierLabel: 'WORLD CLASS',
    nationFlag: 'AZ',
    clubTag: 'MÜMİN FC',
    traitName: 'Eldiven Çekişi',
    attributes: { pace: 86, shooting: 86, passing: 85, dribbling: 85, defending: 89, physical: 88 },
    palette: TIER_PALETTES.HERO,
  },
  arap_kavuncu: {
    styleId: 'arap_kavuncu',
    ovr: 93,
    position: 'RW',
    tier: 'HERO',
    tierLabel: 'WORLD CLASS',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Kasırga Sürüş+',
    attributes: { pace: 94, shooting: 95, passing: 88, dribbling: 92, defending: 76, physical: 91 },
    palette: TIER_PALETTES.HERO,
  },
  zero: {
    styleId: 'zero',
    ovr: 90,
    position: 'CAM',
    tier: 'TOTS',
    tierLabel: 'MİTİK ALGORİTMA',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Plase Falso+',
    attributes: { pace: 89, shooting: 89, passing: 95, dribbling: 92, defending: 73, physical: 82 },
    palette: TIER_PALETTES.TOTS,
  },
  esref_tek: {
    styleId: 'esref_tek',
    ovr: 91,
    position: 'ST',
    tier: 'TOTS',
    tierLabel: 'MİTİK TETİKÇİ',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Dış Ayak Mermi+',
    attributes: { pace: 91, shooting: 94, passing: 86, dribbling: 90, defending: 75, physical: 89 },
    palette: TIER_PALETTES.TOTS,
  },
  hamzac5: {
    styleId: 'hamzac5',
    ovr: 90,
    position: 'LW',
    tier: 'TOTS',
    tierLabel: 'MİTİK NİTRO',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: '5. Vites Depar+',
    attributes: { pace: 96, shooting: 90, passing: 85, dribbling: 91, defending: 71, physical: 86 },
    palette: TIER_PALETTES.TOTS,
  },
  memud: {
    styleId: 'memud',
    ovr: 91,
    position: 'CAM',
    tier: 'TOTS',
    tierLabel: 'MİTİK TAKTİSYEN',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: '90° Akrep Vole+',
    attributes: { pace: 89, shooting: 92, passing: 94, dribbling: 93, defending: 79, physical: 85 },
    palette: TIER_PALETTES.TOTS,
  },
  berk: {
    styleId: 'berk',
    ovr: 91,
    position: 'CB',
    tier: 'TOTS',
    tierLabel: 'MİTİK DUVAR',
    nationFlag: 'TR',
    clubTag: 'MÜMİN FC',
    traitName: 'Demir Kaya Blok+',
    attributes: { pace: 88, shooting: 91, passing: 87, dribbling: 86, defending: 94, physical: 96 },
    palette: TIER_PALETTES.TOTS,
  },
};

export const CAREER_STORAGE_KEY = 'muminrivals_style_career_v1';

export type CareerStatsMap = Partial<Record<StyleId, StyleCareerStats>>;

export function loadCareerStats(): CareerStatsMap {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(CAREER_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as CareerStatsMap;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function saveCareerStats(map: CareerStatsMap): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(CAREER_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore quota errors
  }
}

export function getStyleCareer(map: CareerStatsMap, styleId: StyleId): StyleCareerStats {
  return (
    map[styleId] ?? {
      matches: 0,
      wins: 0,
      goals: 0,
      shots: 0,
      passes: 0,
      steals: 0,
    }
  );
}

/** Computes a small dynamic OVR bonus (up to +2) from real user career goals & wins */
export function getDynamicCardOvr(styleId: StyleId, career: StyleCareerStats): number {
  const base = PLAYER_CARD_META[styleId].ovr;
  const bonus = career.wins >= 10 || career.goals >= 20 ? 2 : career.wins >= 3 || career.goals >= 5 ? 1 : 0;
  return Math.min(99, base + bonus);
}
