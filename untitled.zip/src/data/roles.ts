import type { PlayerRole } from '../types/game.ts';

export interface RoleDefinition {
  id: PlayerRole;
  shortLabel: string;
  name: string;
  description: string;
  accentColor: string;
  speedMult: number;
  shotMult: number;
  staminaRegenMult: number;
}

export const ROLES: Record<PlayerRole, RoleDefinition> = {
  CF: {
    id: 'CF',
    shortLabel: 'ST',
    name: 'Santrafor',
    description: 'Ceza sahası önünde başlar · +5% Şut Gücü',
    accentColor: '#f59e0b',
    speedMult: 1.0,
    shotMult: 1.05,
    staminaRegenMult: 1.0,
  },
  LW: {
    id: 'LW',
    shortLabel: 'LW',
    name: 'Sol Kanat',
    description: 'Sol çizgide hızlı atak · +6% Koşu Hızı',
    accentColor: '#38bdf8',
    speedMult: 1.06,
    shotMult: 1.0,
    staminaRegenMult: 1.05,
  },
  RW: {
    id: 'RW',
    shortLabel: 'RW',
    name: 'Sağ Kanat',
    description: 'Sağ çizgide hızlı atak · +6% Koşu Hızı',
    accentColor: '#22d3ee',
    speedMult: 1.06,
    shotMult: 1.0,
    staminaRegenMult: 1.05,
  },
  CM: {
    id: 'CM',
    shortLabel: 'CM',
    name: 'Orta Saha',
    description: 'Merkez oyun kurucu · +18% Dayanıklılık Yenileme',
    accentColor: '#a78bfa',
    speedMult: 1.02,
    shotMult: 1.0,
    staminaRegenMult: 1.18,
  },
  GK: {
    id: 'GK',
    shortLabel: 'GK',
    name: 'Kaleci',
    description: 'Ceza sahasında [Q]/[E] Uçar, dışarıda normal oyuncu gibi oynar',
    accentColor: '#10b981',
    speedMult: 1.03,
    shotMult: 1.08,
    staminaRegenMult: 1.25,
  },
};

export const ROLE_LIST: RoleDefinition[] = [
  ROLES.CF,
  ROLES.LW,
  ROLES.RW,
  ROLES.CM,
  ROLES.GK,
];

export function getRoleSpawnOffset(role: PlayerRole, team: 'BLUE' | 'RED'): { x: number; z: number } {
  const dir = team === 'BLUE' ? 1 : -1;
  switch (role) {
    case 'GK':
      return { x: team === 'BLUE' ? -121.0 : 121.0, z: 0 };
    case 'LW':
      return { x: -40 * dir, z: -32 * dir };
    case 'RW':
      return { x: -40 * dir, z: 32 * dir };
    case 'CM':
      return { x: -56 * dir, z: 0 };
    case 'CF':
    default:
      return { x: -22 * dir, z: 0 };
  }
}
