import type {
  DailyQuestProgress,
  MatchHistoryEntry,
  MatchMode,
  MatchStats,
  QueueType,
  RankedProfile,
  RankTierId,
  StyleId,
} from '../types/game';

export interface RankTierMeta {
  id: RankTierId;
  name: string;
  minRp: number;
  maxRp: number; // Infinity for top tier
  color: string;
  bg: string;
  badgeText: string;
}

export const RANK_TIERS: RankTierMeta[] = [
  {
    id: 'BRONZE',
    name: 'Bronz İzleyici',
    minRp: 0,
    maxRp: 299,
    color: '#cd7f32',
    bg: 'linear-gradient(135deg, #78350f 0%, #b45309 100%)',
    badgeText: 'BRONZ',
  },
  {
    id: 'SILVER',
    name: 'Gümüş Forvet',
    minRp: 300,
    maxRp: 599,
    color: '#e2e8f0',
    bg: 'linear-gradient(135deg, #475569 0%, #94a3b8 100%)',
    badgeText: 'GÜMÜŞ',
  },
  {
    id: 'GOLD',
    name: 'Altın Egoist',
    minRp: 600,
    maxRp: 999,
    color: '#facc15',
    bg: 'linear-gradient(135deg, #b45309 0%, #facc15 100%)',
    badgeText: 'ALTIN',
  },
  {
    id: 'DIAMOND',
    name: 'Elmas Yıldız',
    minRp: 1000,
    maxRp: 1499,
    color: '#38bdf8',
    bg: 'linear-gradient(135deg, #0284c7 0%, #22d3ee 100%)',
    badgeText: 'ELMAS',
  },
  {
    id: 'PRODIGY',
    name: 'Usta Dahi',
    minRp: 1500,
    maxRp: 2099,
    color: '#c084fc',
    bg: 'linear-gradient(135deg, #7c3aed 0%, #ec4899 100%)',
    badgeText: 'USTA',
  },
  {
    id: 'WORLD_XI',
    name: 'MüminRivals Ası (World XI)',
    minRp: 2100,
    maxRp: Infinity,
    color: '#fbbf24',
    bg: 'linear-gradient(135deg, #f59e0b 0%, #a855f7 50%, #38bdf8 100%)',
    badgeText: 'WORLD XI',
  },
];

export function getRankTier(rp: number): RankTierMeta {
  for (let i = RANK_TIERS.length - 1; i >= 0; i--) {
    if (rp >= RANK_TIERS[i].minRp) return RANK_TIERS[i];
  }
  return RANK_TIERS[0];
}

export function getRankProgress(rp: number): {
  tier: RankTierMeta;
  nextTier: RankTierMeta | null;
  percent: number;
  rpIntoTier: number;
  tierSpan: number;
} {
  const tier = getRankTier(rp);
  const idx = RANK_TIERS.findIndex((t) => t.id === tier.id);
  const nextTier = idx < RANK_TIERS.length - 1 ? RANK_TIERS[idx + 1] : null;
  if (!nextTier) {
    return { tier, nextTier: null, percent: 100, rpIntoTier: rp - tier.minRp, tierSpan: 1 };
  }
  const span = Math.max(1, nextTier.minRp - tier.minRp);
  const into = Math.max(0, rp - tier.minRp);
  return {
    tier,
    nextTier,
    percent: Math.min(100, Math.round((into / span) * 100)),
    rpIntoTier: into,
    tierSpan: span,
  };
}

export const DEFAULT_RANKED_PROFILE: RankedProfile = {
  playerName: 'Egoist',
  rp: 350,
  wins: 0,
  losses: 0,
  draws: 0,
  goals: 0,
  mvps: 0,
  winStreak: 0,
  bestStreak: 0,
  history: [],
};

export function computeRankedOutcome(
  profile: RankedProfile,
  blueScore: number,
  redScore: number,
  stats: MatchStats,
  queueType: QueueType,
  matchMode: MatchMode,
  styleId: StyleId
): { nextProfile: RankedProfile; rpDelta: number; isMvp: boolean; result: 'WIN' | 'LOSS' | 'DRAW' } {
  const result: 'WIN' | 'LOSS' | 'DRAW' =
    blueScore > redScore ? 'WIN' : blueScore === redScore ? 'DRAW' : 'LOSS';
  const isMvp = stats.goals >= 2 || (result === 'WIN' && stats.goals + stats.steals >= 2);

  let rpDelta = 0;
  if (queueType === 'RANKED') {
    if (result === 'WIN') {
      const streakBonus = Math.min(16, profile.winStreak * 4);
      rpDelta = 28 + streakBonus + Math.min(12, stats.goals * 3) + (isMvp ? 6 : 0);
    } else if (result === 'DRAW') {
      rpDelta = 4 + Math.min(6, stats.goals * 2);
    } else {
      rpDelta = Math.min(-4, -18 + Math.min(8, stats.goals * 2));
    }
  }

  const nextRp = Math.max(0, profile.rp + rpDelta);
  const nextStreak = result === 'WIN' ? profile.winStreak + 1 : 0;

  const entry: MatchHistoryEntry = {
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: Date.now(),
    queueType,
    matchMode,
    styleId,
    blueScore,
    redScore,
    goals: stats.goals,
    rpDelta,
    result,
  };

  const nextProfile: RankedProfile = {
    ...profile,
    rp: nextRp,
    wins: profile.wins + (result === 'WIN' ? 1 : 0),
    losses: profile.losses + (result === 'LOSS' ? 1 : 0),
    draws: profile.draws + (result === 'DRAW' ? 1 : 0),
    goals: profile.goals + stats.goals,
    mvps: profile.mvps + (isMvp ? 1 : 0),
    winStreak: nextStreak,
    bestStreak: Math.max(profile.bestStreak, nextStreak),
    history: [entry, ...profile.history].slice(0, 12),
  };

  return { nextProfile, rpDelta, isMvp, result };
}

export interface DailyQuestDef {
  id: string;
  title: string;
  desc: string;
  target: number;
  field: 'goals' | 'skillsOrDribbles' | 'matchesPlayed';
  rewardYen: number;
  rewardSpins: number;
  rewardLucky: number;
}

export const DAILY_QUESTS: DailyQuestDef[] = [
  {
    id: 'q_goals_3',
    title: 'Egoist Golcü',
    desc: 'Maçlarda toplam 3 gol at',
    target: 3,
    field: 'goals',
    rewardYen: 900,
    rewardSpins: 2,
    rewardLucky: 0,
  },
  {
    id: 'q_dribble_8',
    title: 'Saha Hakimi',
    desc: 'Çalım [Q] veya Pas [C] ile 8 aksiyon yap',
    target: 8,
    field: 'skillsOrDribbles',
    rewardYen: 750,
    rewardSpins: 1,
    rewardLucky: 0,
  },
  {
    id: 'q_matches_2',
    title: 'Arena Savaşçısı',
    desc: '2 maç tamamla (Solo veya Online)',
    target: 2,
    field: 'matchesPlayed',
    rewardYen: 1200,
    rewardSpins: 2,
    rewardLucky: 1,
  },
];

export const DEFAULT_QUEST_PROGRESS: DailyQuestProgress = {
  goals: 0,
  skillsOrDribbles: 0,
  matchesPlayed: 0,
  claimedIds: [],
  redeemedCodes: [],
};

export interface PromoCodeReward {
  code: string;
  label: string;
  yen: number;
  spins: number;
  luckySpins: number;
}

export const PROMO_CODES: Record<string, PromoCodeReward> = {
  BLUELOCK: {
    code: 'BLUELOCK',
    label: 'MüminRivals Başlangıç Paketi',
    yen: 1500,
    spins: 3,
    luckySpins: 1,
  },
  MUSABMUSA: {
    code: 'MUSABMUSA',
    label: 'İkiz Roveşata Özel Ödülü',
    yen: 2000,
    spins: 2,
    luckySpins: 2,
  },
  RANKEDKING: {
    code: 'RANKEDKING',
    label: 'Dereceli Arena Hediyesi',
    yen: 1800,
    spins: 4,
    luckySpins: 1,
  },
  EGOIST2025: {
    code: 'EGOIST2025',
    label: 'Sezon Egoist Ödülü',
    yen: 2500,
    spins: 3,
    luckySpins: 1,
  },
};
