import * as THREE from 'three';
import type { OutfitId } from '../types/game';

export function createPitchTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Rich eFootball emerald turf stripes with subtle tonal transition
  const stripeCount = 18;
  const stripeW = canvas.width / stripeCount;
  for (let i = 0; i < stripeCount; i++) {
    const even = i % 2 === 0;
    const g = ctx.createLinearGradient(i * stripeW, 0, (i + 1) * stripeW, 0);
    g.addColorStop(0, even ? '#146635' : '#1b8045');
    g.addColorStop(0.5, even ? '#166f3a' : '#1e884a');
    g.addColorStop(1, even ? '#146635' : '#1b8045');
    ctx.fillStyle = g;
    ctx.fillRect(i * stripeW, 0, stripeW + 1, canvas.height);
  }

  // Fine grass blade noise + darker penalty box wear patches
  for (let i = 0; i < 9500; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    ctx.fillStyle = i % 3 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(6,40,18,0.05)';
    ctx.fillRect(x, y, 2 + (i % 3), 2);
  }

  // Subtle penalty-area turf wear
  const drawWear = (cx: number, cy: number, rx: number, ry: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, ry / rx);
    const rg = ctx.createRadialGradient(0, 0, 12, 0, 0, rx);
    rg.addColorStop(0, 'rgba(72, 62, 32, 0.16)');
    rg.addColorStop(1, 'rgba(72, 62, 32, 0)');
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  drawWear(130, canvas.height / 2, 110, 180);
  drawWear(canvas.width - 130, canvas.height / 2, 110, 180);
  drawWear(canvas.width / 2, canvas.height / 2, 90, 90);

  // Crisp chalk white lines
  ctx.strokeStyle = 'rgba(248, 250, 252, 0.94)';
  ctx.lineWidth = 10;

  const padX = 76;
  const padY = 56;
  const fieldW = canvas.width - padX * 2;
  const fieldH = canvas.height - padY * 2;

  ctx.strokeRect(padX, padY, fieldW, fieldH);

  // Halfway line
  ctx.beginPath();
  ctx.moveTo(canvas.width / 2, padY);
  ctx.lineTo(canvas.width / 2, padY + fieldH);
  ctx.stroke();

  // Center circle + spot
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, 130, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, 12, 0, Math.PI * 2);
  ctx.fill();

  // Blue Lock glowing cyan center hex emblem
  ctx.save();
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
  ctx.lineWidth = 6;
  ctx.beginPath();
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 3) * i - Math.PI / 6;
    const px = cx + Math.cos(a) * 95;
    const py = cy + Math.sin(a) * 95;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();

  // Corner arcs
  const cornerR = 26;
  [
    [padX, padY, 0, Math.PI / 2],
    [padX + fieldW, padY, Math.PI / 2, Math.PI],
    [padX + fieldW, padY + fieldH, Math.PI, Math.PI * 1.5],
    [padX, padY + fieldH, Math.PI * 1.5, Math.PI * 2],
  ].forEach(([x, y, a0, a1]) => {
    ctx.beginPath();
    ctx.arc(x, y, cornerR, a0, a1);
    ctx.stroke();
  });

  // Left & Right Penalty Boxes + Spots (proportional to 250m x 152m pitch: 24m/250m & 52m/152m)
  const penW = 192;
  const penH = 330;
  ctx.strokeRect(padX, (canvas.height - penH) / 2, penW, penH);
  ctx.strokeRect(padX, (canvas.height - 170) / 2, 74, 170);

  ctx.strokeRect(canvas.width - padX - penW, (canvas.height - penH) / 2, penW, penH);
  ctx.strokeRect(canvas.width - padX - 74, (canvas.height - 170) / 2, 74, 170);

  ctx.beginPath();
  ctx.arc(padX + 132, canvas.height / 2, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(canvas.width - padX - 132, canvas.height / 2, 8, 0, Math.PI * 2);
  ctx.fill();

  // Penalty arcs
  ctx.beginPath();
  ctx.arc(padX + 132, canvas.height / 2, 92, -0.78, 0.78);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(canvas.width - padX - 132, canvas.height / 2, 92, Math.PI - 0.78, Math.PI + 0.78);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createPitchBumpTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 14000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = 90 + Math.floor(Math.random() * 90);
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.fillRect(x, y, 2, 3);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 10);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createSoccerBallTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const bg = ctx.createLinearGradient(0, 0, 0, 256);
  bg.addColorStop(0, '#ffffff');
  bg.addColorStop(0.5, '#f1f5f9');
  bg.addColorStop(1, '#e2e8f0');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const drawHex = (cx: number, cy: number, r: number, color: string) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.stroke();
  };

  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 6; col++) {
      const offset = row % 2 === 0 ? 0 : 42;
      drawHex(col * 85 + offset + 22, row * 85 + 42, 24, '#0f172a');
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createSoccerBallBumpTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#c8c8c8';
  ctx.fillRect(0, 0, 512, 256);
  ctx.strokeStyle = '#404040';
  ctx.lineWidth = 4;
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 6; col++) {
      const offset = row % 2 === 0 ? 0 : 42;
      const cx = col * 85 + offset + 22;
      const cy = row * 85 + 42;
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
        const x = cx + Math.cos(a) * 25;
        const y = cy + Math.sin(a) * 25;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createFabricBumpTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 128, 128);
  for (let y = 0; y < 128; y += 4) {
    for (let x = 0; x < 128; x += 4) {
      ctx.fillStyle = (x + y) % 8 === 0 ? '#969696' : '#6c6c6c';
      ctx.fillRect(x, y, 2, 2);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 6);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

/**
 * Dual-sided UV-aligned Torso texture for Three.js CylinderGeometry:
 *   u = 0.25 (canvas x = 128) maps to +X (FRONT CHEST)
 *   u = 0.75 (canvas x = 384) maps to -X (BACK NAME & NUMBER)
 *   u = 0 & 1 seam wraps seamlessly at +Z.
 */
export function createJerseyTexture(
  primaryColor: string,
  secondaryColor: string,
  jerseyNumber: number,
  name: string,
  maxAnisotropy: number,
  outfitId: OutfitId = 'signature'
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  const frontX = 128;
  const backX = 384;

  // Base fabric fill
  const bg = ctx.createLinearGradient(0, 0, 0, 512);
  bg.addColorStop(0, primaryColor);
  bg.addColorStop(1, primaryColor);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 512, 512);

  // Subtle vertical knit shading for realism
  ctx.fillStyle = 'rgba(255,255,255,0.035)';
  for (let x = 0; x < 512; x += 16) {
    ctx.fillRect(x, 0, 6, 512);
  }
  ctx.fillStyle = 'rgba(2,6,23,0.12)';
  ctx.fillRect(0, 468, 512, 44); // lower hem shadow

  // Continuous wrap-around athletic sash (same height at x=0 and x=512 -> zero seam!)
  if (outfitId !== 'hoodie' && outfitId !== 'cyberjacket') {
    ctx.fillStyle = secondaryColor;
    ctx.globalAlpha = 0.22;
    ctx.fillRect(0, 175, 512, 48);
    ctx.globalAlpha = 0.85;
    ctx.fillRect(0, 190, 512, 16);
    ctx.globalAlpha = 1;
  }

  // Side mesh vents at u=0 (x=0/512) and u=0.5 (x=256)
  ctx.fillStyle = 'rgba(15, 23, 42, 0.24)';
  ctx.fillRect(0, 120, 18, 360);
  ctx.fillRect(494, 120, 18, 360);
  ctx.fillRect(238, 120, 36, 360);

  // Collar top trim strip
  ctx.fillStyle = secondaryColor;
  ctx.fillRect(0, 0, 512, 24);

  // ================= FRONT CHEST (x = 128 -> +X) =================
  if (outfitId === 'cyberjacket') {
    // Open athletic track jacket over dark inner compression tee
    ctx.fillStyle = '#090d16';
    ctx.fillRect(frontX - 38, 0, 76, 512);
    // Neon glowing zipper / lapel edges
    ctx.fillStyle = secondaryColor;
    ctx.fillRect(frontX - 42, 0, 8, 512);
    ctx.fillRect(frontX + 34, 0, 8, 512);
    // Inner chest badge
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.font = '900 32px Inter, sans-serif';
    ctx.fillText(String(jerseyNumber), frontX, 170);
  } else if (outfitId === 'hoodie') {
    // Drawstrings + Front Kangaroo Pocket seams
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(frontX - 18, 22);
    ctx.lineTo(frontX - 22, 145);
    ctx.moveTo(frontX + 18, 22);
    ctx.lineTo(frontX + 22, 145);
    ctx.stroke();

    // Kangaroo pocket
    ctx.fillStyle = 'rgba(2, 6, 23, 0.28)';
    ctx.beginPath();
    ctx.moveTo(frontX - 75, 455);
    ctx.lineTo(frontX - 54, 330);
    ctx.lineTo(frontX + 54, 330);
    ctx.lineTo(frontX + 75, 455);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = secondaryColor;
    ctx.lineWidth = 4;
    ctx.stroke();

    // Chest Emblem on hoodie
    ctx.fillStyle = secondaryColor;
    ctx.font = '900 22px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('EGOIST', frontX, 225);
  } else {
    // Standard Pro Jersey Front Chest
    // V-neck placket
    ctx.fillStyle = secondaryColor;
    ctx.beginPath();
    ctx.moveTo(frontX - 36, 0);
    ctx.lineTo(frontX + 36, 0);
    ctx.lineTo(frontX, 58);
    ctx.closePath();
    ctx.fill();

    // Left-chest club crest diamond
    ctx.save();
    ctx.translate(frontX + 38, 128);
    ctx.fillStyle = '#020617';
    ctx.strokeStyle = secondaryColor;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, -24);
    ctx.lineTo(20, 0);
    ctx.lineTo(0, 28);
    ctx.lineTo(-20, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#38bdf8';
    ctx.font = '900 16px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('MR', 0, 7);
    ctx.restore();

    // Mini Front Number
    ctx.fillStyle = outfitId === 'royalwhite' ? '#0f172a' : '#ffffff';
    ctx.textAlign = 'center';
    ctx.font = '900 44px Inter, sans-serif';
    ctx.fillText(String(jerseyNumber), frontX - 34, 146);

    // Subtle sponsor stripe text across abdomen
    ctx.fillStyle = outfitId === 'royalwhite' ? 'rgba(15,23,42,0.75)' : 'rgba(255,255,255,0.85)';
    ctx.font = '900 19px Inter, sans-serif';
    ctx.fillText('MÜMİNRIVALS', frontX, 290);
  }

  // ================= BACK NAME & NUMBER (x = 384 -> -X) =================
  const backTextColor = outfitId === 'royalwhite' ? '#0f172a' : '#ffffff';
  const backOutlineColor = outfitId === 'royalwhite' ? '#ffffff' : '#020617';

  ctx.textAlign = 'center';
  ctx.fillStyle = backTextColor;
  ctx.strokeStyle = backOutlineColor;
  ctx.lineWidth = 6;
  ctx.font = '900 40px Inter, sans-serif';
  const label = name.slice(0, 10).toUpperCase();
  ctx.strokeText(label, backX, 118);
  ctx.fillText(label, backX, 118);

  ctx.font = '900 176px Inter, sans-serif';
  ctx.lineWidth = 10;
  ctx.strokeText(String(jerseyNumber), backX, 330);
  ctx.fillText(String(jerseyNumber), backX, 330);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createStadiumLedTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, 1024, 128);

  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 6;
  ctx.strokeRect(4, 4, 1016, 120);

  ctx.fillStyle = '#38bdf8';
  ctx.font = '900 50px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('MÜMİNRIVALS ARENA  ·  EGOIST ZONE  ·  3D', 512, 82);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.repeat.set(3, 1);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createScreenTexture(
  mode: 'bluelock_game' | 'phone_musab' | 'videocall_musa' | 'ai_cheat' | 'aras_lose',
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  if (mode === 'bluelock_game') {
    const grad = ctx.createLinearGradient(0, 0, 0, 320);
    grad.addColorStop(0, '#020617');
    grad.addColorStop(0.5, '#0c4a6e');
    grad.addColorStop(1, '#14532d');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 320);

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 6;
    ctx.strokeRect(20, 20, 472, 280);

    ctx.fillStyle = '#38bdf8';
    ctx.font = '900 32px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('MÜMİNRIVALS 3D', 256, 70);

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(256, 175, 44, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 6;
    ctx.stroke();
  } else if (mode === 'phone_musab') {
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 512, 320);
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.arc(256, 110, 48, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.font = '800 34px Inter, sans-serif';
    ctx.fillText('MUSAB ARIYOR...', 256, 215);
    ctx.fillStyle = '#38bdf8';
    ctx.font = '700 22px Inter, sans-serif';
    ctx.fillText('GELEN ARAMA', 256, 260);
  } else if (mode === 'videocall_musa') {
    ctx.fillStyle = '#082f49';
    ctx.fillRect(0, 0, 512, 320);
    ctx.fillStyle = '#f2ccb0';
    ctx.fillRect(196, 70, 120, 120);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(190, 48, 132, 36);
    ctx.fillRect(220, 112, 20, 20);
    ctx.fillRect(272, 112, 20, 20);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(236, 152, 40, 14);
    ctx.fillStyle = '#34d399';
    ctx.textAlign = 'center';
    ctx.font = '800 26px Inter, sans-serif';
    ctx.fillText('GÖRÜNTÜLÜ: MUSA', 256, 250);
  } else if (mode === 'ai_cheat') {
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, 512, 320);
    ctx.fillStyle = '#22d3ee';
    ctx.font = '700 20px monospace';
    ctx.fillText('> TACTIC_CORE_v2.ts', 24, 54);
    ctx.fillStyle = '#4ade80';
    ctx.fillText('> CURVE_SOLVER = LOCKED;', 24, 98);
    ctx.fillText('> TARGET = TOP_90_CORNER;', 24, 142);
    ctx.fillText('> ANGLES: COMPUTED [OK]', 24, 186);
    ctx.fillStyle = '#facc15';
    ctx.font = '900 30px Inter, sans-serif';
    ctx.fillText('AÇI KİLİTLENDİ!', 24, 260);
  } else if (mode === 'aras_lose') {
    ctx.fillStyle = '#450a0a';
    ctx.fillRect(0, 0, 512, 320);
    ctx.fillStyle = '#ef4444';
    ctx.textAlign = 'center';
    ctx.font = '900 40px Inter, sans-serif';
    ctx.fillText('SKOR: 0 - 1', 256, 130);
    ctx.fillStyle = '#fde68a';
    ctx.font = '800 24px Inter, sans-serif';
    ctx.fillText('RÖVANŞ ZAMANI!', 256, 200);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 62);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.55)');
  grad.addColorStop(0.6, 'rgba(0, 0, 0, 0.22)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createNameplateTexture(
  name: string,
  team: 'BLUE' | 'RED',
  isUser: boolean,
  isGoalkeeper: boolean
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 112;
  const ctx = canvas.getContext('2d')!;

  const accent = isUser ? '#facc15' : team === 'BLUE' ? '#38bdf8' : '#ef4444';
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Clean chamfered nameplate plate (no rounded pill look)
  const padX = 24;
  const padY = 14;
  const w = canvas.width - padX * 2;
  const h = canvas.height - padY * 2;

  ctx.fillStyle = 'rgba(7, 12, 24, 0.86)';
  ctx.beginPath();
  ctx.moveTo(padX + 14, padY);
  ctx.lineTo(padX + w, padY);
  ctx.lineTo(padX + w - 14, padY + h);
  ctx.lineTo(padX, padY + h);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = accent;
  ctx.lineWidth = 4;
  ctx.stroke();

  // Left team accent bar
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.moveTo(padX + 14, padY);
  ctx.lineTo(padX + 34, padY);
  ctx.lineTo(padX + 20, padY + h);
  ctx.lineTo(padX, padY + h);
  ctx.closePath();
  ctx.fill();

  const label = (name || 'Egoist').trim().slice(0, 14).toUpperCase();
  const display = isGoalkeeper ? `${label} [GK]` : isUser ? `★ ${label}` : label;

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '900 40px Inter, system-ui, sans-serif';
  ctx.lineWidth = 5;
  ctx.strokeStyle = 'rgba(2, 6, 23, 0.95)';
  ctx.strokeText(display, canvas.width / 2 + 8, canvas.height / 2 + 2);
  ctx.fillStyle = isUser ? '#fef08a' : '#f8fafc';
  ctx.fillText(display, canvas.width / 2 + 8, canvas.height / 2 + 2);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createPassCallTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 384;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'rgba(250, 204, 21, 0.95)';
  ctx.beginPath();
  ctx.moveTo(22, 10);
  ctx.lineTo(368, 10);
  ctx.lineTo(352, 82);
  ctx.lineTo(8, 82);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = '#090d16';
  ctx.lineWidth = 5;
  ctx.stroke();

  ctx.fillStyle = '#090d16';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '900 40px Inter, system-ui, sans-serif';
  ctx.fillText('PAS AT!', canvas.width / 2, 47);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

