import * as THREE from 'three';
import type { ActionAnimId, EmoteId } from '../types/game';
import type { PlayerRig } from './models';

export interface ActorAnimParams {
  dt: number;
  speed: number;
  sprint: boolean;
  isGoalkeeper: boolean;
  hasBall: boolean;
  awakened: boolean;
  animPhase: number;
  actionAnim: ActionAnimId | null;
  actionTimer: number;
  actionDir: number;
  stunTimer: number;
  emoteId: EmoteId | null;
  emoteTimer: number;
  isThrowInHold: boolean;
}

const damp = THREE.MathUtils.damp;

function resetSubtlePose(rig: PlayerRig, dt: number) {
  rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0, 14, dt);
  rig.bodyPivot.position.x = damp(rig.bodyPivot.position.x, 0, 14, dt);
  rig.bodyPivot.position.z = damp(rig.bodyPivot.position.z, 0, 14, dt);
  rig.bodyPivot.rotation.x = damp(rig.bodyPivot.rotation.x, 0, 14, dt);
  rig.bodyPivot.rotation.y = damp(rig.bodyPivot.rotation.y, 0, 14, dt);
  rig.bodyPivot.rotation.z = damp(rig.bodyPivot.rotation.z, 0, 14, dt);
  rig.upperTorsoPivot.rotation.y = damp(rig.upperTorsoPivot.rotation.y, 0, 14, dt);
  rig.upperTorsoPivot.rotation.x = damp(rig.upperTorsoPivot.rotation.x, 0, 14, dt);
  rig.headGroup.rotation.set(
    damp(rig.headGroup.rotation.x, 0, 12, dt),
    damp(rig.headGroup.rotation.y, 0, 12, dt),
    damp(rig.headGroup.rotation.z, 0, 12, dt)
  );
}

/**
 * Ground-up multi-joint skeletal kinematics with zero per-frame allocations.
 * Joint axes match buildPlayerRig (+X forward, +Z right):
 *   rotation.z > 0 -> swing forward / upward (+X)
 *   rotation.z < 0 -> swing backward (-X)
 *   knee rotation.z <= 0 -> natural anatomical backward knee bend
 *   elbow rotation.z >= 0 -> natural anatomical forward elbow flexion
 * Returns the updated animPhase for the actor.
 */
export function stepActorAnimation(rig: PlayerRig, params: ActorAnimParams): number {
  const { dt, speed, sprint, isGoalkeeper, hasBall, actionAnim, actionTimer, actionDir, stunTimer, emoteId, emoteTimer, isThrowInHold } =
    params;

  let nextPhase = params.animPhase;

  // 1. Stunned / Knocked / Shook Reaction
  if (stunTimer > 0) {
    const w = Math.sin(stunTimer * 18);
    rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, -0.1, 16, dt);
    rig.bodyPivot.rotation.set(w * 0.14, 0, 0.24 + Math.abs(w) * 0.1);
    rig.upperTorsoPivot.rotation.set(0, w * 0.25, 0.22);
    rig.headGroup.rotation.set(0, w * 0.35, -0.18);
    rig.leftArmPivot.rotation.set(0.35, 0, 0.72 + w * 0.2);
    rig.rightArmPivot.rotation.set(-0.35, 0, 0.72 - w * 0.2);
    rig.leftElbowPivot.rotation.z = 0.85;
    rig.rightElbowPivot.rotation.z = 0.85;
    rig.leftLegPivot.rotation.set(0.14, 0, -0.18);
    rig.rightLegPivot.rotation.set(-0.14, 0, 0.18);
    rig.leftKneePivot.rotation.z = -0.35;
    rig.rightKneePivot.rotation.z = -0.35;
    return nextPhase;
  }

  // 2. Overhead Throw-In Hold Pose while counting down on touchline
  if (isThrowInHold) {
    const sway = Math.sin(performance.now() * 0.004) * 0.04;
    resetSubtlePose(rig, dt);
    rig.upperTorsoPivot.rotation.z = damp(rig.upperTorsoPivot.rotation.z, 0.12, 12, dt);
    rig.headGroup.rotation.z = damp(rig.headGroup.rotation.z, -0.08, 12, dt);
    rig.leftArmPivot.rotation.set(0.18, 0, 2.55 + sway);
    rig.rightArmPivot.rotation.set(-0.18, 0, 2.55 + sway);
    rig.leftElbowPivot.rotation.z = 0.92;
    rig.rightElbowPivot.rotation.z = 0.92;
    rig.leftLegPivot.rotation.set(0.06, 0, -0.22);
    rig.rightLegPivot.rotation.set(-0.06, 0, 0.24);
    rig.leftKneePivot.rotation.z = -0.16;
    rig.rightKneePivot.rotation.z = -0.16;
    return nextPhase;
  }

  // 3. Throw-In Snap Release
  if (actionTimer > 0 && actionAnim === 'THROW_IN') {
    const p = 1 - Math.min(1, actionTimer / 0.42);
    const snap = Math.min(1, p / 0.45);
    const follow = Math.max(0, (p - 0.45) / 0.55);
    resetSubtlePose(rig, dt);
    rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(0.28, -0.36, snap) * (1 - follow * 0.5);
    const armAngle = THREE.MathUtils.lerp(2.75, 0.55, snap);
    rig.leftArmPivot.rotation.set(0.15, 0, armAngle);
    rig.rightArmPivot.rotation.set(-0.15, 0, armAngle);
    rig.leftElbowPivot.rotation.z = THREE.MathUtils.lerp(0.95, 0.14, snap);
    rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(0.95, 0.14, snap);
    rig.leftLegPivot.rotation.z = -0.26;
    rig.rightLegPivot.rotation.z = 0.34;
    rig.leftKneePivot.rotation.z = -0.15;
    rig.rightKneePivot.rotation.z = -0.25;
    return nextPhase;
  }

  // 4. Goalkeeper Lateral Dive & Vault
  if (actionTimer > 0 && actionAnim === 'GK_DIVE') {
    const p = 1 - Math.min(1, actionTimer / 0.55);
    const arc = Math.sin(p * Math.PI);
    const sign = actionDir >= 0 ? 1 : -1;
    rig.bodyPivot.position.set(0, arc * 1.15 + 0.14, 0);
    rig.bodyPivot.rotation.set(sign * -1.18 * arc, 0, -0.14 * arc);
    rig.upperTorsoPivot.rotation.set(0, sign * 0.28 * arc, -0.12);
    rig.leftArmPivot.rotation.set(0.25 * sign, 0, 2.35 * arc);
    rig.rightArmPivot.rotation.set(-0.25 * sign, 0, 2.35 * arc);
    rig.leftElbowPivot.rotation.z = 0.12;
    rig.rightElbowPivot.rotation.z = 0.12;
    rig.leftLegPivot.rotation.z = -0.25;
    rig.rightLegPivot.rotation.z = 0.15;
    rig.leftKneePivot.rotation.z = -0.45 * arc;
    rig.rightKneePivot.rotation.z = -0.2 * arc;
    return nextPhase;
  }

  // 5. Realistic Multi-Stage Kick (Backswing -> Snap -> Follow-through)
  if (actionTimer > 0 && actionAnim === 'KICK') {
    const p = 1 - Math.min(1, actionTimer / 0.36);
    const windup = Math.min(1, p / 0.26);
    const strike = Math.max(0, Math.min(1, (p - 0.24) / 0.34));
    const follow = Math.max(0, (p - 0.58) / 0.42);
    resetSubtlePose(rig, dt);

    rig.bodyPivot.position.y = Math.sin(strike * Math.PI) * 0.14;
    rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-0.08, -0.2, strike) * (1 - follow * 0.4);
    rig.upperTorsoPivot.rotation.set(
      -0.14 * strike,
      THREE.MathUtils.lerp(0.26, -0.42, strike),
      -0.18 * (1 - follow * 0.4)
    );
    // Support left plant leg
    rig.leftLegPivot.rotation.set(0.08, 0, -0.24);
    rig.leftKneePivot.rotation.z = -0.34;
    // Striking right leg
    rig.rightLegPivot.rotation.set(
      0,
      0,
      p < 0.26
        ? THREE.MathUtils.lerp(0, -0.96, windup)
        : THREE.MathUtils.lerp(-0.96, 1.48 - follow * 0.45, strike)
    );
    rig.rightKneePivot.rotation.z =
      p < 0.26
        ? THREE.MathUtils.lerp(-0.15, -1.18, windup)
        : THREE.MathUtils.lerp(-1.18, -0.06, strike);
    // Counterbalance arms
    rig.leftArmPivot.rotation.set(0.45, 0, THREE.MathUtils.lerp(-0.3, 1.12, strike));
    rig.rightArmPivot.rotation.set(-0.3, 0, THREE.MathUtils.lerp(0.4, -0.78, strike));
    rig.leftElbowPivot.rotation.z = 0.72;
    rig.rightElbowPivot.rotation.z = 0.48;
    return nextPhase;
  }

  // 6. Slide Tackle / Awakened Dash Steal
  if (actionTimer > 0 && (actionAnim === 'SLIDE' || actionAnim === 'AWAKENED_STEAL')) {
    const isAwakened = actionAnim === 'AWAKENED_STEAL';
    const maxDur = isAwakened ? 0.56 : 0.48;
    const p = 1 - Math.min(1, actionTimer / maxDur);
    const lunge = Math.sin(Math.min(1, p * 1.25) * Math.PI * 0.6);
    rig.bodyPivot.position.set(0, -0.58 * lunge, 0);
    rig.bodyPivot.rotation.set(0, isAwakened ? p * Math.PI * 0.4 : 0, 0.96 * lunge);
    rig.upperTorsoPivot.rotation.set(0, -0.28 * lunge, -0.28 * lunge);
    rig.rightLegPivot.rotation.z = 1.18 * lunge;
    rig.rightKneePivot.rotation.z = -0.08;
    rig.leftLegPivot.rotation.z = -0.35 * lunge;
    rig.leftKneePivot.rotation.z = -1.28 * lunge;
    rig.leftArmPivot.rotation.set(0.45, 0, -0.52);
    rig.rightArmPivot.rotation.set(-0.25, 0, 0.72);
    rig.leftElbowPivot.rotation.z = 0.45;
    rig.rightElbowPivot.rotation.z = 0.35;
    return nextPhase;
  }

  // 7. Dribble Spin / Roulette
  if (actionTimer > 0 && (actionAnim === 'DRIBBLE_SPIN' || actionAnim === 'AWAKENED_DRIBBLE')) {
    const isAwakened = actionAnim === 'AWAKENED_DRIBBLE';
    const dur = isAwakened ? 0.55 : 0.44;
    const p = 1 - Math.min(1, actionTimer / dur);
    rig.bodyPivot.position.y = Math.sin(p * Math.PI) * (isAwakened ? 0.42 : 0.22);
    rig.bodyPivot.rotation.y = p * Math.PI * 2 * (isAwakened ? 2 : 1);
    rig.upperTorsoPivot.rotation.z = -0.26;
    rig.leftArmPivot.rotation.set(0.55, 0, 0.65);
    rig.rightArmPivot.rotation.set(-0.55, 0, 0.65);
    rig.leftElbowPivot.rotation.z = 0.85;
    rig.rightElbowPivot.rotation.z = 0.85;
    rig.leftLegPivot.rotation.z = Math.sin(p * Math.PI * 4) * 0.55;
    rig.rightLegPivot.rotation.z = -Math.sin(p * Math.PI * 4) * 0.55;
    rig.leftKneePivot.rotation.z = -0.42;
    rig.rightKneePivot.rotation.z = -0.42;
    return nextPhase;
  }

  // 8. Personal Skill Leap / Burst
  if (actionTimer > 0 && (actionAnim === 'SKILL_BURST' || actionAnim === 'SKILL_LEAP')) {
    const p = 1 - Math.min(1, actionTimer / 0.55);
    const arc = Math.sin(p * Math.PI);
    rig.bodyPivot.position.y = actionAnim === 'SKILL_LEAP' ? arc * 1.45 : arc * 0.36;
    rig.bodyPivot.rotation.set(0, actionAnim === 'SKILL_LEAP' ? p * Math.PI * 2 : 0, -0.3 * arc);
    rig.upperTorsoPivot.rotation.z = -0.32;
    rig.leftArmPivot.rotation.set(0.35, 0, -0.85);
    rig.rightArmPivot.rotation.set(-0.35, 0, 0.95);
    rig.leftKneePivot.rotation.z = -0.75 * arc;
    rig.rightKneePivot.rotation.z = -0.35 * arc;
    return nextPhase;
  }

  // 8b. Jumping Header Strike
  if (actionTimer > 0 && actionAnim === 'HEADER') {
    const p = 1 - Math.min(1, actionTimer / 0.42);
    const windup = Math.min(1, p / 0.35);
    const snap = Math.max(0, Math.min(1, (p - 0.35) / 0.35));
    const follow = Math.max(0, (p - 0.7) / 0.3);
    resetSubtlePose(rig, dt);
    const torsoArch = p < 0.35 ? THREE.MathUtils.lerp(0, 0.36, windup) : THREE.MathUtils.lerp(0.36, -0.52, snap) * (1 - follow * 0.4);
    rig.upperTorsoPivot.rotation.set(0, 0, torsoArch);
    rig.headGroup.rotation.set(0, 0, p < 0.35 ? 0.24 * windup : THREE.MathUtils.lerp(0.24, -0.58, snap));
    rig.leftArmPivot.rotation.set(0.45, 0, p < 0.35 ? 0.95 : -0.45);
    rig.rightArmPivot.rotation.set(-0.45, 0, p < 0.35 ? 0.95 : -0.45);
    rig.leftElbowPivot.rotation.z = 0.72;
    rig.rightElbowPivot.rotation.z = 0.72;
    rig.leftLegPivot.rotation.z = -0.25;
    rig.rightLegPivot.rotation.z = -0.22;
    rig.leftKneePivot.rotation.z = -0.78;
    rig.rightKneePivot.rotation.z = -0.72;
    return nextPhase;
  }

  // 9. Celebrations / Emotes
  if (emoteTimer > 0 && emoteId) {
    const t = 2.8 - emoteTimer;
    resetSubtlePose(rig, dt);
    if (emoteId === 'SIUUU') {
      if (t < 0.7) {
        const jumpP = Math.sin((t / 0.7) * Math.PI);
        rig.bodyPivot.position.y = jumpP * 1.35;
        rig.bodyPivot.rotation.y = (t / 0.7) * Math.PI;
        rig.leftArmPivot.rotation.set(0.3, 0, 2.2);
        rig.rightArmPivot.rotation.set(-0.3, 0, 2.2);
      } else {
        rig.bodyPivot.rotation.y = Math.PI;
        rig.bodyPivot.position.y = -0.14;
        rig.upperTorsoPivot.rotation.z = 0.14;
        rig.leftArmPivot.rotation.set(0.65, 0, -0.58);
        rig.rightArmPivot.rotation.set(-0.65, 0, -0.58);
        rig.leftLegPivot.rotation.set(0.28, 0, 0);
        rig.rightLegPivot.rotation.set(-0.28, 0, 0);
        rig.leftKneePivot.rotation.z = -0.25;
        rig.rightKneePivot.rotation.z = -0.25;
      }
      return nextPhase;
    }
    if (emoteId === 'EGOIST_POSE') {
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0.04, 12, dt);
      rig.upperTorsoPivot.rotation.set(0, -0.22, 0.14);
      rig.rightArmPivot.rotation.set(-0.18, 0, 2.35);
      rig.rightElbowPivot.rotation.z = 0.15;
      rig.leftArmPivot.rotation.set(0.32, 0, -0.38);
      rig.leftElbowPivot.rotation.z = 1.45;
      rig.leftLegPivot.rotation.set(0.12, 0, -0.18);
      rig.rightLegPivot.rotation.set(-0.12, 0, 0.22);
      rig.leftKneePivot.rotation.z = -0.15;
      rig.rightKneePivot.rotation.z = -0.12;
      return nextPhase;
    }
    if (emoteId === 'ARMS_CROSSED') {
      rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, 0, 12, dt);
      rig.upperTorsoPivot.rotation.set(0, 0, 0.08);
      rig.headGroup.rotation.set(0, Math.sin(t * 1.8) * 0.18, -0.1);
      rig.leftArmPivot.rotation.set(-0.55, 0, 0.85);
      rig.rightArmPivot.rotation.set(0.55, 0, 0.85);
      rig.leftElbowPivot.rotation.z = 1.65;
      rig.rightElbowPivot.rotation.z = 1.65;
      rig.leftLegPivot.rotation.set(0.1, 0, 0.05);
      rig.rightLegPivot.rotation.set(-0.1, 0, -0.05);
      rig.leftKneePivot.rotation.z = -0.08;
      rig.rightKneePivot.rotation.z = -0.08;
      return nextPhase;
    }
    if (emoteId === 'KNEE_SLIDE') {
      const sp = Math.min(1, t / 0.42);
      const pump = Math.sin(t * 10) * 0.22;
      rig.bodyPivot.position.y = -0.56 * sp;
      rig.bodyPivot.rotation.z = 0.28 * sp;
      rig.upperTorsoPivot.rotation.set(0, 0, 0.18 * sp);
      rig.leftLegPivot.rotation.set(0.12, 0, 0.44 * sp);
      rig.rightLegPivot.rotation.set(-0.12, 0, 0.44 * sp);
      rig.leftKneePivot.rotation.z = -1.56 * sp;
      rig.rightKneePivot.rotation.z = -1.56 * sp;
      rig.leftArmPivot.rotation.set(0.65, 0, (-0.9 + pump) * sp);
      rig.rightArmPivot.rotation.set(-0.65, 0, (-0.9 - pump) * sp);
      rig.leftElbowPivot.rotation.z = 0.9;
      rig.rightElbowPivot.rotation.z = 0.9;
      return nextPhase;
    }
    if (emoteId === 'FLEX_ROAR') {
      rig.bodyPivot.position.y = 0.04 + Math.abs(Math.sin(t * 6)) * 0.05;
      rig.upperTorsoPivot.rotation.set(0, 0, 0.2);
      rig.leftArmPivot.rotation.set(-0.68, 0, 1.25);
      rig.rightArmPivot.rotation.set(0.68, 0, 1.25);
      rig.leftElbowPivot.rotation.z = 1.82;
      rig.rightElbowPivot.rotation.z = 1.82;
      rig.leftLegPivot.rotation.set(0.22, 0, -0.15);
      rig.rightLegPivot.rotation.set(-0.22, 0, 0.15);
      rig.leftKneePivot.rotation.z = -0.22;
      rig.rightKneePivot.rotation.z = -0.22;
      return nextPhase;
    }
  }

  // 10. Ground-Up Organic Locomotion & Idle / GK Stance
  resetSubtlePose(rig, dt);

  if (speed > 0.65) {
    const strideFreq = (sprint ? 1.85 : 1.38) * Math.min(1.65, 0.65 + speed * 0.068);
    nextPhase = (nextPhase + dt * strideFreq * Math.PI * 2) % (Math.PI * 2);
    const s = Math.sin(nextPhase);
    const c = Math.cos(nextPhase);

    const strideAmp = sprint ? 0.96 : 0.66;
    const dribbleMod = hasBall ? 0.88 : 1.0;

    // Vertical COM bounce (double frequency per cycle) + forward athletic lean
    const bob = Math.abs(Math.sin(nextPhase)) * (sprint ? 0.13 : 0.075);
    rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, bob - 0.03, 18, dt);
    rig.upperTorsoPivot.rotation.z = damp(
      rig.upperTorsoPivot.rotation.z,
      sprint ? -0.28 : hasBall ? -0.17 : -0.13,
      14,
      dt
    );
    // Natural torso counter-twist & lateral sway
    rig.upperTorsoPivot.rotation.y = -s * (sprint ? 0.16 : 0.09);
    rig.upperTorsoPivot.rotation.x = c * (sprint ? 0.06 : 0.035);
    rig.headGroup.rotation.z = damp(rig.headGroup.rotation.z, sprint ? 0.16 : 0.06, 12, dt);

    // Legs: asymmetric swing vs plant flexion so knees tuck smoothly during recovery swing
    rig.leftLegPivot.rotation.set(0, 0, s * strideAmp * dribbleMod);
    rig.rightLegPivot.rotation.set(0, 0, -s * strideAmp * dribbleMod);

    const leftRecovery = Math.max(0, -c) * 0.85 + Math.max(0, s) * 0.35;
    const rightRecovery = Math.max(0, c) * 0.85 + Math.max(0, -s) * 0.35;
    rig.leftKneePivot.rotation.z = -0.16 - leftRecovery * (sprint ? 1.05 : 0.72);
    rig.rightKneePivot.rotation.z = -0.16 - rightRecovery * (sprint ? 1.05 : 0.72);

    // Arms: opposite phase to legs with slight inward pump
    const armAmp = sprint ? 1.02 : 0.62;
    rig.leftArmPivot.rotation.set(0.1, 0, -s * armAmp);
    rig.rightArmPivot.rotation.set(-0.1, 0, s * armAmp);
    rig.leftElbowPivot.rotation.z = sprint ? 1.48 - Math.max(0, -s) * 0.35 : 0.86;
    rig.rightElbowPivot.rotation.z = sprint ? 1.48 - Math.max(0, s) * 0.35 : 0.86;
    return nextPhase;
  }

  // Idle / Ready Stance
  nextPhase = (nextPhase + dt * 2.4) % (Math.PI * 2);
  const breath = Math.sin(nextPhase);
  if (isGoalkeeper) {
    // Low coiled GK ready crouch
    rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, -0.09 + breath * 0.025, 10, dt);
    rig.upperTorsoPivot.rotation.z = damp(rig.upperTorsoPivot.rotation.z, -0.18, 12, dt);
    rig.headGroup.rotation.z = 0.12;
    rig.leftLegPivot.rotation.set(0.18, 0, 0.14);
    rig.rightLegPivot.rotation.set(-0.18, 0, -0.14);
    rig.leftKneePivot.rotation.z = -0.44;
    rig.rightKneePivot.rotation.z = -0.44;
    rig.leftArmPivot.rotation.set(0.32, 0, 0.88 + breath * 0.05);
    rig.rightArmPivot.rotation.set(-0.32, 0, 0.88 + breath * 0.05);
    rig.leftElbowPivot.rotation.z = 1.08;
    rig.rightElbowPivot.rotation.z = 1.08;
  } else {
    rig.bodyPivot.position.y = damp(rig.bodyPivot.position.y, breath * 0.024, 10, dt);
    rig.upperTorsoPivot.rotation.z = damp(rig.upperTorsoPivot.rotation.z, -0.04 + breath * 0.02, 10, dt);
    rig.leftLegPivot.rotation.set(0.05, 0, 0.06);
    rig.rightLegPivot.rotation.set(-0.05, 0, -0.06);
    rig.leftKneePivot.rotation.z = damp(rig.leftKneePivot.rotation.z, -0.12, 12, dt);
    rig.rightKneePivot.rotation.z = damp(rig.rightKneePivot.rotation.z, -0.12, 12, dt);
    rig.leftArmPivot.rotation.set(0.08, 0, 0.05 + breath * 0.04);
    rig.rightArmPivot.rotation.set(-0.08, 0, -0.05 - breath * 0.04);
    rig.leftElbowPivot.rotation.z = 0.28;
    rig.rightElbowPivot.rotation.z = 0.28;
  }

  return nextPhase;
}
