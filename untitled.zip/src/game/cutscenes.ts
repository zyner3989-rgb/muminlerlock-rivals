import * as THREE from 'three';
import { soundEngine } from '../audio/soundEngine';
import { STYLES } from '../data/styles';
import type { StyleId } from '../types/game';
import type { CutscenePropPack, PlayerRig } from './models';
import { PITCH_HALF_LENGTH } from './models';

export type CutsceneKind = 'AWAKENING' | 'ULTI' | 'COMBO';

export interface ActiveCutscene {
  styleId: StyleId;
  kind: CutsceneKind;
  attackDir: 1 | -1;
  elapsed: number;
  duration: number;
  anchorPos: THREE.Vector3;
  opponentPos: THREE.Vector3;
  triggeredEvents: Set<string>;
}

export interface CutsceneFrameResult {
  finished: boolean;
  cameraPos: THREE.Vector3;
  cameraLook: THREE.Vector3;
  banner: {
    active: boolean;
    speaker: string;
    subtitle: string;
    badge: string;
    accentColor: string;
  };
  spawnBurst?: { pos: THREE.Vector3; color: string; count: number };
  launchShot?: {
    from: THREE.Vector3;
    range: 'FULL_PITCH' | 'MIDFIELD';
    curve: number;
    speed: number;
    loft: number;
    stealAndTeleportPos?: THREE.Vector3;
  };
}

const _camPos = new THREE.Vector3();
const _camLook = new THREE.Vector3();
const _cleatPos = new THREE.Vector3();

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function easeOutCubic(t: number): number {
  const x = clamp01(t);
  return 1 - Math.pow(1 - x, 3);
}

function easeInOutCubic(t: number): number {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
}

function easeOutBack(t: number): number {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

function getCleatWorldPos(
  rig: PlayerRig,
  side: 'left' | 'right',
  out: THREE.Vector3,
  tipOffsetX = 0.16,
  tipOffsetY = -0.46
): THREE.Vector3 {
  rig.root.updateMatrixWorld(true);
  const pivot = side === 'right' ? rig.rightKneePivot : rig.leftKneePivot;
  return pivot.localToWorld(out.set(tipOffsetX, tipOffsetY, 0));
}

export function startCutsceneState(
  styleId: StyleId,
  kind: CutsceneKind,
  playerPos: THREE.Vector3,
  nearestOpponentPos: THREE.Vector3,
  props: CutscenePropPack,
  attackDir: 1 | -1 = 1
): ActiveCutscene {
  props.root.visible = true;
  props.root.position.set(playerPos.x, 0, playerPos.z);
  props.root.rotation.set(0, attackDir === 1 ? 0 : Math.PI, 0);
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#facc15');
  (props.snapRing.material as THREE.MeshBasicMaterial).opacity = 0.9;
  props.deskHeadset.visible = false;
  props.melon.visible = false;
  props.nitroFlame.visible = false;
  props.waterGun.visible = false;
  props.waterStream.visible = false;
  props.cheapPack.visible = false;
  props.messiCard.visible = false;
  props.messiHero.visible = false;

  if (kind === 'COMBO') {
    soundEngine.playAnimeAwakeningIntro('musab', 'COMBO');
  } else {
    soundEngine.playAnimeAwakeningIntro(styleId, kind);
  }

  const durationMap: Record<CutsceneKind, Record<StyleId, number>> = {
    AWAKENING: {
      musab: 3.5,
      musa: 3.4,
      iskender: 3.4,
      aras: 3.4,
      ebulfez: 3.5,
      zero: 3.3,
      berk: 3.4,
      esref_tek: 3.4,
      arap_kavuncu: 3.4,
      hamzac5: 3.4,
      memud: 3.3,
      umidi: 3.6,
    },
    ULTI: {
      musab: 4.4,
      musa: 3.6,
      iskender: 3.8,
      aras: 3.6,
      ebulfez: 3.6,
      zero: 3.5,
      berk: 3.4,
      esref_tek: 3.7,
      arap_kavuncu: 3.6,
      hamzac5: 3.7,
      memud: 3.5,
      umidi: 4.2,
    },
    COMBO: {
      musab: 4.5,
      musa: 4.5,
      iskender: 4.5,
      aras: 4.5,
      ebulfez: 4.5,
      zero: 4.5,
      berk: 4.5,
      esref_tek: 4.5,
      arap_kavuncu: 4.5,
      hamzac5: 4.5,
      memud: 4.5,
      umidi: 4.5,
    },
  };

  return {
    styleId,
    kind,
    attackDir,
    elapsed: 0,
    duration: durationMap[kind][styleId],
    anchorPos: playerPos.clone(),
    opponentPos: nearestOpponentPos.clone(),
    triggeredEvents: new Set(),
  };
}

function resetSingleRig(rig: PlayerRig) {
  rig.bodyPivot.visible = true;
  rig.bodyPivot.scale.set(1, 1, 1);
  rig.bodyPivot.position.set(0, 0, 0);
  rig.bodyPivot.rotation.set(0, 0, 0);
  rig.upperTorsoPivot.rotation.set(0, 0, 0);
  rig.leftArmPivot.rotation.set(0, 0, 0);
  rig.leftElbowPivot.rotation.set(0, 0, 0);
  rig.rightArmPivot.rotation.set(0, 0, 0);
  rig.rightElbowPivot.rotation.set(0, 0, 0);
  rig.leftLegPivot.rotation.set(0, 0, 0);
  rig.leftKneePivot.rotation.set(0, 0, 0);
  rig.rightLegPivot.rotation.set(0, 0, 0);
  rig.rightKneePivot.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.auraPillars.visible = false;
  rig.auraPillars.position.set(0, 0, 0);
  rig.auraPillars.scale.set(1, 1, 1);
  rig.auraRing.position.set(0, 0.04, 0);
  (rig.auraRing.material as THREE.MeshBasicMaterial).opacity = 0;
  if (rig.headsetProp) rig.headsetProp.visible = true;
}

export function resetAfterCutscene(
  rig: PlayerRig,
  props: CutscenePropPack,
  stopAudio = false,
  partnerRig?: PlayerRig | null
) {
  if (stopAudio) {
    soundEngine.stopSpeech();
  }
  props.root.visible = false;
  props.root.rotation.set(0, 0, 0);
  props.bed.visible = false;
  props.desk.visible = false;
  props.phone.visible = false;
  props.pillow.visible = false;
  props.sock.visible = false;
  props.coach.visible = false;
  props.hamburger.visible = false;
  props.monsterBall.visible = false;
  props.snapRing.visible = false;
  (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#facc15');
  (props.snapRing.material as THREE.MeshBasicMaterial).opacity = 0.9;
  props.deskHeadset.visible = false;
  props.melon.visible = false;
  props.nitroFlame.visible = false;
  props.waterGun.visible = false;
  props.waterStream.visible = false;
  props.cheapPack.visible = false;
  props.messiCard.visible = false;
  props.messiHero.visible = false;

  resetSingleRig(rig);
  if (partnerRig && partnerRig !== rig) {
    resetSingleRig(partnerRig);
  }
}

function normalizeRigForFrame(rig: PlayerRig) {
  rig.bodyPivot.visible = true;
  rig.bodyPivot.scale.set(1, 1, 1);
  rig.bodyPivot.position.set(0, 0, 0);
  rig.bodyPivot.rotation.set(0, 0, 0);
  rig.upperTorsoPivot.rotation.set(0, 0, 0);
  rig.leftArmPivot.rotation.set(0, 0, 0);
  rig.leftElbowPivot.rotation.set(0, 0, 0.18);
  rig.rightArmPivot.rotation.set(0, 0, 0);
  rig.rightElbowPivot.rotation.set(0, 0, 0.18);
  rig.leftLegPivot.rotation.set(0, 0, 0);
  rig.leftKneePivot.rotation.set(0, 0, -0.05);
  rig.rightLegPivot.rotation.set(0, 0, 0);
  rig.rightKneePivot.rotation.set(0, 0, -0.05);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.auraPillars.visible = false;
  rig.auraPillars.position.set(0, 0, 0);
  rig.auraPillars.scale.set(1, 1, 1);
  rig.auraRing.position.set(0, 0.04, 0);
  (rig.auraRing.material as THREE.MeshBasicMaterial).opacity = 0;
}

export function stepCutscene(
  cs: ActiveCutscene,
  dt: number,
  rig: PlayerRig,
  ballGroup: THREE.Group,
  props: CutscenePropPack,
  partnerRig?: PlayerRig | null
): CutsceneFrameResult {
  cs.elapsed += dt;
  const t = cs.elapsed;
  const style = STYLES[cs.styleId];
  const ax = cs.anchorPos.x;
  const az = cs.anchorPos.z;
  const dir = cs.attackDir;
  const rotY = dir === 1 ? 0 : Math.PI;
  const wx = (lx: number) => ax + dir * lx;

  normalizeRigForFrame(rig);
  rig.root.position.set(ax, 0, az);
  rig.root.rotation.set(0, rotY, 0);
  props.root.position.set(ax, 0, az);
  props.root.rotation.set(0, rotY, 0);
  if (partnerRig && partnerRig !== rig) {
    normalizeRigForFrame(partnerRig);
  }

  let subtitle = style.awakeningQuote;
  const badge =
    cs.kind === 'COMBO'
      ? 'KİMYASAL TEPKİME · MUSAB × MUSA'
      : cs.kind === 'AWAKENING'
        ? `UYANIŞ · ${style.rarity}`
        : `ULTİ · ${style.ultiRangeLabel.toUpperCase()}`;
  let spawnBurst: CutsceneFrameResult['spawnBurst'];
  let launchShot: CutsceneFrameResult['launchShot'];

  const fireOnce = (key: string, fn: () => void) => {
    if (!cs.triggeredEvents.has(key)) {
      cs.triggeredEvents.add(key);
      fn();
    }
  };

  const showAuraOn = (targetRig: PlayerRig, intensity: number) => {
    const inverted = Math.abs(targetRig.bodyPivot.rotation.z) > 1.0;
    targetRig.auraPillars.visible = intensity > 0.05 && !inverted;
    targetRig.auraPillars.position.set(
      targetRig.bodyPivot.position.x,
      Math.max(0, targetRig.bodyPivot.position.y * 0.25),
      targetRig.bodyPivot.position.z
    );
    targetRig.auraPillars.rotation.y += dt * 2.8;
    targetRig.auraPillars.scale.set(1, 0.75 + intensity * 0.45, 1);
    targetRig.auraRing.position.set(targetRig.bodyPivot.position.x, 0.04, targetRig.bodyPivot.position.z);
    targetRig.auraRing.rotation.z -= dt * 3.2;
    (targetRig.auraRing.material as THREE.MeshBasicMaterial).opacity = Math.min(0.75, intensity * 0.7);
  };

  const showAura = (intensity: number) => {
    showAuraOn(rig, intensity);
  };

  if (cs.kind === 'AWAKENING') {
    switch (cs.styleId) {
      case 'musab': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);

        if (t < 0.9) {
          fireOnce('musab_sleep', () => soundEngine.playSnore());
          const sitUp = t > 0.62 ? easeInOutCubic((t - 0.62) / 0.28) : 0;
          const breathe = Math.sin(t * 5.2) * 0.03;
          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(-1.12, -0.1, sitUp),
            0.92 + breathe * (1 - sitUp),
            0
          );
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-Math.PI / 2, -0.15, sitUp);
          rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(0.08, -0.24, sitUp);
          rig.leftLegPivot.rotation.z = THREE.MathUtils.lerp(0.28, 0.95, sitUp);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(0.2, 0.85, sitUp);
          rig.leftKneePivot.rotation.z = THREE.MathUtils.lerp(-0.45, -1.05, sitUp);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.32, -0.95, sitUp);
          rig.leftArmPivot.rotation.set(0.3, 0, THREE.MathUtils.lerp(0.2, 0.9, sitUp));
          rig.rightArmPivot.rotation.set(-0.3, 0, THREE.MathUtils.lerp(0.35, 1.0, sitUp));
          rig.leftElbowPivot.rotation.z = 1.1;
          rig.rightElbowPivot.rotation.z = 1.25;
          rig.headGroup.rotation.z = sitUp * 0.22;

          subtitle = t > 0.62 ? 'Tam odak moduna geçti!' : 'Sakin nefes... odaklanıyor...';
          _camPos.set(wx(3.2), 2.55, az + 3.1);
          _camLook.set(wx(0.35), 1.15, az);
        } else if (t < 1.55) {
          fireOnce('jump_boom', () => {
            soundEngine.playPhoneRing();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(1.8), 1.2, az), color: style.auraColor, count: 28 };
          });
          const p = (t - 0.9) / 0.65;
          const easeP = easeOutCubic(p);
          const jumpY = Math.sin(p * Math.PI) * 1.35 + (1 - easeP) * 0.85;
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(-0.1, 2.05, easeP), jumpY, 0);
          rig.bodyPivot.rotation.y = easeP * 0.25;
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.leftLegPivot.rotation.set(0.14, 0, 0.55 * Math.sin(p * Math.PI));
          rig.rightLegPivot.rotation.set(-0.14, 0, -0.35 * Math.sin(p * Math.PI));
          rig.leftKneePivot.rotation.z = -0.95 * Math.sin(p * Math.PI) - 0.35;
          rig.rightKneePivot.rotation.z = -0.75 * Math.sin(p * Math.PI) - 0.25;
          rig.rightArmPivot.rotation.set(0.18, 0, 1.05);
          rig.rightElbowPivot.rotation.z = 1.32;
          rig.leftArmPivot.rotation.set(0.42, 0, 0.75);
          rig.leftElbowPivot.rotation.z = 0.85;

          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(rig.bodyPivot.position.x + 0.28, rig.bodyPivot.position.y + 2.02, 0.36);
          props.phone.rotation.set(0, -Math.PI / 2 + 0.25, -0.15);

          showAura(p);
          subtitle = 'Oyun şimdi başlıyor! Musa, hattın ucunda kal!';
          _camPos.set(wx(4.8), 2.45, az + 3.0);
          _camLook.set(wx(1.5), 1.6, az);
        } else {
          const p = (t - 1.55) / (cs.duration - 1.55);
          const settle = easeOutCubic(Math.min(1, p * 3));
          const hypeBob = Math.abs(Math.sin((t - 1.55) * 10)) * 0.08;
          rig.bodyPivot.position.set(2.05, hypeBob, 0);
          rig.bodyPivot.rotation.y = 0.25 - Math.sin(p * Math.PI) * 0.15;
          rig.upperTorsoPivot.rotation.set(0, Math.sin(t * 8) * 0.14, -0.18 + Math.sin(t * 10) * 0.06);
          rig.headGroup.rotation.z = 0.14;

          rig.leftLegPivot.rotation.set(0.16, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.16, 0, 0.28);
          rig.leftKneePivot.rotation.z = -0.38 - settle * 0.05;
          rig.rightKneePivot.rotation.z = -0.32 - settle * 0.05;

          rig.rightArmPivot.rotation.set(0.22, 0, 1.05);
          rig.rightElbowPivot.rotation.z = 1.35;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.65 + Math.sin(t * 14) * 0.45);
          rig.leftElbowPivot.rotation.z = 1.15;

          props.phone.visible = true;
          props.phone.position.set(2.05 + 0.26, 2.02 + hypeBob, 0.36);
          props.phone.rotation.set(0, -Math.PI / 2 + 0.25, -0.15);

          if (t > 2.2) {
            fireOnce('boom', () => soundEngine.playAwakeningBoom());
          }
          showAura(1.0);
          rig.auraPillars.position.x = 2.05;
          rig.auraRing.position.x = 2.05;
          subtitle = 'Musa, sahanın kontrolü artık tamamen bizde!';
          const orbit = p * 1.15;
          _camPos.set(wx(2.05) + dir * Math.cos(orbit) * 3.8, 2.05, az + Math.sin(orbit) * 3.6);
          _camLook.set(wx(2.05), 1.55, az);
        }
        break;
      }

      case 'musa': {
        fireOnce('ring', () => soundEngine.playPhoneRing());
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.phone_musab;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.05) {
          const vib = Math.sin(t * 36) * 0.025;
          rig.upperTorsoPivot.rotation.z = -0.14;
          rig.headGroup.rotation.z = -0.34;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.12);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.16);
          rig.leftKneePivot.rotation.z = -0.22;
          rig.rightKneePivot.rotation.z = -0.18;

          rig.rightArmPivot.rotation.set(0.28, 0, 0.78);
          rig.rightElbowPivot.rotation.z = 1.12;
          rig.leftArmPivot.rotation.set(0.12, 0, -0.12);
          rig.leftElbowPivot.rotation.z = 0.55;

          props.phone.position.set(0.56 + vib, 1.48, 0.28 + vib);
          props.phone.rotation.set(0, 0.35, -0.45);
          subtitle = 'Gelen çağrı: MUSAB ARIYOR...';
          _camPos.set(wx(3.4), 2.0, az + 2.5);
          _camLook.set(wx(0.2), 1.45, az);
        } else {
          fireOnce('rage', () => {
            soundEngine.playPhonePickup();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: style.auraColor, count: 32 };
          });
          const snapP = easeOutCubic(Math.min(1, (t - 1.05) / 0.35));
          const rageWave = Math.sin((t - 1.05) * 16);

          rig.bodyPivot.position.y = -0.08 + Math.abs(rageWave) * 0.04;
          rig.upperTorsoPivot.rotation.set(0, rageWave * 0.16, THREE.MathUtils.lerp(-0.14, 0.16, snapP) + rageWave * 0.08);
          rig.headGroup.rotation.set(rageWave * 0.12, 0, 0.2);

          rig.leftLegPivot.rotation.set(0.2, 0, -0.26);
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.3);
          rig.leftKneePivot.rotation.z = -0.44;
          rig.rightKneePivot.rotation.z = -0.38;

          rig.rightArmPivot.rotation.set(0.22, 0, THREE.MathUtils.lerp(0.78, 1.08, snapP));
          rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(1.12, 1.38, snapP);
          rig.leftArmPivot.rotation.set(0.35, 0, 0.75 + rageWave * 0.55);
          rig.leftElbowPivot.rotation.z = 1.25 + rageWave * 0.25;

          props.phone.position.set(
            THREE.MathUtils.lerp(0.56, 0.27, snapP),
            THREE.MathUtils.lerp(1.48, 2.02, snapP),
            THREE.MathUtils.lerp(0.28, 0.36, snapP)
          );
          props.phone.rotation.set(0, -Math.PI / 2 + 0.22, -0.12);

          showAura(snapP);
          subtitle = 'Tam zamanında aradın Musab! Şimdi tüm savunmayı yarıyorum!';
          const shake = Math.sin(t * 44) * 0.05;
          _camPos.set(wx(3.3) + shake, 1.95 + shake * 0.5, az - 2.35);
          _camLook.set(ax, 1.55, az);
        }
        break;
      }

      case 'iskender': {
        props.phone.visible = true;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
        (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('isk_call', () => soundEngine.playPhonePickup());
          const nod = Math.sin(t * 8) * 0.08;
          rig.leftLegPivot.rotation.set(0.1, 0, -0.1);
          rig.rightLegPivot.rotation.set(-0.1, 0, 0.14);
          rig.leftKneePivot.rotation.z = -0.18;
          rig.rightKneePivot.rotation.z = -0.15;
          rig.upperTorsoPivot.rotation.z = -0.08;
          rig.headGroup.rotation.z = nod;
          rig.rightArmPivot.rotation.set(0.24, 0, 0.88);
          rig.rightElbowPivot.rotation.z = 1.08;
          rig.leftArmPivot.rotation.set(0.18, 0, 0.25);
          rig.leftElbowPivot.rotation.z = 0.8;

          props.phone.position.set(0.62, 1.62, 0.22);
          props.phone.rotation.set(0, 0.2, -0.25);
          subtitle = 'Görüntülü görüşmede... Hazır mısın Musa?';
          _camPos.set(wx(3.4), 2.0, az + 2.3);
          _camLook.set(wx(0.2), 1.55, az);
        } else {
          fireOnce('sock_boom', () => {
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(0.7), 1.0, az), color: style.auraColor, count: 28 };
          });
          const kickP = easeOutBack(Math.min(1, (t - 1.15) / 0.5));
          const dropP = easeOutCubic(Math.min(1, (t - 1.15) / 0.35));
          props.phone.position.set(
            THREE.MathUtils.lerp(0.62, 1.15, dropP),
            THREE.MathUtils.lerp(1.62, 0.12, dropP),
            THREE.MathUtils.lerp(0.22, 0.48, dropP)
          );
          props.phone.rotation.set(0, -0.2, THREE.MathUtils.lerp(-0.25, -1.25, dropP));

          rig.bodyPivot.position.y = -0.08 * kickP;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.2 * kickP);
          rig.leftKneePivot.rotation.z = -0.26 * kickP;
          rig.upperTorsoPivot.rotation.set(0, -0.18 * kickP, 0.34 * kickP);
          rig.headGroup.rotation.z = -0.24 * kickP;

          rig.leftArmPivot.rotation.set(0.65 * kickP, 0, -0.25);
          rig.leftElbowPivot.rotation.z = 0.55;
          rig.rightArmPivot.rotation.set(-0.65 * kickP, 0, 0.35);
          rig.rightElbowPivot.rotation.z = 0.55;

          const legAng = THREE.MathUtils.lerp(0.14, 1.48, kickP);
          rig.rightLegPivot.rotation.set(0, 0, legAng);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.35, -0.08, kickP);

          props.sock.visible = kickP > 0.35;
          const sockDist = 0.72;
          props.sock.position.set(
            Math.sin(legAng) * sockDist,
            0.92 - 0.08 * kickP - Math.cos(legAng) * sockDist,
            0.18
          );
          props.sock.rotation.set(0, 0, legAng - Math.PI);
          props.sock.scale.setScalar(1.22);

          showAura(kickP);
          subtitle = 'İyi izle Musa — parlayan imza hamlem geliyor!';
          _camPos.set(wx(2.9), 1.45, az + 1.55);
          _camLook.set(wx(0.6), 1.15, az + 0.1);
        }
        break;
      }

      case 'aras': {
        props.desk.visible = true;
        props.desk.position.set(1.45, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.aras_lose;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.15) {
          fireOnce('aras_lose_sfx', () => soundEngine.playGlitchBeep());
          const shake = Math.sin(t * 6) * 0.04;
          rig.bodyPivot.position.set(0.12, -0.22, 0);
          rig.upperTorsoPivot.rotation.z = -0.32;
          rig.headGroup.rotation.set(0, shake, -0.18);
          rig.leftLegPivot.rotation.set(0.15, 0, 1.15);
          rig.rightLegPivot.rotation.set(-0.15, 0, 1.15);
          rig.leftKneePivot.rotation.z = -1.28;
          rig.rightKneePivot.rotation.z = -1.28;
          rig.leftArmPivot.rotation.set(0.22, 0, 0.85);
          rig.rightArmPivot.rotation.set(-0.22, 0, 0.85);
          rig.leftElbowPivot.rotation.z = 0.72;
          rig.rightElbowPivot.rotation.z = 0.72;

          subtitle = 'Skor tabelası geride... Bu böyle kalmayacak!';
          _camPos.set(wx(-2.3), 2.45, az + 3.1);
          _camLook.set(wx(1.1), 1.55, az);
        } else if (t < 1.65) {
          fireOnce('aras_slam', () => soundEngine.playDeskThud());
          const p = easeOutCubic((t - 1.15) / 0.5);
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(0.12, 0.25, p), THREE.MathUtils.lerp(-0.22, -0.12, p), 0);
          rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(-0.32, -0.52, p);
          rig.leftLegPivot.rotation.set(0.15, 0, 0.9);
          rig.rightLegPivot.rotation.set(-0.15, 0, 0.9);
          rig.leftKneePivot.rotation.z = -1.05;
          rig.rightKneePivot.rotation.z = -1.05;
          rig.leftArmPivot.rotation.set(0.22, 0, 1.15);
          rig.rightArmPivot.rotation.set(-0.22, 0, 1.15);
          rig.leftElbowPivot.rotation.z = 0.42;
          rig.rightElbowPivot.rotation.z = 0.42;

          subtitle = 'Bu skor burada bitmeyecek İskender!';
          _camPos.set(wx(-2.0), 2.35, az + 3.0);
          _camLook.set(wx(1.0), 1.5, az);
        } else {
          fireOnce('aras_rage', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(-0.15), 1.4, az), color: '#ef4444', count: 36 };
          });
          const p = easeOutCubic(Math.min(1, (t - 1.65) / 0.45));
          const roarVib = Math.sin(t * 28) * 0.04;
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(0.25, -0.22, p), -0.1, 0);
          rig.upperTorsoPivot.rotation.set(0, roarVib, THREE.MathUtils.lerp(-0.3, 0.28, p));
          rig.headGroup.rotation.set(roarVib * 1.5, 0, 0.32 * p);

          rig.leftLegPivot.rotation.set(0.24, 0, -0.28);
          rig.rightLegPivot.rotation.set(-0.24, 0, 0.32);
          rig.leftKneePivot.rotation.z = -0.46;
          rig.rightKneePivot.rotation.z = -0.4;

          rig.leftArmPivot.rotation.set(0.55, 0, -0.45 + roarVib);
          rig.rightArmPivot.rotation.set(-0.55, 0, -0.45 - roarVib);
          rig.leftElbowPivot.rotation.z = 1.65;
          rig.rightElbowPivot.rotation.z = 1.65;

          showAura(p);
          rig.auraPillars.position.x = -0.22;
          rig.auraRing.position.x = -0.22;
          subtitle = 'Şimdi gerçek maçı başlatıyorum — Tam Alev Gücü!';
          const camShake = Math.sin(t * 46) * 0.06;
          _camPos.set(wx(2.8) + camShake, 1.95 + camShake * 0.4, az + 2.6);
          _camLook.set(wx(-0.15), 1.55, az);
        }
        break;
      }

      case 'ebulfez': {
        if (t < 1.2) {
          const raiseP = easeInOutCubic(t / 1.0);
          rig.bodyPivot.rotation.y = -0.32 * raiseP;
          rig.leftLegPivot.rotation.set(0.12, 0, -0.14);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.14);
          rig.leftKneePivot.rotation.z = -0.2;
          rig.rightKneePivot.rotation.z = -0.2;
          rig.upperTorsoPivot.rotation.set(0, 0.22 * raiseP, 0.08 * raiseP);

          rig.rightArmPivot.rotation.set(0.28 * raiseP, 0, 1.25 * raiseP);
          rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(0.25, 1.05, raiseP);
          rig.leftArmPivot.rotation.set(0.12, 0, -0.18);
          rig.leftElbowPivot.rotation.z = 0.45;

          subtitle = 'Zamanı kendi lehime çeviriyorum...';
          _camPos.set(wx(3.1), 1.9, az + 1.8);
          _camLook.set(ax, 1.65, az);
        } else if (t < 2.25) {
          fireOnce('snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 40 };
          });
          const p = (t - 1.2) / 1.05;
          const fade = Math.max(0, 1 - p * 3.0);
          if (fade > 0.04) {
            rig.bodyPivot.visible = true;
            rig.bodyPivot.scale.setScalar(fade);
            rig.bodyPivot.rotation.y = -0.32 + p * 2.4;
            rig.rightArmPivot.rotation.set(0.25, 0, 1.8);
            rig.rightElbowPivot.rotation.z = 0.45;
          } else {
            rig.bodyPivot.visible = false;
          }

          props.snapRing.visible = true;
          props.snapRing.position.set(0, 1.4, 0);
          props.snapRing.scale.setScalar(1 + easeOutCubic(p) * 7.0);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - p);

          subtitle = 'Tek bir parmak şıklatması yeter!';
          _camPos.set(wx(4.3), 2.35, az + 2.9);
          _camLook.set(ax, 1.45, az);
        } else {
          fireOnce('return_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 0.8, az), color: style.auraColor, count: 34 };
          });
          props.snapRing.visible = false;
          const landP = easeOutCubic(Math.min(1, (t - 2.25) / 0.55));
          rig.bodyPivot.visible = true;
          rig.bodyPivot.scale.setScalar(THREE.MathUtils.lerp(0.25, 1, landP));
          rig.bodyPivot.position.y = (1 - landP) * 0.95 - landP * 0.24;
          rig.bodyPivot.rotation.y = -0.25;
          rig.upperTorsoPivot.rotation.set(0, 0.35, -0.36 * landP);
          rig.headGroup.rotation.z = 0.28 * landP;

          rig.leftLegPivot.rotation.set(0.24, 0, -0.45 * landP);
          rig.leftKneePivot.rotation.z = -0.95 * landP;
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.78 * landP);
          rig.rightKneePivot.rotation.z = -1.25 * landP;

          rig.leftArmPivot.rotation.set(0.28, 0, 1.05 * landP);
          rig.leftElbowPivot.rotation.z = 0.18;
          rig.rightArmPivot.rotation.set(-0.45, 0, -0.65 * landP);
          rig.rightElbowPivot.rotation.z = 0.9;

          showAura(landP);
          subtitle = 'Ebulfez Uyanışı Aktif!';
          _camPos.set(wx(3.4), 1.85, az - 2.3);
          _camLook.set(ax, 1.15, az);
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(1.45, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.35) {
          fireOnce('glitch', () => soundEngine.playAiHackComplete());
          rig.bodyPivot.position.set(0.2, -0.05, 0);
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.headGroup.rotation.set(0, Math.sin(t * 7) * 0.08, -0.12);
          rig.leftLegPivot.rotation.set(0.12, 0, -0.1);
          rig.rightLegPivot.rotation.set(-0.12, 0, 0.12);
          rig.leftKneePivot.rotation.z = -0.24;
          rig.rightKneePivot.rotation.z = -0.24;

          const typeWave = Math.sin(t * 28);
          rig.leftArmPivot.rotation.set(0.18, 0, 0.8 + typeWave * 0.14);
          rig.rightArmPivot.rotation.set(-0.18, 0, 0.8 - typeWave * 0.14);
          rig.leftElbowPivot.rotation.z = 1.15 + typeWave * 0.25;
          rig.rightElbowPivot.rotation.z = 1.15 - typeWave * 0.25;

          subtitle = 'Tüm pas hatları ve açılar hesaplanıyor...';
          _camPos.set(wx(-2.2), 2.35, az + 3.0);
          _camLook.set(wx(1.0), 1.6, az);
        } else {
          fireOnce('zero_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(-0.3), 1.4, az), color: '#22d3ee', count: 32 };
          });
          const p = (t - 1.35) / (cs.duration - 1.35);
          const airP = clamp01(p / 0.52);
          const airArc = p < 0.52 ? Math.sin(airP * Math.PI) : 0;

          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(0.2, -0.45, easeOutCubic(Math.min(1, p * 2.2))),
            airArc * 1.1,
            0
          );
          rig.bodyPivot.rotation.y = airP * Math.PI * 2;
          rig.upperTorsoPivot.rotation.set(0, -0.22, p < 0.52 ? -0.18 : 0.1);

          if (p < 0.52) {
            rig.leftKneePivot.rotation.z = -1.05 * airArc;
            rig.rightKneePivot.rotation.z = -0.95 * airArc;
            rig.leftArmPivot.rotation.set(0.45, 0, 0.8);
            rig.rightArmPivot.rotation.set(-0.45, 0, 0.8);
          } else {
            rig.leftLegPivot.rotation.set(0.18, 0, -0.2);
            rig.rightLegPivot.rotation.set(-0.18, 0, 0.25);
            rig.leftKneePivot.rotation.z = -0.35;
            rig.rightKneePivot.rotation.z = -0.3;
            rig.rightArmPivot.rotation.set(-0.15, 0, 2.28);
            rig.rightElbowPivot.rotation.z = 0.2;
            rig.leftArmPivot.rotation.set(0.32, 0, -0.38);
            rig.leftElbowPivot.rotation.z = 1.45;
          }

          showAura(Math.min(1, p * 2.5));
          rig.auraPillars.position.x = rig.bodyPivot.position.x;
          rig.auraRing.position.x = rig.bodyPivot.position.x;
          subtitle = 'Tüm açılar hesaplandı — savunmanızın artık bir şansı yok!';
          _camPos.set(wx(3.4), 2.05, az + 2.75);
          _camLook.set(wx(-0.35), 1.55, az);
        }
        break;
      }

      case 'berk': {
        props.bed.visible = true;
        props.bed.position.set(0, 0, 0);
        if (t < 1.4) {
          fireOnce('berk_snore', () => soundEngine.playSnore());
          const snore = Math.sin(t * 4.2) * 0.035;
          rig.bodyPivot.position.set(-1.12, 0.92 + snore, 0);
          rig.bodyPivot.rotation.z = -Math.PI / 2;
          rig.leftLegPivot.rotation.z = 0.26;
          rig.rightLegPivot.rotation.z = 0.42;
          rig.leftKneePivot.rotation.z = -0.45;
          rig.rightKneePivot.rotation.z = -0.68;
          rig.leftArmPivot.rotation.set(0.28, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.4;
          rig.rightArmPivot.rotation.set(-0.2, 0, 0.18);
          rig.rightElbowPivot.rotation.z = 0.85;

          subtitle = 'Dinlenme vakti sona eriyor...';
          _camPos.set(wx(3.4), 2.6, az + 3.0);
          _camLook.set(wx(0.15), 1.0, az);
        } else if (t < 2.2) {
          const p = (t - 1.4) / 0.8;
          const e = easeInOutCubic(p);
          const hop = p > 0.35 ? Math.sin(((p - 0.35) / 0.65) * Math.PI) * 0.65 : 0;
          rig.bodyPivot.position.set(
            THREE.MathUtils.lerp(-1.12, 2.0, e),
            THREE.MathUtils.lerp(0.92, 0, e) + hop,
            0
          );
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(-Math.PI / 2, 0, Math.min(1, e * 1.4));
          rig.upperTorsoPivot.rotation.z = 0.14;
          rig.leftKneePivot.rotation.z = -0.55;
          rig.rightKneePivot.rotation.z = -0.45;
          rig.leftArmPivot.rotation.set(0.32, 0, 2.45 * e);
          rig.rightArmPivot.rotation.set(-0.32, 0, 2.45 * e);
          rig.leftElbowPivot.rotation.z = 0.55;
          rig.rightElbowPivot.rotation.z = 0.55;

          subtitle = 'Dinlenme vakti bitti...';
          _camPos.set(wx(4.3), 2.25, az + 2.8);
          _camLook.set(wx(1.2), 1.4, az);
        } else {
          fireOnce('berk_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(2.0), 1.2, az), color: '#60a5fa', count: 26 };
          });
          const settle = easeOutCubic(Math.min(1, (t - 2.2) / 0.6));
          rig.bodyPivot.position.set(2.0, -0.06 * settle, 0);
          rig.upperTorsoPivot.rotation.z = -0.18 * settle;
          rig.leftLegPivot.rotation.set(0.24, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.24, 0, 0.24);
          rig.leftKneePivot.rotation.z = -0.42;
          rig.rightKneePivot.rotation.z = -0.42;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.55);
          rig.rightArmPivot.rotation.set(-0.45, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.45;
          rig.rightElbowPivot.rotation.z = 1.45;

          showAura(settle);
          rig.auraPillars.position.x = 2.0;
          rig.auraRing.position.x = 2.0;
          subtitle = 'Şimdi bu demir savunmadan kimse geçemez!';
          _camPos.set(wx(4.8), 2.05, az + 2.75);
          _camLook.set(wx(2.0), 1.35, az);
        }
        break;
      }

      case 'esref_tek': {
        if (t < 1.35) {
          fireOnce('esref_walk', () => soundEngine.playPhonePickup());
          const p = easeInOutCubic(t / 1.35);
          const stride = Math.sin(p * Math.PI * 2.5);
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(-1.1, 0.25, p), Math.abs(stride) * 0.04, 0);
          rig.upperTorsoPivot.rotation.set(0, -0.18 * p, 0.06);
          rig.leftLegPivot.rotation.z = stride * 0.35;
          rig.rightLegPivot.rotation.z = -stride * 0.35;
          rig.leftKneePivot.rotation.z = -0.25;
          rig.rightKneePivot.rotation.z = -0.25;
          rig.rightArmPivot.rotation.set(0.22, 0, 1.15);
          rig.rightElbowPivot.rotation.z = 1.42;
          rig.leftArmPivot.rotation.set(0.15, 0, -0.22);
          rig.leftElbowPivot.rotation.z = 0.45;

          subtitle = 'Bu sahada kuralı ben koyarım...';
          _camPos.set(wx(3.2), 1.85, az + 2.2);
          _camLook.set(wx(0.15), 1.55, az);
        } else {
          fireOnce('esref_boom', () => {
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(0.3), 1.2, az), color: '#f59e0b', count: 38 };
          });
          const p = easeOutCubic(Math.min(1, (t - 1.35) / 0.55));
          rig.bodyPivot.position.set(0.25, -0.1 * p, 0);
          rig.upperTorsoPivot.rotation.set(0, 0.22, -0.22 * p);
          rig.headGroup.rotation.z = 0.16 * p;
          rig.leftLegPivot.rotation.set(0.22, 0, -0.25);
          rig.rightLegPivot.rotation.set(-0.22, 0, 0.28);
          rig.leftKneePivot.rotation.z = -0.4;
          rig.rightKneePivot.rotation.z = -0.36;
          rig.leftArmPivot.rotation.set(0.68 * p, 0, -0.65 * p);
          rig.rightArmPivot.rotation.set(-0.68 * p, 0, -0.65 * p);
          rig.leftElbowPivot.rotation.z = 0.45;
          rig.rightElbowPivot.rotation.z = 0.45;

          const shockP = clamp01((t - 1.35) / (cs.duration - 1.35));
          props.snapRing.visible = true;
          (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#f59e0b');
          props.snapRing.position.set(0.25, 0.12, 0);
          props.snapRing.scale.setScalar(1 + easeOutCubic(shockP) * 7.5);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.9 - shockP);

          showAura(1.0);
          rig.auraPillars.position.x = 0.25;
          rig.auraRing.position.x = 0.25;
          subtitle = 'Tek başıma yeterim — Eşref Tek sahnede!';
          const shake = Math.sin(t * 40) * 0.04;
          _camPos.set(wx(3.5) + shake, 1.9, az - 2.4);
          _camLook.set(wx(0.25), 1.45, az);
        }
        break;
      }

      case 'arap_kavuncu': {
        props.melon.visible = true;
        if (t < 1.3) {
          fireOnce('kavun_toss', () => soundEngine.playSlide());
          const p = t / 1.3;
          const throwP = clamp01((p - 0.35) / 0.65);
          rig.bodyPivot.position.y = throwP > 0 ? -0.14 * (1 - throwP) : 0;
          rig.upperTorsoPivot.rotation.z = THREE.MathUtils.lerp(-0.18, 0.22, throwP);
          rig.leftArmPivot.rotation.set(0.28, 0, THREE.MathUtils.lerp(0.85, 2.25, throwP));
          rig.rightArmPivot.rotation.set(-0.28, 0, THREE.MathUtils.lerp(0.85, 2.25, throwP));
          rig.leftElbowPivot.rotation.z = 0.55;
          rig.rightElbowPivot.rotation.z = 0.55;
          rig.leftKneePivot.rotation.z = -0.32;
          rig.rightKneePivot.rotation.z = -0.32;

          props.melon.position.set(
            THREE.MathUtils.lerp(0.55, 0.85, throwP),
            THREE.MathUtils.lerp(1.25, 3.35, easeOutCubic(throwP)),
            0
          );
          props.melon.rotation.set(t * 4, t * 6, 0);
          subtitle = 'Çöl rüzgarı arkamda!';
          _camPos.set(wx(3.4), 2.1, az + 2.8);
          _camLook.set(wx(0.5), 1.9, az);
        } else {
          const p = clamp01((t - 1.3) / (cs.duration - 1.3));
          const jumpArc = p < 0.45 ? Math.sin((p / 0.45) * Math.PI) * 1.45 : 0;
          if (p > 0.28) {
            fireOnce('kavun_split', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(0.95);
              spawnBurst = { pos: new THREE.Vector3(wx(0.85), 2.5, az), color: '#fbbf24', count: 40 };
            });
          }
          props.melon.visible = p < 0.3;
          props.melon.position.set(0.85, THREE.MathUtils.lerp(3.35, 2.5, p / 0.3), 0);
          props.melon.rotation.y += dt * 14;

          rig.bodyPivot.position.set(p < 0.45 ? p * 1.0 : 0.45, jumpArc, 0);
          rig.upperTorsoPivot.rotation.set(0, Math.sin(p * Math.PI) * 0.35, -0.22);
          rig.rightArmPivot.rotation.set(-0.2, 0, THREE.MathUtils.lerp(2.4, -0.4, clamp01(p / 0.45)));
          rig.leftArmPivot.rotation.set(0.45, 0, 0.75);
          rig.leftKneePivot.rotation.z = -0.45;
          rig.rightKneePivot.rotation.z = -0.45;

          showAura(1.0);
          rig.auraPillars.position.x = rig.bodyPivot.position.x;
          rig.auraRing.position.x = rig.bodyPivot.position.x;
          subtitle = 'Bu hızda tozuma bile yetişemeyeceksiniz!';
          _camPos.set(wx(3.8), 2.0, az - 2.6);
          _camLook.set(wx(0.5), 1.5, az);
        }
        break;
      }

      case 'hamzac5': {
        props.nitroFlame.visible = true;
        if (t < 1.25) {
          fireOnce('c5_rev', () => soundEngine.playGlitchBeep());
          const vib = Math.sin(t * 36) * 0.03;
          rig.bodyPivot.position.set(-0.65 + vib, -0.24, 0);
          rig.upperTorsoPivot.rotation.z = -0.44;
          rig.headGroup.rotation.z = 0.25;
          rig.leftLegPivot.rotation.set(0.16, 0, -0.55);
          rig.rightLegPivot.rotation.set(-0.16, 0, 0.75);
          rig.leftKneePivot.rotation.z = -0.85;
          rig.rightKneePivot.rotation.z = -1.1;
          rig.leftArmPivot.rotation.set(0.22, 0, -0.55);
          rig.rightArmPivot.rotation.set(-0.22, 0, 0.85);

          props.nitroFlame.position.set(-1.1, 0.85, 0);
          props.nitroFlame.scale.setScalar(0.75 + Math.sin(t * 28) * 0.14);
          props.nitroFlame.rotation.x += dt * 10;

          subtitle = 'Motor devri kökleniyor... 5. vitese hazırlık!';
          _camPos.set(wx(3.0), 1.75, az + 2.6);
          _camLook.set(wx(-0.4), 1.1, az);
        } else {
          fireOnce('c5_nitro', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(1.2), 1.0, az), color: '#a3e635', count: 38 };
          });
          const p = easeOutCubic(clamp01((t - 1.25) / 0.65));
          const xLoc = THREE.MathUtils.lerp(-0.65, 1.55, p);
          rig.bodyPivot.position.set(xLoc, -0.06, 0);
          rig.upperTorsoPivot.rotation.z = -0.28;
          rig.leftLegPivot.rotation.set(0.22, 0, -0.35);
          rig.rightLegPivot.rotation.set(-0.22, 0, 0.42);
          rig.leftKneePivot.rotation.z = -0.45;
          rig.rightKneePivot.rotation.z = -0.4;
          rig.leftArmPivot.rotation.set(0.35, 0, -0.85);
          rig.rightArmPivot.rotation.set(-0.35, 0, -0.85);

          props.nitroFlame.position.set(xLoc - 0.85, 1.05, 0);
          props.nitroFlame.scale.setScalar(1.25 + Math.sin(t * 32) * 0.18);
          props.nitroFlame.rotation.x += dt * 18;

          showAura(1.0);
          rig.auraPillars.position.x = xLoc;
          rig.auraRing.position.x = xLoc;
          subtitle = 'Vites beşe geçti, motor tam güçte! Kimse yakalayamaz!';
          _camPos.set(wx(4.2), 1.95, az + 2.8);
          _camLook.set(wx(1.4), 1.35, az);
        }
        break;
      }

      case 'memud': {
        props.snapRing.visible = true;
        (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#2dd4bf');
        if (t < 1.25) {
          fireOnce('memud_scan', () => soundEngine.playAiHackComplete());
          rig.headGroup.rotation.y = Math.sin(t * 5.2) * 0.42;
          rig.upperTorsoPivot.rotation.z = -0.08;
          rig.rightArmPivot.rotation.set(-0.12, 0, 1.85);
          rig.rightElbowPivot.rotation.z = 0.25;
          rig.leftArmPivot.rotation.set(0.24, 0, -0.2);
          rig.leftKneePivot.rotation.z = -0.18;
          rig.rightKneePivot.rotation.z = -0.15;

          props.snapRing.position.set(0, 0.1, 0);
          props.snapRing.rotation.z += dt * 4;
          props.snapRing.scale.setScalar(1.3 + Math.sin(t * 8) * 0.15);

          subtitle = 'Saha taranıyor... Açılar hesaplandı!';
          _camPos.set(wx(3.3), 2.1, az + 2.4);
          _camLook.set(ax, 1.5, az);
        } else {
          fireOnce('memud_boom', () => {
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.2, az), color: '#2dd4bf', count: 34 };
          });
          const p = clamp01((t - 1.25) / (cs.duration - 1.25));
          const settle = easeOutCubic(Math.min(1, p * 2.5));
          rig.bodyPivot.position.y = -0.06 * settle;
          rig.upperTorsoPivot.rotation.set(0, -0.24, 0.12 * settle);
          rig.leftLegPivot.rotation.set(0.2, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.26);
          rig.leftKneePivot.rotation.z = -0.35;
          rig.rightKneePivot.rotation.z = -0.3;
          rig.rightArmPivot.rotation.set(-0.15, 0, 2.22);
          rig.rightElbowPivot.rotation.z = 0.22;
          rig.leftArmPivot.rotation.set(0.32, 0, -0.36);
          rig.leftElbowPivot.rotation.z = 1.4;

          props.snapRing.position.set(0, 0.12, 0);
          props.snapRing.scale.setScalar(1.4 + easeOutCubic(p) * 5.8);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0.15, 1 - p * 0.7);

          showAura(settle);
          subtitle = 'Hesap tamam, açı net... Sıradaki gol benim!';
          _camPos.set(wx(3.5), 1.95, az - 2.4);
          _camLook.set(ax, 1.45, az);
        }
        break;
      }

      case 'umidi': {
        props.waterGun.visible = true;
        if (t < 1.25) {
          fireOnce('umidi_draw', () => soundEngine.playPhonePickup());
          const p = easeOutCubic(t / 1.25);
          rig.bodyPivot.rotation.y = -0.25 * p;
          rig.upperTorsoPivot.rotation.set(0, 0.22 * p, -0.1 * p);
          rig.leftLegPivot.rotation.set(0.16, 0, -0.22);
          rig.rightLegPivot.rotation.set(-0.16, 0, 0.24);
          rig.leftKneePivot.rotation.z = -0.34;
          rig.rightKneePivot.rotation.z = -0.3;
          rig.rightArmPivot.rotation.set(-0.12, 0, THREE.MathUtils.lerp(0.45, 1.48, p));
          rig.rightElbowPivot.rotation.z = THREE.MathUtils.lerp(0.85, 0.22, p);
          rig.leftArmPivot.rotation.set(0.32, 0, 0.45);
          rig.leftElbowPivot.rotation.z = 0.95;

          props.waterGun.position.set(0.75 * p + 0.15, 1.42, 0.34);
          props.waterGun.rotation.set(0, 0, 0.05);
          props.waterStream.visible = false;

          subtitle = 'Ümidi eline su tabancasını aldı...';
          _camPos.set(wx(3.4), 1.95, az + 2.5);
          _camLook.set(wx(0.4), 1.45, az);
        } else {
          fireOnce('umidi_squirt', () => {
            soundEngine.playWaterSquirt();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(1.8), 1.45, az), color: '#38bdf8', count: 36 };
          });
          const p = clamp01((t - 1.25) / (cs.duration - 1.25));
          const recoil = Math.sin(t * 24) * 0.06;
          rig.bodyPivot.position.set(-0.18 + recoil * 0.5, -0.06, 0);
          rig.upperTorsoPivot.rotation.set(0, 0.14, 0.08 + recoil);
          rig.leftLegPivot.rotation.set(0.2, 0, -0.26);
          rig.rightLegPivot.rotation.set(-0.2, 0, 0.32);
          rig.leftKneePivot.rotation.z = -0.4;
          rig.rightKneePivot.rotation.z = -0.35;
          rig.rightArmPivot.rotation.set(-0.08, 0, 1.54 + recoil);
          rig.rightElbowPivot.rotation.z = 0.14;
          rig.leftArmPivot.rotation.set(0.28, 0, 1.25);
          rig.leftElbowPivot.rotation.z = 0.72;

          props.waterGun.position.set(0.82 + recoil * 0.4, 1.5, 0.32);
          props.waterStream.visible = true;
          props.waterStream.position.set(1.18 + recoil * 0.4, 1.52, 0.32);
          props.waterStream.scale.set(0.85 + Math.min(0.8, p * 1.4), 1 + Math.sin(t * 28) * 0.15, 1);

          showAura(1.0);
          subtitle = 'Lan... YouTube kanalımızı çaldın ve eline ne geçti lan!';
          _camPos.set(wx(3.9), 2.05, az - 2.4);
          _camLook.set(wx(0.9), 1.48, az);
        }
        break;
      }
    }
  } else if (cs.kind === 'COMBO') {
    // ================= MUSAB x MUSA UZAK MESAFE KOMBİNE PAS & GÖKYÜZÜ ROVEŞATA =================
    const musabRig = rig;
    const musaRig = partnerRig ?? rig;
    const centerX = THREE.MathUtils.clamp(ax, -PITCH_HALF_LENGTH + 20, PITCH_HALF_LENGTH - 20);
    const centerZ = THREE.MathUtils.clamp(az, -22, 22);
    const musabStartX = centerX - dir * 11.5;
    const musabStartZ = centerZ - 4.4;
    const musaX = centerX + dir * 9.5;
    const musaZ = centerZ + 3.2;

    musabRig.root.position.set(musabStartX, 0, musabStartZ);
    musabRig.root.rotation.set(0, rotY + (dir === 1 ? -0.34 : 0.34), 0);
    if (musaRig !== musabRig) {
      musaRig.root.position.set(musaX, 0, musaZ);
      musaRig.root.rotation.set(0, rotY + (dir === 1 ? 0.14 : -0.14), 0);
    }

    if (t < 1.55) {
      fireOnce('combo_launch', () => {
        soundEngine.playAwakeningBoom();
        spawnBurst = { pos: new THREE.Vector3(musabStartX + dir * 0.8, 1.0, musabStartZ), color: '#facc15', count: 32 };
      });
      if (t > 0.35) {
        fireOnce('combo_pass_kick', () => soundEngine.playKick(0.82));
      }
      const p = easeOutCubic(t / 1.55);
      const kickP = easeOutCubic(clamp01((t - 0.15) / 0.55));
      const runMusa = clamp01(t / 1.15);
      const leapMusa = easeOutCubic(clamp01((t - 0.9) / 0.65));

      musabRig.bodyPivot.position.set(p * 1.4, Math.sin(kickP * Math.PI) * 0.45, 0);
      musabRig.bodyPivot.rotation.set(0, -0.25 * kickP, -0.18 * kickP);
      musabRig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.3, -0.45, kickP), -0.16);
      musabRig.leftKneePivot.rotation.z = -0.38;
      musabRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.75, 1.52, kickP);
      musabRig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.1, -0.12, kickP);
      musabRig.leftArmPivot.rotation.set(0.45, 0, 1.05);
      musabRig.rightArmPivot.rotation.set(-0.45, 0, -0.55);

      if (musaRig !== musabRig) {
        const stride = Math.sin(t * 14);
        musaRig.bodyPivot.position.set(THREE.MathUtils.lerp(-4.5, 0, runMusa), leapMusa * 2.85, 0);
        musaRig.bodyPivot.rotation.z = leapMusa * 0.35;
        musaRig.upperTorsoPivot.rotation.z = -0.2;
        musaRig.leftLegPivot.rotation.z = (1 - leapMusa) * stride * 0.72;
        musaRig.rightLegPivot.rotation.z = (1 - leapMusa) * -stride * 0.72;
        musaRig.leftKneePivot.rotation.z = -0.55 - leapMusa * 0.55;
        musaRig.rightKneePivot.rotation.z = -0.55 - leapMusa * 0.45;
        musaRig.leftArmPivot.rotation.set(0.4, 0, 0.85);
        musaRig.rightArmPivot.rotation.set(-0.4, 0, 0.85);
      }

      const passArc = easeInOutCubic(clamp01((t - 0.25) / 1.3));
      const bx = THREE.MathUtils.lerp(musabStartX + dir * 1.0, musaX + dir * 0.45, passArc);
      const bz = THREE.MathUtils.lerp(musabStartZ + 0.3, musaZ, passArc);
      const by = THREE.MathUtils.lerp(0.65, 3.65, passArc) + Math.sin(passArc * Math.PI) * 1.35;
      ballGroup.position.set(bx, by, bz);
      ballGroup.rotation.y += dt * 18;

      showAuraOn(musabRig, 0.9);
      if (musaRig !== musabRig) showAuraOn(musaRig, 0.95);

      subtitle = 'Musab: Musa, sol kanattan uç — top havada!';
      _camPos.set(bx - dir * 4.8, Math.max(2.6, by + 0.6), bz + 7.2);
      _camLook.set(bx + dir * 1.4, Math.max(1.8, by * 0.82), bz);
    } else if (t < 2.8) {
      fireOnce('combo_sync', () => {
        soundEngine.playAwakenedImpact();
        spawnBurst = { pos: new THREE.Vector3(musaX + dir * 0.45, 3.65, musaZ), color: '#38bdf8', count: 36 };
      });
      const p = easeInOutCubic((t - 1.55) / 1.25);

      musabRig.bodyPivot.position.set(1.4 + p * 2.2, Math.abs(Math.sin(t * 10)) * 0.14, 0);
      musabRig.leftKneePivot.rotation.z = -0.32;
      musabRig.rightKneePivot.rotation.z = -0.32;
      musabRig.leftArmPivot.rotation.set(0.35, 0, 2.35);
      musabRig.rightArmPivot.rotation.set(-0.35, 0, 2.35);

      if (musaRig !== musabRig) {
        musaRig.bodyPivot.position.set(0, 2.85, 0);
        musaRig.bodyPivot.rotation.z = THREE.MathUtils.lerp(0.35, Math.PI * 0.62, p);
        musaRig.upperTorsoPivot.rotation.set(0, -0.22 * p, 0.18);
        musaRig.leftLegPivot.rotation.z = THREE.MathUtils.lerp(0.2, 0.45, p);
        musaRig.leftKneePivot.rotation.z = -1.05;
        musaRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(0.1, -0.45, p);
        musaRig.rightKneePivot.rotation.z = -1.05;
        musaRig.leftArmPivot.rotation.set(0.6, 0, 0.55);
        musaRig.rightArmPivot.rotation.set(-0.6, 0, 0.55);
      }

      ballGroup.position.set(musaX + dir * 0.45, 3.65, musaZ);
      ballGroup.rotation.y += dt * 24;
      props.snapRing.visible = true;
      props.snapRing.position.set((musaX - ax) * dir + 0.45, 3.65, musaZ - az);
      props.snapRing.rotation.set(0, 0, t * 4);
      props.snapRing.scale.setScalar(1.05 + Math.sin(t * 14) * 0.14);

      showAuraOn(musabRig, 1.0);
      if (musaRig !== musabRig) showAuraOn(musaRig, 1.0);
      subtitle = 'Musa: Pasını aldım Musab — arka direkte bitiriyorum!';
      _camPos.set(musaX - dir * 1.4, 3.25, musaZ + 7.4);
      _camLook.set(musaX + dir * 0.1, 2.75, musaZ);
    } else {
      props.snapRing.visible = false;
      const p = clamp01((t - 2.8) / (cs.duration - 2.8));
      const whip = easeOutCubic(Math.min(1, p / 0.5));

      musabRig.bodyPivot.position.set(3.6, Math.abs(Math.sin(t * 10)) * 0.1, 0);
      musabRig.leftArmPivot.rotation.set(0.35, 0, 2.5);
      musabRig.rightArmPivot.rotation.set(-0.35, 0, 2.5);

      if (musaRig !== musabRig) {
        musaRig.bodyPivot.position.set(0, 2.85 - p * 0.2, 0);
        musaRig.bodyPivot.rotation.z = Math.PI * 0.62 + whip * 0.12;
        musaRig.upperTorsoPivot.rotation.set(0, -0.3, 0.18);
        musaRig.leftLegPivot.rotation.z = 0.28;
        musaRig.leftKneePivot.rotation.z = -1.1;
        musaRig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.45, 0.98, whip);
        musaRig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.05, -0.1, whip);
        musaRig.leftArmPivot.rotation.set(0.75, 0, -0.35);
        musaRig.rightArmPivot.rotation.set(-0.75, 0, -0.35);

        getCleatWorldPos(musaRig, 'right', _cleatPos, 0.22, -0.46);
      } else {
        _cleatPos.set(musaX + dir * 0.45, 3.65, musaZ);
      }

      if (p < 0.48) {
        const approach = clamp01(p / 0.48);
        ballGroup.position.set(
          THREE.MathUtils.lerp(musaX + dir * 0.45, _cleatPos.x, approach),
          THREE.MathUtils.lerp(3.65, _cleatPos.y, approach),
          THREE.MathUtils.lerp(musaZ, _cleatPos.z, approach)
        );
      } else {
        fireOnce('combo_rovesata_boom', () => {
          soundEngine.playAwakeningBoom();
          soundEngine.playKick(1.0);
          spawnBurst = { pos: _cleatPos.clone(), color: '#facc15', count: 44 };
        });
        const fly = easeOutCubic((p - 0.48) / 0.52);
        ballGroup.position.set(_cleatPos.x + dir * fly * 22, _cleatPos.y + fly * 1.4, _cleatPos.z);
      }
      ballGroup.rotation.y += dt * 34;

      showAuraOn(musabRig, 1.0);
      if (musaRig !== musabRig) showAuraOn(musaRig, 1.0);
      subtitle = 'MUSAB × MUSA: İKİZ GÖKYÜZÜ ROVEŞATASI!';
      _camPos.set(musaX - dir * 4.8, 3.6, musaZ + 6.8);
      _camLook.set(musaX + dir * 2.2, 3.1, musaZ);

      if (t >= cs.duration - 0.05) {
        launchShot = {
          from: new THREE.Vector3(musaX + dir * 1.2, 3.6, musaZ),
          range: 'FULL_PITCH',
          curve: 0,
          speed: 78,
          loft: 4.2,
          stealAndTeleportPos: new THREE.Vector3(musaX, 0, musaZ),
        };
      }
    }
  } else {
    // ================= ULTI CUTSCENES =================
    switch (cs.styleId) {
      case 'musab': {
        props.desk.visible = true;
        props.desk.position.set(2.2, 0, 0);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.bluelock_game;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.35) {
          fireOnce('musab_bounce', () => soundEngine.playKick(0.35));
          if (t > 0.65) fireOnce('musab_bounce2', () => soundEngine.playKick(0.35));
          const bounce = Math.abs(Math.sin(t * 10)) * 0.7;
          ballGroup.position.set(ax, 2.85 + bounce, az);
          rig.headGroup.rotation.z = Math.sin(t * 10) * 0.16;
          rig.leftKneePivot.rotation.z = -0.18;
          rig.rightKneePivot.rotation.z = -0.18;
          rig.leftArmPivot.rotation.set(0.32, 0, 0.35);
          rig.rightArmPivot.rotation.set(-0.32, 0, 0.35);
          rig.leftElbowPivot.rotation.z = 1.1;
          rig.rightElbowPivot.rotation.z = 1.1;
          subtitle = 'Monitör başında ritmini yakalıyor...';
          _camPos.set(wx(-2.8), 2.8, az + 3.8);
          _camLook.set(wx(1.5), 2.0, az);
        } else if (t < 2.65) {
          fireOnce('monster', () => {
            soundEngine.playHorrorMonitorBurst();
            spawnBurst = { pos: new THREE.Vector3(wx(2.1), 2.0, az), color: '#a855f7', count: 32 };
          });
          const p = easeOutCubic((t - 1.35) / 1.3);
          props.monsterBall.visible = true;
          props.monsterBall.position.set(
            THREE.MathUtils.lerp(2.0, 0.45, p),
            THREE.MathUtils.lerp(2.05, 3.2, p),
            0
          );
          props.monsterBall.scale.setScalar(0.8 + p * 0.75);
          props.monsterBall.rotation.y += dt * 10;
          ballGroup.position.set(wx(props.monsterBall.position.x), props.monsterBall.position.y, az);
          rig.upperTorsoPivot.rotation.z = 0.18 * p;
          rig.headGroup.rotation.z = 0.42 * p;
          rig.leftKneePivot.rotation.z = -0.35 * p;
          rig.rightKneePivot.rotation.z = -0.35 * p;
          showAura(p);
          subtitle = 'Monitörden fırlayan saf enerji topu sahaya indi!';
          _camPos.set(wx(4.8), 2.4, az + 4.0);
          _camLook.set(wx(0.5), 2.5, az);
        } else {
          fireOnce('headset_off', () => {
            if (rig.headsetProp) rig.headsetProp.visible = false;
            props.deskHeadset.visible = true;
            soundEngine.playDeskThud();
            soundEngine.playAwakeningBoom();
          });
          props.monsterBall.visible = false;
          const p = clamp01((t - 2.65) / (cs.duration - 2.65));
          const leap = easeOutCubic(Math.min(1, p * 1.65));
          const strike = easeOutCubic(clamp01((p - 0.2) / 0.42));
          rig.bodyPivot.position.y = leap * 2.55;
          rig.bodyPivot.rotation.z = leap * Math.PI * 0.36;
          rig.upperTorsoPivot.rotation.set(0, -0.38 * strike, -0.18);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.65, 1.45, strike);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.15, -0.06, strike);
          rig.leftLegPivot.rotation.z = -0.32;
          rig.leftKneePivot.rotation.z = -0.92;
          rig.leftArmPivot.rotation.set(0.45, 0, 1.05);
          rig.rightArmPivot.rotation.set(-0.35, 0, -0.55);
          rig.leftElbowPivot.rotation.z = 0.75;
          rig.rightElbowPivot.rotation.z = 0.75;
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (p < 0.56) {
            const blend = clamp01(p / 0.56);
            ballGroup.position.set(
              THREE.MathUtils.lerp(wx(0.45), _cleatPos.x, blend),
              THREE.MathUtils.lerp(3.2, _cleatPos.y, blend),
              THREE.MathUtils.lerp(az, _cleatPos.z, blend)
            );
          } else {
            fireOnce('musab_kick', () => {
              soundEngine.playKick(1.0);
              spawnBurst = { pos: _cleatPos.clone(), color: '#facc15', count: 36 };
            });
            const fly = easeOutCubic((p - 0.56) / 0.44);
            ballGroup.position.set(_cleatPos.x + dir * fly * 22, _cleatPos.y + fly * 1.2, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 24;
          subtitle = 'Kulaklığı bıraktı — Kaleden kaleye durdurulamaz vole!';
          _camPos.set(wx(-4.2), 3.4, az + 6.4);
          _camLook.set(wx(1.2), 2.7, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.2), 3.3, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 76,
              loft: 4.6,
            };
          }
        }
        break;
      }

      case 'musa': {
        if (t < 1.45) {
          props.pillow.visible = true;
          props.pillow.position.set(1.2, 0.2, 0);
          const runP = t / 1.45;
          rig.bodyPivot.position.x = THREE.MathUtils.lerp(-0.9, 0.35, easeInOutCubic(runP));
          const stride = Math.sin(runP * Math.PI * 3.5);
          rig.leftLegPivot.rotation.z = stride * 0.75;
          rig.rightLegPivot.rotation.z = -stride * 0.75;
          rig.leftKneePivot.rotation.z = -0.65;
          rig.rightKneePivot.rotation.z = -0.85;
          rig.upperTorsoPivot.rotation.z = -0.26;
          rig.leftArmPivot.rotation.set(0.15, 0, -stride * 0.65);
          rig.rightArmPivot.rotation.set(-0.15, 0, stride * 0.65);
          rig.leftElbowPivot.rotation.z = 1.05;
          rig.rightElbowPivot.rotation.z = 1.05;
          ballGroup.position.set(wx(1.2), -5, az);
          subtitle = 'Musa tam güçle vuruş açısına hazırlanıyor...';
          _camPos.set(wx(3.8), 1.8, az + 3.4);
          _camLook.set(wx(0.8), 0.9, az);
        } else {
          const kP = clamp01((t - 1.45) / (cs.duration - 1.45));
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.38));
          if (kP > 0.26) {
            fireOnce('pillow_transform', () => {
              soundEngine.playPillowTransform();
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(wx(1.25), 0.7, az), color: '#38bdf8', count: 36 };
            });
          }
          props.pillow.visible = kP < 0.28;
          props.pillow.position.set(1.2, 0.2, 0);

          rig.bodyPivot.position.x = 0.35 + kickP * 0.25;
          rig.bodyPivot.rotation.z = THREE.MathUtils.lerp(0.08, -0.28, kickP);
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.28, -0.45, kickP), -0.18);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.92, windP) : THREE.MathUtils.lerp(-0.92, 1.48, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.2, -1.2, windP) : THREE.MathUtils.lerp(-1.2, -0.12, kickP);
          rig.leftLegPivot.rotation.z = -0.28;
          rig.leftKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.35, 0, THREE.MathUtils.lerp(-0.4, 0.95, kickP));
          rig.leftElbowPivot.rotation.z = 0.9;
          rig.rightArmPivot.rotation.set(-0.25, 0, -0.55);
          showAura(Math.max(0.4, kickP));

          if (kP < 0.28) {
            ballGroup.position.set(wx(1.35), -5, az);
          } else if (kP < 0.56) {
            ballGroup.position.set(wx(1.35), 0.56, az);
          } else {
            const fly = easeOutCubic((kP - 0.56) / 0.44);
            ballGroup.position.set(wx(1.35 + fly * 22), 0.56 + fly * 1.4, az);
          }
          subtitle = 'Sonik hızda ateşle — Kaleden kaleye füze!';
          _camPos.set(wx(-2.8), 1.9, az + 3.6);
          _camLook.set(wx(5.0), 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.4), 0.68, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 76,
              loft: 4.4,
            };
          }
        }
        break;
      }

      case 'iskender': {
        if (t < 1.4) {
          fireOnce('isk_ulti_say', () => soundEngine.playPhonePickup());
          props.phone.visible = true;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.videocall_musa;
          (props.phoneScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;
          props.phone.position.set(1.6, 0.2, 0.72);
          props.phone.rotation.set(0, -0.25, -1.2);

          const p = easeOutCubic(t / 1.4);
          rig.bodyPivot.position.y = p * 2.85;
          rig.bodyPivot.rotation.z = p * Math.PI * 0.62;
          rig.upperTorsoPivot.rotation.z = 0.18 * p;
          rig.leftKneePivot.rotation.z = -1.0 * p;
          rig.rightLegPivot.rotation.z = -0.4 * p;
          rig.rightKneePivot.rotation.z = -1.0 * p;
          rig.leftArmPivot.rotation.set(0.55, 0, 0.75);
          rig.rightArmPivot.rotation.set(-0.55, 0, 0.75);
          ballGroup.position.set(ax, -5, az);
          subtitle = 'Söz bitti, şimdi sahne benim...';
          _camPos.set(wx(4.4), 2.8, az + 5.6);
          _camLook.set(ax, 2.3, az);
        } else {
          fireOnce('isk_tp', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
          });
          props.phone.visible = false;
          const p = clamp01((t - 1.4) / (cs.duration - 1.4));
          const whip = easeOutCubic(clamp01(p / 0.52));
          rig.bodyPivot.position.y = 2.85;
          rig.bodyPivot.rotation.z = Math.PI * 0.62 + whip * 0.12;
          rig.upperTorsoPivot.rotation.set(0, -0.25 * whip, 0.18);
          rig.leftLegPivot.rotation.z = 0.22;
          rig.leftKneePivot.rotation.z = -1.1;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.4, 0.96, whip);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.0, -0.08, whip);
          rig.leftArmPivot.rotation.set(0.65, 0, 0.2);
          rig.rightArmPivot.rotation.set(-0.65, 0, 0.2);
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (p < 0.5) {
            ballGroup.position.copy(_cleatPos);
          } else {
            fireOnce('isk_kick', () => {
              soundEngine.playKick(1.0);
              spawnBurst = { pos: _cleatPos.clone(), color: '#2dd4bf', count: 36 };
            });
            const fly = easeOutCubic((p - 0.5) / 0.5);
            ballGroup.position.set(_cleatPos.x + dir * fly * 22, _cleatPos.y + fly * 1.2, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 26;
          subtitle = 'Boyut yaran ışınlanma rovaşatası!';
          _camPos.set(wx(-4.2), 3.4, az + 6.4);
          _camLook.set(wx(1.4), 2.75, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.1), 3.5, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 74,
              loft: 4.5,
            };
          }
        }
        break;
      }

      case 'aras': {
        props.coach.visible = true;
        props.coach.position.set(-2.2, 0, -1.8);
        props.coach.rotation.y = -0.4;
        props.hamburger.visible = false;

        if (t < 1.35) {
          fireOnce('aras_coach', () => soundEngine.playWhistle());
          const p = t / 1.35;
          rig.bodyPivot.position.y = -0.18;
          rig.upperTorsoPivot.rotation.z = -0.25;
          rig.leftLegPivot.rotation.set(0.16, 0, -0.35);
          rig.rightLegPivot.rotation.set(-0.16, 0, 0.35);
          rig.leftKneePivot.rotation.z = -0.45;
          rig.rightKneePivot.rotation.z = -0.45;
          rig.leftArmPivot.rotation.set(0.35, 0, -0.45);
          rig.rightArmPivot.rotation.set(-0.35, 0, -0.45);
          ballGroup.position.set(wx(2.8), 0.36 + p * 0.25, az);
          subtitle = 'Tam güç yükleniyor — Topa kilitlendi!';
          _camPos.set(wx(4.5), 2.2, az + 4.2);
          _camLook.set(wx(0.5), 1.1, az);
        } else {
          const kP = clamp01((t - 1.35) / (cs.duration - 1.35));
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.42));
          if (kP > 0.24) {
            fireOnce('burger_tp', () => {
              soundEngine.playTeleportWhoosh();
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(wx(2.4), 0.8, az), color: '#ef4444', count: 34 };
            });
          }
          rig.bodyPivot.position.set(1.9 + kickP * 0.22, Math.sin(kP * Math.PI) * 0.3, 0);
          rig.bodyPivot.rotation.z = -0.25 * kickP;
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.25, -0.45, kickP), -0.2);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.85, windP) : THREE.MathUtils.lerp(-0.85, 1.5, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.25, -1.15, windP) : THREE.MathUtils.lerp(-1.15, -0.1, kickP);
          rig.leftKneePivot.rotation.z = -0.38;
          rig.leftArmPivot.rotation.set(0.4, 0, 0.9);
          rig.rightArmPivot.rotation.set(-0.2, 0, -0.6);
          showAura(1.0);
          rig.auraPillars.position.x = rig.bodyPivot.position.x;
          rig.auraRing.position.x = rig.bodyPivot.position.x;
          if (kP < 0.56) {
            ballGroup.position.set(wx(2.8), 0.58, az);
          } else {
            const fly = easeOutCubic((kP - 0.56) / 0.44);
            ballGroup.position.set(wx(2.8 + fly * 22), 0.58 + fly * 1.4, az);
          }
          subtitle = 'Topun yanına ışınlandı — Kaleden kaleye alev füzesi!';
          _camPos.set(wx(-1.5), 2.2, az + 4.2);
          _camLook.set(wx(3.5), 1.2, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(2.8), 0.6, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 70,
              loft: 4.5,
            };
          }
        }
        break;
      }

      case 'ebulfez': {
        const targetPos = cs.opponentPos.clone();
        if (t < 1.25) {
          fireOnce('ebu_snap', () => {
            soundEngine.playThanosSnap();
            spawnBurst = { pos: new THREE.Vector3(ax, 1.4, az), color: '#facc15', count: 28 };
          });
          const p = easeOutCubic(t / 1.25);
          rig.rightArmPivot.rotation.set(0.25, 0, 1.5 * p);
          rig.rightElbowPivot.rotation.z = 0.85;
          props.snapRing.visible = true;
          props.snapRing.position.set(0, 1.3, 0);
          props.snapRing.scale.setScalar(1 + p * 4.5);
          subtitle = 'Geri döndüm — Zaman benim elimde!';
          _camPos.set(wx(3.5), 2.2, az + 3.2);
          _camLook.set(ax, 1.4, az);
        } else {
          fireOnce('ebu_leap', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            soundEngine.playKick(0.95);
            spawnBurst = { pos: targetPos.clone().setY(1.8), color: '#e879f9', count: 32 };
          });
          props.snapRing.visible = false;
          rig.root.position.set(targetPos.x, 0, targetPos.z);
          props.root.position.set(targetPos.x, 0, targetPos.z);
          const p = clamp01((t - 1.25) / (cs.duration - 1.25));
          const flipP = easeInOutCubic(Math.min(1, p * 1.1));
          const strikeP = easeOutCubic(clamp01((p - 0.35) / 0.38));
          rig.bodyPivot.position.set(flipP * 1.4 - 0.55, Math.sin(flipP * Math.PI * 0.85) * 2.1, 0);
          rig.bodyPivot.rotation.z = flipP * Math.PI * 0.32;
          rig.leftKneePivot.rotation.z = -1.0;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.4, 1.45, strikeP);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.9, -0.15, strikeP);
          rig.leftArmPivot.rotation.set(0.35, 0, 1.1);
          rig.rightArmPivot.rotation.set(-0.35, 0, 1.1);
          showAura(1.0);
          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (p < 0.62) {
            const liftP = easeOutCubic(Math.min(1, p * 2.4));
            ballGroup.position.set(
              THREE.MathUtils.lerp(targetPos.x + dir * 1.0, _cleatPos.x, liftP),
              THREE.MathUtils.lerp(1.2, _cleatPos.y, liftP),
              THREE.MathUtils.lerp(targetPos.z, _cleatPos.z, liftP)
            );
          } else {
            const fly = easeOutCubic((p - 0.62) / 0.38);
            ballGroup.position.set(_cleatPos.x + dir * fly * 20, _cleatPos.y + fly * 1.1, _cleatPos.z);
          }
          subtitle = 'Topu havada yakalayıp kaleye gönderiyor!';
          _camPos.set(targetPos.x - dir * 3.6, 3.0, targetPos.z + 4.4);
          _camLook.set(targetPos.x + dir * 1.0, 2.1, targetPos.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(targetPos.x + dir * 1.2, 2.35, targetPos.z),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 68,
              loft: 4.5,
              stealAndTeleportPos: new THREE.Vector3(targetPos.x + dir * 1.0, 0, targetPos.z),
            };
          }
        }
        break;
      }

      case 'zero': {
        props.desk.visible = true;
        props.desk.position.set(-1.6, 0, -1.4);
        (props.monitorScreen.material as THREE.MeshBasicMaterial).map = props.screenTextures.ai_cheat;
        (props.monitorScreen.material as THREE.MeshBasicMaterial).needsUpdate = true;

        if (t < 1.55) {
          fireOnce('zero_ai', () => soundEngine.playAiHackComplete());
          const p = t / 1.55;
          ballGroup.position.set(wx(1.1), 1.3 + Math.sin(p * 12) * 0.14, az);
          rig.upperTorsoPivot.rotation.z = 0.08;
          rig.rightArmPivot.rotation.set(0.2, 0, 1.55);
          rig.rightElbowPivot.rotation.z = 0.45;
          rig.leftKneePivot.rotation.z = -0.25;
          rig.rightKneePivot.rotation.z = -0.25;
          subtitle = 'Hedef açısı ve falso yörüngesi kilitlendi...';
          _camPos.set(wx(3.6), 2.2, az + 3.4);
          _camLook.set(wx(0.8), 1.4, az);
        } else {
          const kP = clamp01((t - 1.55) / (cs.duration - 1.55));
          const windP = clamp01(kP / 0.25);
          const kickP = easeOutCubic(clamp01((kP - 0.22) / 0.42));
          if (kP > 0.24) {
            fireOnce('zero_kick', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(0.95);
              spawnBurst = { pos: new THREE.Vector3(wx(1.15), 1.3, az), color: '#22d3ee', count: 28 };
            });
          }
          rig.rightLegPivot.rotation.z =
            kP < 0.22 ? THREE.MathUtils.lerp(0, -0.82, windP) : THREE.MathUtils.lerp(-0.82, 1.58, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.22 ? THREE.MathUtils.lerp(-0.2, -1.05, windP) : THREE.MathUtils.lerp(-1.05, -0.1, kickP);
          rig.leftKneePivot.rotation.z = -0.32;
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.2, -0.45, kickP), -0.22);
          rig.leftArmPivot.rotation.set(0.45, 0, 0.9);
          showAura(1.0);
          if (kP < 0.56) {
            ballGroup.position.set(wx(1.25), 1.3, az);
          } else {
            const fly = easeOutCubic((kP - 0.56) / 0.44);
            ballGroup.position.set(wx(1.25 + fly * 20), 1.3 + fly * 1.2, az);
          }
          subtitle = 'Kusursuz falsolu yörünge — doğrudan doksana!';
          _camPos.set(wx(-3.2), 2.4, az + 3.8);
          _camLook.set(wx(4.0), 1.2, az);

          if (t >= cs.duration - 0.05) {
            const distFromGoal = Math.abs(dir * PITCH_HALF_LENGTH - ax);
            launchShot = {
              from: new THREE.Vector3(wx(1.2), 1.3, az),
              range: 'MIDFIELD',
              curve: 0,
              speed: distFromGoal <= PITCH_HALF_LENGTH + 18 ? 62 : 52,
              loft: 4.0,
            };
          }
        }
        break;
      }

      case 'berk': {
        const clampedOppX =
          dir === 1
            ? Math.max(-4, Math.min(PITCH_HALF_LENGTH - 12, cs.opponentPos.x))
            : Math.min(4, Math.max(-PITCH_HALF_LENGTH + 12, cs.opponentPos.x));
        const stealOrigin = new THREE.Vector3(clampedOppX, 0, cs.opponentPos.z);
        if (t < 1.35) {
          fireOnce('berk_steal', () => {
            soundEngine.playKick(0.7);
            spawnBurst = { pos: stealOrigin.clone().setY(1.0), color: '#60a5fa', count: 22 };
          });
          const p = easeOutCubic(t / 1.35);
          rig.root.position.copy(stealOrigin);
          rig.bodyPivot.rotation.z = -0.2 * p;
          rig.upperTorsoPivot.rotation.z = -0.22 * p;
          rig.leftKneePivot.rotation.z = -0.42;
          rig.rightKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.4, 0, 0.55);
          rig.rightArmPivot.rotation.set(-0.4, 0, 0.55);
          rig.leftElbowPivot.rotation.z = 1.25;
          rig.rightElbowPivot.rotation.z = 1.25;
          ballGroup.position.set(stealOrigin.x + dir * 1.0, 0.36, stealOrigin.z);
          subtitle = 'Berk gövde gücüyle topu söktü!';
          _camPos.set(stealOrigin.x - dir * 3.4, 2.3, stealOrigin.z + 3.6);
          _camLook.set(stealOrigin.x + dir * 0.8, 1.2, stealOrigin.z);
        } else {
          const kP = clamp01((t - 1.35) / (cs.duration - 1.35));
          const windP = clamp01(kP / 0.28);
          const kickP = easeOutCubic(clamp01((kP - 0.25) / 0.42));
          if (kP > 0.24) {
            fireOnce('berk_shoot', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(0.95);
            });
          }
          rig.root.position.copy(stealOrigin);
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.22, -0.42, kickP), -0.24);
          rig.rightLegPivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(0, -0.88, windP) : THREE.MathUtils.lerp(-0.88, 1.48, kickP);
          rig.rightKneePivot.rotation.z =
            kP < 0.25 ? THREE.MathUtils.lerp(-0.2, -1.12, windP) : THREE.MathUtils.lerp(-1.12, -0.12, kickP);
          rig.leftKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.45, 0, 0.95);
          showAura(1.0);
          if (kP < 0.56) {
            ballGroup.position.set(stealOrigin.x + dir * 1.2, 0.55, stealOrigin.z);
          } else {
            const fly = easeOutCubic((kP - 0.56) / 0.44);
            ballGroup.position.set(stealOrigin.x + dir * (1.2 + fly * 20), 0.55 + fly * 1.1, stealOrigin.z);
          }
          subtitle = 'Orta sahadan gök gürültüsü gibi demir şut!';
          _camPos.set(stealOrigin.x - dir * 3.0, 2.1, stealOrigin.z + 3.4);
          _camLook.set(stealOrigin.x + dir * 4.0, 1.2, stealOrigin.z);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(stealOrigin.x + dir * 1.2, 0.55, stealOrigin.z),
              range: 'MIDFIELD',
              curve: 0,
              speed: 62,
              loft: 4.0,
              stealAndTeleportPos: stealOrigin.clone(),
            };
          }
        }
        break;
      }

      case 'esref_tek': {
        if (t < 1.35) {
          fireOnce('esref_flick', () => soundEngine.playKick(0.55));
          const p = easeOutCubic(t / 1.35);
          rig.bodyPivot.position.y = Math.sin(p * Math.PI) * 0.2;
          rig.rightLegPivot.rotation.z = Math.sin(p * Math.PI) * 0.72;
          rig.rightKneePivot.rotation.z = -0.5;
          rig.leftKneePivot.rotation.z = -0.25;
          rig.upperTorsoPivot.rotation.z = -0.15;
          ballGroup.position.set(wx(0.75), 0.36 + easeOutCubic(p) * 2.25, az);
          subtitle = 'Eşref Tek topu havalandırdı...';
          _camPos.set(wx(3.4), 2.1, az + 3.0);
          _camLook.set(wx(0.7), 1.5, az);
        } else {
          const kP = clamp01((t - 1.35) / (cs.duration - 1.35));
          const leap = easeOutCubic(Math.min(1, kP / 0.45));
          const strike = easeOutCubic(clamp01((kP - 0.25) / 0.35));
          rig.bodyPivot.position.set(leap * 0.4, Math.sin(Math.min(1, kP / 0.85) * Math.PI) * 1.85, 0);
          rig.bodyPivot.rotation.set(0, leap * Math.PI * 2, 0.24);
          rig.upperTorsoPivot.rotation.set(0, -0.35 * strike, -0.2);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.45, 1.52, strike);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.05, -0.08, strike);
          rig.leftKneePivot.rotation.z = -0.75;
          rig.leftArmPivot.rotation.set(0.4, 0, 0.8);
          rig.rightArmPivot.rotation.set(-0.4, 0, -0.5);
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (kP < 0.52) {
            const b = clamp01(kP / 0.52);
            ballGroup.position.set(
              THREE.MathUtils.lerp(wx(0.75), _cleatPos.x, b),
              THREE.MathUtils.lerp(2.61, _cleatPos.y, b),
              THREE.MathUtils.lerp(az, _cleatPos.z, b)
            );
          } else {
            fireOnce('esref_ulti_boom', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: _cleatPos.clone(), color: '#f59e0b', count: 38 };
            });
            const fly = easeOutCubic((kP - 0.52) / 0.48);
            ballGroup.position.set(_cleatPos.x + dir * fly * 22, _cleatPos.y + fly * 1.1, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 28;
          subtitle = 'Tek tabanca yıldırım vole — kaleden kaleye!';
          _camPos.set(wx(-3.8), 2.8, az + 4.8);
          _camLook.set(wx(2.0), 2.0, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.1), 2.2, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 74,
              loft: 4.3,
            };
          }
        }
        break;
      }

      case 'arap_kavuncu': {
        props.melon.visible = t < 1.75;
        props.snapRing.visible = t < 1.75;
        (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#fbbf24');
        if (t < 1.35) {
          fireOnce('kavun_ulti_charge', () => soundEngine.playSlide());
          const p = t / 1.35;
          ballGroup.position.set(wx(1.05), 0.36 + easeOutCubic(p) * 1.45, az);
          props.melon.position.set(1.05 + Math.cos(t * 10) * 0.65, 1.8, Math.sin(t * 10) * 0.65);
          props.melon.rotation.set(t * 8, t * 12, 0);
          props.snapRing.position.set(1.05, 0.12, 0);
          props.snapRing.scale.setScalar(1.1 + Math.sin(t * 12) * 0.2);

          rig.bodyPivot.position.x = THREE.MathUtils.lerp(-0.8, 0.1, p);
          rig.upperTorsoPivot.rotation.z = -0.2;
          rig.rightLegPivot.rotation.z = -0.75 * p;
          rig.rightKneePivot.rotation.z = -0.95 * p;
          subtitle = 'Altın kasırga enerjisi toplanıyor...';
          _camPos.set(wx(3.8), 2.1, az + 3.4);
          _camLook.set(wx(0.8), 1.4, az);
        } else {
          const kP = clamp01((t - 1.35) / (cs.duration - 1.35));
          const kickP = easeOutCubic(clamp01(kP / 0.45));
          if (kP > 0.25) {
            fireOnce('kavun_ulti_kick', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(wx(1.1), 1.8, az), color: '#fbbf24', count: 40 };
            });
          }
          rig.bodyPivot.position.set(0.1 + kickP * 0.25, Math.sin(Math.min(1, kP / 0.7) * Math.PI) * 0.75, 0);
          rig.bodyPivot.rotation.z = -0.24 * kickP;
          rig.upperTorsoPivot.rotation.set(0, THREE.MathUtils.lerp(0.35, -0.5, kickP), -0.2);
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.75, 1.55, kickP);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.95, -0.08, kickP);
          rig.leftKneePivot.rotation.z = -0.35;
          rig.leftArmPivot.rotation.set(0.4, 0, 1.0);
          rig.rightArmPivot.rotation.set(-0.3, 0, -0.6);
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (kP < 0.45) {
            ballGroup.position.set(wx(1.05), 1.81, az);
          } else {
            const fly = easeOutCubic((kP - 0.45) / 0.55);
            ballGroup.position.set(_cleatPos.x + dir * fly * 22, _cleatPos.y + fly * 1.4, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 30;
          subtitle = 'Altın kasırga vuruşu — durdurulamaz fırtına!';
          _camPos.set(wx(-3.2), 2.2, az + 3.8);
          _camLook.set(wx(3.0), 1.5, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.2), 1.8, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 72,
              loft: 4.4,
            };
          }
        }
        break;
      }

      case 'hamzac5': {
        props.nitroFlame.visible = true;
        if (t < 1.4) {
          fireOnce('c5_sprint_ulti', () => soundEngine.playSlide());
          const p = t / 1.4;
          const stride = Math.sin(p * Math.PI * 4);
          rig.bodyPivot.position.set(THREE.MathUtils.lerp(-1.2, 0, p), 0, 0);
          rig.upperTorsoPivot.rotation.z = -0.28;
          rig.leftLegPivot.rotation.z = stride * 0.72;
          rig.rightLegPivot.rotation.z = -stride * 0.72;
          rig.leftKneePivot.rotation.z = -0.65;
          rig.rightKneePivot.rotation.z = -0.65;
          props.nitroFlame.position.set(rig.bodyPivot.position.x - 0.75, 1.0, 0);
          props.nitroFlame.rotation.x += dt * 16;
          ballGroup.position.set(wx(0.9), 0.36 + easeOutCubic(p) * 2.85, az);
          subtitle = 'HamzaC5 tam gaz deparla sıçrıyor...';
          _camPos.set(wx(3.6), 2.2, az + 4.0);
          _camLook.set(wx(0.5), 1.8, az);
        } else {
          const kP = clamp01((t - 1.4) / (cs.duration - 1.4));
          const whip = easeOutCubic(clamp01(kP / 0.5));
          rig.bodyPivot.position.set(0, 2.75, 0);
          rig.bodyPivot.rotation.z = Math.PI * 0.62 + whip * 0.1;
          rig.upperTorsoPivot.rotation.set(0, -0.24 * whip, 0.16);
          rig.leftLegPivot.rotation.z = 0.24;
          rig.leftKneePivot.rotation.z = -1.05;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.38, 0.96, whip);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-1.0, -0.08, whip);
          rig.leftArmPivot.rotation.set(0.6, 0, 0.25);
          rig.rightArmPivot.rotation.set(-0.6, 0, 0.25);

          props.nitroFlame.position.set(-0.4, 2.5, 0);
          props.nitroFlame.scale.setScalar(1.3);
          props.nitroFlame.rotation.x += dt * 20;
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (kP < 0.5) {
            const b = clamp01(kP / 0.5);
            ballGroup.position.set(
              THREE.MathUtils.lerp(wx(0.9), _cleatPos.x, b),
              THREE.MathUtils.lerp(3.21, _cleatPos.y, b),
              THREE.MathUtils.lerp(az, _cleatPos.z, b)
            );
          } else {
            fireOnce('c5_rove_boom', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: _cleatPos.clone(), color: '#a3e635', count: 38 };
            });
            const fly = easeOutCubic((kP - 0.5) / 0.5);
            ballGroup.position.set(_cleatPos.x + dir * fly * 20, _cleatPos.y + fly * 1.2, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 30;
          subtitle = 'C5 nitro rovaşata! Tam gaz filelere!';
          _camPos.set(wx(-4.0), 3.3, az + 6.0);
          _camLook.set(wx(1.2), 2.7, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.0), 3.2, az),
              range: 'MIDFIELD',
              curve: 0,
              speed: 64,
              loft: 4.8,
            };
          }
        }
        break;
      }

      case 'memud': {
        props.snapRing.visible = t < 1.6;
        (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#2dd4bf');
        if (t < 1.35) {
          fireOnce('memud_lock', () => soundEngine.playAiHackComplete());
          const p = t / 1.35;
          ballGroup.position.set(wx(0.95), 0.36 + easeOutCubic(p) * 2.25, az);
          props.snapRing.position.set(0.95, 2.6, 0);
          props.snapRing.rotation.z += dt * 6;
          props.snapRing.scale.setScalar(0.9 + Math.sin(p * Math.PI) * 0.35);

          rig.bodyPivot.position.y = p * 0.35;
          rig.upperTorsoPivot.rotation.z = -0.18;
          rig.leftKneePivot.rotation.z = -0.35;
          rig.rightLegPivot.rotation.z = -0.55 * p;
          subtitle = 'Memud hedef açısını 90 dereceye kilitledi...';
          _camPos.set(wx(3.6), 2.3, az + 3.4);
          _camLook.set(wx(0.8), 1.8, az);
        } else {
          const kP = clamp01((t - 1.35) / (cs.duration - 1.35));
          const whip = easeOutCubic(clamp01(kP / 0.48));
          rig.bodyPivot.position.set(0, 2.25, 0);
          rig.bodyPivot.rotation.set(0, -0.35, Math.PI * 0.44 + whip * 0.1);
          rig.upperTorsoPivot.rotation.set(0, -0.3, 0.14);
          rig.leftLegPivot.rotation.z = 0.25;
          rig.leftKneePivot.rotation.z = -1.0;
          rig.rightLegPivot.rotation.z = THREE.MathUtils.lerp(-0.4, 1.15, whip);
          rig.rightKneePivot.rotation.z = THREE.MathUtils.lerp(-0.95, -0.1, whip);
          rig.leftArmPivot.rotation.set(0.55, 0, 0.35);
          rig.rightArmPivot.rotation.set(-0.55, 0, 0.35);
          showAura(1.0);

          getCleatWorldPos(rig, 'right', _cleatPos, 0.22, -0.46);
          if (kP < 0.48) {
            const b = clamp01(kP / 0.48);
            ballGroup.position.set(
              THREE.MathUtils.lerp(wx(0.95), _cleatPos.x, b),
              THREE.MathUtils.lerp(2.61, _cleatPos.y, b),
              THREE.MathUtils.lerp(az, _cleatPos.z, b)
            );
          } else {
            fireOnce('memud_ulti_boom', () => {
              soundEngine.playAwakeningBoom();
              soundEngine.playKick(1.0);
              spawnBurst = { pos: _cleatPos.clone(), color: '#2dd4bf', count: 36 };
            });
            const fly = easeOutCubic((kP - 0.48) / 0.52);
            ballGroup.position.set(_cleatPos.x + dir * fly * 20, _cleatPos.y + fly * 1.1, _cleatPos.z);
          }
          ballGroup.rotation.y += dt * 30;
          subtitle = 'Doksan dereceye akrep vole füzesi!';
          _camPos.set(wx(-3.8), 3.0, az + 5.2);
          _camLook.set(wx(1.4), 2.3, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(1.0), 2.5, az),
              range: 'MIDFIELD',
              curve: 0,
              speed: 65,
              loft: 4.1,
            };
          }
        }
        break;
      }

      case 'umidi': {
        if (t < 1.25) {
          fireOnce('umidi_pack_drop', () => soundEngine.playPhonePickup());
          const p = easeOutCubic(t / 1.25);
          props.cheapPack.visible = true;
          props.messiCard.visible = false;
          props.messiHero.visible = false;
          props.cheapPack.position.set(1.35, THREE.MathUtils.lerp(3.2, 1.55, p) + Math.sin(t * 7) * 0.08, 0);
          props.cheapPack.rotation.set(0.15, -Math.PI / 2 + Math.sin(t * 6) * 0.3, 0);
          props.cheapPack.scale.setScalar(0.9 + p * 0.2);

          rig.upperTorsoPivot.rotation.z = -0.14;
          rig.rightArmPivot.rotation.set(0.25, 0, 1.25);
          rig.rightElbowPivot.rotation.z = 0.85;
          rig.leftArmPivot.rotation.set(-0.2, 0, 1.15);
          rig.leftElbowPivot.rotation.z = 0.85;
          ballGroup.position.set(wx(1.7), 0.36, az);

          subtitle = 'Dandik paket dediler... Bakalım içinden ne çıkacak!';
          _camPos.set(wx(3.8), 2.05, az + 2.8);
          _camLook.set(wx(1.1), 1.55, az);
        } else if (t < 2.55) {
          fireOnce('umidi_pack_burst', () => {
            soundEngine.playPackOpen();
            spawnBurst = { pos: new THREE.Vector3(wx(1.4), 1.65, az), color: '#fbbf24', count: 44 };
          });
          const p = clamp01((t - 1.25) / 1.3);
          const cardPop = easeOutBack(Math.min(1, p * 1.4));
          props.cheapPack.visible = false;
          props.messiCard.visible = true;
          props.messiHero.visible = false;

          props.messiCard.position.set(1.4, 1.65 + Math.sin(t * 8) * 0.08, 0);
          props.messiCard.rotation.set(0, -Math.PI / 2 + Math.sin(p * Math.PI * 2) * 0.35, 0);
          props.messiCard.scale.setScalar(0.35 + cardPop * 0.95);

          props.snapRing.visible = true;
          (props.snapRing.material as THREE.MeshBasicMaterial).color.set('#fbbf24');
          props.snapRing.position.set(1.4, 1.65, 0);
          props.snapRing.scale.setScalar(0.8 + p * 3.8);
          (props.snapRing.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - p);

          rig.upperTorsoPivot.rotation.z = 0.16;
          rig.leftArmPivot.rotation.set(0.45, 0, 2.25);
          rig.rightArmPivot.rotation.set(-0.45, 0, 2.25);
          ballGroup.position.set(wx(1.75), 0.36, az);
          showAura(0.85);

          subtitle = '99 REYTİNG MESSI KARTI ÇIKTI!!';
          _camPos.set(wx(4.1), 2.1, az + 2.6);
          _camLook.set(wx(1.35), 1.65, az);
        } else {
          fireOnce('umidi_messi_spawn', () => {
            soundEngine.playTeleportWhoosh();
            soundEngine.playAwakeningBoom();
            spawnBurst = { pos: new THREE.Vector3(wx(1.45), 1.5, az), color: '#38bdf8', count: 44 };
          });
          props.cheapPack.visible = false;
          props.snapRing.visible = false;
          const p = clamp01((t - 2.55) / (cs.duration - 2.55));
          props.messiCard.visible = p < 0.25;
          props.messiCard.scale.setScalar(Math.max(0.05, 1.3 * (1 - p * 4)));

          props.messiHero.visible = true;
          const leapP = easeOutCubic(Math.min(1, p / 0.45));
          props.messiHero.position.set(
            THREE.MathUtils.lerp(1.45, 1.85, leapP),
            Math.sin(Math.min(1, p / 0.6) * Math.PI) * 0.55,
            0
          );
          props.messiHero.rotation.set(0, 0, THREE.MathUtils.lerp(0.18, -0.22, leapP));
          props.messiHero.scale.setScalar(0.55 + leapP * 0.55);

          rig.upperTorsoPivot.rotation.z = -0.15;
          rig.leftArmPivot.rotation.set(0.5, 0, 1.8);
          rig.rightArmPivot.rotation.set(-0.5, 0, 1.8);
          showAura(1.0);

          if (p < 0.44) {
            ballGroup.position.set(wx(2.3), 0.55, az);
          } else {
            fireOnce('umidi_messi_kick', () => {
              soundEngine.playKick(1.0);
              spawnBurst = { pos: new THREE.Vector3(wx(2.35), 0.7, az), color: '#fbbf24', count: 42 };
            });
            const fly = easeOutCubic((p - 0.44) / 0.56);
            ballGroup.position.set(wx(2.35 + fly * 24), 0.65 + fly * 1.35, az);
          }
          ballGroup.rotation.y += dt * 36;

          subtitle = 'MESSI KARTTAN ÇIKTI — KALEYİ YIKAN SÜPER ŞUT!!';
          _camPos.set(wx(-2.8), 2.35, az + 4.4);
          _camLook.set(wx(2.4), 1.45, az);

          if (t >= cs.duration - 0.05) {
            launchShot = {
              from: new THREE.Vector3(wx(2.3), 0.72, az),
              range: 'FULL_PITCH',
              curve: 0,
              speed: 74,
              loft: 4.2,
            };
          }
        }
        break;
      }
    }
  }

  return {
    finished: t >= cs.duration,
    cameraPos: _camPos.clone(),
    cameraLook: _camLook.clone(),
    banner: {
      active: true,
      speaker: cs.kind === 'COMBO' ? 'MUSAB × MUSA' : style.name,
      subtitle,
      badge,
      accentColor: cs.kind === 'COMBO' ? '#facc15' : style.auraColor,
    },
    spawnBurst,
    launchShot,
  };
}
