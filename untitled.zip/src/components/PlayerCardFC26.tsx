import { PLAYER_CARD_META, getDynamicCardOvr } from '../data/playerCards';
import { STYLES } from '../data/styles';
import type { StyleCareerStats, StyleId } from '../types/game';

interface PlayerCardFC26Props {
  styleId: StyleId;
  careerStats?: StyleCareerStats;
  playerName?: string;
  compact?: boolean;
  showCareer?: boolean;
}

export function PlayerCardFC26({
  styleId,
  careerStats,
  playerName,
  compact = false,
  showCareer = true,
}: PlayerCardFC26Props) {
  const style = STYLES[styleId];
  const meta = PLAYER_CARD_META[styleId];
  const stats: StyleCareerStats = careerStats ?? {
    matches: 0,
    wins: 0,
    goals: 0,
    shots: 0,
    passes: 0,
    steals: 0,
  };
  const dynamicOvr = getDynamicCardOvr(styleId, stats);
  const p = meta.palette;

  const statRows: Array<{ label: string; val: number }> = [
    { label: 'HIZ', val: meta.attributes.pace },
    { label: 'DRİ', val: meta.attributes.dribbling },
    { label: 'ŞUT', val: meta.attributes.shooting },
    { label: 'DEF', val: meta.attributes.defending },
    { label: 'PAS', val: meta.attributes.passing },
    { label: 'FİZ', val: meta.attributes.physical },
  ];

  const isLightFace = meta.tier === 'ICON';

  return (
    <div
      className={`relative select-none overflow-hidden shadow-2xl ${
        compact ? 'w-[220px] p-3.5 rounded-2xl' : 'w-[280px] p-5 rounded-3xl'
      }`}
      style={{
        background: `linear-gradient(155deg, ${p.bgTop} 0%, ${p.bgMid} 48%, ${p.bgBottom} 100%)`,
        border: `2px solid ${p.border}`,
        clipPath: 'polygon(6% 0%, 94% 0%, 100% 7%, 100% 88%, 50% 100%, 0% 88%, 0% 7%)',
      }}
    >
      {/* Inner foil hairline frame */}
      <div
        className="pointer-events-none absolute inset-2 rounded-2xl border opacity-45"
        style={{ borderColor: p.border }}
      />

      {/* Top row: OVR + Position + Character silhouette */}
      <div className="relative flex items-start justify-between gap-2 pt-1">
        <div className="flex flex-col items-center min-w-[54px]">
          <div
            className={`${compact ? 'text-3xl' : 'text-4xl'} font-black leading-none tabular-nums`}
            style={{ color: p.textPrimary }}
          >
            {dynamicOvr}
          </div>
          <div
            className="text-xs font-black tracking-wider mt-0.5"
            style={{ color: p.textSecondary }}
          >
            {meta.position}
          </div>
          <div
            className="w-7 h-[1px] my-1.5"
            style={{ backgroundColor: p.divider }}
          />
          <div
            className="text-[10px] font-black tracking-widest"
            style={{ color: p.textPrimary }}
          >
            {meta.nationFlag}
          </div>
          <div
            className="text-[9px] font-bold tracking-wide opacity-85 mt-0.5"
            style={{ color: p.textSecondary }}
          >
            #{style.jerseyNumber}
          </div>
        </div>

        {/* Stylized Jersey & Silhouette Avatar */}
        <div className={`relative flex-1 flex items-center justify-center ${compact ? 'h-24' : 'h-32'}`}>
          <svg
            viewBox="0 0 120 120"
            className="w-full h-full drop-shadow-lg"
            aria-label={style.name}
          >
            {/* Aura Halo */}
            <circle cx="60" cy="54" r="42" fill={style.auraColor} opacity="0.22" />
            <circle
              cx="60"
              cy="54"
              r="36"
              fill="none"
              stroke={style.auraColor}
              strokeWidth="1.8"
              opacity="0.7"
            />
            {/* Shoulders & Jersey */}
            <path
              d="M24 114 C26 84, 40 76, 60 76 C80 76, 94 84, 96 114 Z"
              fill={style.primaryColor}
              stroke={style.secondaryColor}
              strokeWidth="3"
            />
            <path d="M46 76 L60 92 L74 76" fill="none" stroke={style.secondaryColor} strokeWidth="2.5" />
            {/* Neck & Head */}
            <rect x="53" y="62" width="14" height="16" rx="5" fill={style.skinColor} />
            <circle cx="60" cy="48" r="18" fill={style.skinColor} />
            {/* Hair / Accessory Motif */}
            <path
              d="M41 44 C42 25, 78 25, 79 44 C73 34, 47 34, 41 44 Z"
              fill={style.hairColor}
            />
            {style.accessory === 'shades' && (
              <g fill="#0f172a" stroke="#e2e8f0" strokeWidth="1.2">
                <rect x="46" y="45" width="12" height="6" rx="2" />
                <rect x="62" y="45" width="12" height="6" rx="2" />
                <line x1="58" y1="48" x2="62" y2="48" />
              </g>
            )}
            {style.accessory === 'visor' && (
              <rect x="45" y="44" width="30" height="6" rx="2" fill={style.auraColor} opacity="0.85" />
            )}
            {style.accessory === 'headband' && (
              <rect x="42" y="36" width="36" height="5" rx="2" fill={style.auraColor} />
            )}
            {style.accessory === 'headset' && (
              <path
                d="M40 48 C40 28, 80 28, 80 48"
                fill="none"
                stroke={style.auraColor}
                strokeWidth="3.5"
              />
            )}
            <text
              x="60"
              y="108"
              textAnchor="middle"
              fill={style.secondaryColor}
              fontSize="15"
              fontWeight="900"
            >
              {style.jerseyNumber}
            </text>
          </svg>
        </div>
      </div>

      {/* Name & Tier Subtitle */}
      <div
        className="relative mt-1 pt-2 text-center border-t"
        style={{ borderColor: p.divider }}
      >
        <div
          className={`${compact ? 'text-base' : 'text-xl'} font-black tracking-wide uppercase truncate`}
          style={{ color: isLightFace ? '#1e1b18' : '#ffffff' }}
        >
          {style.name}
        </div>
        <div
          className="text-[10px] font-bold tracking-wider truncate"
          style={{ color: isLightFace ? '#451a03' : '#e2e8f0' }}
        >
          {meta.tierLabel}
          {playerName ? ` · ${playerName}` : ''}
        </div>
      </div>

      {/* 6 Attributes (3x2 grid) */}
      <div
        className={`relative mt-2.5 pt-2 border-t grid grid-cols-2 gap-x-4 gap-y-1 ${
          compact ? 'text-xs' : 'text-sm'
        }`}
        style={{
          borderColor: p.divider,
          color: isLightFace ? '#1e1b18' : '#f8fafc',
        }}
      >
        {statRows.map((row) => (
          <div key={row.label} className="flex items-center justify-between font-black tabular-nums">
            <span>{row.val}</span>
            <span
              className="text-[11px] font-bold opacity-80"
              style={{ color: isLightFace ? '#451a03' : '#cbd5e1' }}
            >
              {row.label}
            </span>
          </div>
        ))}
      </div>

      {/* Trait & Career Summary */}
      <div
        className="relative mt-2.5 pt-2 pb-3 border-t text-center space-y-1"
        style={{ borderColor: p.divider }}
      >
        <div
          className="text-[11px] font-black tracking-wide"
          style={{ color: p.accent === '#92400e' ? '#78350f' : p.accent }}
        >
          {meta.traitName}
        </div>
        {showCareer && (
          <div
            className="text-[10px] font-bold tabular-nums"
            style={{ color: isLightFace ? '#451a03' : '#cbd5e1' }}
          >
            {stats.matches} Maç · {stats.wins} Galibiyet · {stats.goals} Gol
          </div>
        )}
      </div>
    </div>
  );
}
