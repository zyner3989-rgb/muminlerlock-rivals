import { useState } from 'react';
import { Check, Lock, Sparkles, Unlock, X, Zap } from 'lucide-react';
import { PlayerCardFC26 } from './PlayerCardFC26';
import { getStyleCareer, type CareerStatsMap } from '../data/playerCards';
import {
  FLOWS,
  RARITY_COLORS,
  rollFlowGacha,
  rollStyleGacha,
  STYLE_LIST,
  STYLES,
} from '../data/styles';
import { soundEngine } from '../audio/soundEngine';
import type { FlowId, StyleDefinition, StyleId } from '../types/game';

interface SpinLobbyModalProps {
  selectedStyle: StyleId;
  selectedFlow: FlowId;
  unlockedStyles: StyleId[];
  sandboxAllUnlocked: boolean;
  spins: number;
  luckySpins: number;
  yen: number;
  playerName?: string;
  careerStatsMap?: CareerStatsMap;
  onSelectStyle: (id: StyleId) => void;
  onSelectFlow: (id: FlowId) => void;
  onUnlockStyle: (id: StyleId) => void;
  onConsumeSpin: (lucky: boolean) => void;
  onBuySpins: (kind: 'NORMAL' | 'LUCKY') => void;
  onToggleSandbox: () => void;
  onClose: () => void;
}

export function SpinLobbyModal({
  selectedStyle,
  selectedFlow,
  unlockedStyles,
  sandboxAllUnlocked,
  spins,
  luckySpins,
  yen,
  playerName,
  careerStatsMap,
  onSelectStyle,
  onSelectFlow,
  onUnlockStyle,
  onConsumeSpin,
  onBuySpins,
  onToggleSandbox,
  onClose,
}: SpinLobbyModalProps) {
  const [rolling, setRolling] = useState(false);
  const [rollBanner, setRollBanner] = useState<StyleDefinition | null>(null);
  const [previewId, setPreviewId] = useState<StyleId>(selectedStyle);
  const [tab, setTab] = useState<'STYLES' | 'FLOWS'>('STYLES');

  const previewStyle = STYLES[previewId];
  const previewRarity = RARITY_COLORS[previewStyle.rarity];

  const handleSpin = (lucky: boolean) => {
    if (rolling) return;
    if (lucky && luckySpins <= 0) return;
    if (!lucky && spins <= 0) return;

    onConsumeSpin(lucky);
    setRolling(true);
    setRollBanner(null);

    let step = 0;
    const interval = window.setInterval(() => {
      const randomCard = STYLE_LIST[step % STYLE_LIST.length];
      setPreviewId(randomCard.id);
      soundEngine.playSpinTick(false);
      step++;
      if (step >= 12) {
        window.clearInterval(interval);
        const won = rollStyleGacha(lucky);
        setPreviewId(won.id);
        setRollBanner(won);
        onUnlockStyle(won.id);
        onSelectStyle(won.id);
        soundEngine.playSpinTick(true);
        setRolling(false);
      }
    }, 85);
  };

  const handleFlowSpin = () => {
    if (yen < 250) return;
    const wonFlow = rollFlowGacha();
    onSelectFlow(wonFlow.id);
    soundEngine.playSpinTick(true);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="w-full max-w-5xl max-h-[90vh] bg-[#090f1e] border border-sky-500/40 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b border-slate-800 bg-[#050811]">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <div>
              <h2 className="text-lg font-black tracking-wide text-white">
                MÜMİNRIVALS STİL ÇARKI & FLOW LABORATUVARI
              </h2>
              <p className="text-xs text-slate-400">
                Master (En İyi) &gt; World Class &gt; Mitik &gt; Rare (En Düşük)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onToggleSandbox}
              className={`flex items-center gap-1.5 text-xs font-extrabold px-3 py-2 rounded-lg border cursor-pointer transition-colors ${
                sandboxAllUnlocked
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                  : 'bg-slate-800 border-slate-600 text-slate-300'
              }`}
            >
              {sandboxAllUnlocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              {sandboxAllUnlocked ? 'Tüm Stiller Açık (Serbest)' : 'Kilitle / Çark Modu'}
            </button>

            <div className="text-xs font-black bg-slate-900 border border-amber-500/40 text-amber-300 px-3 py-2 rounded-lg tabular-nums">
              ¥{yen.toLocaleString('tr-TR')}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
              aria-label="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-[#070b17]">
          <button
            type="button"
            onClick={() => setTab('STYLES')}
            className={`px-4 py-2 text-xs font-black tracking-wider border-b-2 cursor-pointer ${
              tab === 'STYLES'
                ? 'border-sky-400 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            STİLLER & ÇARK (11 KARAKTER)
          </button>
          <button
            type="button"
            onClick={() => setTab('FLOWS')}
            className={`px-4 py-2 text-xs font-black tracking-wider border-b-2 cursor-pointer ${
              tab === 'FLOWS'
                ? 'border-purple-400 text-purple-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            FLOW AURALARI
          </button>
        </div>

        {tab === 'STYLES' ? (
          <div className="flex-1 overflow-y-auto custom-scroll p-6 grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Style Roster List */}
            <div className="lg:col-span-5 space-y-2.5">
              {STYLE_LIST.map((s) => {
                const r = RARITY_COLORS[s.rarity];
                const isUnlocked = sandboxAllUnlocked || unlockedStyles.includes(s.id);
                const isSelected = selectedStyle === s.id;
                const isPreview = previewId === s.id;

                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setPreviewId(s.id);
                      if (isUnlocked) onSelectStyle(s.id);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isPreview
                        ? 'bg-slate-800/95 border-sky-400'
                        : 'bg-[#0d152a] hover:bg-slate-800/70 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center font-black text-sm text-white border"
                        style={{
                          backgroundColor: s.primaryColor,
                          borderColor: r.border,
                        }}
                      >
                        #{s.jerseyNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-white">{s.name}</span>
                          <span
                            className="text-[10px] font-black px-1.5 py-0.5 rounded text-slate-950"
                            style={{ background: r.badgeBg }}
                          >
                            {s.rarity}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">{s.title}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {isSelected ? (
                        <span className="flex items-center gap-1 text-[11px] font-black text-emerald-300 bg-emerald-500/15 px-2 py-1 rounded">
                          <Check className="w-3.5 h-3.5" /> SEÇİLİ
                        </span>
                      ) : !isUnlocked ? (
                        <Lock className="w-4 h-4 text-slate-500" />
                      ) : (
                        <span className="text-[11px] font-bold text-sky-300">Seç</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right: Preview Card + Gacha Spin Controls */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              {rollBanner && (
                <div
                  className="rounded-xl p-3 border text-center font-black text-sm text-white"
                  style={{
                    borderColor: RARITY_COLORS[rollBanner.rarity].border,
                    background: 'rgba(15, 23, 42, 0.95)',
                  }}
                >
                  TEBRİKLER! ÇARKTAN ÇIKAN STİL: {rollBanner.name} ({rollBanner.rarity})!
                </div>
              )}

              <div
                className="rounded-2xl p-5 border bg-[#060b16]"
                style={{ borderColor: previewRarity.border }}
              >
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
                  <div className="shrink-0">
                    <PlayerCardFC26
                      styleId={previewStyle.id}
                      careerStats={getStyleCareer(careerStatsMap ?? {}, previewStyle.id)}
                      playerName={playerName}
                      compact
                    />
                  </div>

                  <div className="flex-1 w-full">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span
                          className="inline-block text-[11px] font-black px-2.5 py-0.5 rounded text-slate-950"
                          style={{ background: previewRarity.badgeBg }}
                        >
                          {previewRarity.labelTr}
                        </span>
                        <h3 className="text-2xl font-black text-white mt-1.5">
                          {previewStyle.name} <span className="text-slate-500">#{previewStyle.jerseyNumber}</span>
                        </h3>
                        <p className="text-xs text-sky-300 font-semibold">{previewStyle.title}</p>
                      </div>

                      {(sandboxAllUnlocked || unlockedStyles.includes(previewStyle.id)) && (
                        <button
                          type="button"
                          onClick={() => onSelectStyle(previewStyle.id)}
                          className={`px-4 py-2 rounded-xl font-black text-xs cursor-pointer ${
                            selectedStyle === previewStyle.id
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                          }`}
                        >
                          {selectedStyle === previewStyle.id ? 'KUŞANILDI' : 'STİLİ KUŞAN'}
                        </button>
                      )}
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4">
                      {[
                        ['HIZ', previewStyle.stats.speed],
                        ['ŞUT', previewStyle.stats.shotPower],
                        ['ÇALIM', previewStyle.stats.dribble],
                        ['KAPMA', previewStyle.stats.steal],
                      ].map(([label, val]) => (
                        <div key={String(label)} className="bg-slate-900/90 border border-slate-800 rounded-lg p-2">
                          <div className="text-[10px] text-slate-400 font-bold">{label}</div>
                          <div className="text-base font-black text-white tabular-nums">{val}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Skills, Awakening & Ulti */}
                <div className="mt-4 space-y-2.5 text-xs">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                      <div className="text-sky-300 font-black">
                        [{previewStyle.skill1.key}] {previewStyle.skill1.name}
                      </div>
                      <p className="text-slate-300 mt-1">{previewStyle.skill1.description}</p>
                    </div>
                    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                      <div className="text-sky-300 font-black">
                        [{previewStyle.skill2.key}] {previewStyle.skill2.name}
                      </div>
                      <p className="text-slate-300 mt-1">{previewStyle.skill2.description}</p>
                    </div>
                  </div>

                  <div className="bg-emerald-500/10 border border-emerald-400/40 rounded-xl p-3">
                    <div className="text-emerald-300 font-black">
                      [{previewStyle.personalSkill.key}] KİŞİYE ÖZEL: {previewStyle.personalSkill.name}
                    </div>
                    <p className="text-slate-200 mt-1">{previewStyle.personalSkill.description}</p>
                  </div>

                  <div className="bg-amber-500/10 border border-amber-400/40 rounded-xl p-3">
                    <div className="text-amber-300 font-black flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5" /> [G] UYANIŞ: {previewStyle.awakeningName}
                    </div>
                    <p className="text-slate-200 mt-1">{previewStyle.awakeningSummary}</p>
                  </div>

                  <div className="bg-purple-500/10 border border-purple-400/40 rounded-xl p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-purple-300 font-black">
                        [V] ULTİ VURUŞU: {previewStyle.ultiName}
                      </span>
                      <span className="text-[10px] font-black bg-purple-500/30 text-purple-200 px-2 py-0.5 rounded">
                        Menzil: {previewStyle.ultiRangeLabel}
                      </span>
                    </div>
                    <p className="text-slate-200 mt-1">{previewStyle.ultiSummary}</p>
                  </div>
                </div>
              </div>

              {/* Spin Buttons */}
              <div className="bg-[#0d152a] border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    disabled={rolling || spins <= 0}
                    onClick={() => handleSpin(false)}
                    className="bg-sky-500 hover:bg-sky-400 disabled:opacity-45 text-slate-950 font-black text-xs px-4 py-3 rounded-xl cursor-pointer tabular-nums"
                  >
                    NORMAL SPİN ({spins})
                  </button>
                  <button
                    type="button"
                    disabled={rolling || luckySpins <= 0}
                    onClick={() => handleSpin(true)}
                    className="bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-slate-950 font-black text-xs px-4 py-3 rounded-xl cursor-pointer tabular-nums"
                  >
                    ŞANSLI SPİN ({luckySpins})
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={yen < 300}
                    onClick={() => onBuySpins('NORMAL')}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-45 border border-slate-700 text-slate-200 font-bold text-xs px-3 py-2.5 rounded-lg cursor-pointer"
                  >
                    +1 Spin (¥300)
                  </button>
                  <button
                    type="button"
                    disabled={yen < 900}
                    onClick={() => onBuySpins('LUCKY')}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-45 border border-amber-500/40 text-amber-200 font-bold text-xs px-3 py-2.5 rounded-lg cursor-pointer"
                  >
                    +1 Şanslı (¥900)
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto custom-scroll p-6 space-y-4">
            <div className="flex items-center justify-between bg-[#0d152a] border border-slate-800 rounded-xl p-4">
              <div>
                <div className="text-sm font-black text-white">Rastgele Flow Çevir</div>
                <div className="text-xs text-slate-400">
                  Her Flow uyanış sırasında hız, şut gücü ve dayanıklılık pasifi verir.
                </div>
              </div>
              <button
                type="button"
                disabled={yen < 250}
                onClick={handleFlowSpin}
                className="bg-purple-500 hover:bg-purple-400 disabled:opacity-45 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
              >
                FLOW ÇEVİR (¥250)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.values(FLOWS).map((f) => {
                const active = selectedFlow === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => onSelectFlow(f.id)}
                    className={`text-left p-4 rounded-xl border cursor-pointer transition-colors ${
                      active
                        ? 'bg-slate-800 border-purple-400'
                        : 'bg-[#0d152a] hover:bg-slate-800/70 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-sm text-white">{f.name}</span>
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: f.color }}
                      />
                    </div>
                    <div className="text-[11px] font-bold text-purple-300 mt-1">{f.rarity}</div>
                    <div className="text-xs text-slate-300 mt-2">{f.bonusText}</div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
