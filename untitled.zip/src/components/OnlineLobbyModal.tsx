import { useEffect, useState } from 'react';
import {
  Activity,
  Award,
  Check,
  Clock,
  Copy,
  Crown,
  Edit3,
  Loader2,
  Play,
  RefreshCw,
  Search,
  Shield,
  Swords,
  Trophy,
  Users,
  Wifi,
  X,
} from 'lucide-react';
import { ChatVoicePanel } from './ChatVoicePanel';
import { PLAYER_CARD_META } from '../data/playerCards';
import { ROLE_LIST, ROLES } from '../data/roles';
import { getRankProgress, getRankTier } from '../data/ranked';
import { FLOWS, RARITY_COLORS, STYLE_LIST, STYLES } from '../data/styles';
import type {
  ChatMessage,
  FlowId,
  GkDifficulty,
  LeaderboardEntry,
  MatchMode,
  MatchmakingStatus,
  PlayerRole,
  QueueType,
  RankedProfile,
  RoomLobbyState,
  StyleId,
  VoicePeerState,
} from '../types/game';

interface PublicRoomSummary {
  roomCode: string;
  playerCount: number;
  gkDifficulty: GkDifficulty;
  matchMode?: MatchMode;
  queueType?: QueueType;
  status: string;
}

export type OnlineTransportMode = 'p2p' | 'ws';

interface OnlineLobbyModalProps {
  mode: OnlineTransportMode;
  connected: boolean;
  pingMs: number | null;
  clientId: string | null;
  playerName: string;
  room: RoomLobbyState | null;
  errorMsg: string | null;
  defaultStyle: StyleId;
  defaultFlow: FlowId;
  defaultGk: GkDifficulty;
  defaultMatchMode: MatchMode;
  defaultRole: PlayerRole;
  rankedProfile: RankedProfile;
  matchmakingStatus: MatchmakingStatus | null;
  chatMessages: ChatMessage[];
  voicePeers: VoicePeerState[];
  voiceStatus: {
    joined: boolean;
    muted: boolean;
    deafened: boolean;
    speaking: boolean;
    error: string | null;
  };
  onChangeMode: (mode: OnlineTransportMode) => void;
  onOpenRenameModal: () => void;
  onSelectRole?: (role: PlayerRole) => void;
  onStartMatchmaking: (
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    matchMode: MatchMode,
    queueType: QueueType,
    role: PlayerRole
  ) => void;
  onCancelMatchmaking: () => void;
  onForceStartMatchmaking: () => void;
  onCreateRoom: (
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    gk: GkDifficulty,
    matchMode: MatchMode,
    role: PlayerRole
  ) => void;
  onJoinRoom: (code: string, name: string, styleId: StyleId, flowId: FlowId, role: PlayerRole) => void;
  onLeaveRoom: () => void;
  onUpdatePlayer: (patch: {
    name?: string;
    styleId?: StyleId;
    flowId?: FlowId;
    team?: 'BLUE' | 'RED';
    role?: PlayerRole;
  }) => void;
  onSetGk: (gk: GkDifficulty) => void;
  onSetMatchMode: (mode: MatchMode) => void;
  onSetMatchDuration: (durationSec: number) => void;
  onStartOnlineMatch: () => void;
  onSendChat: (text: string) => void;
  onToggleVoice: () => void;
  onToggleMute: () => void;
  onToggleDeafen: () => void;
  onClose: () => void;
}

const GK_LABELS: Record<GkDifficulty, string> = {
  EASY: 'KOLAY',
  MEDIUM: 'ORTA',
  HARD: 'ZOR',
};

const DURATION_OPTIONS = [
  { sec: 120, label: '2 Dk' },
  { sec: 180, label: '3 Dk' },
  { sec: 300, label: '5 Dk' },
];

export function OnlineLobbyModal({
  mode,
  connected,
  pingMs,
  clientId,
  playerName,
  room,
  errorMsg,
  defaultStyle,
  defaultFlow,
  defaultGk,
  defaultMatchMode,
  defaultRole,
  rankedProfile,
  matchmakingStatus,
  chatMessages,
  voicePeers,
  voiceStatus,
  onChangeMode,
  onOpenRenameModal,
  onSelectRole,
  onStartMatchmaking,
  onCancelMatchmaking,
  onForceStartMatchmaking,
  onCreateRoom,
  onJoinRoom,
  onLeaveRoom,
  onUpdatePlayer,
  onSetGk,
  onSetMatchMode,
  onSetMatchDuration,
  onStartOnlineMatch,
  onSendChat,
  onToggleVoice,
  onToggleMute,
  onToggleDeafen,
  onClose,
}: OnlineLobbyModalProps) {
  const [lobbyTab, setLobbyTab] = useState<'MATCHMAKING' | 'CUSTOM'>('CUSTOM');
  const [queueType, setQueueType] = useState<QueueType>('RANKED');
  const [queueMode, setQueueMode] = useState<MatchMode>(defaultMatchMode);
  const [selectedRole, setSelectedRole] = useState<PlayerRole>(defaultRole);
  const [joinCode, setJoinCode] = useState('');
  const [publicRooms, setPublicRooms] = useState<PublicRoomSummary[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const rankProgress = getRankProgress(rankedProfile.rp);

  const fetchRooms = async () => {
    if (mode !== 'ws') return;
    try {
      const res = await fetch('/api/rooms');
      const data = await res.json();
      if (Array.isArray(data?.rooms)) {
        setPublicRooms(data.rooms);
      }
    } catch {
      // ignore fetch errors
    }
  };

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch('/api/leaderboard');
      const data = await res.json();
      if (Array.isArray(data?.entries)) {
        setLeaderboard(data.entries);
      }
    } catch {
      // ignore fetch errors
    }
  };

  useEffect(() => {
    if (!room) {
      fetchLeaderboard();
      if (mode === 'ws') fetchRooms();
    }
  }, [room, mode]);

  const me = room?.players.find((p) => p.clientId === clientId);
  const isHost = Boolean(room && clientId && room.hostId === clientId);
  const isSearching = Boolean(matchmakingStatus?.searching);

  const handleRoleChange = (role: PlayerRole) => {
    setSelectedRole(role);
    onSelectRole?.(role);
  };

  const handleCopyCode = async () => {
    if (!room) return;
    try {
      await navigator.clipboard.writeText(room.roomCode);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 1800);
    } catch {
      // ignore clipboard restrictions inside iframes
    }
  };

  const handleCopyInviteLink = async () => {
    if (!room) return;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('room', room.roomCode);
      url.searchParams.set('net', mode);
      await navigator.clipboard.writeText(url.toString());
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      // ignore clipboard restrictions
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="w-full max-w-4xl max-h-[90vh] bg-[#090f1e] border border-sky-500/40 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#050811]">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-sky-400" />
            <div>
              <h2 className="text-lg font-black text-white">ONLİNE MAÇ EŞLEME & DERECELİ ARENA</h2>
              <p className="text-xs text-slate-400">
                {mode === 'ws'
                  ? connected
                    ? 'Düşük Ping Sunucu (WS) Bağlı — Dereceli Eşleşme veya Özel Oda'
                    : 'Sunucuya bağlanılıyor...'
                  : 'P2P Paylaşım Modu (Farklı linklerden arkadaşlarla oynamak için)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {pingMs !== null && (
              <div
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-black tabular-nums ${
                  pingMs < 75
                    ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300'
                    : pingMs < 150
                      ? 'bg-amber-500/15 border-amber-400/40 text-amber-300'
                      : 'bg-red-500/15 border-red-400/40 text-red-300'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                {pingMs} ms
              </div>
            )}
            <button
              type="button"
              onClick={() => {
                if (isSearching) onCancelMatchmaking();
                onClose();
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
              aria-label="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-6 space-y-5">
          {/* Transport Mode & Sub-Navigation Selector */}
          {!room && (
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#060b16] border border-slate-800 rounded-2xl p-3.5">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setLobbyTab('MATCHMAKING')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black border cursor-pointer ${
                    lobbyTab === 'MATCHMAKING'
                      ? 'bg-amber-400 border-amber-200 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Trophy className="w-3.5 h-3.5" /> MAÇ EŞLEME (DERECELİ)
                </button>
                <button
                  type="button"
                  onClick={() => setLobbyTab('CUSTOM')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black border cursor-pointer ${
                    lobbyTab === 'CUSTOM'
                      ? 'bg-sky-500 border-sky-300 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Swords className="w-3.5 h-3.5" /> ÖZEL ODA KUR / KATIL
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <Wifi className="w-4 h-4 text-emerald-400 shrink-0 mr-1" />
                <button
                  type="button"
                  disabled={isSearching}
                  onClick={() => onChangeMode('ws')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:opacity-50 ${
                    mode === 'ws'
                      ? 'bg-sky-500 border-sky-300 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  Sunucu WS (En Düşük Ping)
                </button>
                <button
                  type="button"
                  disabled={isSearching}
                  onClick={() => onChangeMode('p2p')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:opacity-50 ${
                    mode === 'p2p'
                      ? 'bg-emerald-500 border-emerald-300 text-slate-950'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  P2P (Share Uyumlu)
                </button>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="bg-red-950/70 border border-red-500/50 text-red-200 text-xs font-bold rounded-xl px-4 py-3">
              {errorMsg}
            </div>
          )}

          {!room && lobbyTab === 'MATCHMAKING' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Left: Ranked Card & Matchmaking Controls */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 space-y-4">
                {/* Player Rank Card */}
                <div className="bg-[#090f1e] border border-amber-400/35 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="px-2.5 py-1 rounded-lg text-[11px] font-black text-slate-950"
                        style={{ background: rankProgress.tier.bg }}
                      >
                        {rankProgress.tier.badgeText}
                      </span>
                      <div>
                        <div className="text-xs font-black text-white">{rankProgress.tier.name}</div>
                        <div className="text-[11px] font-bold text-sky-300 tabular-nums">
                          {rankedProfile.rp} RP · {rankedProfile.wins}G / {rankedProfile.losses}M
                        </div>
                      </div>
                    </div>
                    {rankedProfile.winStreak > 0 && (
                      <span className="text-[10px] font-black px-2 py-1 rounded bg-amber-400/20 border border-amber-400/40 text-amber-300">
                        {rankedProfile.winStreak} SERİ
                      </span>
                    )}
                  </div>
                  {rankProgress.nextTier && (
                    <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-sky-400 to-amber-400"
                        style={{ width: `${rankProgress.percent}%` }}
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3.5 py-2.5">
                  <div>
                    <div className="text-[10px] font-black text-slate-400 uppercase">OYUNCU KİMLİĞİN</div>
                    <div className="text-sm font-black text-white">{playerName}</div>
                  </div>
                  <button
                    type="button"
                    disabled={isSearching}
                    onClick={onOpenRenameModal}
                    className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300 cursor-pointer disabled:opacity-50"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Düzenle
                  </button>
                </div>

                {/* Queue Type: Ranked vs Casual */}
                <div>
                  <div className="text-[11px] font-black text-slate-400 uppercase mb-1.5">
                    KUYRUK TİPİ
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={isSearching}
                      onClick={() => setQueueType('RANKED')}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer disabled:opacity-60 ${
                        queueType === 'RANKED'
                          ? 'bg-gradient-to-r from-amber-400/20 to-purple-500/20 border-amber-400 text-white'
                          : 'bg-[#090f1e] border-slate-800 text-slate-400 hover:bg-slate-900'
                      }`}
                    >
                      <div className="text-xs font-black text-amber-300">DERECELİ (RANKED)</div>
                      <div className="text-[10px] font-semibold text-slate-300">
                        RP Kazan/Kaybet · Zor Kaleci
                      </div>
                    </button>
                    <button
                      type="button"
                      disabled={isSearching}
                      onClick={() => setQueueType('CASUAL')}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer disabled:opacity-60 ${
                        queueType === 'CASUAL'
                          ? 'bg-sky-500/20 border-sky-400 text-white'
                          : 'bg-[#090f1e] border-slate-800 text-slate-400 hover:bg-slate-900'
                      }`}
                    >
                      <div className="text-xs font-black text-sky-300">HIZLI MAÇ (SERBEST)</div>
                      <div className="text-[10px] font-semibold text-slate-300">
                        RP Riski Yok · Orta Kaleci
                      </div>
                    </button>
                  </div>
                </div>

                {/* Format: 1v1 / 3v3 */}
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-black text-slate-400 uppercase">FORMAT</span>
                  <div className="flex gap-1.5">
                    {(['1V1', '3V3'] as MatchMode[]).map((mm) => (
                      <button
                        key={mm}
                        type="button"
                        disabled={isSearching}
                        onClick={() => setQueueMode(mm)}
                        className={`px-4 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:opacity-60 ${
                          queueMode === mm
                            ? 'bg-sky-500 border-sky-300 text-slate-950'
                            : 'bg-[#090f1e] border-slate-700 text-slate-300'
                        }`}
                      >
                        {mm === '1V1' ? '1v1 Düello' : '3v3 Takım'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Role Selector */}
                <div>
                  <div className="text-[11px] font-black text-slate-400 uppercase mb-1.5">MEVKİ SEÇİMİ</div>
                  <div className="flex flex-wrap gap-1.5">
                    {ROLE_LIST.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        disabled={isSearching}
                        onClick={() => handleRoleChange(r.id)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:opacity-60 ${
                          selectedRole === r.id
                            ? r.id === 'GK'
                              ? 'bg-emerald-400 border-emerald-200 text-slate-950'
                              : 'bg-sky-500 border-sky-300 text-slate-950'
                            : 'bg-[#090f1e] border-slate-700 text-slate-300'
                        }`}
                      >
                        {r.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Search / Searching Box */}
                {!isSearching ? (
                  <button
                    type="button"
                    disabled={mode === 'ws' && !connected}
                    onClick={() =>
                      onStartMatchmaking(
                        playerName.trim() || 'Egoist',
                        defaultStyle,
                        defaultFlow,
                        queueMode,
                        queueType,
                        selectedRole
                      )
                    }
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-110 disabled:opacity-45 text-slate-950 font-black text-sm py-3.5 rounded-xl shadow-[0_0_24px_rgba(251,191,36,0.35)] cursor-pointer"
                  >
                    <Search className="w-4 h-4" />
                    {queueType === 'RANKED' ? 'DERECELİ MAÇ ARA' : 'HIZLI MAÇ ARA'} ({queueMode})
                  </button>
                ) : (
                  <div className="bg-[#090f1e] border border-amber-400/60 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-black text-amber-300">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        RAKİP ARANIYOR ({matchmakingStatus?.queueType === 'RANKED' ? 'DERECELİ' : 'HIZLI'})
                      </div>
                      <span className="text-xs font-black text-white tabular-nums">
                        {matchmakingStatus?.elapsedSec ?? 0}s
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Kuyrukta {matchmakingStatus?.playersInQueue ?? 1} oyuncu · 6 sn içinde eşleşme dolmazsa AI rakiplerle otomatik başlar.
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={onForceStartMatchmaking}
                        className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs py-2.5 rounded-lg cursor-pointer"
                      >
                        HEMEN BAŞLAT
                      </button>
                      <button
                        type="button"
                        onClick={onCancelMatchmaking}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs px-4 py-2.5 rounded-lg cursor-pointer"
                      >
                        İPTAL
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Right: Live Ranked Leaderboard */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <span className="flex items-center gap-1.5 text-xs font-black tracking-wider text-amber-300">
                    <Award className="w-4 h-4" /> SUNUCU SIRALAMASI (TOP RP)
                  </span>
                  <button
                    type="button"
                    onClick={fetchLeaderboard}
                    className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Yenile
                  </button>
                </div>

                {leaderboard.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-xs text-slate-500 py-8 text-center gap-2">
                    <Trophy className="w-8 h-8 text-slate-700" />
                    <span>Henüz dereceli sıralama kaydı yok. İlk dereceli maçını oynayarak liderliğe otur!</span>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scroll pr-1">
                    {leaderboard.map((entry, idx) => {
                      const t = getRankTier(entry.rp);
                      return (
                        <div
                          key={`${entry.playerName}_${idx}`}
                          className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3.5 py-2"
                        >
                          <div className="flex items-center gap-2.5">
                            <span
                              className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black ${
                                idx === 0
                                  ? 'bg-amber-400 text-slate-950'
                                  : idx === 1
                                    ? 'bg-slate-300 text-slate-950'
                                    : idx === 2
                                      ? 'bg-orange-600 text-white'
                                      : 'bg-slate-800 text-slate-300'
                              }`}
                            >
                              {idx + 1}
                            </span>
                            <div>
                              <div className="text-xs font-black text-white">{entry.playerName}</div>
                              <div className="text-[10px] text-slate-400">
                                {STYLES[entry.favoriteStyle]?.name ?? entry.favoriteStyle} · {entry.wins}G {entry.losses}M · {entry.goals} Gol
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <span
                              className="text-[9px] font-black px-1.5 py-0.5 rounded text-slate-950 inline-block"
                              style={{ background: t.bg }}
                            >
                              {t.badgeText}
                            </span>
                            <div className="text-xs font-black text-sky-300 tabular-nums mt-0.5">
                              {entry.rp} RP
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          ) : !room ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Create / Join Box */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3.5 py-2.5">
                  <div>
                    <div className="text-[10px] font-black text-slate-400 uppercase">GRUPTA GÖRÜNECEK ADIN</div>
                    <div className="text-sm font-black text-white">{playerName}</div>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenRenameModal}
                    className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Değiştir
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] font-black text-slate-400 uppercase mb-1.5">
                    MEVKİN
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {ROLE_LIST.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => handleRoleChange(r.id)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                          selectedRole === r.id
                            ? r.id === 'GK'
                              ? 'bg-emerald-400 border-emerald-200 text-slate-950'
                              : 'bg-sky-500 border-sky-300 text-slate-950'
                            : 'bg-[#090f1e] border-slate-700 text-slate-300'
                        }`}
                      >
                        {r.name}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={mode === 'ws' && !connected}
                  onClick={() =>
                    onCreateRoom(playerName, defaultStyle, defaultFlow, defaultGk, defaultMatchMode, selectedRole)
                  }
                  className="w-full bg-sky-500 hover:bg-sky-400 disabled:opacity-45 text-slate-950 font-black text-sm py-3 rounded-xl cursor-pointer"
                >
                  YENİ GRUP ODASI KUR ({defaultMatchMode === '1V1' ? '1v1' : '3v3'})
                </button>

                <div className="pt-2 border-t border-slate-800">
                  <label className="block text-[11px] font-black text-slate-400 uppercase mb-1.5">
                    ODA KODU İLE KATIL (4 HANELİ = WS · 5 HANELİ = P2P SHARE)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={joinCode}
                      maxLength={8}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                      placeholder="KOD (ÖRN: A7B2K)"
                      className="flex-1 bg-[#090f1e] border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-sm font-black tracking-widest text-white uppercase outline-none"
                    />
                    <button
                      type="button"
                      disabled={(mode === 'ws' && !connected && joinCode.trim().length !== 5) || !joinCode.trim()}
                      onClick={() => onJoinRoom(joinCode, playerName, defaultStyle, defaultFlow, selectedRole)}
                      className="bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-slate-950 font-black text-xs px-5 rounded-xl cursor-pointer"
                    >
                      KATIL
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Panel: Instructions for P2P or Active Rooms for WS */}
              <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-5 flex flex-col">
                {mode === 'p2p' ? (
                  <div className="space-y-3">
                    <div className="text-xs font-black tracking-wider text-emerald-300">
                      SHARE LİNKİ İLE ARKADAŞINLA NASIL BAĞLANILIR?
                    </div>
                    <ol className="space-y-2 text-xs text-slate-300 leading-relaxed list-decimal list-inside">
                      <li>
                        Sen soldan <strong className="text-white">YENİ ÖZEL ODA KUR</strong> butonuna bas. 5 haneli bir P2P oda kodu açılacak.
                      </li>
                      <li>
                        Oda açılınca <strong className="text-emerald-300">Davet Linki Kopyala</strong> butonuna basıp arkadaşına at (veya Share linki + 5 haneli kodu paylaş).
                      </li>
                      <li>
                        Arkadaşın normal tarayıcıdan (Chrome/Safari — Discord içi tarayıcı değil) açıp kodu girdiğinde otomatik <strong className="text-emerald-300">P2P (Share Uyumlu)</strong> köprüsünden bağlanır!
                      </li>
                      <li>
                        Not: <code className="text-sky-300">ais-dev-</code> ile <code className="text-amber-300">ais-pre-</code> (Share) ayrı sunucularda çalıştığı için arkadaşlar arası bağlantıda üstten <strong className="text-emerald-300">P2P (Share Uyumlu)</strong> seçili olmalıdır.
                      </li>
                    </ol>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-black tracking-wider text-slate-300">
                        AÇIK ODALAR ({publicRooms.length})
                      </span>
                      <button
                        type="button"
                        onClick={fetchRooms}
                        className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Yenile
                      </button>
                    </div>

                    {publicRooms.length === 0 ? (
                      <div className="flex-1 flex items-center justify-center text-xs text-slate-500 py-8 text-center">
                        Şu anda açık özel oda yok. Yeni bir oda kurabilir veya Maç Eşleme sekmesinden hemen maça girebilirsin!
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {publicRooms.map((r) => (
                          <div
                            key={r.roomCode}
                            className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3.5 py-2.5"
                          >
                            <div>
                              <div className="text-sm font-black text-white tracking-wider">
                                ODA: {r.roomCode}
                              </div>
                              <div className="text-[11px] text-slate-400">
                                {r.matchMode === '1V1' ? '1v1' : '3v3'} · {r.playerCount}/6 Oyuncu · Kaleci: {GK_LABELS[r.gkDifficulty]}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => onJoinRoom(r.roomCode, playerName, defaultStyle, defaultFlow, selectedRole)}
                              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-3.5 py-2 rounded-lg cursor-pointer"
                            >
                              KATIL
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          ) : (
            /* INSIDE ROOM LOBBY: Every player picks Style, Flow, Role, Team; Host picks GK Difficulty & Starts */
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-[#060b16] border border-sky-500/40 rounded-2xl p-4">
                <div>
                  <div className="text-[10px] font-black text-sky-300 tracking-widest uppercase">
                    KALICI GRUP KODU (MAÇ BİTİNCE GRUPTA KALIRSINIZ · {mode === 'p2p' ? 'P2P SHARE' : 'SUNUCU WS'})
                  </div>
                  <div className="flex flex-wrap items-center gap-2 mt-0.5">
                    <span className="text-3xl font-black tracking-[0.2em] text-amber-300">
                      {room.roomCode}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 text-xs font-bold px-2.5 py-1.5 rounded-lg cursor-pointer"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCode ? 'Kopyalandı' : 'Kodu Kopyala'}
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyInviteLink}
                      className="flex items-center gap-1 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 text-xs font-bold px-2.5 py-1.5 rounded-lg cursor-pointer"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedLink ? 'Link Kopyalandı!' : 'Gruba Katılma Linki'}
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div>
                    <div className="text-[10px] font-black text-slate-400 mb-1 flex items-center gap-1">
                      <Swords className="w-3 h-3 text-amber-400" /> MOD
                    </div>
                    <div className="flex gap-1.5">
                      {(['1V1', '3V3'] as MatchMode[]).map((mm) => (
                        <button
                          key={mm}
                          type="button"
                          disabled={!isHost}
                          onClick={() => onSetMatchMode(mm)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:cursor-default ${
                            (room.matchMode ?? '3V3') === mm
                              ? 'bg-amber-400 border-amber-200 text-slate-950'
                              : 'bg-slate-900 border-slate-700 text-slate-300'
                          }`}
                        >
                          {mm === '1V1' ? '1v1' : '3v3'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] font-black text-slate-400 mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-emerald-400" /> SÜRE
                    </div>
                    <div className="flex gap-1.5">
                      {DURATION_OPTIONS.map((opt) => (
                        <button
                          key={opt.sec}
                          type="button"
                          disabled={!isHost}
                          onClick={() => onSetMatchDuration(opt.sec)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:cursor-default ${
                            (room.matchDurationSec ?? 180) === opt.sec
                              ? 'bg-emerald-400 border-emerald-200 text-slate-950'
                              : 'bg-slate-900 border-slate-700 text-slate-300'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] font-black text-slate-400 mb-1 flex items-center gap-1">
                      <Shield className="w-3 h-3 text-sky-400" /> AI KALECİ
                    </div>
                    <div className="flex gap-1.5">
                      {(['EASY', 'MEDIUM', 'HARD'] as GkDifficulty[]).map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          disabled={!isHost}
                          onClick={() => onSetGk(lvl)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-black border cursor-pointer disabled:cursor-default ${
                            room.gkDifficulty === lvl
                              ? 'bg-sky-500 border-sky-300 text-slate-950'
                              : 'bg-slate-900 border-slate-700 text-slate-300'
                          }`}
                        >
                          {GK_LABELS[lvl]}
                        </button>
                      ))}
                    </div>
                  </div>

                  {isHost && (
                    <button
                      type="button"
                      onClick={onStartOnlineMatch}
                      className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm px-6 py-3 rounded-xl cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-slate-950" /> MAÇI BAŞLAT
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={onLeaveRoom}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs px-4 py-3 rounded-xl cursor-pointer"
                  >
                    GRUPTAN ÇIK
                  </button>
                </div>
              </div>

              {/* Pick Your Own Character Style & Team */}
              {me && (
                <div className="bg-[#060b16] border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-black text-white">
                      KARAKTERİNİ VE TAKIMINI SEÇ
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onUpdatePlayer({ team: 'BLUE' })}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                          me.team === 'BLUE'
                            ? 'bg-sky-500 border-sky-300 text-slate-950'
                            : 'bg-slate-900 border-slate-700 text-slate-300'
                        }`}
                      >
                        MAVİ TAKIM
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdatePlayer({ team: 'RED' })}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black border cursor-pointer ${
                          me.team === 'RED'
                            ? 'bg-red-500 border-red-300 text-white'
                            : 'bg-slate-900 border-slate-700 text-slate-300'
                        }`}
                      >
                        KIRMIZI TAKIM
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2">
                    {STYLE_LIST.map((s) => {
                      const active = me.styleId === s.id;
                      const r = RARITY_COLORS[s.rarity];
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => onUpdatePlayer({ styleId: s.id })}
                          className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                            active
                              ? 'bg-slate-800 border-amber-400'
                              : 'bg-[#090f1e] hover:bg-slate-800/70 border-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs text-white">{s.name}</span>
                            <span
                              className="w-3 h-3 rounded-full border border-white/30"
                              style={{ backgroundColor: s.primaryColor }}
                            />
                          </div>
                          <div
                            className="text-[9px] font-black px-1.5 py-0.5 rounded text-slate-950 inline-block mt-1"
                            style={{ background: r.badgeBg }}
                          >
                            {s.rarity}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] font-bold text-slate-400">FLOW:</span>
                    {Object.values(FLOWS).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => onUpdatePlayer({ flowId: f.id })}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer ${
                          me.flowId === f.id
                            ? 'bg-purple-500 border-purple-300 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        {f.name}
                      </button>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] font-bold text-emerald-300">MEVKİ:</span>
                    {ROLE_LIST.map((r) => {
                      const active = (me.role ?? 'CF') === r.id;
                      return (
                        <button
                          key={r.id}
                          type="button"
                          onClick={() => {
                            handleRoleChange(r.id);
                            onUpdatePlayer({ role: r.id });
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-black border cursor-pointer ${
                            active
                              ? r.id === 'GK'
                                ? 'bg-emerald-400 border-emerald-200 text-slate-950'
                                : 'bg-sky-500 border-sky-300 text-slate-950'
                              : 'bg-slate-900 border-slate-800 text-slate-400'
                          }`}
                        >
                          {r.name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Connected Roster */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(['BLUE', 'RED'] as const).map((team) => {
                  const list = room.players.filter((p) => p.team === team);
                  return (
                    <div
                      key={team}
                      className={`rounded-2xl p-4 border ${
                        team === 'BLUE'
                          ? 'bg-sky-950/25 border-sky-500/40'
                          : 'bg-red-950/25 border-red-500/40'
                      }`}
                    >
                      <div className="text-xs font-black tracking-wider mb-2.5 text-white">
                        {team === 'BLUE' ? 'MAVİ TAKIM (MÜMİNRIVALS)' : 'KIRMIZI TAKIM (RAKİPLER)'}
                      </div>
                      <div className="space-y-2">
                        {list.length === 0 ? (
                          <div className="text-xs text-slate-500">Boş slotlar AI bot ile doldurulur.</div>
                        ) : (
                          list.map((p) => {
                            const st = STYLES[p.styleId];
                            const roleInfo = ROLES[p.role ?? 'CF'];
                            return (
                              <div
                                key={p.clientId}
                                className="flex items-center justify-between bg-[#090f1e] border border-slate-800 rounded-xl px-3 py-2"
                              >
                                <div className="flex items-center gap-2">
                                  {p.isHost && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                                  <span className="text-xs font-black text-white">{p.name}</span>
                                  {p.clientId === clientId && (
                                    <span className="text-[10px] font-bold text-sky-300">(Sen)</span>
                                  )}
                                  <span
                                    className="text-[9px] font-black px-1.5 py-0.5 rounded text-slate-950"
                                    style={{ backgroundColor: roleInfo.accentColor }}
                                  >
                                    {roleInfo.shortLabel}
                                  </span>
                                </div>
                                <div className="text-xs font-black text-amber-300">
                                  {PLAYER_CARD_META[p.styleId].ovr} OVR · {st.name} · {FLOWS[p.flowId].name}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Group Live Text & Voice Chat */}
              <div className="h-72">
                <ChatVoicePanel
                  messages={chatMessages}
                  voicePeers={voicePeers}
                  selfId={clientId}
                  voiceStatus={voiceStatus}
                  onSendChat={onSendChat}
                  onToggleVoice={onToggleVoice}
                  onToggleMute={onToggleMute}
                  onToggleDeafen={onToggleDeafen}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
