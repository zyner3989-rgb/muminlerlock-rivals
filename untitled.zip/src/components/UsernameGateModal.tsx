import { useEffect, useRef, useState, type FormEvent } from 'react';
import { UserCheck, X } from 'lucide-react';

interface UsernameGateModalProps {
  initialName: string;
  canClose?: boolean;
  onConfirm: (name: string) => void;
  onClose?: () => void;
}

export function UsernameGateModal({
  initialName,
  canClose = false,
  onConfirm,
  onClose,
}: UsernameGateModalProps) {
  const [value, setValue] = useState(initialName === 'Egoist' ? '' : initialName);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleaned = value.trim().slice(0, 14);
    if (cleaned.length < 2) {
      setError('Lütfen en az 2 karakterli bir kullanıcı adı gir.');
      return;
    }
    setError(null);
    onConfirm(cleaned);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#040711]/95 p-4">
      <div className="w-full max-w-md bg-[#090f1e] border border-sky-500/45 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#050811]">
          <div>
            <h2 className="text-lg font-black tracking-wide text-white">
              MÜMİNRIVALS&apos;A HOŞ GELDİN
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Adınız sahada başınızın üstünde ve tüm çevrimiçi odalarda otomatik görünür.
            </p>
          </div>
          {canClose && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Kapat"
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label
              htmlFor="mumin-username-input"
              className="block text-xs font-bold text-sky-300 mb-2"
            >
              Adınızı Giriniz (2–14 karakter)
            </label>
            <input
              id="mumin-username-input"
              ref={inputRef}
              type="text"
              maxLength={14}
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                if (error) setError(null);
              }}
              onKeyDown={(e) => e.stopPropagation()}
              placeholder="Örn: MusabPro"
              className="w-full bg-[#050811] border border-slate-700 focus:border-sky-400 rounded-xl px-4 py-3 text-base font-bold text-white outline-none"
            />
            {error && <p className="text-xs font-semibold text-red-400 mt-2">{error}</p>}
          </div>

          <button
            type="submit"
            disabled={value.trim().length < 2}
            className="w-full flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-400 disabled:opacity-45 text-slate-950 font-black text-sm py-3.5 rounded-xl cursor-pointer transition-colors"
          >
            <UserCheck className="w-4 h-4" />
            {canClose ? 'ADIMI KAYDET' : 'ARENAYA GİR'}
          </button>
        </form>
      </div>
    </div>
  );
}
