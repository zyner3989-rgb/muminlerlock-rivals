import { useEffect, useRef, useState, type FormEvent } from 'react';
import { HeadphoneOff, Headphones, MessageSquare, Mic, MicOff, PhoneOff, Send, Volume2, X } from 'lucide-react';
import type { ChatMessage, VoicePeerState } from '../types/game';

interface VoiceStatus {
  joined: boolean;
  muted: boolean;
  deafened: boolean;
  speaking: boolean;
  error: string | null;
}

interface ChatVoicePanelProps {
  messages: ChatMessage[];
  voicePeers: VoicePeerState[];
  selfId: string | null;
  voiceStatus: VoiceStatus;
  onSendChat: (text: string) => void;
  onToggleVoice: () => void;
  onToggleMute: () => void;
  onToggleDeafen: () => void;
  compact?: boolean;
  onClose?: () => void;
}

export function ChatVoicePanel({
  messages,
  voicePeers,
  selfId,
  voiceStatus,
  onSendChat,
  onToggleVoice,
  onToggleMute,
  onToggleDeafen,
  compact = false,
  onClose,
}: ChatVoicePanelProps) {
  const [draft, setDraft] = useState('');
  const listRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const el = listRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages.length]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleaned = draft.trim();
    if (!cleaned) return;
    onSendChat(cleaned);
    setDraft('');
  };

  return (
    <div
      className={`flex flex-col bg-[#060b16] border border-slate-700/90 rounded-2xl overflow-hidden shadow-2xl ${
        compact ? 'w-80 max-w-[calc(100vw-2rem)] h-80' : 'w-full h-full min-h-[260px]'
      }`}
    >
      {/* Header & Voice Controls */}
      <div className="px-3.5 py-2.5 bg-[#090f1e] border-b border-slate-800 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-black text-white">
            <MessageSquare className="w-4 h-4 text-sky-400" />
            <span>GRUP SOHBET &amp; SES</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onToggleVoice}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-black cursor-pointer transition-colors ${
                voiceStatus.joined
                  ? 'bg-red-500/20 hover:bg-red-500/30 border border-red-400/60 text-red-200'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
              }`}
            >
              {voiceStatus.joined ? (
                <>
                  <PhoneOff className="w-3.5 h-3.5" />
                  Sesten Çık
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  Sesliye Katıl
                </>
              )}
            </button>

            {voiceStatus.joined && (
              <>
                <button
                  type="button"
                  onClick={onToggleMute}
                  aria-label={voiceStatus.muted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat'}
                  className={`p-1.5 rounded-lg border cursor-pointer ${
                    voiceStatus.muted
                      ? 'bg-red-500/25 border-red-400/60 text-red-200'
                      : 'bg-slate-800 border-slate-600 text-emerald-300 hover:bg-slate-700'
                  }`}
                >
                  {voiceStatus.muted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={onToggleDeafen}
                  aria-label={voiceStatus.deafened ? 'Sesi Aç' : 'Sesi Kapat'}
                  className={`p-1.5 rounded-lg border cursor-pointer ${
                    voiceStatus.deafened
                      ? 'bg-amber-500/25 border-amber-400/60 text-amber-200'
                      : 'bg-slate-800 border-slate-600 text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  {voiceStatus.deafened ? (
                    <HeadphoneOff className="w-3.5 h-3.5" />
                  ) : (
                    <Headphones className="w-3.5 h-3.5" />
                  )}
                </button>
              </>
            )}

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                aria-label="Sohbeti Kapat"
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {voiceStatus.error && (
          <div className="text-[11px] font-semibold text-red-300 bg-red-950/60 border border-red-500/40 rounded-lg px-2.5 py-1.5">
            {voiceStatus.error}
          </div>
        )}

        {voicePeers.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-300">
            <span className="font-bold text-slate-400">Ses Kanalı ({voicePeers.length}):</span>
            {voicePeers.map((vp) => (
              <span
                key={vp.clientId}
                className={`inline-flex items-center gap-1 font-bold ${
                  vp.speaking && !vp.muted
                    ? 'text-emerald-300'
                    : vp.muted
                      ? 'text-slate-400'
                      : 'text-slate-200'
                }`}
              >
                {vp.muted ? <MicOff className="w-3 h-3 text-red-400" /> : <Mic className="w-3 h-3" />}
                <span>
                  {vp.name}
                  {vp.clientId === selfId ? ' (Sen)' : ''}
                </span>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Chat Messages */}
      <div
        ref={listRef}
        className={`flex-1 overflow-y-auto custom-scroll px-3.5 py-2.5 space-y-2 ${
          compact ? 'max-h-48' : 'max-h-60'
        }`}
      >
        {messages.length === 0 ? (
          <div className="text-xs text-slate-500 py-4 text-center">
            Henüz mesaj yok. Takım arkadaşlarına yazabilir veya sesli sohbete bağlanabilirsin.
          </div>
        ) : (
          messages.map((m) => {
            const time = new Date(m.timestamp).toLocaleTimeString('tr-TR', {
              hour: '2-digit',
              minute: '2-digit',
            });
            if (m.system) {
              return (
                <div key={m.id} className="text-[11px] text-amber-300/90 font-semibold">
                  <span className="text-slate-500 mr-1.5 tabular-nums">{time}</span>
                  <span>{m.text}</span>
                </div>
              );
            }
            const nameColor =
              m.team === 'BLUE'
                ? 'text-sky-300'
                : m.team === 'RED'
                  ? 'text-rose-300'
                  : 'text-emerald-300';
            return (
              <div key={m.id} className="text-xs leading-relaxed break-words">
                <span className="text-[10px] text-slate-500 mr-1.5 tabular-nums">{time}</span>
                <span className={`font-black mr-1.5 ${nameColor}`}>{m.senderName}:</span>
                <span className="text-slate-100">{m.text}</span>
              </div>
            );
          })
        )}
      </div>

      {/* Composer */}
      <form onSubmit={handleSubmit} className="p-2.5 border-t border-slate-800 bg-[#090f1e] flex gap-2">
        <input
          ref={inputRef}
          type="text"
          maxLength={220}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === 'Escape') {
              inputRef.current?.blur();
              if (compact && onClose) onClose();
            }
          }}
          placeholder="Mesaj yaz..."
          className="flex-1 bg-[#050811] border border-slate-700 focus:border-sky-400 rounded-xl px-3 py-2 text-xs text-white outline-none"
        />
        <button
          type="submit"
          disabled={!draft.trim()}
          aria-label="Mesaj Gönder"
          className="bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-slate-950 font-black px-3 py-2 rounded-xl cursor-pointer flex items-center justify-center"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}
