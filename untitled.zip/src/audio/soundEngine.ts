import { TURKISH_VOICE_SCRIPTS } from '../data/voiceScripts';
import type { StyleId } from '../types/game';

const ALL_VOICED_STYLE_IDS: StyleId[] = [
  'musab',
  'musa',
  'iskender',
  'aras',
  'ebulfez',
  'zero',
  'berk',
  'esref_tek',
  'arap_kavuncu',
  'hamzac5',
  'memud',
  'umidi',
];
const DYNAMIC_VOICE_STYLE_IDS: StyleId[] = ALL_VOICED_STYLE_IDS;

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private voiceGain: GainNode | null = null;
  private busOut: AudioNode | null = null;
  private duckTimeout: number | null = null;
  private muted = false;
  private masterVolume = 0.9;

  private voiceBufferCache = new Map<string, AudioBuffer>();
  private voiceFetchPromises = new Map<string, Promise<AudioBuffer | null>>();
  private voiceUnavailableKeys = new Set<string>();
  private activeVoiceSource: AudioBufferSourceNode | null = null;
  private activeHtmlAudio: HTMLAudioElement | null = null;
  private activeVoiceTimeout: number | null = null;
  private voicePlayNonce = 0;
  private rainSource: AudioBufferSourceNode | null = null;
  private rainGain: GainNode | null = null;
  private preloaded = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const unlockOnce = () => {
        this.unlock();
      };
      window.addEventListener('pointerdown', unlockOnce, { passive: true });
      window.addEventListener('keydown', unlockOnce, { passive: true });
    }
  }

  public unlock() {
    if (this.muted || typeof window === 'undefined') return;
    const ctx = this.ensureContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.getVoices();
      } catch {
        // ignore
      }
    }
    if (!this.preloaded) {
      this.preloaded = true;
      this.preloadCutsceneVoices();
    }
  }

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const compressor = ctx.createDynamicsCompressor();
        compressor.threshold.setValueAtTime(-16, ctx.currentTime);
        compressor.knee.setValueAtTime(16, ctx.currentTime);
        compressor.ratio.setValueAtTime(3.2, ctx.currentTime);
        compressor.attack.setValueAtTime(0.005, ctx.currentTime);
        compressor.release.setValueAtTime(0.2, ctx.currentTime);

        const sfxMaster = ctx.createGain();
        sfxMaster.gain.setValueAtTime(this.muted ? 0.0001 : 1.15 * this.masterVolume, ctx.currentTime);
        sfxMaster.connect(compressor);
        compressor.connect(ctx.destination);

        // Dedicated uncompressed bus for dialogue so impacts never squash voice clarity
        const voiceBus = ctx.createGain();
        voiceBus.gain.setValueAtTime(this.muted ? 0.0001 : 1.85 * this.masterVolume, ctx.currentTime);
        voiceBus.connect(ctx.destination);

        this.ctx = ctx;
        this.masterGain = sfxMaster;
        this.voiceGain = voiceBus;
        this.busOut = sfxMaster;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getOutputNode(ctx: AudioContext): AudioNode {
    return this.busOut ?? ctx.destination;
  }

  private getVoiceOutputNode(ctx: AudioContext): AudioNode {
    return this.voiceGain ?? ctx.destination;
  }

  public duckSfx(durationSec = 3.5, level = 0.36) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || this.muted) return;
    const now = ctx.currentTime;
    const normal = 1.15 * this.masterVolume;
    const ducked = normal * Math.max(0.18, Math.min(0.85, level));
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.setTargetAtTime(ducked, now, 0.04);
    this.masterGain.gain.setTargetAtTime(normal, now + Math.max(0.4, durationSec), 0.16);
    if (typeof window !== 'undefined') {
      if (this.duckTimeout !== null) window.clearTimeout(this.duckTimeout);
      this.duckTimeout = window.setTimeout(() => {
        this.duckTimeout = null;
        if (!this.muted && this.masterGain && this.ctx) {
          this.masterGain.gain.setTargetAtTime(1.15 * this.masterVolume, this.ctx.currentTime, 0.08);
        }
      }, Math.round((durationSec + 0.4) * 1000));
    }
  }

  private getNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const len = ctx.sampleRate * 1.5;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buf;
  }

  private clipKey(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO'): string {
    if (kind === 'COMBO') return 'musab_musa_combo';
    return `${styleId}_${kind === 'AWAKENING' ? 'awakening' : 'ulti'}`;
  }

  private clipUrl(key: string): string {
    return `/api/voice/${encodeURIComponent(key)}?v=2`;
  }

  private loadVoiceBuffer(key: string, styleId?: StyleId): Promise<AudioBuffer | null> {
    const cached = this.voiceBufferCache.get(key);
    if (cached) return Promise.resolve(cached);
    if (this.voiceUnavailableKeys.has(key)) return Promise.resolve(null);
    const existing = this.voiceFetchPromises.get(key);
    if (existing) return existing;

    const ctx = this.ensureContext();
    if (!ctx) return Promise.resolve(null);

    const p = fetch(this.clipUrl(key))
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.arrayBuffer();
      })
      .then((arr) => ctx.decodeAudioData(arr))
      .then((decoded) => {
        this.voiceBufferCache.set(key, decoded);
        return decoded;
      })
      .catch(() => {
        if (!styleId || DYNAMIC_VOICE_STYLE_IDS.includes(styleId)) {
          this.voiceUnavailableKeys.add(key);
        }
        return null;
      })
      .finally(() => {
        this.voiceFetchPromises.delete(key);
      });

    this.voiceFetchPromises.set(key, p);
    return p;
  }

  public preloadCutsceneVoices() {
    if (typeof window === 'undefined' || this.muted) return;
    for (const styleId of ALL_VOICED_STYLE_IDS) {
      void this.loadVoiceBuffer(this.clipKey(styleId, 'AWAKENING'), styleId);
      void this.loadVoiceBuffer(this.clipKey(styleId, 'ULTI'), styleId);
    }
    void this.loadVoiceBuffer('musab_musa_combo');
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (muted) {
      this.stopCutsceneAudio();
      this.setRainAmbiance(false);
      if (this.masterGain && this.ctx) {
        this.masterGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);
      }
      if (this.voiceGain && this.ctx) {
        this.voiceGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);
      }
    } else if (this.ctx) {
      if (this.masterGain) {
        this.masterGain.gain.setValueAtTime(1.15 * this.masterVolume, this.ctx.currentTime);
      }
      if (this.voiceGain) {
        this.voiceGain.gain.setValueAtTime(1.85 * this.masterVolume, this.ctx.currentTime);
      }
    }
  }

  public setMasterVolume(percent: number) {
    this.masterVolume = Math.max(0, Math.min(1, percent / 100));
    if (!this.muted && this.ctx) {
      if (this.masterGain) {
        this.masterGain.gain.setValueAtTime(1.15 * this.masterVolume, this.ctx.currentTime);
      }
      if (this.voiceGain) {
        this.voiceGain.gain.setValueAtTime(1.85 * this.masterVolume, this.ctx.currentTime);
      }
    }
    if (this.activeHtmlAudio) {
      this.activeHtmlAudio.volume = Math.min(1, this.masterVolume);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public stopCutsceneAudio() {
    this.voicePlayNonce++;
    if (this.activeVoiceTimeout !== null && typeof window !== 'undefined') {
      window.clearTimeout(this.activeVoiceTimeout);
      this.activeVoiceTimeout = null;
    }
    if (this.activeVoiceSource) {
      try {
        this.activeVoiceSource.stop();
      } catch {
        // ignore
      }
      this.activeVoiceSource = null;
    }
    if (this.activeHtmlAudio) {
      try {
        this.activeHtmlAudio.pause();
        this.activeHtmlAudio.currentTime = 0;
      } catch {
        // ignore
      }
      this.activeHtmlAudio = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
    }
  }

  public stopSpeech() {
    this.stopCutsceneAudio();
  }

  private pickMaleTurkishVoice(): SpeechSynthesisVoice | null {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    const trVoices = voices.filter((v) => v.lang.toLowerCase().startsWith('tr'));
    if (trVoices.length === 0) return null;

    const maleHint = /ahmet|mehmet|emre|tolga|cem|yusuf|mustafa|deniz|ali|can|male|erkek|google türkçe/i;
    const femaleHint = /emel|yelda|filiz|seda|leyla|zeynep|ayşe|female|kadın/i;
    return (
      trVoices.find((v) => maleHint.test(v.name) && !femaleHint.test(v.name)) ??
      trVoices.find((v) => !femaleHint.test(v.name)) ??
      trVoices[0]
    );
  }

  private playAnimeMaleKiai(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO', delaySec: number) {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    const out = this.getVoiceOutputNode(ctx);
    const t0 = ctx.currentTime + Math.max(0, delaySec);

    // Distinct deep shonen male formant frequencies per character
    const basePitch =
      styleId === 'esref_tek'
        ? 112
        : styleId === 'memud'
          ? 118
          : styleId === 'umidi'
            ? 124
            : styleId === 'arap_kavuncu'
              ? 126
              : 138;
    const peakPitch = kind !== 'AWAKENING' ? basePitch * 1.42 : basePitch * 1.24;
    const dur = kind !== 'AWAKENING' ? 0.62 : 0.48;

    const glottal = ctx.createOscillator();
    glottal.type = 'sawtooth';
    glottal.frequency.setValueAtTime(basePitch * 0.92, t0);
    glottal.frequency.exponentialRampToValueAtTime(peakPitch, t0 + dur * 0.35);
    glottal.frequency.exponentialRampToValueAtTime(basePitch * 1.05, t0 + dur);

    // Subtle vocal vibrato
    const vib = ctx.createOscillator();
    const vibGain = ctx.createGain();
    vib.frequency.setValueAtTime(6.2, t0);
    vibGain.gain.setValueAtTime(3.8, t0);
    vib.connect(vibGain);
    vibGain.connect(glottal.frequency);

    // Parallel vocal tract formants (F1 + F2 for strong "HA!" / "ORYA!" male vowel resonance)
    const f1 = ctx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.setValueAtTime(640, t0);
    f1.frequency.linearRampToValueAtTime(780, t0 + dur * 0.5);
    f1.Q.setValueAtTime(5.2, t0);

    const f2 = ctx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.setValueAtTime(1180, t0);
    f2.frequency.linearRampToValueAtTime(1380, t0 + dur * 0.5);
    f2.Q.setValueAtTime(6.5, t0);

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.001, t0);
    env.gain.linearRampToValueAtTime(0.28, t0 + 0.05);
    env.gain.setValueAtTime(0.24, t0 + dur * 0.55);
    env.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

    glottal.connect(f1);
    glottal.connect(f2);
    f1.connect(env);
    f2.connect(env);
    env.connect(out);

    glottal.start(t0);
    vib.start(t0);
    glottal.stop(t0 + dur + 0.03);
    vib.stop(t0 + dur + 0.03);
  }

  private playAnimeMaleFallback(
    styleId: StyleId,
    key: string,
    kind: 'AWAKENING' | 'ULTI' | 'COMBO',
    delaySec: number,
    nonce: number
  ) {
    if (this.muted || nonce !== this.voicePlayNonce || typeof window === 'undefined') return;
    this.playAnimeMaleKiai(styleId, kind, delaySec);

    const spec = TURKISH_VOICE_SCRIPTS[key];
    if (spec && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(spec.text);
        utter.lang = 'tr-TR';
        const chosenVoice = this.pickMaleTurkishVoice();
        const looksFemale = chosenVoice ? /emel|yelda|filiz|seda|leyla|zeynep|ayşe|female|kadın/i.test(chosenVoice.name) : false;
        if (chosenVoice) {
          utter.voice = chosenVoice;
        }
        utter.pitch = looksFemale
          ? Math.max(0.62, spec.pitchFallback * 0.72)
          : Math.max(0.75, spec.pitchFallback * 0.92);
        utter.rate = spec.rateFallback;
        utter.volume = Math.min(1, this.masterVolume);
        this.activeVoiceTimeout = window.setTimeout(() => {
          this.activeVoiceTimeout = null;
          if (!this.muted && nonce === this.voicePlayNonce) {
            try {
              window.speechSynthesis.speak(utter);
            } catch {
              // ignore
            }
          }
        }, Math.round(delaySec * 1000));
      } catch {
        // ignore
      }
    }
  }

  private playDecodedVoiceBuffer(ctx: AudioContext, buf: AudioBuffer, delaySec: number) {
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(1.18, ctx.currentTime);
    src.connect(gain);
    gain.connect(this.getVoiceOutputNode(ctx));
    const startAt = ctx.currentTime + Math.max(0, delaySec);
    src.start(startAt);
    this.duckSfx(Math.min(5.2, buf.duration + 0.15), 0.34);
    src.onended = () => {
      if (this.activeVoiceSource === src) {
        this.activeVoiceSource = null;
      }
    };
    this.activeVoiceSource = src;
  }

  /**
   * Plays the pre-mastered or Gemini-synthesized Anime Male voice clip
   * on an uncompressed voice bus while softly ducking background SFX.
   */
  public playCutsceneVoice(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO', delaySec = 0.04) {
    if (this.muted || typeof window === 'undefined') return;
    this.stopCutsceneAudio();
    const nonce = this.voicePlayNonce;

    const key = this.clipKey(styleId, kind);
    const ctx = this.ensureContext();
    const cached = this.voiceBufferCache.get(key);

    if (ctx && cached) {
      this.playDecodedVoiceBuffer(ctx, cached, delaySec);
      return;
    }

    if (this.voiceUnavailableKeys.has(key)) {
      this.playAnimeMaleFallback(styleId, key, kind, delaySec, nonce);
      return;
    }
    void this.loadVoiceBuffer(key, styleId).then((decoded) => {
      if (this.muted || nonce !== this.voicePlayNonce) return;
      const activeCtx = this.ensureContext();
      if (activeCtx && decoded) {
        this.playDecodedVoiceBuffer(activeCtx, decoded, 0.02);
      } else {
        this.playAnimeMaleFallback(styleId, key, kind, 0.02, nonce);
      }
    });
  }

  /**
   * Cinematic Blue Lock sub-bass boom + heartbeat + aura sweep paired with the real anime male voice!
   */
  public playAnimeAwakeningIntro(styleId: StyleId, kind: 'AWAKENING' | 'ULTI' | 'COMBO') {
    this.unlock();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    // 1. Deep Heartbeat Double-Thump (kept punchy but below dialogue threshold)
    [0, 0.16].forEach((offset, idx) => {
      const hb = ctx.createOscillator();
      const hg = ctx.createGain();
      hb.type = 'sine';
      hb.frequency.setValueAtTime(idx === 0 ? 86 : 104, now + offset);
      hb.frequency.exponentialRampToValueAtTime(30, now + offset + 0.14);
      hg.gain.setValueAtTime(idx === 0 ? 0.34 : 0.4, now + offset);
      hg.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.16);
      hb.connect(hg);
      hg.connect(out);
      hb.start(now + offset);
      hb.stop(now + offset + 0.17);
    });

    // 2. Crisp Aura Wind Whoosh underneath voice
    const noise = ctx.createBufferSource();
    noise.buffer = this.getNoiseBuffer(ctx);
    const sweep = ctx.createBiquadFilter();
    sweep.type = 'bandpass';
    sweep.Q.setValueAtTime(2.0, now);
    sweep.frequency.setValueAtTime(220, now);
    sweep.frequency.exponentialRampToValueAtTime(2400, now + 0.5);
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.01, now);
    ng.gain.linearRampToValueAtTime(0.16, now + 0.25);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    noise.connect(sweep);
    sweep.connect(ng);
    ng.connect(out);
    noise.start(now);
    noise.stop(now + 0.68);

    // 3. Play real anime male seiyuu voice clip on uncompressed voice bus immediately!
    this.playCutsceneVoice(styleId, kind, 0.04);

    // 4. Cinematic Bass Drop at 0.36s (subtler so voice stays crisp)
    const drop = ctx.createOscillator();
    const dropGain = ctx.createGain();
    drop.type = 'sine';
    drop.frequency.setValueAtTime(kind !== 'AWAKENING' ? 140 : 122, now + 0.36);
    drop.frequency.exponentialRampToValueAtTime(28, now + 1.1);
    dropGain.gain.setValueAtTime(0.001, now + 0.35);
    dropGain.gain.linearRampToValueAtTime(0.32, now + 0.4);
    dropGain.gain.exponentialRampToValueAtTime(0.001, now + 1.15);
    drop.connect(dropGain);
    dropGain.connect(out);
    drop.start(now + 0.35);
    drop.stop(now + 1.18);
  }

  public playKick(power = 0.6) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    const startFreq = 140 + power * 90;
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.14);

    gain.gain.setValueAtTime(0.32 + power * 0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playWhistle() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(2850, now);

    lfo.frequency.setValueAtTime(42, now);
    lfoGain.gain.setValueAtTime(140, now);
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.03);
    gain.gain.setValueAtTime(0.18, now + 0.28);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    lfo.start(now);
    osc.stop(now + 0.44);
    lfo.stop(now + 0.44);
  }

  public playSkill(pitch = 420) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(pitch, now);
    osc.frequency.exponentialRampToValueAtTime(pitch * 2.1, now + 0.18);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.23);
  }

  public playAwakeningBoom() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(150, now);
    sub.frequency.exponentialRampToValueAtTime(28, now + 0.8);
    subGain.gain.setValueAtTime(0.55, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    sub.connect(subGain);
    subGain.connect(out);
    sub.start(now);
    sub.stop(now + 0.88);
  }

  public playSnap() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.1);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.012));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2450, now);
    filter.Q.setValueAtTime(2.2, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.85, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    noise.start(now);
  }

  public playThanosSnap() {
    this.playSnap();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(120, now + 0.02);
    sub.frequency.exponentialRampToValueAtTime(26, now + 0.95);
    subGain.gain.setValueAtTime(0.65, now + 0.02);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.98);
    sub.connect(subGain);
    subGain.connect(out);
    sub.start(now + 0.02);
    sub.stop(now + 1.0);
  }

  public playPhoneRing() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [0, 0.26].forEach((offset) => {
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc2.type = 'sine';
      osc.frequency.setValueAtTime(1180, now + offset);
      osc2.frequency.setValueAtTime(1480, now + offset);
      gain.gain.setValueAtTime(0.16, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.19);
      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(out);
      osc.start(now + offset);
      osc2.start(now + offset);
      osc.stop(now + offset + 0.2);
      osc2.stop(now + offset + 0.2);
    });
  }

  public playPhonePickup() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(860, now);
    osc.frequency.setValueAtTime(1320, now + 0.05);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playCensorBeep() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, now);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.setValueAtTime(0.24, now + 0.42);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.52);
  }

  public playSnore() {
    // Kept subtle so it never clashes with the real voice clip
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(92, now);
    osc.frequency.linearRampToValueAtTime(72, now + 0.35);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.44);
  }

  public playHorrorMonitorBurst() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const bufSize = Math.floor(ctx.sampleRate * 0.25);
    const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < bufSize; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.06));
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(2000, now);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.45, now);
    src.connect(hp);
    hp.connect(g);
    g.connect(out);
    src.start(now);
  }

  public playDeskThud() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.14);
    gain.gain.setValueAtTime(0.48, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playPillowTransform() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(860, now + 0.32);
    gain.gain.setValueAtTime(0.32, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  public playTeleportWhoosh() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(1450, now + 0.16);
    osc.frequency.exponentialRampToValueAtTime(170, now + 0.38);
    gain.gain.setValueAtTime(0.38, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.44);
  }

  public playBurgerSplat() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.16);
    gain.gain.setValueAtTime(0.34, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.19);
  }

  public playAiHackComplete() {
    this.playGlitchBeep();
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [660, 880, 1100, 1320].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + 0.16 + i * 0.055);
      gain.gain.setValueAtTime(0.16, now + 0.16 + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16 + i * 0.055 + 0.15);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + 0.16 + i * 0.055);
      osc.stop(now + 0.16 + i * 0.055 + 0.17);
    });
  }

  public playGlitchBeep() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const freqs = [520, 880, 1240, 1760];
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(f, now + i * 0.045);
      gain.gain.setValueAtTime(0.1, now + i * 0.045);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.04);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.045);
      osc.stop(now + i * 0.045 + 0.045);
    });
  }

  public playGoalHorn() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const freqs = [196, 246.94, 293.66, 392];
    freqs.forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.06);
      gain.gain.setValueAtTime(0.12, now + 0.55);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.05);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now);
      osc.stop(now + 1.1);
    });
  }

  public playSpinTick(isFinal = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = isFinal ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(isFinal ? 880 : 620, now);
    if (isFinal) {
      osc.frequency.exponentialRampToValueAtTime(1320, now + 0.25);
    }
    gain.gain.setValueAtTime(isFinal ? 0.26 : 0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isFinal ? 0.35 : 0.04));
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + (isFinal ? 0.36 : 0.05));
  }

  public playPostClang() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [420, 685, 1120].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.22 / (i + 1), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now);
      osc.stop(now + 0.46);
    });
  }

  public playSlide() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.24);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(950, now);
    filter.frequency.exponentialRampToValueAtTime(280, now + 0.24);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    noise.start(now);
  }

  public playCrowdCheer() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    // Swelling stadium crowd roar
    const buf = this.getNoiseBuffer(ctx);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(650, now);
    bp.frequency.linearRampToValueAtTime(1250, now + 0.45);
    bp.frequency.exponentialRampToValueAtTime(480, now + 2.3);
    bp.Q.setValueAtTime(0.85, now);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.42, now + 0.25);
    g.gain.setValueAtTime(0.38, now + 1.1);
    g.gain.exponentialRampToValueAtTime(0.001, now + 2.4);

    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start(now);
    src.stop(now + 2.45);
  }

  public setRainAmbiance(active: boolean) {
    if (!active || this.muted) {
      if (this.rainSource) {
        try {
          this.rainSource.stop();
        } catch {
          // ignore
        }
        this.rainSource = null;
        this.rainGain = null;
      }
      return;
    }
    if (this.rainSource) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const src = ctx.createBufferSource();
    src.buffer = this.getNoiseBuffer(ctx);
    src.loop = true;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1800, ctx.currentTime);
    bp.Q.setValueAtTime(0.65, ctx.currentTime);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.055, ctx.currentTime);
    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start();
    this.rainSource = src;
    this.rainGain = g;
  }

  public playEmoteChime() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.055);
      gain.gain.setValueAtTime(0.16, now + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.22);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.055);
      osc.stop(now + i * 0.055 + 0.24);
    });
  }

  public playAwakenedImpact() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.26);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(gain);
    gain.connect(out);
    osc.start(now);
    osc.stop(now + 0.3);
  }

  public playPassRequestCall() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;
    [980, 1460].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      gain.gain.setValueAtTime(0.001, now + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.24, now + idx * 0.08 + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.12);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.13);
    });
  }

  public playWaterSquirt() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    const src = ctx.createBufferSource();
    src.buffer = this.getNoiseBuffer(ctx);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1400, now);
    bp.frequency.exponentialRampToValueAtTime(3400, now + 0.16);
    bp.frequency.exponentialRampToValueAtTime(950, now + 0.36);
    bp.Q.setValueAtTime(2.6, now);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.01, now);
    g.gain.linearRampToValueAtTime(0.45, now + 0.05);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start(now);
    src.stop(now + 0.44);
  }

  public playPackOpen() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const out = this.getOutputNode(ctx);
    const now = ctx.currentTime;

    // Foil rip + iconic walkout sparkle chord
    const rip = ctx.createBufferSource();
    rip.buffer = this.getNoiseBuffer(ctx);
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(1900, now);
    const rg = ctx.createGain();
    rg.gain.setValueAtTime(0.32, now);
    rg.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    rip.connect(hp);
    hp.connect(rg);
    rg.connect(out);
    rip.start(now);
    rip.stop(now + 0.24);

    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + 0.12 + idx * 0.06);
      g.gain.setValueAtTime(0.001, now + 0.12 + idx * 0.06);
      g.gain.linearRampToValueAtTime(0.18, now + 0.14 + idx * 0.06);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.55 + idx * 0.06);
      osc.connect(g);
      g.connect(out);
      osc.start(now + 0.12 + idx * 0.06);
      osc.stop(now + 0.6 + idx * 0.06);
    });
  }
}

export const soundEngine = new SoundEngine();
