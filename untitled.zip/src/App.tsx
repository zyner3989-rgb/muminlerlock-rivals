import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { soundEngine } from './audio/soundEngine';
import { GameHUD } from './components/GameHUD';
import { OnlineLobbyModal, type OnlineTransportMode } from './components/OnlineLobbyModal';
import { QuestsModal } from './components/QuestsModal';
import { SettingsModal } from './components/SettingsModal';
import { SpinLobbyModal } from './components/SpinLobbyModal';
import { TitleScreen } from './components/TitleScreen';
import { UsernameGateModal } from './components/UsernameGateModal';
import { WardrobeModal } from './components/WardrobeModal';
import { DEFAULT_SETTINGS, DEFAULT_WARDROBE } from './data/cosmetics';
import {
  getStyleCareer,
  loadCareerStats,
  saveCareerStats,
  type CareerStatsMap,
} from './data/playerCards';
import {
  computeRankedOutcome,
  DAILY_QUESTS,
  DEFAULT_QUEST_PROGRESS,
  DEFAULT_RANKED_PROFILE,
  PROMO_CODES,
} from './data/ranked';
import { STYLE_LIST } from './data/styles';
import { BlueLockEngine } from './game/Engine';
import { OnlineClient, type MultiplayerClient, type OnlineClientCallbacks } from './network/onlineClient';
import { P2POnlineClient } from './network/p2pClient';
import { VoiceChatManager } from './network/voiceChat';
import type {
  ChatMessage,
  DailyQuestProgress,
  FlowId,
  GameSettings,
  GkDifficulty,
  HudSnapshot,
  MatchMode,
  MatchmakingStatus,
  MatchStats,
  PlayerRole,
  QueueType,
  RankedProfile,
  RoomLobbyState,
  StyleId,
  VoicePeerState,
  WardrobeConfig,
} from './types/game';

const STORAGE_KEY = 'muminrivals_save_v1';

interface SavedState {
  selectedStyle: StyleId;
  selectedFlow: FlowId;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  selectedRole: PlayerRole;
  unlockedStyles: StyleId[];
  sandboxAllUnlocked: boolean;
  yen: number;
  spins: number;
  luckySpins: number;
  wardrobe: WardrobeConfig;
  settings: GameSettings;
  rankedProfile: RankedProfile;
  questProgress: DailyQuestProgress;
  nameCustomized?: boolean;
}

const DEFAULT_HUD: HudSnapshot = {
  phase: 'IDLE',
  blueScore: 0,
  redScore: 0,
  timeRemaining: 180,
  stamina: 100,
  awakening: 40,
  isAwakened: false,
  awakeningTimeLeft: 0,
  ultiUsedInAwakening: false,
  skill1Cd: 0,
  skill1MaxCd: 6,
  skill2Cd: 0,
  skill2MaxCd: 8,
  personalCd: 0,
  personalMaxCd: 10,
  dribbleCd: 0,
  slideCd: 0,
  hasBall: false,
  shotCharge: 0,
  isTraining: false,
  shiftLock: false,
  isOnline: false,
  roomCode: null,
  fps: 60,
  gkDifficulty: 'MEDIUM',
  matchMode: '3V3',
  role: 'CF',
  gkBallInHands: false,
  gkHoldLeft: 0,
  gkDiveCd: 0,
  stats: { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 },
  goalBanner: null,
  cutsceneBanner: null,
  lastActionToast: null,
  setPiece: null,
};

function loadInitialSave(): SavedState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY) || window.localStorage.getItem('bluelock_save_v1');
    if (raw) {
      const p = JSON.parse(raw) as Partial<SavedState>;
      const validIds = new Set(STYLE_LIST.map((s) => s.id));
      const unlocked = Array.isArray(p.unlockedStyles)
        ? p.unlockedStyles.filter((id): id is StyleId => validIds.has(id))
        : (['musab', 'berk'] as StyleId[]);
      return {
        selectedStyle: p.selectedStyle && validIds.has(p.selectedStyle) ? p.selectedStyle : 'musab',
        selectedFlow: p.selectedFlow ?? 'egoist',
        gkDifficulty: p.gkDifficulty ?? 'MEDIUM',
        matchMode: p.matchMode ?? '3V3',
        selectedRole: p.selectedRole ?? 'CF',
        unlockedStyles: unlocked.length > 0 ? unlocked : ['musab', 'berk'],
        sandboxAllUnlocked: p.sandboxAllUnlocked ?? true,
        yen: typeof p.yen === 'number' ? p.yen : 2400,
        spins: typeof p.spins === 'number' ? p.spins : 5,
        luckySpins: typeof p.luckySpins === 'number' ? p.luckySpins : 1,
        wardrobe: { ...DEFAULT_WARDROBE, ...(p.wardrobe ?? {}) },
        settings: { ...DEFAULT_SETTINGS, ...(p.settings ?? {}) },
        rankedProfile: { ...DEFAULT_RANKED_PROFILE, ...(p.rankedProfile ?? {}) },
        questProgress: { ...DEFAULT_QUEST_PROGRESS, ...(p.questProgress ?? {}) },
        nameCustomized: Boolean(p.nameCustomized),
      };
    }
  } catch {
    // ignore corrupted local storage
  }
  return {
    selectedStyle: 'musab',
    selectedFlow: 'egoist',
    gkDifficulty: 'MEDIUM',
    matchMode: '3V3',
    selectedRole: 'CF',
    unlockedStyles: ['musab', 'berk'],
    sandboxAllUnlocked: true,
    yen: 2400,
    spins: 5,
    luckySpins: 1,
    wardrobe: { ...DEFAULT_WARDROBE },
    settings: { ...DEFAULT_SETTINGS },
    rankedProfile: { ...DEFAULT_RANKED_PROFILE },
    questProgress: { ...DEFAULT_QUEST_PROGRESS },
    nameCustomized: false,
  };
}

function playMappedNetworkSound(sound: string, power?: number, pitch?: number) {
  switch (sound) {
    case 'KICK':
      soundEngine.playKick(power ?? 0.7);
      break;
    case 'WHISTLE':
      soundEngine.playWhistle();
      break;
    case 'SKILL':
      soundEngine.playSkill(pitch ?? 580);
      break;
    case 'SLIDE':
      soundEngine.playSlide();
      break;
    case 'EMOTE':
      soundEngine.playEmoteChime();
      break;
    case 'AWAKENED_IMPACT':
      soundEngine.playAwakenedImpact();
      break;
    case 'POST_CLANG':
      soundEngine.playPostClang();
      break;
    case 'PASS_CALL':
      soundEngine.playPassRequestCall();
      break;
    case 'GOAL':
      soundEngine.playGoalHorn();
      soundEngine.playCrowdCheer();
      break;
    default:
      break;
  }
}

export default function App() {
  const initialSave = useMemo(() => loadInitialSave(), []);
  const canvasHostRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BlueLockEngine | null>(null);

  const [selectedStyle, setSelectedStyle] = useState<StyleId>(initialSave.selectedStyle);
  const [selectedFlow, setSelectedFlow] = useState<FlowId>(initialSave.selectedFlow);
  const [gkDifficulty, setGkDifficulty] = useState<GkDifficulty>(initialSave.gkDifficulty);
  const [matchMode, setMatchMode] = useState<MatchMode>(initialSave.matchMode);
  const [selectedRole, setSelectedRole] = useState<PlayerRole>(initialSave.selectedRole);
  const [unlockedStyles, setUnlockedStyles] = useState<StyleId[]>(initialSave.unlockedStyles);
  const [sandboxAllUnlocked, setSandboxAllUnlocked] = useState<boolean>(initialSave.sandboxAllUnlocked);
  const [yen, setYen] = useState<number>(initialSave.yen);
  const [spins, setSpins] = useState<number>(initialSave.spins);
  const [luckySpins, setLuckySpins] = useState<number>(initialSave.luckySpins);
  const [wardrobe, setWardrobe] = useState<WardrobeConfig>(initialSave.wardrobe);
  const [settings, setSettings] = useState<GameSettings>(initialSave.settings);
  const [rankedProfile, setRankedProfile] = useState<RankedProfile>(initialSave.rankedProfile);
  const [nameCustomized, setNameCustomized] = useState<boolean>(Boolean(initialSave.nameCustomized));
  const [renameModalOpen, setRenameModalOpen] = useState<boolean>(false);
  const [careerStatsMap, setCareerStatsMap] = useState<CareerStatsMap>(() => loadCareerStats());
  const [questProgress, setQuestProgress] = useState<DailyQuestProgress>(initialSave.questProgress);
  const [muted, setMuted] = useState<boolean>(false);

  const [hud, setHud] = useState<HudSnapshot>(DEFAULT_HUD);
  const [activeModal, setActiveModal] = useState<'NONE' | 'SPIN' | 'ONLINE' | 'WARDROBE' | 'QUESTS' | 'SETTINGS'>('NONE');
  const [previewActive, setPreviewActive] = useState(false);
  const [engineError, setEngineError] = useState<string | null>(null);
  const [lastMatchSummary, setLastMatchSummary] = useState<{
    rpDelta: number;
    isMvp: boolean;
    queueType: QueueType;
  } | null>(null);

  // Online multiplayer & Chat / Voice state
  const [transportMode, setTransportMode] = useState<OnlineTransportMode>(() => {
    const sp = new URLSearchParams(window.location.search);
    const netParam = sp.get('net');
    const roomParam = sp.get('room');
    if (netParam === 'ws') return 'ws';
    if (netParam === 'p2p' || (roomParam && roomParam.trim().length === 5)) return 'p2p';
    return 'ws';
  });
  const [onlineConnected, setOnlineConnected] = useState(false);
  const [onlinePingMs, setOnlinePingMs] = useState<number | null>(null);
  const [onlineClientId, setOnlineClientId] = useState<string | null>(null);
  const [onlineRoom, setOnlineRoom] = useState<RoomLobbyState | null>(null);
  const [onlineError, setOnlineError] = useState<string | null>(null);
  const [matchmakingStatus, setMatchmakingStatus] = useState<MatchmakingStatus | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [voicePeers, setVoicePeers] = useState<VoicePeerState[]>([]);
  const [voiceStatus, setVoiceStatus] = useState<{
    joined: boolean;
    muted: boolean;
    deafened: boolean;
    speaking: boolean;
    error: string | null;
  }>({ joined: false, muted: false, deafened: false, speaking: false, error: null });

  const clientRef = useRef<MultiplayerClient | null>(null);
  const voiceManagerRef = useRef<VoiceChatManager | null>(null);
  const onlineStartedRoomRef = useRef<string | null>(null);
  const deepLinkPendingRef = useRef<string | null>(null);
  const prevStatsRef = useRef<MatchStats>({ goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 });
  const rankedProfileRef = useRef(rankedProfile);
  const selectedStyleRef = useRef(selectedStyle);
  const onlineRoomRef = useRef<RoomLobbyState | null>(null);

  rankedProfileRef.current = rankedProfile;
  selectedStyleRef.current = selectedStyle;
  onlineRoomRef.current = onlineRoom;

  const playerName = rankedProfile.playerName?.trim() || 'Egoist';

  // Persist save state cleanly
  useEffect(() => {
    try {
      const data: SavedState = {
        selectedStyle,
        selectedFlow,
        gkDifficulty,
        matchMode,
        selectedRole,
        unlockedStyles,
        sandboxAllUnlocked,
        yen,
        spins,
        luckySpins,
        wardrobe,
        settings,
        rankedProfile,
        questProgress,
        nameCustomized,
      };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // ignore storage quota failures
    }
  }, [
    selectedStyle,
    selectedFlow,
    gkDifficulty,
    matchMode,
    selectedRole,
    unlockedStyles,
    sandboxAllUnlocked,
    yen,
    spins,
    luckySpins,
    wardrobe,
    settings,
    rankedProfile,
    questProgress,
    nameCustomized,
  ]);

  // Apply master volume on initial mount & setting changes
  useEffect(() => {
    soundEngine.setMasterVolume(settings.masterVolume);
  }, [settings.masterVolume]);

  // Initialize WebRTC Voice Chat Manager once
  useEffect(() => {
    const vm = new VoiceChatManager({
      sendSignal: (sig) => clientRef.current?.sendVoiceSignal(sig),
      sendState: (patch) => clientRef.current?.updateVoiceState(patch),
      onStatusChange: (st) => setVoiceStatus(st),
    });
    voiceManagerRef.current = vm;
    return () => {
      vm.leave();
      voiceManagerRef.current = null;
    };
  }, []);

  useEffect(() => {
    voiceManagerRef.current?.setSelfId(onlineClientId);
  }, [onlineClientId]);

  const handleMatchEnd = useCallback((blue: number, red: number, stats: MatchStats) => {
    const activeQueueType: QueueType =
      onlineRoomRef.current?.queueType === 'RANKED' ? 'RANKED' : 'CASUAL';
    const mode = onlineRoomRef.current?.matchMode ?? matchMode;
    const rewardYen = (blue > red ? 1200 : 500) + stats.goals * 150;
    const activeStyle = selectedStyleRef.current;

    setYen((y) => y + rewardYen);
    setSpins((s) => s + 2);
    setQuestProgress((q) => ({ ...q, matchesPlayed: q.matchesPlayed + 1 }));

    // Update per-character FC 26 career stats
    setCareerStatsMap((prev) => {
      const cur = getStyleCareer(prev, activeStyle);
      const nextMap: CareerStatsMap = {
        ...prev,
        [activeStyle]: {
          matches: cur.matches + 1,
          wins: cur.wins + (blue > red ? 1 : 0),
          goals: cur.goals + stats.goals,
          shots: cur.shots + stats.shots,
          passes: cur.passes + stats.passes,
          steals: cur.steals + stats.steals,
        },
      };
      saveCareerStats(nextMap);
      return nextMap;
    });

    const outcome = computeRankedOutcome(
      rankedProfileRef.current,
      blue,
      red,
      stats,
      activeQueueType,
      mode,
      activeStyle
    );
    setRankedProfile(outcome.nextProfile);
    setLastMatchSummary({
      rpDelta: outcome.rpDelta,
      isMvp: outcome.isMvp,
      queueType: activeQueueType,
    });

    if (activeQueueType === 'RANKED') {
      fetch('/api/leaderboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerName: outcome.nextProfile.playerName || 'Egoist',
          rp: outcome.nextProfile.rp,
          wins: outcome.nextProfile.wins,
          losses: outcome.nextProfile.losses,
          goals: outcome.nextProfile.goals,
          favoriteStyle: activeStyle,
        }),
      }).catch(() => {
        // ignore network issues
      });
    }
  }, [matchMode]);

  // Initialize 3D Engine once
  useEffect(() => {
    const host = canvasHostRef.current;
    if (!host) return;

    let engine: BlueLockEngine | null = null;
    try {
      engine = new BlueLockEngine(
        host,
        initialSave.selectedStyle,
        initialSave.selectedFlow,
        initialSave.gkDifficulty,
        initialSave.matchMode,
        initialSave.wardrobe,
        initialSave.settings,
        (snap) => {
          setHud(snap);
          if (snap.phase === 'IDLE') {
            setPreviewActive(false);
          }
          // Track incremental daily quest progress during live play
          const prev = prevStatsRef.current;
          const dGoals = Math.max(0, snap.stats.goals - prev.goals);
          const dSkills = Math.max(
            0,
            snap.stats.passes + snap.stats.dribbles - (prev.passes + prev.dribbles)
          );
          if (dGoals > 0 || dSkills > 0) {
            setQuestProgress((q) => ({
              ...q,
              goals: q.goals + dGoals,
              skillsOrDribbles: q.skillsOrDribbles + dSkills,
            }));
          }
          prevStatsRef.current = { ...snap.stats };
        },
        handleMatchEnd,
        initialSave.selectedRole
      );
      engineRef.current = engine;
      engine.setPlayerIdentity(initialSave.rankedProfile.playerName || 'Egoist');
      setEngineError(null);
    } catch (err) {
      console.error('3D Engine initialization failed:', err);
      setEngineError('Tarayıcıda 3D WebGL başlatılamadı. Lütfen donanım hızlandırmayı kontrol edip sayfayı yenile.');
    }

    return () => {
      engine?.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleMatchEnd]);

  // Sync loadout & player identity changes to idle preview engine
  useEffect(() => {
    engineRef.current?.setLoadout(selectedStyle, selectedFlow, gkDifficulty, matchMode, selectedRole);
  }, [selectedStyle, selectedFlow, gkDifficulty, matchMode, selectedRole]);

  useEffect(() => {
    engineRef.current?.setPlayerIdentity(playerName);
  }, [playerName]);

  useEffect(() => {
    engineRef.current?.setWardrobe(wardrobe);
  }, [wardrobe]);

  useEffect(() => {
    engineRef.current?.applySettings(settings);
  }, [settings]);

  // Connect or switch multiplayer client when Online lobby is opened or transport changes
  const ensureOnlineClient = useCallback(
    (mode: OnlineTransportMode): MultiplayerClient => {
      if (clientRef.current) {
        clientRef.current.disconnect();
        clientRef.current = null;
      }
      voiceManagerRef.current?.leave();
      setChatMessages([]);
      setVoicePeers([]);
      setOnlineConnected(false);
      setOnlineClientId(null);
      setOnlinePingMs(null);
      setOnlineError(null);

      const callbacks: OnlineClientCallbacks = {
        onConnected: (cid) => {
          setOnlineConnected(true);
          setOnlineClientId(cid);
          voiceManagerRef.current?.setSelfId(cid);
          setOnlineError(null);
          const pendingRoom = deepLinkPendingRef.current;
          if (pendingRoom) {
            deepLinkPendingRef.current = null;
            clientRef.current?.joinRoom(
              pendingRoom,
              rankedProfileRef.current.playerName || 'Egoist',
              selectedStyleRef.current,
              selectedFlow,
              rankedProfileRef.current.rp,
              selectedRole
            );
          }
        },
        onDisconnected: () => {
          setOnlineConnected(false);
          setOnlinePingMs(null);
          voiceManagerRef.current?.leave();
          setVoicePeers([]);
        },
        onRoomState: (room) => {
          setOnlineRoom(room);
          setOnlineError(null);
          engineRef.current?.setMatchDurationSec(room.matchDurationSec ?? 180);
          if (room.status === 'PLAYING' && onlineStartedRoomRef.current !== room.roomCode && clientRef.current) {
            onlineStartedRoomRef.current = room.roomCode;
            setActiveModal('NONE');
            setLastMatchSummary(null);
            prevStatsRef.current = { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 };
            engineRef.current?.startOnlineSession(
              clientRef.current,
              room.roomCode,
              room.queueType ?? 'CASUAL'
            );
          } else if (room.status === 'LOBBY' && onlineStartedRoomRef.current !== null) {
            // Match finished and group returned to persistent lobby
            onlineStartedRoomRef.current = null;
            setPreviewActive(false);
            engineRef.current?.returnToTitle();
            setActiveModal('ONLINE');
          } else if (room.status === 'LOBBY') {
            onlineStartedRoomRef.current = null;
          }
        },
        onRoomError: (msg) => {
          setOnlineError(msg);
        },
        onWorldState: (snap) => {
          const cid = clientRef.current?.clientId;
          if (cid) {
            engineRef.current?.applyNetworkWorld(snap, cid);
          }
        },
        onCutscene: (evt) => {
          engineRef.current?.triggerNetworkCutscene(evt);
        },
        onSound: (sound, power, pitch) => {
          playMappedNetworkSound(sound, power, pitch);
        },
        onPing: (ms) => {
          setOnlinePingMs(ms);
          engineRef.current?.setOnlineMeta(ms, onlineRoomRef.current?.queueType ?? 'CASUAL');
        },
        onMatchmakingStatus: (status) => {
          setMatchmakingStatus(status);
        },
        onMatchmakingMatched: (room) => {
          setMatchmakingStatus(null);
          setOnlineRoom(room);
        },
        onChatMessage: (msg) => {
          setChatMessages((prev) => [...prev.slice(-79), msg]);
        },
        onVoicePeers: (peers) => {
          setVoicePeers(peers);
          voiceManagerRef.current?.syncPeers(peers);
        },
        onVoiceSignal: (sig) => {
          voiceManagerRef.current?.handleSignal(sig);
        },
      };

      const client: MultiplayerClient =
        mode === 'p2p' ? new P2POnlineClient(callbacks) : new OnlineClient(callbacks);
      clientRef.current = client;
      client.connect();
      return client;
    },
    [selectedFlow, selectedRole]
  );

  // Auto-open invite room link on startup (?room=XXXXX)
  useEffect(() => {
    const sp = new URLSearchParams(window.location.search);
    const roomParam = sp.get('room');
    if (roomParam && roomParam.trim().length >= 4) {
      const cleaned = roomParam.trim().toUpperCase();
      const targetMode: OnlineTransportMode =
        sp.get('net') === 'p2p' || cleaned.length === 5 ? 'p2p' : 'ws';
      setTransportMode(targetMode);
      deepLinkPendingRef.current = cleaned;
      setActiveModal('ONLINE');
      ensureOnlineClient(targetMode);
    }
    return () => {
      clientRef.current?.disconnect();
      clientRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleOpenOnline = () => {
    setActiveModal('ONLINE');
    if (!clientRef.current) {
      ensureOnlineClient(transportMode);
    }
  };

  const handleChangeTransport = (nextMode: OnlineTransportMode) => {
    setTransportMode(nextMode);
    setOnlineRoom(null);
    setMatchmakingStatus(null);
    ensureOnlineClient(nextMode);
  };

  const handleJoinRoom = (
    code: string,
    name: string,
    styleId: StyleId,
    flowId: FlowId,
    role: PlayerRole
  ) => {
    const cleaned = code.trim().toUpperCase();
    if (!cleaned) return;
    if (cleaned.length === 5 && transportMode !== 'p2p') {
      setTransportMode('p2p');
      deepLinkPendingRef.current = cleaned;
      ensureOnlineClient('p2p');
      return;
    }
    clientRef.current?.joinRoom(cleaned, name, styleId, flowId, rankedProfile.rp, role);
  };

  const handleToggleMute = () => {
    setMuted((prev) => {
      const next = !prev;
      soundEngine.setMuted(next);
      return next;
    });
  };

  const handleStartSolo = (training: boolean) => {
    setLastMatchSummary(null);
    prevStatsRef.current = { goals: 0, shots: 0, passes: 0, dribbles: 0, steals: 0 };
    engineRef.current?.startNewMatch(gkDifficulty, matchMode, training);
  };

  const handleLeaveOnlineRoom = () => {
    voiceManagerRef.current?.leave();
    clientRef.current?.leaveVoice();
    clientRef.current?.leaveRoom();
    setOnlineRoom(null);
    setChatMessages([]);
    setVoicePeers([]);
    onlineStartedRoomRef.current = null;
  };

  const handleExitToLobby = () => {
    if (onlineRoom || clientRef.current) {
      handleLeaveOnlineRoom();
    }
    setPreviewActive(false);
    engineRef.current?.returnToTitle();
  };

  const handleConfirmUsername = (nextName: string) => {
    setRankedProfile((prev) => ({ ...prev, playerName: nextName }));
    setNameCustomized(true);
    setRenameModalOpen(false);
    engineRef.current?.setPlayerIdentity(nextName);
    if (onlineRoomRef.current) {
      clientRef.current?.updatePlayer({ name: nextName });
    }
  };

  const handleToggleVoice = async () => {
    if (voiceStatus.joined) {
      voiceManagerRef.current?.leave();
      clientRef.current?.leaveVoice();
    } else {
      const ok = await voiceManagerRef.current?.join();
      if (ok) {
        clientRef.current?.joinVoice();
        voiceManagerRef.current?.syncPeers(voicePeers);
      }
    }
  };

  const handleToggleVoiceMute = () => {
    voiceManagerRef.current?.setMuted(!voiceStatus.muted);
  };

  const handleToggleVoiceDeafen = () => {
    voiceManagerRef.current?.setDeafened(!voiceStatus.deafened);
  };

  const handleClaimQuest = (questId: string) => {
    const q = DAILY_QUESTS.find((d) => d.id === questId);
    if (!q) return;
    if (questProgress.claimedIds.includes(questId)) return;
    if (questProgress[q.field] < q.target) return;

    setYen((y) => y + q.rewardYen);
    setSpins((s) => s + q.rewardSpins);
    setLuckySpins((l) => l + q.rewardLucky);
    setQuestProgress((prev) => ({
      ...prev,
      claimedIds: [...prev.claimedIds, questId],
    }));
    soundEngine.playSpinTick(true);
  };

  const handleRedeemCode = (rawCode: string): { ok: boolean; message: string } => {
    const code = rawCode.trim().toUpperCase();
    const reward = PROMO_CODES[code];
    if (!reward) {
      return { ok: false, message: 'Geçersiz promosyon kodu.' };
    }
    if (questProgress.redeemedCodes.includes(code)) {
      return { ok: false, message: 'Bu promosyon kodu zaten kullanıldı.' };
    }
    setYen((y) => y + reward.yen);
    setSpins((s) => s + reward.spins);
    setLuckySpins((l) => l + reward.luckySpins);
    setQuestProgress((prev) => ({
      ...prev,
      redeemedCodes: [...prev.redeemedCodes, code],
    }));
    soundEngine.playSpinTick(true);
    return {
      ok: true,
      message: `${reward.label}: +${reward.yen} Yen, +${reward.spins} Spin, +${reward.luckySpins} Şanslı Spin!`,
    };
  };

  const claimableQuestsCount = DAILY_QUESTS.filter(
    (q) => questProgress[q.field] >= q.target && !questProgress.claimedIds.includes(q.id)
  ).length;

  const isIdle = hud.phase === 'IDLE' && !previewActive;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050811] select-none">
      <div ref={canvasHostRef} className="absolute inset-0 w-full h-full" />

      {engineError && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 bg-red-950/95 border border-red-400 text-red-100 text-xs font-bold px-4 py-2 rounded-xl shadow-lg">
          {engineError}
        </div>
      )}

      {isIdle && (
        <TitleScreen
          playerName={playerName}
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          gkDifficulty={gkDifficulty}
          matchMode={matchMode}
          selectedRole={selectedRole}
          yen={yen}
          spins={spins}
          luckySpins={luckySpins}
          muted={muted}
          rankedProfile={rankedProfile}
          careerStatsMap={careerStatsMap}
          activeGroupCode={onlineRoom?.roomCode ?? null}
          claimableQuestsCount={claimableQuestsCount}
          onSelectGkDifficulty={setGkDifficulty}
          onSelectMatchMode={setMatchMode}
          onSelectRole={setSelectedRole}
          onOpenRenameModal={() => setRenameModalOpen(true)}
          onStartMatch={() => handleStartSolo(false)}
          onStartTraining={() => handleStartSolo(true)}
          onOpenOnlineLobby={handleOpenOnline}
          onOpenSpinLobby={() => setActiveModal('SPIN')}
          onOpenWardrobe={() => setActiveModal('WARDROBE')}
          onOpenQuests={() => setActiveModal('QUESTS')}
          onOpenSettings={() => setActiveModal('SETTINGS')}
          onPreviewCutscene={(styleId, kind) => {
            setPreviewActive(true);
            engineRef.current?.previewCutscene(styleId, kind);
          }}
          onToggleMute={handleToggleMute}
        />
      )}

      {previewActive && hud.phase === 'CUTSCENE' && (
        <div className="fixed inset-0 z-30 pointer-events-none flex flex-col justify-between p-5">
          <div className="flex justify-end pointer-events-auto">
            <button
              type="button"
              onClick={() => {
                setPreviewActive(false);
                engineRef.current?.stopPreviewCutscene();
              }}
              className="bg-[#090f1e]/92 hover:bg-slate-800 border border-sky-400/50 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
            >
              İZLEMEYİ KAPAT [ESC]
            </button>
          </div>

          {hud.cutsceneBanner && hud.cutsceneBanner.active && (
            <div
              className="mb-3 mx-auto max-w-2xl w-full bg-[#050811]/95 border-2 rounded-2xl px-6 py-4 text-center shadow-2xl"
              style={{ borderColor: hud.cutsceneBanner.accentColor }}
            >
              <div className="flex items-center justify-center gap-2">
                <span
                  className="text-[11px] font-black px-2.5 py-0.5 rounded text-slate-950"
                  style={{ backgroundColor: hud.cutsceneBanner.accentColor }}
                >
                  {hud.cutsceneBanner.badge}
                </span>
                <span className="text-sm font-black text-white">{hud.cutsceneBanner.speaker}</span>
              </div>
              <div className="text-lg md:text-xl font-black italic text-amber-200 mt-1.5">
                “{hud.cutsceneBanner.subtitle}”
              </div>
            </div>
          )}
        </div>
      )}

      {hud.phase !== 'IDLE' && !previewActive && (
        <GameHUD
          hud={hud}
          activeStyleId={selectedStyle}
          muted={muted}
          showFps={settings.showFps}
          rankedProfile={rankedProfile}
          lastMatchSummary={lastMatchSummary}
          chatMessages={chatMessages}
          voicePeers={voicePeers}
          selfId={onlineClientId}
          voiceStatus={voiceStatus}
          isRoomHost={Boolean(onlineRoom && onlineClientId && onlineRoom.hostId === onlineClientId)}
          onToggleMute={handleToggleMute}
          onTogglePause={() => engineRef.current?.togglePause()}
          onOpenSettings={() => setActiveModal('SETTINGS')}
          onRestart={() => handleStartSolo(hud.isTraining)}
          onReturnToGroupLobby={() => clientRef.current?.returnToLobby()}
          onExitToLobby={handleExitToLobby}
          onSendChat={(text) => clientRef.current?.sendChat(text)}
          onToggleVoice={handleToggleVoice}
          onToggleVoiceMute={handleToggleVoiceMute}
          onToggleVoiceDeafen={handleToggleVoiceDeafen}
          onTriggerAction={(action) => engineRef.current?.triggerActionFromHud(action)}
        />
      )}

      {activeModal === 'SPIN' && (
        <SpinLobbyModal
          selectedStyle={selectedStyle}
          selectedFlow={selectedFlow}
          unlockedStyles={unlockedStyles}
          sandboxAllUnlocked={sandboxAllUnlocked}
          spins={spins}
          luckySpins={luckySpins}
          yen={yen}
          playerName={playerName}
          careerStatsMap={careerStatsMap}
          onSelectStyle={setSelectedStyle}
          onSelectFlow={setSelectedFlow}
          onUnlockStyle={(id) =>
            setUnlockedStyles((prev) => (prev.includes(id) ? prev : [...prev, id]))
          }
          onConsumeSpin={(lucky) => {
            if (lucky) setLuckySpins((v) => Math.max(0, v - 1));
            else setSpins((v) => Math.max(0, v - 1));
          }}
          onBuySpins={(kind) => {
            if (kind === 'NORMAL' && yen >= 300) {
              setYen((y) => y - 300);
              setSpins((s) => s + 1);
            } else if (kind === 'LUCKY' && yen >= 900) {
              setYen((y) => y - 900);
              setLuckySpins((s) => s + 1);
            }
          }}
          onToggleSandbox={() => setSandboxAllUnlocked((v) => !v)}
          onClose={() => setActiveModal('NONE')}
        />
      )}

      {activeModal === 'ONLINE' && (
        <OnlineLobbyModal
          mode={transportMode}
          connected={onlineConnected}
          pingMs={onlinePingMs}
          clientId={onlineClientId}
          playerName={playerName}
          room={onlineRoom}
          errorMsg={onlineError}
          defaultStyle={selectedStyle}
          defaultFlow={selectedFlow}
          defaultGk={gkDifficulty}
          defaultMatchMode={matchMode}
          defaultRole={selectedRole}
          rankedProfile={rankedProfile}
          matchmakingStatus={matchmakingStatus}
          chatMessages={chatMessages}
          voicePeers={voicePeers}
          voiceStatus={voiceStatus}
          onChangeMode={handleChangeTransport}
          onOpenRenameModal={() => setRenameModalOpen(true)}
          onSelectRole={setSelectedRole}
          onStartMatchmaking={(name, styleId, flowId, mm, qt, role) =>
            clientRef.current?.joinMatchmaking(name, styleId, flowId, mm, qt, rankedProfile.rp, role)
          }
          onCancelMatchmaking={() => clientRef.current?.cancelMatchmaking()}
          onForceStartMatchmaking={() => clientRef.current?.forceStartMatchmaking()}
          onCreateRoom={(name, styleId, flowId, gk, mm, role) =>
            clientRef.current?.createRoom(name, styleId, flowId, gk, mm, 'CASUAL', rankedProfile.rp, role)
          }
          onJoinRoom={handleJoinRoom}
          onLeaveRoom={handleLeaveOnlineRoom}
          onUpdatePlayer={(patch) => clientRef.current?.updatePlayer(patch)}
          onSetGk={(gk) => clientRef.current?.setGkDifficulty(gk)}
          onSetMatchMode={(mm) => clientRef.current?.setMatchMode(mm)}
          onSetMatchDuration={(dur) => clientRef.current?.setMatchDuration(dur)}
          onStartOnlineMatch={() => clientRef.current?.startMatch()}
          onSendChat={(text) => clientRef.current?.sendChat(text)}
          onToggleVoice={handleToggleVoice}
          onToggleMute={handleToggleVoiceMute}
          onToggleDeafen={handleToggleVoiceDeafen}
          onClose={() => setActiveModal('NONE')}
        />
      )}

      {activeModal === 'WARDROBE' && (
        <WardrobeModal
          activeStyleId={selectedStyle}
          wardrobe={wardrobe}
          onChangeWardrobe={setWardrobe}
          onClose={() => setActiveModal('NONE')}
        />
      )}

      {activeModal === 'QUESTS' && (
        <QuestsModal
          profile={rankedProfile}
          questProgress={questProgress}
          onClaimQuest={handleClaimQuest}
          onRedeemCode={handleRedeemCode}
          onClose={() => setActiveModal('NONE')}
        />
      )}

      {activeModal === 'SETTINGS' && (
        <SettingsModal
          settings={settings}
          muted={muted}
          onChangeSettings={setSettings}
          onToggleMute={handleToggleMute}
          onClose={() => setActiveModal('NONE')}
        />
      )}

      {(!nameCustomized || renameModalOpen) && (
        <UsernameGateModal
          initialName={playerName}
          canClose={nameCustomized}
          onConfirm={handleConfirmUsername}
          onClose={() => setRenameModalOpen(false)}
        />
      )}
    </div>
  );
}
