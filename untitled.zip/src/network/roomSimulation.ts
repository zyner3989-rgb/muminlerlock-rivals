import { getRoleSpawnOffset, ROLES } from '../data/roles.ts';
import { FLOWS, STYLE_LIST, STYLES } from '../data/styles.ts';
import { EMOTE_LIST } from '../data/voiceScripts.ts';
import type {
  ActionAnimId,
  EmoteId,
  FlowId,
  GkDifficulty,
  MatchMode,
  MatchPhase,
  NetActorState,
  NetCutsceneEvent,
  NetWorldSnapshot,
  PlayerRole,
  QueueType,
  RoomLobbyState,
  RoomPlayerInfo,
  SetPieceHudInfo,
  SetPieceKind,
  StyleId,
} from '../types/game.ts';

export const SIM_PITCH_HALF_LENGTH = 125;
export const SIM_PITCH_HALF_WIDTH = 76;
export const SIM_GOAL_HALF_WIDTH = 7.8;
export const SIM_GOAL_HEIGHT = 4.6;
export const SIM_PENALTY_BOX_X = 101;
export const SIM_PENALTY_BOX_HALF_Z = 26;
export const SIM_MATCH_DURATION_SEC = 180;
export const SIM_AWAKENING_DURATION_SEC = 35;

export interface PlayerInputPacket {
  moveX: number;
  moveZ: number;
  sprint: boolean;
  chargingShot: boolean;
  aimYaw?: number;
  lockYaw?: boolean;
  aimPitch?: number;
}

export interface SimActor {
  id: string;
  clientId?: string;
  name: string;
  team: 'BLUE' | 'RED';
  styleId: StyleId;
  flowId: FlowId;
  role: PlayerRole;
  isGoalkeeper: boolean;
  gkBallInHands: boolean;
  gkHoldTimer: number;
  gkDiveTimer: number;
  gkDiveCd: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  jumpCd: number;
  yaw: number;
  homeX: number;
  homeZ: number;
  stun: number;
  slide: number;
  dribble: number;
  stealCd: number;
  stamina: number;
  awakening: number;
  awakened: boolean;
  awakeningLeft: number;
  ultiUsed: boolean;
  skill1Cd: number;
  skill2Cd: number;
  personalCd: number;
  dribbleCd: number;
  slideCd: number;
  speedBoost: number;
  wallShield: number;
  shotCharging: boolean;
  shotCharge: number;
  emote: EmoteId | null;
  emoteTimer: number;
  emoteCursor: number;
  actionAnim: ActionAnimId;
  actionTimer: number;
  requestPassTimer: number;
  input: PlayerInputPacket;
}

export interface SimBall {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  curve: number;
  topspin: number;
  ownerId: string | null;
  lastTouchActorId: string | null;
  lastTouchTeam: 'BLUE' | 'RED';
  lastTouchName: string;
  isUlti: boolean;
}

export interface PendingUltiLaunch {
  actorId: string;
  styleId: StyleId;
  team: 'BLUE' | 'RED';
  fromX: number;
  fromY: number;
  fromZ: number;
  range: 'FULL_PITCH' | 'MIDFIELD';
  curve: number;
  speed: number;
  loft: number;
}

export interface SimRoomState {
  roomCode: string;
  hostId: string;
  gkDifficulty: GkDifficulty;
  matchMode: MatchMode;
  queueType: QueueType;
  matchDurationSec: number;
  status: 'LOBBY' | 'PLAYING';
  players: Map<string, RoomPlayerInfo>;
  phase: MatchPhase;
  blueScore: number;
  redScore: number;
  timeRemaining: number;
  actors: SimActor[];
  ball: SimBall;
  cutsceneTimer: number;
  pendingUlti: PendingUltiLaunch | null;
  setPiece: {
    kind: SetPieceKind;
    team: 'BLUE' | 'RED';
    takerId: string;
    x: number;
    z: number;
    timer: number;
    aiDelay: number;
  } | null;
  duoPass: {
    active: boolean;
    passerId: string;
    receiverId: string;
    timer: number;
    autoTriggerTimer: number;
  } | null;
  duoComboCd: number;
  aiDuoCooldown: number;
  goalTimer: number;
  goalBanner: NetWorldSnapshot['goalBanner'];
  kickoffLockTeam: 'BLUE' | 'RED' | null;
  kickoffLockTimer: number;
  toast: string | null;
  toastTimer: number;
  tickAccum: number;
  worldSeq: number;
}

export interface SimBroadcastSink {
  broadcastLobby: (lobby: RoomLobbyState) => void;
  broadcastCutscene: (evt: NetCutsceneEvent) => void;
  broadcastSound: (sound: string, power?: number, pitch?: number) => void;
}

export function clampVal(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function isInOwnPenaltyBox(team: 'BLUE' | 'RED', x: number, z: number): boolean {
  return team === 'BLUE'
    ? x <= -SIM_PENALTY_BOX_X && Math.abs(z) <= SIM_PENALTY_BOX_HALF_Z
    : x >= SIM_PENALTY_BOX_X && Math.abs(z) <= SIM_PENALTY_BOX_HALF_Z;
}

export function createInitialBall(): SimBall {
  return {
    x: 0,
    y: 0.36,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    curve: 0,
    topspin: 0,
    ownerId: null,
    lastTouchActorId: null,
    lastTouchTeam: 'BLUE',
    lastTouchName: 'MÜMİNRIVALS',
    isUlti: false,
  };
}

export function createSimRoom(
  roomCode: string,
  hostId: string,
  gkDifficulty: GkDifficulty,
  matchMode: MatchMode = '3V3',
  queueType: QueueType = 'CASUAL'
): SimRoomState {
  return {
    roomCode,
    hostId,
    gkDifficulty,
    matchMode,
    queueType,
    matchDurationSec: SIM_MATCH_DURATION_SEC,
    status: 'LOBBY',
    players: new Map(),
    phase: 'IDLE',
    blueScore: 0,
    redScore: 0,
    timeRemaining: SIM_MATCH_DURATION_SEC,
    actors: [],
    ball: createInitialBall(),
    cutsceneTimer: 0,
    pendingUlti: null,
    setPiece: null,
    duoPass: null,
    duoComboCd: 0,
    aiDuoCooldown: 5.5,
    goalTimer: 0,
    goalBanner: null,
    kickoffLockTeam: null,
    kickoffLockTimer: 0,
    toast: null,
    toastTimer: 0,
    tickAccum: 0,
    worldSeq: 0,
  };
}

export function serializeSimLobby(room: SimRoomState): RoomLobbyState {
  return {
    roomCode: room.roomCode,
    hostId: room.hostId,
    gkDifficulty: room.gkDifficulty,
    matchMode: room.matchMode,
    queueType: room.queueType,
    matchDurationSec: room.matchDurationSec,
    status: room.status,
    players: Array.from(room.players.values()),
  };
}

export function buildSimActors(room: SimRoomState): SimActor[] {
  const result: SimActor[] = [];
  const blueSlots: Array<[number, number]> =
    room.matchMode === '1V1'
      ? [[-22, 0]]
      : [
          [-22, 0],
          [-46, -28],
          [-46, 28],
        ];
  const redSlots: Array<[number, number]> =
    room.matchMode === '1V1'
      ? [[22, 0]]
      : [
          [22, 0],
          [46, -28],
          [46, 28],
        ];

  const makeActor = (
    id: string,
    clientId: string | undefined,
    name: string,
    team: 'BLUE' | 'RED',
    styleId: StyleId,
    flowId: FlowId,
    role: PlayerRole,
    isGoalkeeper: boolean,
    hx: number,
    hz: number
  ): SimActor => ({
    id,
    clientId,
    name,
    team,
    styleId,
    flowId,
    role,
    isGoalkeeper,
    gkBallInHands: false,
    gkHoldTimer: 0,
    gkDiveTimer: 0,
    gkDiveCd: 0,
    x: hx,
    y: 0,
    z: hz,
    vx: 0,
    vy: 0,
    vz: 0,
    jumpCd: 0,
    yaw: team === 'BLUE' ? 0 : Math.PI,
    homeX: hx,
    homeZ: hz,
    stun: 0,
    slide: 0,
    dribble: 0,
    stealCd: 0,
    stamina: 100,
    awakening: 40,
    awakened: false,
    awakeningLeft: 0,
    ultiUsed: false,
    skill1Cd: 0,
    skill2Cd: 0,
    personalCd: 0,
    dribbleCd: 0,
    slideCd: 0,
    speedBoost: 0,
    wallShield: 0,
    shotCharging: false,
    shotCharge: 0,
    emote: null,
    emoteTimer: 0,
    emoteCursor: 0,
    actionAnim: 'NONE',
    actionTimer: 0,
    requestPassTimer: 0,
    input: { moveX: 0, moveZ: 0, sprint: false, chargingShot: false },
  });

  const buildTeam = (team: 'BLUE' | 'RED', slots: Array<[number, number]>, botPrefix: string, defaultFlow: FlowId) => {
    const humans = Array.from(room.players.values()).filter((p) => p.team === team);
    const gkHuman = humans.find((h) => h.role === 'GK');
    const fieldHumans = humans.filter((h) => h !== gkHuman);
    const usedStyles = new Set<StyleId>(humans.map((h) => h.styleId));

    fieldHumans.forEach((h, idx) => {
      const role: PlayerRole = h.role ?? 'CF';
      const spawn = getRoleSpawnOffset(role, team);
      const fallback = slots[idx % slots.length];
      const hx = idx === 0 ? spawn.x : fallback[0];
      const hz = idx === 0 ? spawn.z : fallback[1];
      result.push(
        makeActor(`p_${h.clientId}`, h.clientId, h.name, team, h.styleId, h.flowId, role, false, hx, hz)
      );
    });

    const targetFieldBots = Math.max(0, slots.length - fieldHumans.length);
    for (let i = 0; i < targetFieldBots; i++) {
      const [hx, hz] = slots[(fieldHumans.length + i) % slots.length];
      let botStyle = STYLE_LIST[(i + (team === 'BLUE' ? 1 : 3)) % STYLE_LIST.length];
      if (usedStyles.has('musab') && !usedStyles.has('musa')) botStyle = STYLES.musa;
      else if (usedStyles.has('musa') && !usedStyles.has('musab')) botStyle = STYLES.musab;
      usedStyles.add(botStyle.id);
      result.push(
        makeActor(
          `${botPrefix}_${i}`,
          undefined,
          `${botStyle.name} BOT`,
          team,
          botStyle.id,
          defaultFlow,
          i === 0 ? 'CF' : i === 1 ? 'LW' : 'RW',
          false,
          hx,
          hz
        )
      );
    }

    if (gkHuman) {
      const gkSpawn = getRoleSpawnOffset('GK', team);
      result.push(
        makeActor(
          `p_${gkHuman.clientId}`,
          gkHuman.clientId,
          gkHuman.name,
          team,
          gkHuman.styleId,
          gkHuman.flowId,
          'GK',
          true,
          gkSpawn.x,
          gkSpawn.z
        )
      );
    } else {
      result.push(
        makeActor(
          team === 'BLUE' ? 'blue_gk' : 'red_gk',
          undefined,
          team === 'BLUE' ? 'MAVİ KALECİ' : 'KIRMIZI KALECİ',
          team,
          team === 'BLUE' ? 'berk' : 'aras',
          'dribbler',
          'GK',
          true,
          team === 'BLUE' ? -SIM_PITCH_HALF_LENGTH + 4.0 : SIM_PITCH_HALF_LENGTH - 4.0,
          0
        )
      );
    }
  };

  buildTeam('BLUE', blueSlots, 'bot_b', 'egoist');
  buildTeam('RED', redSlots, 'bot_r', 'wildcard');

  return result;
}

export function resetSimKickoff(room: SimRoomState) {
  room.ball = createInitialBall();
  room.duoPass = null;
  room.setPiece = null;
  room.kickoffLockTeam = null;
  room.kickoffLockTimer = 0;
  for (const a of room.actors) {
    a.x = a.homeX;
    a.y = 0;
    a.z = a.homeZ;
    a.vx = 0;
    a.vy = 0;
    a.vz = 0;
    a.jumpCd = 0;
    a.yaw = a.team === 'BLUE' ? 0 : Math.PI;
    a.stun = 0;
    a.slide = 0;
    a.dribble = 0;
    a.stealCd = 0;
    a.gkBallInHands = false;
    a.gkHoldTimer = 0;
    a.gkDiveTimer = 0;
    a.gkDiveCd = 0;
    a.shotCharging = false;
    a.shotCharge = 0;
    a.emote = null;
    a.emoteTimer = 0;
    a.actionAnim = 'NONE';
    a.actionTimer = 0;
    a.requestPassTimer = 0;
  }
}

export function setSimMatchDuration(room: SimRoomState, durationSec: number) {
  const clamped = clampVal(Math.round(Number(durationSec) || SIM_MATCH_DURATION_SEC), 60, 600);
  room.matchDurationSec = clamped;
  if (room.status === 'LOBBY') {
    room.timeRemaining = clamped;
  }
}

export function startSimMatch(room: SimRoomState, sink: SimBroadcastSink) {
  room.status = 'PLAYING';
  room.phase = 'LIVE';
  room.blueScore = 0;
  room.redScore = 0;
  room.timeRemaining = room.matchDurationSec || SIM_MATCH_DURATION_SEC;
  room.goalBanner = null;
  room.pendingUlti = null;
  room.setPiece = null;
  room.duoPass = null;
  room.duoComboCd = 0;
  room.aiDuoCooldown = 5.5;
  room.cutsceneTimer = 0;
  room.kickoffLockTeam = null;
  room.kickoffLockTimer = 0;
  room.actors = buildSimActors(room);
  resetSimKickoff(room);
  sink.broadcastLobby(serializeSimLobby(room));
  sink.broadcastSound('WHISTLE');
}

export function returnSimToLobby(room: SimRoomState, sink: SimBroadcastSink) {
  room.status = 'LOBBY';
  room.phase = 'IDLE';
  room.blueScore = 0;
  room.redScore = 0;
  room.timeRemaining = room.matchDurationSec || SIM_MATCH_DURATION_SEC;
  room.goalBanner = null;
  room.pendingUlti = null;
  room.setPiece = null;
  room.duoPass = null;
  room.cutsceneTimer = 0;
  room.kickoffLockTeam = null;
  room.kickoffLockTimer = 0;
  room.toast = null;
  room.toastTimer = 0;
  room.actors = [];
  room.ball = createInitialBall();
  for (const p of room.players.values()) {
    p.ready = p.clientId === room.hostId;
  }
  sink.broadcastLobby(serializeSimLobby(room));
}

export function getSimActorByClient(room: SimRoomState, clientId: string): SimActor | undefined {
  return room.actors.find((a) => a.clientId === clientId);
}

export function applySimPlayerInput(
  room: SimRoomState,
  clientId: string,
  moveX: number,
  moveZ: number,
  sprint: boolean,
  chargingShot: boolean,
  aimYaw?: number,
  lockYaw?: boolean,
  aimPitch?: number
) {
  const actor = getSimActorByClient(room, clientId);
  if (!actor) return;
  actor.input.moveX = clampVal(Number(moveX) || 0, -1, 1);
  actor.input.moveZ = clampVal(Number(moveZ) || 0, -1, 1);
  actor.input.sprint = Boolean(sprint);
  actor.input.lockYaw = Boolean(lockYaw);
  if (typeof aimYaw === 'number' && Number.isFinite(aimYaw)) {
    actor.input.aimYaw = aimYaw;
  }
  if (typeof aimPitch === 'number' && Number.isFinite(aimPitch)) {
    actor.input.aimPitch = clampVal(aimPitch, -0.65, 1.2);
  }
  const charging = Boolean(chargingShot);
  if (charging && !actor.shotCharging && room.ball.ownerId === actor.id) {
    actor.shotCharging = true;
    actor.shotCharge = 0.22;
  }
}

function stealBallSim(
  room: SimRoomState,
  thief: SimActor,
  victim: SimActor,
  sink: SimBroadcastSink,
  forceAwakened = false
) {
  if (victim.gkBallInHands) return;
  if (!forceAwakened && (victim.dribble > 0 || victim.wallShield > 0)) return;
  victim.stun = forceAwakened ? 1.25 : 0.75;
  victim.stealCd = forceAwakened ? 1.2 : 0.9;
  room.ball.ownerId = thief.id;
  room.duoPass = null;
  room.ball.lastTouchActorId = thief.id;
  room.ball.lastTouchTeam = thief.team;
  room.ball.lastTouchName = thief.name || STYLES[thief.styleId].name;
  thief.awakening = Math.min(100, thief.awakening + 10);
  room.toast = forceAwakened
    ? `${thief.name || STYLES[thief.styleId].name} UYANIK TOP KAPMA ŞOKU!!`
    : `${thief.name || STYLES[thief.styleId].name} topu kaptı!`;
  room.toastTimer = 1.8;
  sink.broadcastSound('KICK', forceAwakened ? 0.95 : 0.75);
}

function launchSimDuoPass(room: SimRoomState, passer: SimActor, receiver: SimActor, sink: SimBroadcastSink) {
  const attackDir = passer.team === 'BLUE' ? 1 : -1;
  // Ensure long-distance separation if AI receiver is too close
  if (!receiver.clientId && Math.hypot(receiver.x - passer.x, receiver.z - passer.z) < 16) {
    receiver.x = clampVal(passer.x + attackDir * 22, -SIM_PITCH_HALF_LENGTH + 8, SIM_PITCH_HALF_LENGTH - 8);
    receiver.z = clampVal(passer.z >= 0 ? -12 : 12, -SIM_PITCH_HALF_WIDTH + 5, SIM_PITCH_HALF_WIDTH - 5);
  }
  const dx = receiver.x - passer.x;
  const dz = receiver.z - passer.z;
  const dist = Math.hypot(dx, dz) || 1;
  const flightTime = clampVal(dist / 17.5, 0.95, 1.72);
  room.duoComboCd = 20.0;
  room.aiDuoCooldown = 20.0;
  room.ball.ownerId = null;
  passer.stealCd = 0.65;
  passer.actionAnim = 'KICK';
  passer.actionTimer = 0.44;
  room.ball.x = passer.x + (dx / dist) * 0.9;
  room.ball.y = 0.6;
  room.ball.z = passer.z + (dz / dist) * 0.9;
  room.ball.vx = dx / flightTime;
  room.ball.vy = clampVal(8.5 + dist * 0.14, 9.2, 13.5);
  room.ball.vz = dz / flightTime;
  room.ball.curve = 0;
  room.ball.topspin = 0;
  room.duoPass = {
    active: true,
    passerId: passer.id,
    receiverId: receiver.id,
    timer: 3.4,
    autoTriggerTimer: receiver.clientId ? 99 : Math.max(0.75, flightTime * 0.8),
  };
  sink.broadcastSound('KICK', 0.8);
}

function triggerSimMusabMusaCombo(
  room: SimRoomState,
  musab: SimActor,
  musa: SimActor,
  sink: SimBroadcastSink
) {
  room.duoPass = null;
  room.ball.ownerId = null;
  const anchorX = clampVal(musa.x, -SIM_PITCH_HALF_LENGTH + 14, SIM_PITCH_HALF_LENGTH - 14);
  const anchorZ = clampVal(musa.z, -SIM_PITCH_HALF_WIDTH + 8, SIM_PITCH_HALF_WIDTH - 8);
  const dir = musa.team === 'BLUE' ? 1 : -1;

  room.phase = 'CUTSCENE';
  room.cutsceneTimer = 4.5;
  room.pendingUlti = {
    actorId: musa.id,
    styleId: 'musa',
    team: musa.team,
    fromX: anchorX + dir * 9.5,
    fromY: 3.65,
    fromZ: anchorZ,
    range: 'FULL_PITCH',
    curve: 0,
    speed: 74,
    loft: 4.5,
  };
  sink.broadcastCutscene({
    actorId: musab.id,
    partnerId: musa.id,
    styleId: 'musab',
    kind: 'COMBO',
    team: musa.team,
    anchorX,
    anchorZ,
    oppX: anchorX,
    oppZ: anchorZ,
  });
}

export function handleSimDiscreteAction(
  room: SimRoomState,
  clientId: string,
  action: string,
  sink: SimBroadcastSink
) {
  if (room.phase === 'SET_PIECE') {
    const sp = room.setPiece;
    const actor = getSimActorByClient(room, clientId);
    if (!sp || !actor || sp.takerId !== actor.id) return;
    if (action === 'PASS') {
      executeSimSetPieceKick(room, 'SHORT', sink);
    } else if (action === 'SHOOT_RELEASE') {
      executeSimSetPieceKick(room, 'LONG', sink);
    }
    return;
  }
  if (room.phase !== 'LIVE') return;
  const actor = getSimActorByClient(room, clientId);
  if (!actor || actor.stun > 0) return;
  const style = STYLES[actor.styleId];
  const awake = actor.awakened;
  const inOwnBox = actor.isGoalkeeper && isInOwnPenaltyBox(actor.team, actor.x, actor.z);

  if (action === 'REQUEST_PASS') {
    actor.requestPassTimer = 1.65;
    room.toast = `${actor.name}: Pas istiyor!`;
    room.toastTimer = 1.4;
    sink.broadcastSound('PASS_CALL');
  } else if (action === 'EMOTE') {
    const spec = EMOTE_LIST[actor.emoteCursor % EMOTE_LIST.length];
    actor.emoteCursor++;
    actor.emote = spec.id;
    actor.emoteTimer = 2.2;
    room.toast = `${actor.name}: "${spec.shout}"`;
    room.toastTimer = 1.6;
    sink.broadcastSound('EMOTE');
  } else if (action === 'GK_DIVE_LEFT' || action === 'GK_DIVE_RIGHT') {
    if (!inOwnBox || actor.gkBallInHands || actor.gkDiveCd > 0) return;
    const refYaw = typeof actor.input.aimYaw === 'number' ? actor.input.aimYaw : actor.yaw;
    const rightX = Math.sin(refYaw);
    const rightZ = Math.cos(refYaw);
    const sign = action === 'GK_DIVE_RIGHT' ? 1 : -1;
    const dx = rightX * sign;
    const dz = rightZ * sign;
    actor.gkDiveTimer = 0.48;
    actor.gkDiveCd = 1.05;
    actor.vx = dx * 21;
    actor.vz = dz * 21;
    actor.actionAnim = 'GK_DIVE';
    actor.actionTimer = 0.55;
    sink.broadcastSound('SLIDE');
    if (
      !room.ball.ownerId &&
      Math.hypot(room.ball.x - actor.x, room.ball.z - actor.z) < 3.0 &&
      room.ball.y < 3.6
    ) {
      if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
        room.kickoffLockTeam = null;
        room.kickoffLockTimer = 0;
      }
      room.ball.ownerId = actor.id;
      room.ball.isUlti = false;
      room.duoPass = null;
      room.ball.lastTouchActorId = actor.id;
      room.ball.lastTouchTeam = actor.team;
      room.ball.lastTouchName = actor.name || style.name;
      actor.gkBallInHands = true;
      actor.gkHoldTimer = 6.0;
      room.toast = `${actor.name}: Kurtarış!`;
      room.toastTimer = 1.5;
      sink.broadcastSound('KICK', 0.65);
    }
  } else if (action === 'GK_JUMP' || action === 'JUMP_HEADER') {
    if (action === 'GK_JUMP' && inOwnBox) {
      if (actor.gkBallInHands || actor.gkDiveCd > 0) return;
      actor.gkDiveTimer = 0.36;
      actor.gkDiveCd = 0.9;
      actor.actionAnim = 'GK_DIVE';
      actor.actionTimer = 0.42;
      sink.broadcastSound('SKILL', undefined, 500);
    } else if (actor.y <= 0.15 && actor.jumpCd <= 0 && !actor.gkBallInHands) {
      actor.vy = 9.2;
      actor.y = Math.max(actor.y, 0.05);
      actor.jumpCd = 0.72;
      actor.actionAnim = 'HEADER';
      actor.actionTimer = 0.45;
      sink.broadcastSound('SKILL', undefined, 510);
    }
  } else if (action === 'DRIBBLE') {
    if (inOwnBox) return;
    if (actor.dribbleCd > 0 || actor.stamina < 12) return;
    actor.dribbleCd = awake ? 1.35 : 2.0;
    actor.stamina = Math.max(0, actor.stamina - (awake ? 8 : 12));
    actor.dribble = awake ? 1.15 : 0.65;
    actor.speedBoost = Math.max(actor.speedBoost, awake ? 1.15 : 0.55);
    actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'DRIBBLE_SPIN';
    actor.actionTimer = awake ? 0.78 : 0.55;
    actor.awakening = Math.min(100, actor.awakening + 6);
    if (awake) {
      const fx = Math.cos(actor.yaw);
      const fz = -Math.sin(actor.yaw);
      actor.vx = fx * 26;
      actor.vz = fz * 26;
      for (const opp of room.actors) {
        if (opp.team !== actor.team && !opp.isGoalkeeper && Math.hypot(opp.x - actor.x, opp.z - actor.z) < 5.2) {
          opp.stun = 0.95;
          opp.vx = (opp.x - actor.x) * 3.5;
          opp.vz = (opp.z - actor.z) * 3.5;
        }
      }
      sink.broadcastSound('AWAKENED_IMPACT');
    } else {
      sink.broadcastSound('SKILL', undefined, 540);
    }
  } else if (action === 'SLIDE') {
    if (actor.slideCd > 0 || actor.stamina < 14) return;
    actor.slideCd = awake ? 1.45 : 2.2;
    actor.stamina = Math.max(0, actor.stamina - (awake ? 10 : 14));
    actor.slide = awake ? 0.56 : 0.42;
    actor.actionAnim = awake ? 'AWAKENED_STEAL' : 'SLIDE';
    actor.actionTimer = awake ? 0.58 : 0.44;
    const fx = Math.cos(actor.yaw);
    const fz = -Math.sin(actor.yaw);
    actor.vx = fx * (awake ? 31 : 23);
    actor.vz = fz * (awake ? 31 : 23);
    sink.broadcastSound(awake ? 'AWAKENED_IMPACT' : 'SLIDE');
    const stealRadius = awake ? 5.2 : 3.4;
    if (room.ball.ownerId) {
      const owner = room.actors.find((o) => o.id === room.ball.ownerId);
      if (owner && !owner.gkBallInHands && owner.team !== actor.team && Math.hypot(owner.x - actor.x, owner.z - actor.z) < stealRadius) {
        if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
          room.kickoffLockTeam = null;
          room.kickoffLockTimer = 0;
        }
        stealBallSim(room, actor, owner, sink, awake);
      }
    }
  } else if (action === 'PASS') {
    if (room.ball.ownerId !== actor.id) return;
    if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
      room.kickoffLockTeam = null;
      room.kickoffLockTimer = 0;
    }
    let bestMate: SimActor | null = null;
    let bestScore = -Infinity;
    const dirMult = actor.team === 'BLUE' ? 1 : -1;
    for (const m of room.actors) {
      if (m.team === actor.team && m.id !== actor.id && !m.isGoalkeeper) {
        const d = Math.hypot(m.x - actor.x, m.z - actor.z);
        const score = m.x * dirMult * 0.6 - d * 0.45;
        if (score > bestScore) {
          bestScore = score;
          bestMate = m;
        }
      }
    }
    const aimPitch = typeof actor.input.aimPitch === 'number' ? actor.input.aimPitch : 0.35;
    const upFactor = clampVal((0.28 - aimPitch) / 0.83, 0, 1);

    let vx: number;
    let vz: number;
    if (bestMate) {
      const dx = bestMate.x - room.ball.x;
      const dz = bestMate.z - room.ball.z;
      const dist = Math.hypot(dx, dz) || 1;
      const spd = clampVal(dist * 1.4, 18, 38);
      vx = (dx / dist) * spd;
      vz = (dz / dist) * spd;
    } else {
      const aimYaw = typeof actor.input.aimYaw === 'number' ? actor.input.aimYaw : actor.yaw;
      const spd = 28;
      vx = Math.cos(aimYaw) * spd;
      vz = -Math.sin(aimYaw) * spd;
    }
    room.ball.ownerId = null;
    actor.gkBallInHands = false;
    actor.gkHoldTimer = 0;
    room.ball.lastTouchActorId = actor.id;
    room.ball.lastTouchTeam = actor.team;
    room.ball.lastTouchName = actor.name || style.name;
    actor.stealCd = 0.45;
    actor.actionAnim = 'KICK';
    actor.actionTimer = 0.34;
    room.ball.vx = vx;
    room.ball.vy = (actor.isGoalkeeper ? 4.8 : 2.6) + upFactor * 8.5;
    room.ball.vz = vz;
    room.ball.curve = 0;
    room.ball.topspin = 0.1;
    actor.awakening = Math.min(100, actor.awakening + 6);
    sink.broadcastSound('KICK', 0.55);
  } else if (action === 'SHOOT_RELEASE') {
    const charge = Math.max(0.28, actor.shotCharge);
    actor.shotCharging = false;
    actor.shotCharge = 0;
    if (room.ball.ownerId !== actor.id) return;
    if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
      room.kickoffLockTeam = null;
      room.kickoffLockTimer = 0;
    }
    const wasInHands = actor.gkBallInHands;
    actor.gkBallInHands = false;
    actor.gkHoldTimer = 0;

    const flow = FLOWS[actor.flowId];
    const powerStat = style.stats.shotPower / 100;
    const awakeMult = awake ? 1.28 : 1.0;
    const targetGoalX = actor.team === 'BLUE' ? SIM_PITCH_HALF_LENGTH : -SIM_PITCH_HALF_LENGTH;
    const aimZ = clampVal(
      actor.z * 0.32 + (Math.random() - 0.5) * 2.2,
      -SIM_GOAL_HALF_WIDTH + 0.5,
      SIM_GOAL_HALF_WIDTH - 0.5
    );

    let gx = targetGoalX - room.ball.x;
    let gz = aimZ - room.ball.z;
    const glen = Math.hypot(gx, gz) || 1;
    gx /= glen;
    gz /= glen;

    const fx = Math.cos(actor.yaw);
    const fz = -Math.sin(actor.yaw);
    const sameSide = fx * (actor.team === 'BLUE' ? 1 : -1) > -0.25;
    const goalAssist = actor.input.lockYaw ? 0.25 : 0.72;
    let dx = sameSide ? fx * (1 - goalAssist) + gx * goalAssist : fx;
    let dz = sameSide ? fz * (1 - goalAssist) + gz * goalAssist : fz;
    const dlen = Math.hypot(dx, dz) || 1;
    dx /= dlen;
    dz /= dlen;

    const roleShotMult = ROLES[actor.role]?.shotMult ?? 1.0;
    const speed =
      (30 + charge * 28) *
      (0.85 + powerStat * 0.35) *
      flow.shotMult *
      awakeMult *
      roleShotMult *
      (wasInHands ? 1.15 : 1.0);
    const curve = clampVal((actor.z > 0 ? -0.34 : 0.34) * charge, -0.78, 0.78);
    const compAngle = curve * 0.22;
    const cosC = Math.cos(compAngle);
    const sinC = Math.sin(compAngle);
    const rx = dx * cosC - dz * sinC;
    const rz = dx * sinC + dz * cosC;

    const aimPitch = typeof actor.input.aimPitch === 'number' ? actor.input.aimPitch : 0.35;
    const upFactor = clampVal((0.28 - aimPitch) / 0.83, 0, 1);

    room.ball.ownerId = null;
    room.duoPass = null;
    room.ball.lastTouchActorId = actor.id;
    room.ball.lastTouchTeam = actor.team;
    room.ball.lastTouchName = actor.name || style.name;
    actor.stealCd = 0.55;
    actor.actionAnim = 'KICK';
    actor.actionTimer = 0.44;
    room.ball.vx = rx * speed;
    room.ball.vy = (wasInHands ? 6.2 : 2.6) + charge * 4.8 + upFactor * 9.5;
    room.ball.vz = rz * speed;
    room.ball.curve = curve;
    room.ball.topspin = 0.36 * charge;
    actor.awakening = Math.min(100, actor.awakening + 10);
    sink.broadcastSound('KICK', charge);
  } else if (action === 'SKILL1' || action === 'SKILL2' || action === 'PERSONAL') {
    if (action === 'PERSONAL') {
      if (room.duoPass?.active && room.duoPass.receiverId === actor.id) {
        const musab = room.actors.find((o) => o.id === room.duoPass!.passerId);
        if (musab) {
          triggerSimMusabMusaCombo(room, musab, actor, sink);
          return;
        }
      }
      if (actor.styleId === 'musab' && room.ball.ownerId === actor.id) {
        const musaMate = room.actors.find((o) => o.team === actor.team && !o.isGoalkeeper && o.styleId === 'musa');
        if (musaMate) {
          if (room.duoComboCd <= 0) {
            launchSimDuoPass(room, actor, musaMate, sink);
            actor.awakening = Math.min(100, actor.awakening + 10);
            room.toast = `${actor.name} -> MUSA UZAK HAVADAN KOMBİNE PAS! ROVEŞATA İÇİN [E]!`;
            room.toastTimer = 2.4;
            return;
          } else if (actor.personalCd > 0) {
            room.toast = `Musab × Musa Pas Bekleme: ${Math.ceil(room.duoComboCd)}s`;
            room.toastTimer = 1.4;
            return;
          }
        }
      }
    }

    if (action === 'SKILL1' && actor.skill1Cd > 0) return;
    if (action === 'SKILL2' && actor.skill2Cd > 0) return;
    if (action === 'PERSONAL' && actor.personalCd > 0) return;

    if (action === 'SKILL1') actor.skill1Cd = awake ? Math.max(2.5, style.skill1.cooldown * 0.65) : style.skill1.cooldown;
    if (action === 'SKILL2') actor.skill2Cd = awake ? Math.max(3.0, style.skill2.cooldown * 0.65) : style.skill2.cooldown;
    if (action === 'PERSONAL') actor.personalCd = awake ? Math.max(3.5, style.personalSkill.cooldown * 0.65) : style.personalSkill.cooldown;

    actor.awakening = Math.min(100, actor.awakening + 12);
    if (awake) sink.broadcastSound('AWAKENED_IMPACT');
    else sink.broadcastSound('SKILL', undefined, action === 'PERSONAL' ? 840 : 600);

    const fx = Math.cos(actor.yaw);
    const fz = -Math.sin(actor.yaw);
    const targetGoalX = actor.team === 'BLUE' ? SIM_PITCH_HALF_LENGTH : -SIM_PITCH_HALF_LENGTH;

    if (action === 'SKILL1') {
      if (actor.styleId === 'ebulfez') {
        const dist = awake ? 12.5 : 7.0;
        actor.x = clampVal(actor.x + fx * dist, -SIM_PITCH_HALF_LENGTH + 2, SIM_PITCH_HALF_LENGTH - 2);
        actor.z = clampVal(actor.z + fz * dist, -SIM_PITCH_HALF_WIDTH + 2, SIM_PITCH_HALF_WIDTH - 2);
        actor.dribble = awake ? 1.45 : 0.9;
        actor.actionAnim = 'SKILL_LEAP';
        actor.actionTimer = 0.62;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 5.5) {
              o.stun = 1.1;
              if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, true);
            }
          }
        }
      } else if (actor.styleId === 'iskender' || actor.styleId === 'aras') {
        const range = awake ? 11.5 : 7.5;
        for (const o of room.actors) {
          if (o.team !== actor.team && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 2.2 : 1.6;
            if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, awake);
          }
        }
        actor.speedBoost = awake ? 2.0 : 1.4;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.62;
      } else if (actor.styleId === 'berk') {
        actor.vx = fx * (awake ? 28 : 20);
        actor.vz = fz * (awake ? 28 : 20);
        actor.actionAnim = awake ? 'AWAKENED_STEAL' : 'SKILL_BURST';
        actor.actionTimer = 0.65;
        const stealRange = awake ? 8.5 : 5.5;
        if (room.ball.ownerId) {
          const owner = room.actors.find((o) => o.id === room.ball.ownerId);
          if (owner && owner.team !== actor.team && Math.hypot(owner.x - actor.x, owner.z - actor.z) < stealRange) {
            stealBallSim(room, actor, owner, sink, awake);
          }
        }
      } else if (actor.styleId === 'esref_tek') {
        actor.dribble = awake ? 1.6 : 1.1;
        actor.speedBoost = awake ? 2.2 : 1.5;
        actor.vx = fx * (awake ? 36 : 30);
        actor.vz = fz * (awake ? 36 : 30);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.7;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 4.5) {
              o.stun = 1.1;
              if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, true);
            }
          }
        }
      } else if (actor.styleId === 'arap_kavuncu') {
        actor.dribble = awake ? 1.75 : 1.2;
        actor.speedBoost = awake ? 2.4 : 1.7;
        actor.vx = fx * (awake ? 38 : 31);
        actor.vz = fz * (awake ? 38 : 31);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.68;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 5.0) o.stun = 1.0;
          }
        }
      } else if (actor.styleId === 'hamzac5') {
        actor.dribble = awake ? 1.55 : 1.0;
        actor.speedBoost = 2.6;
        actor.vx = fx * (awake ? 40 : 32);
        actor.vz = fz * (awake ? 40 : 32);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.72;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 5.2) o.stun = 1.05;
          }
        }
      } else if (actor.styleId === 'memud') {
        actor.dribble = awake ? 1.7 : 1.15;
        actor.speedBoost = awake ? 2.3 : 1.65;
        actor.vx = fx * (awake ? 36 : 29);
        actor.vz = fz * (awake ? 36 : 29);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.66;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 4.8) o.stun = 0.95;
          }
        }
      } else if (actor.styleId === 'umidi') {
        actor.dribble = awake ? 1.55 : 1.0;
        actor.speedBoost = awake ? 2.2 : 1.5;
        actor.vx = fx * (awake ? 36 : 28);
        actor.vz = fz * (awake ? 36 : 28);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.68;
        const coneRange = awake ? 10.5 : 7.5;
        for (const o of room.actors) {
          if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < coneRange) {
            o.stun = awake ? 1.85 : 1.3;
          }
        }
        sink.broadcastSound('WATER_SQUIRT');
      } else {
        actor.dribble = awake ? 1.65 : 1.05;
        actor.speedBoost = awake ? 2.4 : 1.6;
        actor.vx = fx * (awake ? 34 : 26);
        actor.vz = fz * (awake ? 34 : 26);
        actor.actionAnim = awake ? 'AWAKENED_DRIBBLE' : 'SKILL_BURST';
        actor.actionTimer = 0.7;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 5.5) {
              o.stun = 1.0;
            }
          }
        }
      }
      room.toast = `${actor.name}: ${style.skill1.name}`;
      room.toastTimer = 1.3;
    } else if (action === 'SKILL2') {
      const touchesBall =
        room.ball.ownerId === actor.id ||
        (room.ball.ownerId === null && Math.hypot(room.ball.x - actor.x, room.ball.z - actor.z) <= 1.85);
      const curOwnerS2 = room.ball.ownerId ? room.actors.find((o) => o.id === room.ball.ownerId) : undefined;

      if (
        actor.styleId === 'ebulfez' &&
        room.ball.ownerId !== actor.id &&
        !curOwnerS2?.gkBallInHands &&
        Math.hypot(room.ball.x - actor.x, room.ball.z - actor.z) < (awake ? 11.0 : 7.0)
      ) {
        if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
          room.kickoffLockTeam = null;
          room.kickoffLockTimer = 0;
        }
        room.ball.ownerId = actor.id;
        room.duoPass = null;
        room.ball.lastTouchActorId = actor.id;
        room.ball.lastTouchTeam = actor.team;
        room.ball.lastTouchName = actor.name || style.name;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.55;
      } else if (touchesBall) {
        if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
          room.kickoffLockTeam = null;
          room.kickoffLockTimer = 0;
        }
        const goalZ = actor.z > 0 ? -SIM_GOAL_HALF_WIDTH * 0.65 : SIM_GOAL_HALF_WIDTH * 0.65;
        const dx = targetGoalX - room.ball.x;
        const dz = goalZ - room.ball.z;
        const len = Math.hypot(dx, dz) || 1;
        const nx = dx / len;
        const nz = dz / len;
        const baseSpd =
          actor.styleId === 'umidi'
            ? 45
            : style.rarity === 'MASTER'
              ? 52
              : style.rarity === 'WORLD CLASS'
                ? 48
                : style.rarity === 'MYTHIC'
                  ? 46
                  : 42;
        const spd = baseSpd * (awake ? 1.24 : 1.0);
        const curve = clampVal((actor.z > 0 ? -0.58 : 0.58) * (awake ? 1.25 : 1.0), -0.82, 0.82);
        const compAngle = curve * 0.24;
        const cosC = Math.cos(compAngle);
        const sinC = Math.sin(compAngle);
        const rx = nx * cosC - nz * sinC;
        const rz = nx * sinC + nz * cosC;

        room.ball.ownerId = null;
        room.duoPass = null;
        room.ball.lastTouchActorId = actor.id;
        room.ball.lastTouchTeam = actor.team;
        room.ball.lastTouchName = actor.name || style.name;
        actor.stealCd = 0.55;
        actor.actionAnim = 'KICK';
        actor.actionTimer = 0.5;
        room.ball.vx = rx * spd;
        room.ball.vy = awake ? 5.2 : 4.6;
        room.ball.vz = rz * spd;
        room.ball.curve = curve;
        room.ball.topspin = 0.52;
        sink.broadcastSound('KICK', 0.95);
        if (actor.styleId === 'umidi') sink.broadcastSound('PACK_OPEN');
      } else {
        actor.speedBoost = awake ? 2.2 : 1.4;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.55;
      }
      room.toast = `${actor.name}: ${style.skill2.name}`;
      room.toastTimer = 1.3;
    } else {
      if (actor.styleId === 'aras') {
        actor.stamina = Math.min(100, actor.stamina + (awake ? 90 : 50));
        actor.speedBoost = awake ? 2.8 : 2.0;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.65;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 6.5) o.stun = 1.2;
          }
        }
      } else if (actor.styleId === 'berk') {
        actor.wallShield = awake ? 5.2 : 3.2;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.65;
        if (awake) {
          for (const o of room.actors) {
            if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < 7.0) {
              o.stun = 1.2;
              if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, true);
            }
          }
        }
      } else if (actor.styleId === 'ebulfez') {
        const curOwner = room.ball.ownerId ? room.actors.find((o) => o.id === room.ball.ownerId) : undefined;
        if (!curOwner?.gkBallInHands && Math.hypot(room.ball.x - actor.x, room.ball.z - actor.z) < (awake ? 9.5 : 6.0)) {
          if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
            room.kickoffLockTeam = null;
            room.kickoffLockTimer = 0;
          }
          room.ball.ownerId = actor.id;
          room.duoPass = null;
          room.ball.lastTouchActorId = actor.id;
          room.ball.lastTouchTeam = actor.team;
          room.ball.lastTouchName = actor.name || style.name;
        }
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.6;
      } else if (actor.styleId === 'musab' || actor.styleId === 'zero') {
        const range = awake ? 12.5 : 8.0;
        for (const o of room.actors) {
          if (o.team !== actor.team && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 1.85 : 1.3;
            if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, awake);
          }
        }
        actor.speedBoost = awake ? 2.4 : 1.6;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'musa') {
        const range = awake ? 11.5 : 7.0;
        if (room.ball.ownerId) {
          const owner = room.actors.find((o) => o.id === room.ball.ownerId);
          if (owner && owner.team !== actor.team && Math.hypot(owner.x - actor.x, owner.z - actor.z) < range) {
            stealBallSim(room, actor, owner, sink, awake);
          }
        }
        actor.speedBoost = awake ? 2.5 : 1.8;
        actor.actionAnim = awake ? 'AWAKENED_STEAL' : 'SKILL_BURST';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'iskender') {
        const warpDist = awake ? 13.5 : 8.5;
        actor.x = clampVal(actor.x + fx * warpDist, -SIM_PITCH_HALF_LENGTH + 2, SIM_PITCH_HALF_LENGTH - 2);
        actor.z = clampVal(actor.z + fz * warpDist, -SIM_PITCH_HALF_WIDTH + 2, SIM_PITCH_HALF_WIDTH - 2);
        actor.dribble = awake ? 1.65 : 1.1;
        actor.actionAnim = 'SKILL_LEAP';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'esref_tek') {
        const range = awake ? 13.5 : 9.0;
        for (const o of room.actors) {
          if (o.team !== actor.team && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 2.1 : 1.5;
            if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, awake);
          }
        }
        actor.speedBoost = awake ? 2.3 : 1.6;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.68;
      } else if (actor.styleId === 'arap_kavuncu') {
        actor.stamina = Math.min(100, actor.stamina + (awake ? 85 : 45));
        actor.speedBoost = awake ? 3.0 : 2.3;
        const range = awake ? 10.0 : 7.0;
        for (const o of room.actors) {
          if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 1.8 : 1.2;
            if (room.ball.ownerId === o.id && awake) stealBallSim(room, actor, o, sink, true);
          }
        }
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'hamzac5') {
        const stealRange = awake ? 11.5 : 7.5;
        actor.vx = fx * (awake ? 32 : 24);
        actor.vz = fz * (awake ? 32 : 24);
        if (room.ball.ownerId) {
          const owner = room.actors.find((o) => o.id === room.ball.ownerId);
          if (owner && owner.team !== actor.team && Math.hypot(owner.x - actor.x, owner.z - actor.z) < stealRange) {
            stealBallSim(room, actor, owner, sink, awake);
          }
        }
        actor.speedBoost = 2.4;
        actor.actionAnim = awake ? 'AWAKENED_STEAL' : 'SKILL_BURST';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'memud') {
        const range = awake ? 14.0 : 10.0;
        for (const o of room.actors) {
          if (o.team !== actor.team && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 1.7 : 1.1;
            if (room.ball.ownerId === o.id && awake) stealBallSim(room, actor, o, sink, true);
          }
        }
        actor.speedBoost = 2.0;
        actor.actionAnim = 'SKILL_BURST';
        actor.actionTimer = 0.65;
      } else if (actor.styleId === 'umidi') {
        const range = awake ? 12.0 : 8.5;
        actor.vx = fx * (awake ? 33 : 25);
        actor.vz = fz * (awake ? 33 : 25);
        for (const o of room.actors) {
          if (o.team !== actor.team && !o.isGoalkeeper && Math.hypot(o.x - actor.x, o.z - actor.z) < range) {
            o.stun = awake ? 1.7 : 1.25;
            if (room.ball.ownerId === o.id) stealBallSim(room, actor, o, sink, awake);
          }
        }
        actor.speedBoost = 2.4;
        actor.actionAnim = awake ? 'AWAKENED_STEAL' : 'SKILL_BURST';
        actor.actionTimer = 0.65;
      }
      room.toast = `${actor.name}: ${style.personalSkill.name}`;
      room.toastTimer = 1.3;
    }
  } else if (action === 'AWAKENING') {
    if (actor.awakened || actor.awakening < 100) return;
    actor.awakening = 0;
    actor.awakened = true;
    actor.awakeningLeft = SIM_AWAKENING_DURATION_SEC;
    actor.ultiUsed = false;
    actor.skill1Cd = 0;
    actor.skill2Cd = 0;
    actor.personalCd = 0;
    actor.stamina = 100;

    const opp = room.actors.find((o) => o.team !== actor.team && !o.isGoalkeeper) ?? actor;
    const awakeDurMap: Partial<Record<StyleId, number>> = {
      umidi: 3.6,
      esref_tek: 3.5,
      musab: 3.5,
      musa: 3.5,
    };
    room.phase = 'CUTSCENE';
    room.cutsceneTimer = awakeDurMap[actor.styleId] ?? 3.4;
    sink.broadcastCutscene({
      actorId: actor.id,
      styleId: actor.styleId,
      kind: 'AWAKENING',
      team: actor.team,
      anchorX: actor.x,
      anchorZ: actor.z,
      oppX: opp.x,
      oppZ: opp.z,
    });
  } else if (action === 'ULTI') {
    if (!actor.awakened || actor.ultiUsed) return;
    const isThiefUlti = actor.styleId === 'berk' || actor.styleId === 'ebulfez';
    const ownsOrTouches =
      room.ball.ownerId === actor.id ||
      (room.ball.ownerId === null && Math.hypot(room.ball.x - actor.x, room.ball.z - actor.z) <= 2.2);
    const carrier = room.ball.ownerId ? room.actors.find((o) => o.id === room.ball.ownerId) : undefined;
    const oppHasBall = Boolean(carrier && carrier.team !== actor.team && !carrier.isGoalkeeper);

    if (isThiefUlti) {
      if (!ownsOrTouches && !oppHasBall) {
        room.toast = `${actor.name}: Ulti için top sende veya rakipte olmalı!`;
        room.toastTimer = 1.5;
        return;
      }
    } else if (!ownsOrTouches) {
      room.toast = `${actor.name}: Ulti için top sende olmalı!`;
      room.toastTimer = 1.5;
      return;
    }

    if (room.kickoffLockTeam && actor.team !== room.kickoffLockTeam) {
      room.kickoffLockTeam = null;
      room.kickoffLockTimer = 0;
    }

    const stealTarget = isThiefUlti && oppHasBall ? carrier : undefined;
    if (stealTarget) {
      stealTarget.stun = 1.4;
      stealTarget.stealCd = 1.2;
    }

    actor.ultiUsed = true;
    room.ball.ownerId = null;
    room.duoPass = null;
    const opp = stealTarget ?? (isThiefUlti ? actor : room.actors.find((o) => o.team !== actor.team && !o.isGoalkeeper) ?? actor);
    const durMap: Record<StyleId, number> = {
      musab: 4.4,
      musa: 3.8,
      iskender: 3.8,
      aras: 3.6,
      ebulfez: 3.6,
      zero: 3.6,
      berk: 3.6,
      esref_tek: 3.8,
      arap_kavuncu: 3.6,
      hamzac5: 3.8,
      memud: 3.6,
      umidi: 4.2,
    };
    const speedMap: Record<StyleId, number> = {
      musa: 76,
      musab: 74,
      umidi: 74,
      esref_tek: 72,
      iskender: 72,
      berk: 70,
      aras: 70,
      arap_kavuncu: 70,
      memud: 68,
      zero: 66,
      hamzac5: 66,
      ebulfez: 64,
    };
    room.phase = 'CUTSCENE';
    room.cutsceneTimer = durMap[actor.styleId];
    const dir = actor.team === 'BLUE' ? 1 : -1;
    room.pendingUlti = {
      actorId: actor.id,
      styleId: actor.styleId,
      team: actor.team,
      fromX: isThiefUlti ? opp.x + dir * 1.1 : actor.x + dir * 1.2,
      fromY:
        actor.styleId === 'musab'
          ? 3.4
          : actor.styleId === 'iskender'
            ? 2.65
            : actor.styleId === 'ebulfez'
              ? 2.45
              : actor.styleId === 'hamzac5' || actor.styleId === 'umidi'
                ? 2.2
                : 1.0,
      fromZ: isThiefUlti ? opp.z : actor.z,
      range: style.ultiRange,
      curve: 0,
      speed: speedMap[actor.styleId] ?? 68,
      loft: actor.styleId === 'musab' || actor.styleId === 'iskender' || actor.styleId === 'musa' ? 4.8 : 4.3,
    };
    sink.broadcastCutscene({
      actorId: actor.id,
      styleId: actor.styleId,
      kind: 'ULTI',
      team: actor.team,
      anchorX: actor.x,
      anchorZ: actor.z,
      oppX: opp.x,
      oppZ: opp.z,
    });
  }
}

function triggerSimSetPiece(
  room: SimRoomState,
  kind: SetPieceKind,
  team: 'BLUE' | 'RED',
  x: number,
  z: number,
  sink: SimBroadcastSink
) {
  room.ball.ownerId = null;
  room.duoPass = null;
  room.ball.isUlti = false;
  room.ball.vx = 0;
  room.ball.vy = 0;
  room.ball.vz = 0;
  room.ball.curve = 0;
  room.ball.topspin = 0;
  room.ball.x = x;
  room.ball.y = 0.36;
  room.ball.z = z;

  const teamHumans = room.actors.filter((a) => a.team === team && !a.isGoalkeeper && a.clientId);
  let taker: SimActor | undefined;
  let bestDist = Infinity;
  const pool = teamHumans.length > 0 ? teamHumans : room.actors.filter((a) => a.team === team && !a.isGoalkeeper);
  for (const a of pool) {
    const d = Math.hypot(a.x - x, a.z - z);
    if (d < bestDist) {
      bestDist = d;
      taker = a;
    }
  }
  taker = taker ?? room.actors.find((a) => a.team === team) ?? room.actors[0];
  if (!taker) return;

  const attDir = team === 'BLUE' ? 1 : -1;
  const zSign = z >= 0 ? 1 : -1;
  const xSign = x >= 0 ? 1 : -1;

  if (kind === 'THROW_IN') {
    taker.x = x;
    taker.z = z + zSign * 1.15;
    taker.yaw = z >= 0 ? Math.PI / 2 : -Math.PI / 2; // face inward toward the pitch
  } else {
    taker.x = x + xSign * 1.15;
    taker.z = z + zSign * 1.15;
    const spotX = attDir * (SIM_PITCH_HALF_LENGTH - 14);
    taker.yaw = Math.atan2(-(0 - taker.z), spotX - taker.x);
  }
  taker.vx = 0;
  taker.vz = 0;
  taker.stun = 0;
  taker.shotCharging = false;
  taker.shotCharge = 0;

  let attIdx = 0;
  let defIdx = 0;
  for (const a of room.actors) {
    if (a.id === taker.id || a.isGoalkeeper) continue;
    a.vx = 0;
    a.vz = 0;
    a.stun = 0;
    a.shotCharging = false;
    a.shotCharge = 0;
    if (kind === 'CORNER') {
      const boxCenterX = x > 0 ? SIM_PITCH_HALF_LENGTH - 15 : -SIM_PITCH_HALF_LENGTH + 15;
      const inDir = x > 0 ? -1 : 1;
      if (a.team === team) {
        a.x = boxCenterX + inDir * (attIdx * 3.2);
        a.z = clampVal((attIdx % 2 === 0 ? -1 : 1) * (3.2 + Math.floor(attIdx / 2) * 3.6), -18, 18);
        attIdx++;
      } else {
        a.x = boxCenterX - inDir * (2.0 + defIdx * 1.8);
        a.z = clampVal((defIdx % 2 === 0 ? 1 : -1) * (2.6 + Math.floor(defIdx / 2) * 3.2), -18, 18);
        defIdx++;
      }
      a.yaw = Math.atan2(-(z - a.z), x - a.x);
    } else {
      const dx = a.x - x;
      const dz = a.z - z;
      const d = Math.hypot(dx, dz);
      if (d < 9.5) {
        const pushAngle = d > 0.1 ? Math.atan2(dz, dx) : (z >= 0 ? -Math.PI / 2 : Math.PI / 2);
        a.x = clampVal(x + Math.cos(pushAngle) * 11, -SIM_PITCH_HALF_LENGTH + 4, SIM_PITCH_HALF_LENGTH - 4);
        a.z = clampVal(z + Math.sin(pushAngle) * 11, -SIM_PITCH_HALF_WIDTH + 6, SIM_PITCH_HALF_WIDTH - 6);
      } else {
        a.z = clampVal(a.z, -SIM_PITCH_HALF_WIDTH + 5, SIM_PITCH_HALF_WIDTH - 5);
      }
      a.yaw = Math.atan2(-(z - a.z), x - a.x);
    }
  }

  room.setPiece = {
    kind,
    team,
    takerId: taker.id,
    x,
    z,
    timer: 5.5,
    aiDelay: taker.clientId ? 99 : 1.15,
  };
  room.phase = 'SET_PIECE';
  room.toast =
    kind === 'THROW_IN'
      ? `TAÇ ATIŞI (${team === 'BLUE' ? 'MAVİ' : 'KIRMIZI'})`
      : `KORNER (${team === 'BLUE' ? 'MAVİ' : 'KIRMIZI'})`;
  room.toastTimer = 2.0;
  sink.broadcastSound('WHISTLE');
}

function triggerSimAutGoalKick(room: SimRoomState, defTeam: 'BLUE' | 'RED', sink: SimBroadcastSink) {
  room.ball.ownerId = null;
  room.duoPass = null;
  room.ball.isUlti = false;
  room.ball.vx = 0;
  room.ball.vy = 0;
  room.ball.vz = 0;
  room.ball.curve = 0;
  room.ball.topspin = 0;

  const gk =
    room.actors.find((a) => a.team === defTeam && a.isGoalkeeper) ??
    room.actors.find((a) => a.team === defTeam) ??
    room.actors[0];
  if (!gk) return;

  const defDir = defTeam === 'BLUE' ? -1 : 1;
  gk.x = defDir * (SIM_PITCH_HALF_LENGTH - 6);
  gk.z = 0;
  gk.vx = 0;
  gk.vz = 0;
  gk.yaw = defTeam === 'BLUE' ? 0 : Math.PI;
  gk.gkBallInHands = true;
  gk.gkHoldTimer = 6.0;

  room.ball.ownerId = gk.id;
  room.ball.lastTouchActorId = gk.id;
  room.ball.lastTouchTeam = gk.team;
  room.ball.lastTouchName = gk.name || STYLES[gk.styleId].name;
  room.ball.x = gk.x + Math.cos(gk.yaw) * 0.72;
  room.ball.y = 1.24;
  room.ball.z = gk.z - Math.sin(gk.yaw) * 0.72;

  for (const a of room.actors) {
    if (a.team !== defTeam && !a.isGoalkeeper) {
      if ((defTeam === 'BLUE' && a.x < -SIM_PITCH_HALF_LENGTH + 36) || (defTeam === 'RED' && a.x > SIM_PITCH_HALF_LENGTH - 36)) {
        a.x = defDir * (SIM_PITCH_HALF_LENGTH - 36);
        a.vx = 0;
        a.vz = 0;
      }
    }
  }

  room.toast = `AUT (${defTeam === 'BLUE' ? 'MAVİ' : 'KIRMIZI'})`;
  room.toastTimer = 1.6;
  sink.broadcastSound('WHISTLE');
}

function executeSimSetPieceKick(room: SimRoomState, mode: 'SHORT' | 'LONG', sink: SimBroadcastSink) {
  const sp = room.setPiece;
  if (!sp) return;
  const taker = room.actors.find((a) => a.id === sp.takerId) ?? room.actors[0];
  room.setPiece = null;
  room.phase = 'LIVE';
  if (!taker) return;

  const attDir = sp.team === 'BLUE' ? 1 : -1;
  let bestMate: SimActor | null = null;
  let bestScore = -Infinity;
  for (const m of room.actors) {
    if (m.team === sp.team && m.id !== taker.id && !m.isGoalkeeper) {
      const d = Math.hypot(m.x - sp.x, m.z - sp.z);
      const inwardGain = Math.abs(sp.z) - Math.abs(m.z);
      const score = inwardGain * 0.65 + m.x * attDir * 0.45 - d * 0.22 + (m.clientId ? 8 : 0);
      if (score > bestScore) {
        bestScore = score;
        bestMate = m;
      }
    }
  }

  const aimPitch = typeof taker.input.aimPitch === 'number' ? taker.input.aimPitch : 0.35;
  const upFactor = clampVal((0.28 - aimPitch) / 0.83, 0, 1);

  room.ball.x = sp.x;
  room.ball.y = sp.kind === 'THROW_IN' ? 2.15 : 0.38;
  room.ball.z = sp.z;

  if (sp.kind === 'CORNER') {
    const boxX = (sp.x >= 0 ? 1 : -1) * (SIM_PITCH_HALF_LENGTH - 15);
    const boxZ = (Math.random() - 0.5) * 14.0;
    const dx = boxX - sp.x;
    const dz = boxZ - sp.z;
    const len = Math.hypot(dx, dz) || 1;
    const spd = mode === 'LONG' ? 35 : 27;
    room.ball.vx = (dx / len) * spd;
    room.ball.vy = (mode === 'LONG' ? 15.5 : 10.5) + upFactor * 4.5;
    room.ball.vz = (dz / len) * spd;
    room.ball.curve = sp.z >= 0 ? -0.38 : 0.38;
    room.ball.topspin = 0.16;
  } else if (sp.kind === 'THROW_IN') {
    const rawTargetX = bestMate ? bestMate.x + attDir * 4.0 : clampVal(sp.x + attDir * 14, -SIM_PITCH_HALF_LENGTH + 8, SIM_PITCH_HALF_LENGTH - 8);
    const rawTargetZ = bestMate ? bestMate.z : 0;
    const targetX = clampVal(rawTargetX, -SIM_PITCH_HALF_LENGTH + 6, SIM_PITCH_HALF_LENGTH - 6);
    const targetZ = clampVal(rawTargetZ, -SIM_PITCH_HALF_WIDTH + 6, SIM_PITCH_HALF_WIDTH - 6);
    const dx = targetX - sp.x;
    const dz = targetZ - sp.z;
    const len = Math.hypot(dx, dz) || 1;
    const spd = clampVal(len * (mode === 'LONG' ? 1.4 : 1.15), 17, 29);
    room.ball.vx = (dx / len) * spd;
    room.ball.vy = (mode === 'LONG' ? 7.2 : 4.8) + upFactor * 6.5;
    room.ball.vz = (dz / len) * spd;
    room.ball.curve = 0;
    room.ball.topspin = 0.05;
  } else if (bestMate) {
    const leadX = bestMate.x + (mode === 'LONG' ? attDir * 6 : 0);
    const dx = leadX - sp.x;
    const dz = bestMate.z - sp.z;
    const len = Math.hypot(dx, dz) || 1;
    const spd = clampVal(len * (mode === 'LONG' ? 1.55 : 1.3), mode === 'LONG' ? 24 : 17, mode === 'LONG' ? 34 : 26);
    room.ball.vx = (dx / len) * spd;
    room.ball.vy = (mode === 'LONG' ? 7.0 : 4.0) + upFactor * 5.0;
    room.ball.vz = (dz / len) * spd;
    room.ball.curve = 0;
    room.ball.topspin = 0.1;
  } else {
    const dirX = attDir;
    const dirZ = sp.z >= 0 ? -1 : 1;
    const spd = mode === 'LONG' ? 28 : 20;
    room.ball.vx = dirX * spd;
    room.ball.vy = (mode === 'LONG' ? 7.0 : 4.0) + upFactor * 5.0;
    room.ball.vz = dirZ * spd;
    room.ball.curve = 0;
    room.ball.topspin = 0.1;
  }

  room.ball.ownerId = null;
  room.ball.isUlti = false;
  room.ball.lastTouchActorId = taker.id;
  room.ball.lastTouchTeam = taker.team;
  room.ball.lastTouchName = taker.name || STYLES[taker.styleId].name;
  taker.stealCd = 0.6;
  taker.yaw = Math.atan2(-room.ball.vz, room.ball.vx);
  taker.actionAnim = sp.kind === 'THROW_IN' ? 'THROW_IN' : 'KICK';
  taker.actionTimer = 0.42;
  sink.broadcastSound('KICK', sp.kind === 'THROW_IN' ? 0.55 : mode === 'LONG' ? 0.85 : 0.6);
}

function stepSimSetPiece(room: SimRoomState, dt: number, sink: SimBroadcastSink) {
  const sp = room.setPiece;
  if (!sp) {
    room.phase = 'LIVE';
    return;
  }
  room.ball.x = sp.x;
  room.ball.y = sp.kind === 'THROW_IN' ? 2.15 : 0.36;
  room.ball.z = sp.z;
  for (const a of room.actors) {
    a.vx *= Math.exp(-8 * dt);
    a.vz *= Math.exp(-8 * dt);
    a.actionTimer = Math.max(0, a.actionTimer - dt);
    if (a.actionTimer === 0) a.actionAnim = 'NONE';
  }
  sp.timer -= dt;
  sp.aiDelay -= dt;
  if (sp.aiDelay <= 0 || sp.timer <= 0) {
    executeSimSetPieceKick(room, sp.kind === 'CORNER' ? 'LONG' : 'SHORT', sink);
  }
}

export function stepSimRoom(room: SimRoomState, dt: number, sink: SimBroadcastSink) {
  if (room.status !== 'PLAYING') return;

  if (room.toastTimer > 0) {
    room.toastTimer -= dt;
    if (room.toastTimer <= 0) room.toast = null;
  }

  if (room.phase === 'CUTSCENE') {
    room.cutsceneTimer -= dt;
    if (room.cutsceneTimer <= 0) {
      room.phase = 'LIVE';
      if (room.pendingUlti) {
        const u = room.pendingUlti;
        room.pendingUlti = null;
        const targetGoalX = u.team === 'BLUE' ? SIM_PITCH_HALF_LENGTH + 1.5 : -SIM_PITCH_HALF_LENGTH - 1.5;
        const targetZ = (Math.random() - 0.5) * 3.6;
        const dx = targetGoalX - u.fromX;
        const dz = targetZ - u.fromZ;
        const dist = Math.hypot(dx, dz) || 1;
        let spd = u.speed;
        if (u.range === 'MIDFIELD' && dist > SIM_PITCH_HALF_LENGTH + 14) {
          spd = Math.min(spd, 48);
        }
        room.ball.x = u.fromX;
        room.ball.y = u.fromY;
        room.ball.z = u.fromZ;
        room.ball.vx = (dx / dist) * spd;
        room.ball.vy = u.loft;
        room.ball.vz = (dz / dist) * spd;
        room.ball.curve = 0;
        room.ball.topspin = 0.25;
        room.ball.ownerId = null;
        room.ball.isUlti = true;
        room.ball.lastTouchActorId = u.actorId;
        room.ball.lastTouchTeam = u.team;
        const ultiActor = room.actors.find((o) => o.id === u.actorId);
        room.ball.lastTouchName = ultiActor?.name ?? STYLES[u.styleId].name;
        sink.broadcastSound('KICK', 1.0);
      }
    }
    return;
  }

  if (room.phase === 'GOAL_CELEBRATION') {
    room.goalTimer -= dt;
    for (const a of room.actors) {
      a.vx *= Math.exp(-5 * dt);
      a.vz *= Math.exp(-5 * dt);
      a.emoteTimer = Math.max(0, a.emoteTimer - dt);
      a.actionTimer = Math.max(0, a.actionTimer - dt);
      if (a.emoteTimer === 0) a.emote = null;
      if (a.actionTimer === 0) a.actionAnim = 'NONE';
    }
    if (room.goalTimer <= 0) {
      const scoringTeam = room.goalBanner?.team ?? null;
      room.goalBanner = null;
      resetSimKickoff(room);
      room.kickoffLockTeam = scoringTeam;
      room.kickoffLockTimer = scoringTeam ? 3.0 : 0;
      room.phase = 'LIVE';
      sink.broadcastSound('WHISTLE');
    }
    return;
  }

  if (room.phase === 'SET_PIECE') {
    stepSimSetPiece(room, dt, sink);
    return;
  }

  if (room.phase !== 'LIVE') return;

  room.timeRemaining = Math.max(0, room.timeRemaining - dt);
  if (room.timeRemaining <= 0) {
    room.phase = 'ENDED';
    sink.broadcastSound('WHISTLE');
    return;
  }

  if (room.kickoffLockTimer > 0) {
    room.kickoffLockTimer = Math.max(0, room.kickoffLockTimer - dt);
    if (room.kickoffLockTimer <= 0) room.kickoffLockTeam = null;
  }

  room.duoComboCd = Math.max(0, room.duoComboCd - dt);
  room.aiDuoCooldown = Math.max(0, room.aiDuoCooldown - dt);
  if (room.duoPass?.active) {
    room.duoPass.timer -= dt;
    room.duoPass.autoTriggerTimer -= dt;
    if (room.duoPass.timer <= 0) {
      room.duoPass = null;
    } else if (room.duoPass.autoTriggerTimer <= 0) {
      const passer = room.actors.find((o) => o.id === room.duoPass?.passerId);
      const receiver = room.actors.find((o) => o.id === room.duoPass?.receiverId);
      if (passer && receiver && !receiver.clientId && Math.hypot(room.ball.x - receiver.x, room.ball.z - receiver.z) < 8.5) {
        triggerSimMusabMusaCombo(room, passer, receiver, sink);
        return;
      }
    }
  }

  for (const a of room.actors) {
    a.stun = Math.max(0, a.stun - dt);
    a.slide = Math.max(0, a.slide - dt);
    a.dribble = Math.max(0, a.dribble - dt);
    a.stealCd = Math.max(0, a.stealCd - dt);
    a.skill1Cd = Math.max(0, a.skill1Cd - dt);
    a.skill2Cd = Math.max(0, a.skill2Cd - dt);
    a.personalCd = Math.max(0, a.personalCd - dt);
    a.dribbleCd = Math.max(0, a.dribbleCd - dt);
    a.slideCd = Math.max(0, a.slideCd - dt);
    a.speedBoost = Math.max(0, a.speedBoost - dt);
    a.wallShield = Math.max(0, a.wallShield - dt);
    a.gkDiveCd = Math.max(0, a.gkDiveCd - dt);
    a.gkDiveTimer = Math.max(0, a.gkDiveTimer - dt);
    a.jumpCd = Math.max(0, a.jumpCd - dt);
    a.emoteTimer = Math.max(0, a.emoteTimer - dt);
    a.actionTimer = Math.max(0, a.actionTimer - dt);
    a.requestPassTimer = Math.max(0, a.requestPassTimer - dt);
    if (a.emoteTimer === 0) a.emote = null;
    if (a.actionTimer === 0) a.actionAnim = 'NONE';

    if (a.y > 0 || a.vy > 0) {
      a.vy -= 22.0 * dt;
      a.y += a.vy * dt;
      if (a.y <= 0) {
        a.y = 0;
        a.vy = 0;
      }
    }

    if (
      a.y > 0.25 &&
      !a.gkBallInHands &&
      !room.ball.ownerId &&
      a.stealCd <= 0 &&
      !(room.kickoffLockTeam === a.team && room.kickoffLockTimer > 0) &&
      Math.hypot(room.ball.x - a.x, room.ball.z - a.z) < 2.25 &&
      Math.abs(room.ball.y - (a.y + 1.55)) < 1.65
    ) {
      const canSaveUlti = a.isGoalkeeper && isInOwnPenaltyBox(a.team, a.x, a.z);
      if (room.ball.isUlti && !canSaveUlti) {
        if (a.team !== room.ball.lastTouchTeam) a.stun = 0.8;
      } else {
        if (room.kickoffLockTeam && a.team !== room.kickoffLockTeam) {
          room.kickoffLockTeam = null;
          room.kickoffLockTimer = 0;
        }
        const aimYaw = typeof a.input.aimYaw === 'number' ? a.input.aimYaw : a.yaw;
        const aimPitch = typeof a.input.aimPitch === 'number' ? a.input.aimPitch : 0.35;
        const upFactor = clampVal((0.28 - aimPitch) / 0.83, 0, 1);
        const headerSpeed = 30 + (STYLES[a.styleId].stats.shotPower / 100) * 10;
        room.ball.ownerId = null;
        room.duoPass = null;
        room.ball.isUlti = false;
        room.ball.lastTouchActorId = a.id;
        room.ball.lastTouchTeam = a.team;
        room.ball.lastTouchName = a.name || STYLES[a.styleId].name;
        a.stealCd = 0.45;
        a.actionAnim = 'HEADER';
        a.actionTimer = 0.42;
        room.ball.vx = Math.cos(aimYaw) * headerSpeed;
        room.ball.vz = -Math.sin(aimYaw) * headerSpeed;
        room.ball.vy = 2.8 + upFactor * 11.5;
        room.ball.curve = 0;
        room.ball.topspin = 0.2;
        a.awakening = Math.min(100, a.awakening + 8);
        sink.broadcastSound('KICK', 0.85);
      }
    }

    if (a.gkBallInHands) {
      if (room.ball.ownerId !== a.id) {
        a.gkBallInHands = false;
        a.gkHoldTimer = 0;
      } else {
        a.gkHoldTimer = Math.max(0, a.gkHoldTimer - dt);
        const insideBox = isInOwnPenaltyBox(a.team, a.x, a.z);
        if (!insideBox) {
          a.gkBallInHands = false;
          a.gkHoldTimer = 0;
        } else if (a.gkHoldTimer <= 0) {
          a.gkBallInHands = false;
          room.ball.ownerId = null;
          a.stealCd = 0.6;
          const outDir = a.team === 'BLUE' ? 1 : -1;
          room.ball.vx = outDir * 30;
          room.ball.vy = 6.5;
          room.ball.vz = (Math.random() - 0.5) * 10;
          sink.broadcastSound('KICK', 0.75);
        }
      }
    }

    if (a.awakened) {
      a.awakeningLeft -= dt;
      if (a.awakeningLeft <= 0) {
        a.awakened = false;
        a.awakeningLeft = 0;
        a.ultiUsed = false;
      }
    } else {
      a.awakening = Math.min(100, a.awakening + dt * (100 / 60));
    }

    if (a.stun > 0) {
      a.vx *= Math.exp(-8 * dt);
      a.vz *= Math.exp(-8 * dt);
      a.x += a.vx * dt;
      a.z += a.vz * dt;
      continue;
    }

    if (a.gkDiveTimer > 0) {
      if (!isInOwnPenaltyBox(a.team, a.x, a.z)) {
        a.gkDiveTimer = 0;
      } else {
        a.x = clampVal(a.x + a.vx * dt, -SIM_PITCH_HALF_LENGTH - 1.5, SIM_PITCH_HALF_LENGTH + 1.5);
        a.z = clampVal(a.z + a.vz * dt, -SIM_PITCH_HALF_WIDTH - 1.5, SIM_PITCH_HALF_WIDTH + 1.5);
        a.vx *= Math.exp(-3.4 * dt);
        a.vz *= Math.exp(-3.4 * dt);
        if (!room.ball.ownerId && Math.hypot(room.ball.x - a.x, room.ball.z - a.z) < 2.8 && room.ball.y < 3.6) {
          room.ball.ownerId = a.id;
          room.ball.isUlti = false;
          room.duoPass = null;
          a.gkBallInHands = true;
          a.gkHoldTimer = 6.0;
          sink.broadcastSound('KICK', 0.68);
        }
        continue;
      }
    }

    if (a.slide > 0) {
      a.x += a.vx * dt;
      a.z += a.vz * dt;
      a.vx *= Math.exp(-3.8 * dt);
      a.vz *= Math.exp(-3.8 * dt);
      a.x = clampVal(a.x, -SIM_PITCH_HALF_LENGTH - 1.5, SIM_PITCH_HALF_LENGTH + 1.5);
      a.z = clampVal(a.z, -SIM_PITCH_HALF_WIDTH - 1.5, SIM_PITCH_HALF_WIDTH + 1.5);
      if (room.ball.ownerId) {
        const owner = room.actors.find((o) => o.id === room.ball.ownerId);
        if (owner && !owner.gkBallInHands && owner.team !== a.team && Math.hypot(owner.x - a.x, owner.z - a.z) < (a.awakened ? 3.2 : 2.6)) {
          stealBallSim(room, a, owner, sink, a.awakened);
        }
      }
      continue;
    }

    if (a.clientId) {
      if (a.shotCharging && room.ball.ownerId === a.id) {
        a.shotCharge = Math.min(1, a.shotCharge + dt * 1.45);
      }
      const style = STYLES[a.styleId];
      const flow = FLOWS[a.flowId];
      const roleMeta = ROLES[a.role];
      const len = Math.hypot(a.input.moveX, a.input.moveZ);
      const isMoving = len > 0.05;
      const wantsSprint = a.input.sprint && isMoving && a.stamina > 2;
      if (wantsSprint) a.stamina = Math.max(0, a.stamina - dt * 22);
      else a.stamina = Math.min(100, a.stamina + dt * 15 * flow.staminaRegenMult * roleMeta.staminaRegenMult);

      const baseSpeed = (9.5 + (style.stats.speed / 100) * 5.2) * roleMeta.speedMult;
      const maxSpeed =
        baseSpeed *
        (wantsSprint ? 1.38 : 1.0) *
        (a.awakened ? flow.speedMult * 1.12 : 1.0) *
        (a.speedBoost > 0 ? 1.32 : 1.0) *
        (room.ball.ownerId === a.id ? 0.94 : 1.0);

      if (isMoving) {
        const nx = a.input.moveX / len;
        const nz = a.input.moveZ / len;
        a.vx += (nx * maxSpeed - a.vx) * Math.min(1, 12 * dt);
        a.vz += (nz * maxSpeed - a.vz) * Math.min(1, 12 * dt);
        if (a.input.lockYaw && typeof a.input.aimYaw === 'number') {
          a.yaw = a.input.aimYaw;
        } else {
          a.yaw = Math.atan2(-nz, nx);
        }
      } else {
        a.vx *= Math.exp(-12 * dt);
        a.vz *= Math.exp(-12 * dt);
        if (a.input.lockYaw && typeof a.input.aimYaw === 'number') {
          a.yaw = a.input.aimYaw;
        }
      }
      a.x = clampVal(a.x + a.vx * dt, -SIM_PITCH_HALF_LENGTH - 1.5, SIM_PITCH_HALF_LENGTH + 1.5);
      a.z = clampVal(a.z + a.vz * dt, -SIM_PITCH_HALF_WIDTH - 1.5, SIM_PITCH_HALF_WIDTH + 1.5);
    } else if (a.isGoalkeeper) {
      const diffCfg =
        room.gkDifficulty === 'EASY'
          ? { speed: 6.0, reach: 1.4, saveChance: 0.48, parryChance: 0.2 }
          : room.gkDifficulty === 'HARD'
            ? { speed: 13.8, reach: 2.45, saveChance: 0.92, parryChance: 0.65 }
            : { speed: 9.6, reach: 1.92, saveChance: 0.72, parryChance: 0.42 };

      const gx = a.team === 'BLUE' ? -SIM_PITCH_HALF_LENGTH + 4.0 : SIM_PITCH_HALF_LENGTH - 4.0;
      const tz = clampVal(room.ball.z * 0.78, -SIM_GOAL_HALF_WIDTH + 0.6, SIM_GOAL_HALF_WIDTH - 0.6);
      const dz = tz - a.z;
      const dx = gx - a.x;
      const dist = Math.hypot(dx, dz);
      if (dist > 0.08) {
        const step = Math.min(dist, diffCfg.speed * dt);
        a.x += (dx / dist) * step;
        a.z += (dz / dist) * step;
      }
      a.yaw = a.team === 'BLUE' ? 0 : Math.PI;

      if (room.ball.ownerId === a.id) {
        room.ball.ownerId = null;
        a.stealCd = 0.7;
        const dirX = a.team === 'BLUE' ? 1 : -1;
        room.ball.vx = dirX * 28;
        room.ball.vy = 5.0;
        room.ball.vz = (Math.random() - 0.5) * 14;
        room.ball.curve = 0;
        sink.broadcastSound('KICK', 0.7);
      } else if (
        !room.ball.ownerId &&
        isInOwnPenaltyBox(a.team, a.x, a.z) &&
        Math.hypot(room.ball.x - a.x, room.ball.z - a.z) < diffCfg.reach &&
        room.ball.y < 3.6
      ) {
        const ballSpeed = Math.hypot(room.ball.vx, room.ball.vz);
        const ultiSaveChance = room.gkDifficulty === 'HARD' ? 0.72 : room.gkDifficulty === 'MEDIUM' ? 0.48 : 0.28;
        if (room.ball.isUlti && Math.random() > ultiSaveChance) {
          a.stun = 0.85;
        } else if (Math.random() < diffCfg.saveChance || room.ball.isUlti) {
          room.ball.isUlti = false;
          if (ballSpeed > 32 && Math.random() < diffCfg.parryChance) {
            const outDir = a.team === 'BLUE' ? 1 : -1;
            room.ball.vx = outDir * 14;
            room.ball.vy = 4.2;
            room.ball.vz = (room.ball.z >= 0 ? 1 : -1) * 11;
            room.toast = 'Kaleciden Kritik Çelme!';
            room.toastTimer = 1.4;
          } else {
            room.ball.ownerId = a.id;
            room.toast = 'Kaleci Kurtardı!';
            room.toastTimer = 1.4;
          }
          sink.broadcastSound('KICK', 0.65);
        }
      }
    } else {
      const style = STYLES[a.styleId];
      const speed = 7.4 + (style.stats.speed / 100) * 3.8;
      const attackDir = a.team === 'BLUE' ? 1 : -1;
      const goalX = attackDir * SIM_PITCH_HALF_LENGTH;
      const owner = room.ball.ownerId ? room.actors.find((o) => o.id === room.ball.ownerId) : undefined;

      // Pairwise separation force so AI bots NEVER bunch up like a train or crowd teammates
      let sepX = 0;
      let sepZ = 0;
      for (const other of room.actors) {
        if (other.id === a.id || other.isGoalkeeper) continue;
        const rx = a.x - other.x;
        const rz = a.z - other.z;
        const rdist = Math.hypot(rx, rz);
        const minSpace = other.team === a.team ? 5.2 : 2.8;
        if (rdist > 0.001 && rdist < minSpace) {
          const push = ((minSpace - rdist) / minSpace) * speed * 1.35;
          sepX += (rx / rdist) * push;
          sepZ += (rz / rdist) * push;
        }
      }

      if (owner && owner.id === a.id) {
        // AI Musab -> Human Musa: Uzak mesafe havadan özel Roveşata pası gönder! (20s CD)
        if (a.styleId === 'musab' && !room.duoPass && room.aiDuoCooldown <= 0 && room.duoComboCd <= 0) {
          const musaHuman = room.actors.find(
            (m) => m.team === a.team && !m.isGoalkeeper && m.styleId === 'musa' && m.clientId && m.stun <= 0
          );
          if (musaHuman && Math.hypot(musaHuman.x - a.x, musaHuman.z - a.z) >= 8) {
            launchSimDuoPass(room, a, musaHuman, sink);
            room.toast = `${a.name} UZAKTAN HAVADAN PAS ATTI — ROVEŞATA İÇİN [E]'YE BAS!!`;
            room.toastTimer = 2.5;
            continue;
          }
        }

        // AI has the ball: evade closest defender, look for open pass (prefer human!), or shoot on goal
        let nearestDef: SimActor | null = null;
        let nearestDefDist = Infinity;
        for (const opp of room.actors) {
          if (opp.team !== a.team && !opp.isGoalkeeper) {
            const d = Math.hypot(opp.x - a.x, opp.z - a.z);
            if (d < nearestDefDist) {
              nearestDefDist = d;
              nearestDef = opp;
            }
          }
        }

        // Honor teammate pass requests immediately!
        let requester: SimActor | null = null;
        for (const mate of room.actors) {
          if (mate.team === a.team && mate.id !== a.id && !mate.isGoalkeeper && mate.stun <= 0 && mate.requestPassTimer > 0) {
            requester = mate;
            break;
          }
        }

        // Consider passing to a better-positioned teammate (preferring human teammates)
        let bestMate: SimActor | null = requester;
        let bestMateScore = requester ? 999 : -Infinity;
        if (!requester) {
          for (const mate of room.actors) {
            if (mate.team === a.team && mate.id !== a.id && !mate.isGoalkeeper && mate.stun <= 0) {
              const d = Math.hypot(mate.x - a.x, mate.z - a.z);
              if (d < 4 || d > 38) continue;
              const forwardGain = (mate.x - a.x) * attackDir;
              const score = forwardGain * 1.1 + (mate.clientId ? 7 : 0) - d * 0.25;
              if (score > bestMateScore) {
                bestMateScore = score;
                bestMate = mate;
              }
            }
          }
        }

        const shouldPass =
          Boolean(requester) ||
          (bestMate &&
            ((nearestDefDist < 4.8 && Math.random() < dt * 3.5) ||
              (bestMateScore > 8 && Math.random() < dt * 0.9)));

        if (shouldPass && bestMate) {
          if (requester) requester.requestPassTimer = 0;
          const pdx = bestMate.x - room.ball.x;
          const pdz = bestMate.z - room.ball.z;
          const pdist = Math.hypot(pdx, pdz) || 1;
          const pspd = clampVal(pdist * 1.45, 17, 34);
          room.ball.ownerId = null;
          room.ball.lastTouchActorId = a.id;
          room.ball.lastTouchTeam = a.team;
          room.ball.lastTouchName = a.name || style.name;
          a.stealCd = 0.55;
          a.actionAnim = 'KICK';
          a.actionTimer = 0.34;
          room.ball.vx = (pdx / pdist) * pspd;
          room.ball.vy = pdist > 22 ? 3.8 : 2.2;
          room.ball.vz = (pdz / pdist) * pspd;
          room.ball.curve = 0;
          room.ball.topspin = 0.1;
          sink.broadcastSound('KICK', 0.55);
        } else if (Math.abs(goalX - a.x) < 38 && Math.random() < dt * 1.7) {
          const cornerZ = (a.z >= 0 ? -1 : 1) * (SIM_GOAL_HALF_WIDTH - 1.1) + (Math.random() - 0.5) * 1.4;
          const sx = goalX - a.x;
          const sz = cornerZ - a.z;
          const slen = Math.hypot(sx, sz) || 1;
          room.ball.ownerId = null;
          room.ball.lastTouchActorId = a.id;
          room.ball.lastTouchTeam = a.team;
          room.ball.lastTouchName = a.name || style.name;
          a.stealCd = 0.6;
          a.actionAnim = 'KICK';
          a.actionTimer = 0.42;
          room.ball.vx = (sx / slen) * 38;
          room.ball.vy = 3.6;
          room.ball.vz = (sz / slen) * 38;
          room.ball.curve = (a.z > 0 ? -0.35 : 0.35);
          sink.broadcastSound('KICK', 0.82);
        } else {
          let dx = goalX - a.x;
          let dz = -a.z * 0.35;
          if (nearestDef && nearestDefDist < 7.0) {
            // Subtle lateral dodge away from defender
            const dodgeSign = a.z - nearestDef.z >= 0 ? 1 : -1;
            dz += dodgeSign * 6.5;
          }
          const len = Math.hypot(dx, dz) || 1;
          const desVx = (dx / len) * speed * 0.92 + sepX * 0.25;
          const desVz = (dz / len) * speed * 0.92 + sepZ * 0.25;
          a.vx += (desVx - a.vx) * Math.min(1, 10 * dt);
          a.vz += (desVz - a.vz) * Math.min(1, 10 * dt);
          a.yaw = Math.atan2(-a.vz, a.vx);
          a.x += a.vx * dt;
          a.z += a.vz * dt;
        }
      } else {
        let tx: number;
        let tz: number;
        let isDesignatedPresser = false;

        if (owner && owner.gkBallInHands && owner.team !== a.team) {
          // Kaleci topu eline aldığında tüm botlar ceza sahası dışına çekilir!
          const backX = owner.team === 'BLUE' ? -52 : 52;
          tx = backX;
          tz = clampVal(a.homeZ, -SIM_PITCH_HALF_WIDTH + 5, SIM_PITCH_HALF_WIDTH - 5);
        } else if (owner && owner.team === a.team) {
          // Teammate (e.g. human player!) has the ball -> spread out & make an open attacking run!
          const spreadSide = Math.abs(a.homeZ) > 3 ? Math.sign(a.homeZ) : owner.z >= 0 ? -1 : 1;
          const laneZ = Math.abs(owner.z - a.homeZ) < 9 ? spreadSide * 24 : a.homeZ * 1.2;
          tx = clampVal(owner.x + attackDir * 16 + a.homeX * 0.12, -SIM_PITCH_HALF_LENGTH + 7, SIM_PITCH_HALF_LENGTH - 7);
          tz = clampVal(laneZ, -SIM_PITCH_HALF_WIDTH + 3.5, SIM_PITCH_HALF_WIDTH - 3.5);
        } else {
          // Opponent has ball or loose ball -> ONLY the closest teammate presses; others hold zones!
          const myDist = Math.hypot(room.ball.x - a.x, room.ball.z - a.z);
          let closerTeammateExists = false;
          for (const mate of room.actors) {
            if (mate.id !== a.id && mate.team === a.team && !mate.isGoalkeeper && mate.stun <= 0) {
              const md = Math.hypot(room.ball.x - mate.x, room.ball.z - mate.z);
              if ((mate.clientId && md < 6.5) || md + (mate.clientId ? -1.5 : 0.4) < myDist) {
                closerTeammateExists = true;
                break;
              }
            }
          }

          if (!closerTeammateExists) {
            isDesignatedPresser = true;
            tx = room.ball.x;
            tz = room.ball.z;
          } else {
            tx = clampVal(a.homeX * 0.65 + room.ball.x * 0.42, -SIM_PITCH_HALF_LENGTH + 7, SIM_PITCH_HALF_LENGTH - 7);
            tz = clampVal(a.homeZ * 0.8 + room.ball.z * 0.25, -SIM_PITCH_HALF_WIDTH + 3.5, SIM_PITCH_HALF_WIDTH - 3.5);
          }
        }

        const dx = tx - a.x;
        const dz = tz - a.z;
        const distTarget = Math.hypot(dx, dz);
        let desVx = sepX;
        let desVz = sepZ;
        if (distTarget > 0.8) {
          const moveScale = isDesignatedPresser ? speed : clampVal(distTarget * 0.9, 2.5, speed * 0.88);
          desVx += (dx / distTarget) * moveScale;
          desVz += (dz / distTarget) * moveScale;
        }
        const totalMag = Math.hypot(desVx, desVz);
        if (totalMag > speed) {
          desVx = (desVx / totalMag) * speed;
          desVz = (desVz / totalMag) * speed;
        }
        a.vx += (desVx - a.vx) * Math.min(1, 9 * dt);
        a.vz += (desVz - a.vz) * Math.min(1, 9 * dt);
        a.x += a.vx * dt;
        a.z += a.vz * dt;

        if (Math.hypot(a.vx, a.vz) > 0.8) {
          a.yaw = Math.atan2(-a.vz, a.vx);
        } else {
          a.yaw = Math.atan2(-(room.ball.z - a.z), room.ball.x - a.x);
        }

        if (owner && !owner.gkBallInHands && owner.team !== a.team && a.stealCd <= 0 && Math.random() < dt * 2.2) {
          if (Math.hypot(owner.x - a.x, owner.z - a.z) < 1.85) {
            stealBallSim(room, a, owner, sink);
          }
        }
      }
      a.x = clampVal(a.x, -SIM_PITCH_HALF_LENGTH - 1.5, SIM_PITCH_HALF_LENGTH + 1.5);
      a.z = clampVal(a.z, -SIM_PITCH_HALF_WIDTH - 1.5, SIM_PITCH_HALF_WIDTH + 1.5);
    }

    if (room.kickoffLockTimer > 0 && a.team === room.kickoffLockTeam) {
      if (a.team === 'BLUE' && a.x > -3.5) {
        a.x = -3.5;
        if (a.vx > 0) a.vx = 0;
      } else if (a.team === 'RED' && a.x < 3.5) {
        a.x = 3.5;
        if (a.vx < 0) a.vx = 0;
      }
    }
  }

  const b = room.ball;
  if (b.ownerId) {
    const owner = room.actors.find((o) => o.id === b.ownerId);
    if (owner) {
      const dist = owner.gkBallInHands ? 0.72 : 0.95;
      b.x = owner.x + Math.cos(owner.yaw) * dist;
      b.y = owner.gkBallInHands ? 1.24 : 0.36;
      b.z = owner.z - Math.sin(owner.yaw) * dist;
      b.vx = owner.vx;
      b.vy = 0;
      b.vz = owner.vz;
    } else {
      b.ownerId = null;
    }
  } else {
    const grav = b.isUlti ? 5.6 + b.topspin * 2.0 : 17.5 + b.topspin * 8.0;
    b.vy -= grav * dt;
    if (Math.abs(b.curve) > 0.01) {
      const hl = Math.hypot(b.vx, b.vz);
      if (hl > 3) {
        const px = -b.vz / hl;
        const pz = b.vx / hl;
        b.vx += px * b.curve * 12 * dt;
        b.vz += pz * b.curve * 12 * dt;
      }
      b.curve *= Math.exp(-1.15 * dt);
    }
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.z += b.vz * dt;

    if (b.y < 0.36) {
      b.y = 0.36;
      b.vy = Math.abs(b.vy) > 1.8 ? -b.vy * 0.58 : 0;
      const fr = Math.exp(-(b.isUlti ? 0.45 : 1.55) * dt);
      b.vx *= fr;
      b.vz *= fr;
      b.curve *= Math.exp(-2 * dt);
      b.topspin *= Math.exp(-2 * dt);
    } else {
      const drag = Math.exp(-(b.isUlti ? 0.04 : 0.26) * dt);
      b.vx *= drag;
      b.vz *= drag;
    }

    const posts: Array<[number, number]> = [
      [-SIM_PITCH_HALF_LENGTH, -SIM_GOAL_HALF_WIDTH],
      [-SIM_PITCH_HALF_LENGTH, SIM_GOAL_HALF_WIDTH],
      [SIM_PITCH_HALF_LENGTH, -SIM_GOAL_HALF_WIDTH],
      [SIM_PITCH_HALF_LENGTH, SIM_GOAL_HALF_WIDTH],
    ];
    for (const [px, pz] of posts) {
      if (b.y < SIM_GOAL_HEIGHT + 0.25) {
        const dx = b.x - px;
        const dz = b.z - pz;
        const d = Math.hypot(dx, dz);
        if (d < 0.5 && d > 0.001) {
          const nx = dx / d;
          const nz = dz / d;
          b.x = px + nx * 0.52;
          b.z = pz + nz * 0.52;
          const dot = b.vx * nx + b.vz * nz;
          if (dot < 0) {
            b.vx = (b.vx - 2 * dot * nx) * 0.78;
            b.vz = (b.vz - 2 * dot * nz) * 0.78;
            sink.broadcastSound('POST_CLANG');
          }
        }
      }
    }

    if (Math.abs(b.z) < SIM_GOAL_HALF_WIDTH - 0.25 && b.y < SIM_GOAL_HEIGHT) {
      const triggerGoal = (scoringTeam: 'BLUE' | 'RED') => {
        if (scoringTeam === 'BLUE') room.blueScore++;
        else room.redScore++;

        const emoteSpec = EMOTE_LIST[Math.floor(Math.random() * EMOTE_LIST.length)];
        let scorer =
          (b.lastTouchActorId ? room.actors.find((o) => o.id === b.lastTouchActorId) : undefined) ??
          room.actors.find((o) => o.team === scoringTeam && !o.isGoalkeeper);
        if (scorer && scorer.team !== scoringTeam) {
          scorer = room.actors.find((o) => o.team === scoringTeam && !o.isGoalkeeper) ?? scorer;
        }
        if (scorer) {
          scorer.emote = emoteSpec.id;
          scorer.emoteTimer = 2.6;
        }

        room.phase = 'GOAL_CELEBRATION';
        room.goalTimer = 2.6;
        room.goalBanner = {
          scorerId: scorer?.id ?? null,
          scorerName: scorer?.name ?? b.lastTouchName,
          scorerStyleId: scorer?.styleId,
          team: scoringTeam,
          isUltiGoal: b.isUlti,
          emote: emoteSpec.id,
        };
        b.isUlti = false;
        sink.broadcastSound('GOAL');
      };

      if (b.x >= SIM_PITCH_HALF_LENGTH) {
        triggerGoal('BLUE');
        return;
      }
      if (b.x <= -SIM_PITCH_HALF_LENGTH) {
        triggerGoal('RED');
        return;
      }
    }

    if (Math.abs(b.z) > SIM_PITCH_HALF_WIDTH) {
      const throwTeam: 'BLUE' | 'RED' = b.lastTouchTeam === 'BLUE' ? 'RED' : 'BLUE';
      const sx = clampVal(b.x, -SIM_PITCH_HALF_LENGTH + 2, SIM_PITCH_HALF_LENGTH - 2);
      const sz = Math.sign(b.z) * SIM_PITCH_HALF_WIDTH;
      triggerSimSetPiece(room, 'THROW_IN', throwTeam, sx, sz, sink);
      return;
    }
    if (Math.abs(b.x) > SIM_PITCH_HALF_LENGTH) {
      if (Math.abs(b.z) >= SIM_GOAL_HALF_WIDTH - 0.25 || b.y >= SIM_GOAL_HEIGHT) {
        const defTeam: 'BLUE' | 'RED' = b.x > 0 ? 'RED' : 'BLUE';
        const attTeam: 'BLUE' | 'RED' = defTeam === 'RED' ? 'BLUE' : 'RED';
        if (b.lastTouchTeam === defTeam) {
          const cx = Math.sign(b.x) * (SIM_PITCH_HALF_LENGTH - 0.5);
          const cz = (b.z >= 0 ? 1 : -1) * (SIM_PITCH_HALF_WIDTH - 0.5);
          triggerSimSetPiece(room, 'CORNER', attTeam, cx, cz, sink);
        } else {
          triggerSimAutGoalKick(room, defTeam, sink);
        }
        return;
      }
    }

    if (b.y < 2.2) {
      for (const a of room.actors) {
        if (a.stealCd > 0 || a.stun > 0) continue;
        if (room.kickoffLockTeam === a.team && room.kickoffLockTimer > 0) continue;
        // AI bot GK has its own save logic above; human GK catches cleanly inside box or close touch
        if (a.isGoalkeeper && !a.clientId) continue;
        const inOwnBox = a.isGoalkeeper && isInOwnPenaltyBox(a.team, a.x, a.z);
        const pickupRadius = inOwnBox ? 1.85 : 1.45;
        if (Math.hypot(a.x - b.x, a.z - b.z) < pickupRadius && (inOwnBox || b.y < 1.85)) {
          if (b.isUlti && !inOwnBox) {
            if (a.team !== b.lastTouchTeam) a.stun = 0.85;
            continue;
          }
          if (room.duoPass?.active && b.y > 0.95 && !a.isGoalkeeper) {
            const passer = room.actors.find((o) => o.id === room.duoPass?.passerId);
            if (passer && a.team !== passer.team) continue;
          }
          if (room.kickoffLockTeam && a.team !== room.kickoffLockTeam) {
            room.kickoffLockTeam = null;
            room.kickoffLockTimer = 0;
          }
          b.ownerId = a.id;
          if (inOwnBox) {
            a.gkBallInHands = true;
            a.gkHoldTimer = 6.0;
            room.toast = `${a.name}: Topu aldı`;
            room.toastTimer = 1.4;
          }
          if (room.duoPass?.active && a.id !== room.duoPass.receiverId) {
            room.duoPass = null;
          }
          b.isUlti = false;
          b.lastTouchActorId = a.id;
          b.lastTouchTeam = a.team;
          b.lastTouchName = a.name || STYLES[a.styleId].name;
          break;
        }
      }
    }
  }
}

export function buildSimWorldSnapshot(room: SimRoomState, clientId: string): NetWorldSnapshot {
  const self = getSimActorByClient(room, clientId);
  const actors: NetActorState[] = room.actors.map((a) => ({
    id: a.id,
    clientId: a.clientId,
    name: a.name,
    team: a.team,
    styleId: a.styleId,
    role: a.role,
    isGoalkeeper: a.isGoalkeeper,
    gkBallInHands: a.gkBallInHands,
    x: Number(a.x.toFixed(2)),
    y: Number(a.y.toFixed(2)),
    z: Number(a.z.toFixed(2)),
    vx: Number(a.vx.toFixed(2)),
    vz: Number(a.vz.toFixed(2)),
    yaw: Number(a.yaw.toFixed(3)),
    stun: Number(a.stun.toFixed(2)),
    slide: Number(a.slide.toFixed(2)),
    dribble: Number(a.dribble.toFixed(2)),
    awakened: a.awakened,
    emote: a.emote,
    emoteTimer: Number(a.emoteTimer.toFixed(2)),
    actionAnim: a.actionAnim,
    actionTimer: Number(a.actionTimer.toFixed(2)),
    wallShield: Number(a.wallShield.toFixed(2)),
    requestPassTimer: Number(a.requestPassTimer.toFixed(2)),
  }));

  let duoComboPrompt: NetWorldSnapshot['duoComboPrompt'] = null;
  if (self) {
    if (room.duoPass?.active && (room.duoPass.receiverId === self.id || room.duoPass.passerId === self.id)) {
      const isReceiver = room.duoPass.receiverId === self.id;
      duoComboPrompt = {
        active: true,
        role: isReceiver ? 'RECEIVER' : 'PASSER',
        title: isReceiver ? "MUSAB'DAN HAVADAN PAS!" : 'MUSA ROVEŞATA BEKLİYOR!',
        subtitle: isReceiver ? "[E]'YE BAS — İKİZ ROVEŞATA!" : 'MUSA [E] İLE ROVEŞATA VURUYOR!',
        timeLeft: Number(Math.max(0, room.duoPass.timer).toFixed(1)),
        cooldownLeft: Number(room.duoComboCd.toFixed(1)),
      };
    } else if (
      self.styleId === 'musab' &&
      room.ball.ownerId === self.id &&
      room.actors.some((o) => o.team === self.team && !o.isGoalkeeper && o.styleId === 'musa')
    ) {
      duoComboPrompt = {
        active: room.duoComboCd <= 0,
        role: 'PASSER',
        title: 'MUSAB × MUSA PAS',
        subtitle:
          room.duoComboCd <= 0
            ? "[E] İLE MUSA'YA HAVADAN PAS AT!"
            : `Bekleme: ${Math.ceil(room.duoComboCd)}s`,
        timeLeft: 0,
        cooldownLeft: Number(room.duoComboCd.toFixed(1)),
      };
    }
  }

  return {
    seq: room.worldSeq,
    phase: room.phase,
    blueScore: room.blueScore,
    redScore: room.redScore,
    timeRemaining: Math.ceil(room.timeRemaining),
    gkDifficulty: room.gkDifficulty,
    matchMode: room.matchMode,
    kickoffLockLeft:
      room.kickoffLockTimer > 0 && self && room.kickoffLockTeam === self.team
        ? Number(room.kickoffLockTimer.toFixed(1))
        : 0,
    ball: {
      x: Number(room.ball.x.toFixed(2)),
      y: Number(room.ball.y.toFixed(2)),
      z: Number(room.ball.z.toFixed(2)),
      vx: Number(room.ball.vx.toFixed(2)),
      vy: Number(room.ball.vy.toFixed(2)),
      vz: Number(room.ball.vz.toFixed(2)),
      ownerId: room.ball.ownerId,
      isUlti: room.ball.isUlti,
    },
    actors,
    selfHud: self
      ? {
          stamina: Math.round(self.stamina),
          awakening: Math.round(self.awakening),
          isAwakened: self.awakened,
          awakeningTimeLeft: Number(Math.max(0, self.awakeningLeft).toFixed(1)),
          ultiUsedInAwakening: self.ultiUsed,
          shotCharge: Number(self.shotCharge.toFixed(2)),
          skill1Cd: Number(self.skill1Cd.toFixed(1)),
          skill2Cd: Number(self.skill2Cd.toFixed(1)),
          personalCd: Number(self.personalCd.toFixed(1)),
          dribbleCd: Number(self.dribbleCd.toFixed(1)),
          slideCd: Number(self.slideCd.toFixed(1)),
          gkBallInHands: self.gkBallInHands,
          gkHoldLeft: Number(self.gkHoldTimer.toFixed(1)),
          gkDiveCd: Number(self.gkDiveCd.toFixed(1)),
          gkInBox: self.isGoalkeeper ? isInOwnPenaltyBox(self.team, self.x, self.z) : false,
        }
      : undefined,
    goalBanner: room.goalBanner,
    duoComboPrompt,
    setPiece: room.setPiece
      ? {
          kind: room.setPiece.kind,
          team: room.setPiece.team,
          takerName: room.actors.find((a) => a.id === room.setPiece!.takerId)?.name ?? 'OYUNCU',
          isUserTaker: Boolean(self && room.setPiece.takerId === self.id),
          timeLeft: Number(Math.max(0, room.setPiece.timer).toFixed(1)),
        }
      : null,
    toast: room.toast,
  };
}
