import type { VoicePeerState, VoiceSignalPayload } from '../types/game';

const VOICE_ICE_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' },
  ],
};

interface PeerAudioConn {
  pc: RTCPeerConnection;
  audioEl: HTMLAudioElement;
  pendingIce: RTCIceCandidateInit[];
  remoteSet: boolean;
}

export class VoiceChatManager {
  private selfId: string | null = null;
  private localStream: MediaStream | null = null;
  private peers = new Map<string, PeerAudioConn>();
  private joined = false;
  private muted = false;
  private deafened = false;
  private speaking = false;

  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private analyserData: Uint8Array<ArrayBuffer> | null = null;
  private meterTimer: number | null = null;

  private sendSignal: (signal: Omit<VoiceSignalPayload, 'fromId'>) => void;
  private sendState: (patch: { muted?: boolean; speaking?: boolean }) => void;
  private onStatusChange?: (status: {
    joined: boolean;
    muted: boolean;
    deafened: boolean;
    speaking: boolean;
    error: string | null;
  }) => void;

  constructor(opts: {
    sendSignal: (signal: Omit<VoiceSignalPayload, 'fromId'>) => void;
    sendState: (patch: { muted?: boolean; speaking?: boolean }) => void;
    onStatusChange?: (status: {
      joined: boolean;
      muted: boolean;
      deafened: boolean;
      speaking: boolean;
      error: string | null;
    }) => void;
  }) {
    this.sendSignal = opts.sendSignal;
    this.sendState = opts.sendState;
    this.onStatusChange = opts.onStatusChange;
  }

  public setSelfId(id: string | null) {
    this.selfId = id;
  }

  private emitStatus(error: string | null = null) {
    this.onStatusChange?.({
      joined: this.joined,
      muted: this.muted,
      deafened: this.deafened,
      speaking: this.speaking,
      error,
    });
  }

  public async join(): Promise<boolean> {
    if (this.joined) return true;
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      this.emitStatus('Tarayıcı mikrofon API desteklemiyor.');
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      });
      this.localStream = stream;
      this.joined = true;
      this.muted = false;
      this.speaking = false;
      this.startSpeakingMonitor(stream);
      this.emitStatus(null);
      return true;
    } catch {
      this.emitStatus('Mikrofon izni reddedildi veya cihaz bulunamadı.');
      return false;
    }
  }

  public leave() {
    this.joined = false;
    this.speaking = false;
    this.stopSpeakingMonitor();
    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
    for (const [peerId, conn] of this.peers.entries()) {
      this.destroyPeer(peerId, conn);
    }
    this.peers.clear();
    this.emitStatus(null);
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach((t) => {
        t.enabled = !muted;
      });
    }
    if (muted && this.speaking) {
      this.speaking = false;
    }
    this.sendState({ muted, speaking: this.speaking });
    this.emitStatus(null);
  }

  public setDeafened(deafened: boolean) {
    this.deafened = deafened;
    for (const conn of this.peers.values()) {
      conn.audioEl.muted = deafened;
    }
    this.emitStatus(null);
  }

  public syncPeers(voicePeers: VoicePeerState[]) {
    if (!this.joined || !this.selfId) return;
    const activeIds = new Set(voicePeers.filter((p) => p.joined && p.clientId !== this.selfId).map((p) => p.clientId));

    // Close removed peers
    for (const [peerId, conn] of this.peers.entries()) {
      if (!activeIds.has(peerId)) {
        this.destroyPeer(peerId, conn);
        this.peers.delete(peerId);
      }
    }

    // Deterministic initiator tie-breaker: lexicographically smaller clientId sends the WebRTC offer
    for (const peerId of activeIds) {
      if (!this.peers.has(peerId)) {
        const isInitiator = this.selfId < peerId;
        this.createPeer(peerId, isInitiator);
      }
    }
  }

  public async handleSignal(signal: VoiceSignalPayload) {
    if (!this.joined || !this.selfId || signal.fromId === this.selfId) return;
    let conn = this.peers.get(signal.fromId);
    if (!conn) {
      conn = this.createPeer(signal.fromId, false);
    }
    if (!conn) return;

    try {
      if (signal.signalType === 'offer' && signal.sdp) {
        await conn.pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));
        conn.remoteSet = true;
        for (const c of conn.pendingIce) {
          await conn.pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => {});
        }
        conn.pendingIce = [];
        const answer = await conn.pc.createAnswer();
        await conn.pc.setLocalDescription(answer);
        if (conn.pc.localDescription) {
          this.sendSignal({
            targetId: signal.fromId,
            signalType: 'answer',
            sdp: conn.pc.localDescription.toJSON ? conn.pc.localDescription.toJSON() : conn.pc.localDescription,
          });
        }
      } else if (signal.signalType === 'answer' && signal.sdp) {
        await conn.pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));
        conn.remoteSet = true;
        for (const c of conn.pendingIce) {
          await conn.pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => {});
        }
        conn.pendingIce = [];
      } else if (signal.signalType === 'ice' && signal.candidate) {
        if (conn.remoteSet) {
          await conn.pc.addIceCandidate(new RTCIceCandidate(signal.candidate)).catch(() => {});
        } else {
          conn.pendingIce.push(signal.candidate);
        }
      }
    } catch {
      // Ignore transient WebRTC negotiation races
    }
  }

  private createPeer(peerId: string, isInitiator: boolean): PeerAudioConn | undefined {
    if (typeof RTCPeerConnection === 'undefined') return undefined;
    const pc = new RTCPeerConnection(VOICE_ICE_CONFIG);
    const audioEl = document.createElement('audio');
    audioEl.autoplay = true;
    audioEl.setAttribute('playsinline', 'true');
    audioEl.muted = this.deafened;
    audioEl.style.display = 'none';
    document.body.appendChild(audioEl);

    const conn: PeerAudioConn = {
      pc,
      audioEl,
      pendingIce: [],
      remoteSet: false,
    };
    this.peers.set(peerId, conn);

    if (this.localStream) {
      this.localStream.getAudioTracks().forEach((track) => {
        pc.addTrack(track, this.localStream!);
      });
    }

    pc.ontrack = (ev) => {
      const stream = ev.streams?.[0] ?? new MediaStream([ev.track]);
      audioEl.srcObject = stream;
      audioEl.play().catch(() => {});
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        this.sendSignal({
          targetId: peerId,
          signalType: 'ice',
          candidate: ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate,
        });
      }
    };

    if (isInitiator) {
      pc.createOffer()
        .then((offer) => pc.setLocalDescription(offer))
        .then(() => {
          if (pc.localDescription) {
            this.sendSignal({
              targetId: peerId,
              signalType: 'offer',
              sdp: pc.localDescription.toJSON ? pc.localDescription.toJSON() : pc.localDescription,
            });
          }
        })
        .catch(() => {});
    }

    return conn;
  }

  private destroyPeer(_peerId: string, conn: PeerAudioConn) {
    try {
      conn.pc.close();
    } catch {
      // ignore
    }
    try {
      conn.audioEl.srcObject = null;
      conn.audioEl.remove();
    } catch {
      // ignore
    }
  }

  private startSpeakingMonitor(stream: MediaStream) {
    this.stopSpeakingMonitor();
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      this.audioCtx = ctx;
      this.analyser = analyser;
      this.analyserData = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));

      this.meterTimer = window.setInterval(() => {
        if (!this.analyser || !this.analyserData || !this.joined) return;
        if (this.muted) {
          if (this.speaking) {
            this.speaking = false;
            this.sendState({ speaking: false });
            this.emitStatus(null);
          }
          return;
        }
        this.analyser.getByteFrequencyData(this.analyserData);
        let sum = 0;
        for (let i = 0; i < this.analyserData.length; i++) {
          sum += this.analyserData[i];
        }
        const avg = sum / Math.max(1, this.analyserData.length);
        const isNowSpeaking = avg > 14;
        if (isNowSpeaking !== this.speaking) {
          this.speaking = isNowSpeaking;
          this.sendState({ speaking: isNowSpeaking });
          this.emitStatus(null);
        }
      }, 140);
    } catch {
      // AudioContext meter optional
    }
  }

  private stopSpeakingMonitor() {
    if (this.meterTimer !== null) {
      clearInterval(this.meterTimer);
      this.meterTimer = null;
    }
    if (this.audioCtx) {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
    this.analyser = null;
    this.analyserData = null;
  }
}
